"""Who owns the app, shown on every screen. Change the name here (and in
TERMS OF USE.txt) and rebuild; nothing else needs editing."""
APP_NAME = "OptionIQ"
OWNER = "Quantum Nexus LLC."
YEAR = 2026
VERSION = "1.7"
# Where the app finds latest.json: the owner's public GitHub updates page.
# The app checks it for new versions (tracker/updates.py); empty turns that off.
UPDATE_URL = "https://raw.githubusercontent.com/skjaggi/optioniq-updates/main/latest.json"
# Bump when the Terms of Use change, so everyone is asked to agree again.
TERMS_VERSION = "2"


def notice() -> str:
    owner = OWNER if OWNER.endswith(".") else OWNER + "."
    return f"© {YEAR} {owner} All rights reserved."


def info() -> dict:
    return {"app": APP_NAME, "owner": OWNER, "year": YEAR, "version": VERSION,
            "notice": notice(), "termsVersion": TERMS_VERSION}
