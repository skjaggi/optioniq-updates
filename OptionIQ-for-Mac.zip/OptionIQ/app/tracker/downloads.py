"""Broker files the person has just downloaded.

"Get from Fidelity" opens the broker's download pages in the person's own
browser; they sign in and press Download there (OptionIQ never sees their
password). This finds the new files in their Downloads folder so the page
can open them without a file picker.
"""
from __future__ import annotations

import base64
import os
from pathlib import Path

# The broker pages "Get from …" may open, and nothing else.
BROKER_PAGES = {
    "Fidelity": [
        ("Positions", "https://digital.fidelity.com/ftgw/digital/portfolio/positions"),
        ("Activity & Orders", "https://digital.fidelity.com/ftgw/digital/portfolio/activity"),
    ],
}

SUFFIXES = {".csv", ".xlsx", ".xlsm", ".txt"}
MAX_BYTES = 20_000_000


def folders() -> list[Path]:
    """Where a browser saves downloads: Downloads, or OneDrive's copy of it."""
    home = Path.home()
    out = []
    for p in (home / "Downloads", home / "OneDrive" / "Downloads"):
        if p.is_dir() and p not in out:
            out.append(p)
    return out


def new_files(since: float, where: list[Path] | None = None) -> list[dict]:
    """Spreadsheet files saved after `since` (seconds since 1970), newest first.
    Files still being written (a browser's .crdownload/.part) are skipped."""
    found = []
    for folder in (where if where is not None else folders()):
        try:
            entries = list(os.scandir(folder))
        except OSError:
            continue
        for e in entries:
            p = Path(e.path)
            if not e.is_file() or p.suffix.lower() not in SUFFIXES:
                continue
            st = e.stat()
            if st.st_mtime <= since or st.st_size == 0 or st.st_size > MAX_BYTES:
                continue
            data = p.read_bytes()
            item = {"name": p.name, "modified": st.st_mtime}
            if p.suffix.lower() in (".xlsx", ".xlsm"):
                item["base64"] = base64.b64encode(data).decode()
            else:
                item["text"] = data.decode("utf-8-sig", errors="replace")
            found.append(item)
    found.sort(key=lambda x: x["modified"], reverse=True)
    return found


def pages(broker: str) -> list[tuple[str, str]]:
    if broker not in BROKER_PAGES:
        raise ValueError(f"OptionIQ can't get files from {broker} yet")
    return BROKER_PAGES[broker]
