"""New versions of OptionIQ, found and installed from inside the app.

The owner keeps three files in a shared OneDrive folder: `latest.json` (the
newest version number, what's new, and a link plus SHA-256 for each zip),
`OptionIQ.zip` and `OptionIQ for Mac.zip`. The link to latest.json is built
into the app (brand.UPDATE_URL).

At most once a day the app reads latest.json. When it names a newer version,
the page offers it. If the person clicks Update now, the app backs up their
data, downloads the zip, checks its SHA-256, unpacks the program files into
Settings/update/staged, and starts a small helper that waits for the app to
close, copies them over the old ones and starts the app again. "My Data" and
"Settings" are never in the zip and never touched, so nothing is asked again.

Only the shareable (portable) build updates itself.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

from tracker import brand, config

CHECK_EVERY = 6 * 3600
# The first check after the app starts always asks GitHub, so a new version
# shows up on the next start instead of up to a day later.
_checked_this_run = False
APP_DIR = Path(__file__).resolve().parent.parent           # <their folder>/app
# What an update may replace, relative to the folder the person unzipped into.
ALLOWED_TOP = ("app/", "Start OptionIQ.bat", "Start OptionIQ.command", "README.md",
               "READ ME FIRST.txt")

state = {"state": "idle", "error": "", "done": 0, "total": 0}
_lock = threading.Lock()


# ---- versions ----------------------------------------------------------------
def parse_version(v) -> tuple:
    out = []
    for part in str(v or "").strip().lstrip("vV").split("."):
        digits = "".join(c for c in part if c.isdigit())
        out.append(int(digits) if digits else 0)
    while len(out) < 3:
        out.append(0)
    return tuple(out)


def newer(latest, current=None) -> bool:
    return parse_version(latest) > parse_version(current or brand.VERSION)


def platform_key() -> str:
    return "mac" if sys.platform == "darwin" else "windows"


def enabled() -> bool:
    return bool(brand.UPDATE_URL) and config.PORTABLE_ROOT is not None


# ---- downloads from a OneDrive (or any) share link ------------------------------
def candidate_urls(link: str) -> list[str]:
    """A share link opens a web page; these are the ways to get the file itself.
    Tried in order until one gives the real file."""
    link = link.strip()
    urls = []
    host = urllib.parse.urlparse(link).netloc.lower()
    if any(h in host for h in ("1drv.ms", "onedrive.live.com", "sharepoint.com", "onedrive.com")):
        bare = link.split("?")[0]
        for form in dict.fromkeys([link, bare]):
            token = base64.urlsafe_b64encode(form.encode()).decode().rstrip("=")
            urls.append(f"https://api.onedrive.com/v1.0/shares/u!{token}/root/content")
        sep = "&" if "?" in link else "?"
        urls.append(link + sep + "download=1")
        urls.append(bare + "?download=1")
    elif "drive.google.com" in host:
        fid = ""
        parts = urllib.parse.urlparse(link)
        if "/d/" in parts.path:
            fid = parts.path.split("/d/")[1].split("/")[0]
        fid = fid or urllib.parse.parse_qs(parts.query).get("id", [""])[0]
        if fid:
            urls.append(f"https://drive.google.com/uc?export=download&id={fid}")
    elif "dropbox.com" in host:
        urls.append(link.replace("dl=0", "dl=1") if "dl=0" in link else link + ("&" if "?" in link else "?") + "dl=1")
    urls.append(link)
    return urls


def _get(url: str, timeout: float, progress=None) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": f"OptionIQ/{brand.VERSION}"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        total = int(r.headers.get("Content-Length") or 0)
        chunks, got = [], 0
        while True:
            block = r.read(256 * 1024)
            if not block:
                break
            chunks.append(block)
            got += len(block)
            if progress:
                progress(got, total)
        return b"".join(chunks)


def fetch(link: str, accept, timeout: float = 60, progress=None, getter=None) -> bytes:
    """Download a share link, trying each way in turn; `accept(data)` says
    whether what came back is the real file (not a sign-in or preview page)."""
    getter = getter or _get
    errors = []
    for url in candidate_urls(link):
        try:
            data = getter(url, timeout, progress)
        except Exception as exc:  # try the next way
            errors.append(f"{exc}")
            print(f"update download: {url[:80]} failed: {exc}", file=sys.stderr)
            continue
        if accept(data):
            print(f"update download: {url[:80]} ok ({len(data)} bytes)", file=sys.stderr)
            return data
        errors.append("what came back wasn't the right file")
        print(f"update download: {url[:80]} gave {data[:60]!r}", file=sys.stderr)
    raise RuntimeError("couldn't download it (" + "; ".join(errors[-2:]) + ")")


def _is_json(data: bytes) -> bool:
    try:
        return isinstance(json.loads(data.decode("utf-8-sig")), dict)
    except (ValueError, UnicodeDecodeError):
        return False


# ---- checking ------------------------------------------------------------------
def _cache_file() -> Path:
    return config.config_dir() / "update_check.json"


def _read_cache() -> dict:
    try:
        return json.loads(_cache_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def check(force: bool = False, getter=None) -> dict:
    """What the page shows. Reads latest.json once per start, then every few hours."""
    global _checked_this_run
    if not enabled():
        return {"enabled": False, "current": brand.VERSION}
    cache = _read_cache()
    latest = cache.get("latest")
    error = ""
    if force or not latest or not _checked_this_run or time.time() - cache.get("checkedAt", 0) > CHECK_EVERY:
        try:
            latest = json.loads(fetch(brand.UPDATE_URL, _is_json, timeout=20, getter=getter).decode("utf-8-sig"))
            cache = {"checkedAt": time.time(), "latest": latest}
            _checked_this_run = True
            config.config_dir().mkdir(parents=True, exist_ok=True)
            _cache_file().write_text(json.dumps(cache, indent=2), encoding="utf-8")
        except Exception as exc:
            error = str(exc)
            print(f"update check failed: {exc}", file=sys.stderr)
    latest = latest or {}
    pkg = latest.get(platform_key()) or {}
    with _lock:
        st = dict(state)
    return {
        "enabled": True,
        "current": brand.VERSION,
        "latest": latest.get("version"),
        "date": latest.get("date"),
        "notes": latest.get("notes", ""),
        "available": bool(latest.get("version") and newer(latest["version"]) and pkg.get("url") and pkg.get("sha256")),
        "manualLink": pkg.get("url", ""),
        "checkError": error,
        "install": st,
    }


# ---- installing ----------------------------------------------------------------
def _staging() -> Path:
    return config.config_dir() / "update"


def _set(**kw) -> None:
    with _lock:
        state.update(kw)


def unpack(data: bytes, dest: Path) -> int:
    """Put the zip's program files in `dest`, laid out like the person's folder.
    The Mac zip has everything inside an `OptionIQ/` folder; the Windows one
    doesn't. Anything outside the program files is left out."""
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)
    count = 0
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names = [n for n in z.namelist() if not n.endswith("/")]
        prefix = "OptionIQ/" if names and all(n.startswith("OptionIQ/") for n in names) else ""
        for info in z.infolist():
            name = info.filename
            if name.endswith("/") or not name.startswith(prefix):
                continue
            rel = name[len(prefix):]
            parts = rel.split("/")
            if ".." in parts or rel.startswith("/") or ":" in rel:
                continue
            if not (rel.startswith("app/") or rel in ALLOWED_TOP):
                continue
            target = dest.joinpath(*parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(z.read(info))
            mode = (info.external_attr >> 16) & 0o777
            if mode and os.name != "nt":
                os.chmod(target, mode)
            count += 1
    if not (dest / "app" / "position_tracker.py").exists():
        raise RuntimeError("the download isn't an OptionIQ zip")
    return count


WINDOWS_HELPER = r"""
param([int]$AppPid, [string]$Src, [string]$Dst, [string]$Log)
$ErrorActionPreference = 'Continue'
"$(Get-Date) waiting for OptionIQ ($AppPid) to close" | Out-File -Append $Log
try { Wait-Process -Id $AppPid -Timeout 60 -ErrorAction SilentlyContinue } catch {}
Start-Sleep -Seconds 2
$ok = $false
for ($i = 0; $i -lt 5 -and -not $ok; $i++) {
    robocopy "$Src" "$Dst" /E /IS /IT /R:3 /W:1 /NP /NFL /NDL /NJH /NJS | Out-File -Append $Log
    if ($LASTEXITCODE -lt 8) { $ok = $true } else { Start-Sleep -Seconds 3 }
}
"$(Get-Date) copy finished, ok=$ok" | Out-File -Append $Log
Start-Process -FilePath (Join-Path $Dst 'app\python\pythonw.exe') -ArgumentList '"app\position_tracker.py"','--portable' -WorkingDirectory $Dst
"""

POSIX_HELPER = """#!/bin/sh
# OptionIQ update helper: wait for the app to close, copy the new files in, start again.
APP_PID="$1"; SRC="$2"; DST="$3"; LOG="$4"
echo "$(date) waiting for OptionIQ ($APP_PID) to close" >>"$LOG"
n=0
while kill -0 "$APP_PID" 2>/dev/null && [ $n -lt 60 ]; do sleep 1; n=$((n+1)); done
sleep 1
cp -Rp "$SRC/." "$DST/" >>"$LOG" 2>&1 && echo "$(date) copy finished" >>"$LOG" || echo "$(date) copy FAILED" >>"$LOG"
chmod +x "$DST/Start OptionIQ.command" 2>/dev/null
xattr -dr com.apple.quarantine "$DST/app" 2>/dev/null
cd "$DST" || exit 1
if [ -z "$SSL_CERT_FILE" ] && [ -f /etc/ssl/cert.pem ]; then export SSL_CERT_FILE=/etc/ssl/cert.pem; fi
nohup "$5" app/position_tracker.py --portable </dev/null >>"Settings/start.log" 2>&1 &
"""


def _launch_helper(staged: Path) -> None:
    root = config.PORTABLE_ROOT
    work = _staging()
    log = work / "update.log"
    if sys.platform == "win32":
        script = work / "apply_update.ps1"
        script.write_text(WINDOWS_HELPER, encoding="utf-8")
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        subprocess.Popen(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                          "-File", str(script), str(os.getpid()), str(staged), str(root), str(log)],
                         creationflags=flags, close_fds=True)
    else:
        script = work / "apply_update.sh"
        script.write_text(POSIX_HELPER, encoding="utf-8")
        os.chmod(script, 0o755)
        python = root / "app" / "python" / "bin" / "python3"
        subprocess.Popen(["/bin/sh", str(script), str(os.getpid()), str(staged), str(root), str(log),
                          str(python if python.exists() else sys.executable)],
                         start_new_session=True, close_fds=True,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def install(store, on_ready, getter=None) -> None:
    """Back up, download, check, unpack, then hand over to the helper and let
    `on_ready` close the app. Runs in the background; progress in `state`."""
    def run():
        try:
            latest = (_read_cache().get("latest") or {})
            pkg = latest.get(platform_key()) or {}
            if not (pkg.get("url") and pkg.get("sha256") and newer(latest.get("version"))):
                raise RuntimeError("no newer version found; try Check for updates first")
            _set(state="backing-up", error="", done=0, total=0)
            if store.exists():
                store.backup()
            _set(state="downloading")
            want = pkg["sha256"].lower()
            data = fetch(pkg["url"], lambda d: hashlib.sha256(d).hexdigest() == want, timeout=300,
                         progress=lambda got, total: _set(done=got, total=total), getter=getter)
            _set(state="unpacking")
            work = _staging()
            work.mkdir(parents=True, exist_ok=True)
            staged = work / "staged"
            unpack(data, staged)
            _set(state="restarting")
            _launch_helper(staged)
            on_ready()
        except Exception as exc:
            print(f"update failed: {exc}", file=sys.stderr)
            _set(state="failed", error=str(exc))

    with _lock:
        if state["state"] in ("backing-up", "downloading", "unpacking", "restarting"):
            return
        state.update(state="starting", error="")
    threading.Thread(target=run, daemon=True).start()


def status() -> dict:
    with _lock:
        return dict(state)


def cleanup() -> None:
    """Called at start: the helper has finished with the unpacked copy."""
    staged = _staging() / "staged"
    if staged.exists():
        shutil.rmtree(staged, ignore_errors=True)
