"""The link between OptionIQ on the computer and the OptionIQ phone app.

There is no server. Both sides use one folder next to the data file, which
sits in the user's cloud drive (OneDrive, Google Drive or Dropbox):

    My Data/
      tracker_data.json          the main records; only the computer writes it
      Phone/
        phone-copy.json          written here, read by the phone
        inbox/<op>.json          one file per change made on the phone
        inbox/done/              files already added, kept 30 days
        inbox/problem/           files that could not be read

The phone never touches the main records. It drops a small file in the inbox
for each new trade, close, roll, fix, delete or watchlist ticker; the app
window adds them to the records with the logger's own rules
(web/app/phone_inbox.js) and then moves the files to done/. Only the computer ever changes tracker_data.json, so two
devices can never overwrite each other's work.
"""
from __future__ import annotations

import json
import os
import threading
import time
from datetime import date, datetime, timedelta
from pathlib import Path

from tracker import brand, config
from tracker.kvstore import STOCKS_KEY, TRADES_KEY, WATCHLIST_KEY, KVStore, replace_file

FOLDER = "Phone"
COPY_FILE = "phone-copy.json"
APPLIED_KEY = "phone_applied_v1"   # op ids already added (kept in the data file)
HISTORY_KEY = "phone_history_v1"   # the trade as it was before each phone change
SUMMARY_KEY = "phone_summary_v1"   # the summary cards, worked out by the logger
PRICES_KEY = "phone_option_prices_v1"   # latest option prices + profit target, from the logger
CLOSED_DAYS = 90                   # closed trades the phone can still see and fix
KEEP_DONE_DAYS = 30
MAX_INBOX_FILE = 200_000
# A file the cloud drive is still bringing down can't be read yet (OneDrive
# "files on demand" shows it before its contents arrive). Such a file is tried
# again each minute and only set aside once it has stayed unreadable this long.
SETTLE_SECONDS = 15 * 60
PHONE_OPS = ("new", "close", "edit", "delete", "watch", "split")

# Only these fields go to the phone; the rest of a trade is worked out again
# on the computer when a phone change is added.
TRADE_FIELDS = ("id", "account", "date", "company", "ticker", "strike", "currentStock", "expDate",
                "sellPremium", "contracts", "cp", "sb", "action", "closeDate", "closePremium",
                "netPL", "total", "moneyOnHold", "currentOptionPrice", "rolledFromId", "rolledToId", "fromPhone")
STOCK_FIELDS = ("id", "account", "ticker", "company", "shares", "dateAcquired", "costBasis",
                "currentPrice", "status")


def phone_dir(store: KVStore) -> Path:
    return store.path.parent / FOLDER


def inbox_dir(store: KVStore) -> Path:
    return phone_dir(store) / "inbox"


def _rows(kv: dict, key: str) -> list:
    try:
        v = json.loads(kv.get(key) or "[]")
    except ValueError:
        return []
    return v if isinstance(v, list) else []


def _is_open(t: dict) -> bool:
    return not t.get("action") or t.get("action") == "Open"


def build_copy(state: dict, today: date | None = None) -> dict:
    """What the phone sees: open trades, trades closed in the last 90 days,
    stocks still held and the watchlist, plus the account names and the
    person's own Finnhub key (they agreed to it travelling in their own cloud
    folder, so prices can be refreshed on the phone)."""
    today = today or date.today()
    kv = state.get("kv", {})
    since = (today - timedelta(days=CLOSED_DAYS)).isoformat()
    trades = []
    for t in _rows(kv, TRADES_KEY):
        if not isinstance(t, dict):
            continue
        if _is_open(t) or str(t.get("closeDate") or "")[:10] >= since:
            trades.append({k: t[k] for k in TRADE_FIELDS if k in t})
    stocks = [{k: s[k] for k in STOCK_FIELDS if k in s} for s in _rows(kv, STOCKS_KEY)
              if isinstance(s, dict) and (s.get("status") or "Held") != "Sold"]
    try:
        watch = json.loads(kv.get(WATCHLIST_KEY) or "{}")
    except ValueError:
        watch = {}
    applied = _rows(kv, APPLIED_KEY)
    try:
        summary = json.loads(kv.get(SUMMARY_KEY) or "null")
    except ValueError:
        summary = None
    try:
        prices = json.loads(kv.get(PRICES_KEY) or "null")
    except ValueError:
        prices = None
    settings = state.get("settings", {})
    return {
        "version": 1,
        "app": brand.APP_NAME,
        "appVersion": brand.VERSION,
        "writtenAt": datetime.now().astimezone().isoformat(timespec="seconds"),
        "accounts": list(settings.get("accounts") or []),
        "reminderDays": settings.get("reminderDays") or 7,
        "finnhubKey": config.get_keys().get("finnhub") or "",
        "trades": trades,
        "stocks": stocks,
        "watchlist": [{"ticker": k, "name": str(watch[k] or "")} for k in sorted(watch)] if isinstance(watch, dict) else [],
        # The summary cards exactly as the computer shows them (all-time totals
        # need every trade, and the phone only gets some).
        "summary": summary if isinstance(summary, dict) else None,
        # Each open option's price at the computer's last 🔄 Prices (by trade
        # id), and the "profit captured" target set there.
        "optionPrices": prices if isinstance(prices, dict) else None,
        # So the phone can drop changes it made from its "waiting" list.
        "appliedOps": applied[-500:],
    }


def write_copy(store: KVStore) -> Path | None:
    """Write Phone/phone-copy.json (all at once, so the cloud drive never
    uploads half a file). Does nothing before first-run setup."""
    state = store.load()
    if not state["settings"].get("setupDone"):
        return None
    folder = phone_dir(store)
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "inbox").mkdir(exist_ok=True)
    target = folder / COPY_FILE
    tmp = folder / (COPY_FILE + ".tmp")
    tmp.write_text(json.dumps(build_copy(state), separators=(",", ":")), encoding="utf-8")
    replace_file(tmp, target)
    return target


class CopyWriter:
    """Rewrites the phone copy a few seconds after the data changes, so a
    burst of saves (a price refresh writes every trade) makes one file."""

    def __init__(self, store: KVStore, delay: float = 3.0):
        self.store = store
        self.delay = delay
        self._timer: threading.Timer | None = None
        self._lock = threading.Lock()

    def poke(self) -> None:
        with self._lock:
            if self._timer:
                self._timer.cancel()
            self._timer = threading.Timer(self.delay, self._run)
            self._timer.daemon = True
            self._timer.start()

    def _run(self) -> None:
        try:
            write_copy(self.store)
        except Exception as exc:  # the phone copy must never get in the way of saving
            print(f"phone copy not written: {exc}")


def read_inbox(store: KVStore) -> list:
    """Changes waiting from the phone, oldest first. A file that isn't a
    readable change is moved to inbox/problem so it is not tried forever."""
    folder = inbox_dir(store)
    if not folder.is_dir():
        return []
    items = []
    for f in sorted(folder.glob("*.json")):
        try:
            if f.stat().st_size > MAX_INBOX_FILE:
                raise ValueError("too large")
            op = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            if _age(f) >= SETTLE_SECONDS:      # not just still downloading
                _move(f, folder / "problem")
            continue
        if not isinstance(op, dict) or not op.get("opId") or op.get("op") not in PHONE_OPS:
            _move(f, folder / "problem")
            continue
        op["file"] = f.name
        items.append(op)
    items.sort(key=lambda o: (str(o.get("at") or ""), o["file"]))
    return items


def mark_done(store: KVStore, names: list) -> int:
    folder = inbox_dir(store)
    moved = 0
    for name in names or []:
        name = Path(str(name)).name          # never anything outside the inbox
        f = folder / name
        if name.endswith(".json") and f.is_file():
            _move(f, folder / "done")
            moved += 1
    _tidy(folder / "done")
    return moved


def _age(f: Path) -> float:
    try:
        return time.time() - f.stat().st_mtime
    except OSError:
        return 0.0


def _move(f: Path, to: Path) -> None:
    to.mkdir(parents=True, exist_ok=True)
    try:
        os.replace(f, to / f.name)
    except OSError:
        pass


def _tidy(folder: Path) -> None:
    cutoff = time.time() - KEEP_DONE_DAYS * 86400
    for f in folder.glob("*.json") if folder.is_dir() else []:
        try:
            if f.stat().st_mtime < cutoff:
                f.unlink()
        except OSError:
            pass
