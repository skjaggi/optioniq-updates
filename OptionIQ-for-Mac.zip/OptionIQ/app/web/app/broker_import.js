// Reads a broker's own download file and works out what it means for
// OptionIQ: new trades, trades that were bought back, expired or assigned,
// and lines that are already in OptionIQ.
//
// For now: Fidelity's Activity & Orders download (Accounts_History.csv).
// Schwab and Robinhood come next and plug in the same way (a detect test and
// a reader that turns their lines into the same events).
//
// A broker file is a list of events, not of trades: one line when an option
// is sold, another when it is bought back, expires or is assigned. The lines
// are paired here into trades, using OptionIQ's own trades too, so a trade
// typed in by hand is closed by the file rather than added twice.
//
// Pure: no saving, no dialogs. The trade screen shows the result for the
// person to check, then saves. Tested by tests/broker_import_test.js.
(function (root) {
  "use strict";

  function str(v) { return v === null || v === undefined ? "" : String(v).trim(); }
  function norm(v) { return str(v).toLowerCase().replace(/[^a-z]/g, ""); }
  function num(v) {
    var s = str(v).replace(/[$,\s]/g, "").replace(/^\((.*)\)$/, "-$1");
    if (s === "" || s === "--") return null;
    var n = parseFloat(s);
    return isNaN(n) ? null : n;
  }
  function round(n, d) { var f = Math.pow(10, d); return Math.round(n * f) / f; }
  function p2(n) { return String(n).padStart(2, "0"); }
  var MON = { JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6, JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12 };
  var MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  // 10/17/2026, 10/17/26 or 2026-10-17.
  function day(v) {
    var s = str(v), m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2}|\d{4})\b/);
    if (m) return (m[3].length === 2 ? "20" + m[3] : m[3]) + "-" + p2(m[1]) + "-" + p2(m[2]);
    m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})\b/);
    return m ? m[1] + "-" + p2(m[2]) + "-" + p2(m[3]) : "";
  }
  function daysApart(a, b) { return Math.abs((Date.parse(a) - Date.parse(b)) / 864e5); }
  function shortDay(d) { return d ? MONTHS[+d.slice(5, 7) - 1] + " " + (+d.slice(8, 10)) : ""; }
  function dollars(v) {
    var n = Number(v) || 0;
    return (n < 0 ? "-$" : "$") + Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  // Fidelity's option symbol: "-KO261017P62", "-SPY261017C580.5".
  function occ(sym) {
    var m = str(sym).toUpperCase().replace(/\s/g, "").match(/^-([A-Z][A-Z0-9.]{0,6}?)(\d{2})(\d{2})(\d{2})([CP])(\d+(?:\.\d+)?)$/);
    return m ? { ticker: m[1], expDate: "20" + m[2] + "-" + m[3] + "-" + m[4], cp: m[5], strike: parseFloat(m[6]) } : null;
  }
  // The same option in words: "PUT (KO) COCA COLA CO OCT 17 26 $62 (100 SHS)".
  function described(text) {
    var m = str(text).toUpperCase().match(/\b(CALL|PUT)\s*\(([A-Z][A-Z0-9.]{0,6})\)\s*(.*?)\s*\b([A-Z]{3})\s+(\d{1,2})\s+(\d{2})\s+\$(\d+(?:\.\d+)?)/);
    if (!m || !MON[m[4]]) return null;
    return { ticker: m[2], company: m[3].trim(), expDate: "20" + m[6] + "-" + p2(MON[m[4]]) + "-" + p2(m[5]),
             cp: m[1][0], strike: parseFloat(m[7]) };
  }
  // Money market funds and cash sweeps: cash, not shares to track.
  function cashLike(symbol, description) {
    return /\*\*$/.test(str(symbol)) || /MONEY MARKET|MMKT|DEPOSIT SWEEP|CASH RESERVES/i.test(str(description));
  }
  function titleCase(s) {
    return str(s).toLowerCase().replace(/\b[a-z]/g, function (c) { return c.toUpperCase(); })
      .replace(/\b(Inc|Co|Corp|Ltd|Plc|Etf|Tr)\b/g, function (w) { return w === "Etf" ? "ETF" : w; });
  }

  // ── Fidelity ────────────────────────────────────────────────
  var FID_COLS = {
    date: ["rundate", "date"], account: ["account", "accountname"], number: ["accountnumber"],
    action: ["action"], symbol: ["symbol"], description: ["description", "securitydescription"],
    quantity: ["quantity"], price: ["price"], amount: ["amount"]
  };
  function fidHeader(rows) {
    for (var i = 0; i < Math.min(rows.length, 30); i++) {
      var h = rows[i].map(norm);
      if ((h.indexOf("rundate") >= 0 || h.indexOf("date") >= 0) && h.indexOf("action") >= 0 && h.indexOf("symbol") >= 0) return i;
    }
    return -1;
  }
  function fidColumns(head) {
    var h = head.map(norm), col = {};
    Object.keys(FID_COLS).forEach(function (k) {
      col[k] = -1;
      FID_COLS[k].some(function (name) { col[k] = h.indexOf(name); return col[k] >= 0; });
    });
    return col;
  }

  // One line of the file as an event, or why it is left out.
  function fidEvent(r, col) {
    var g = function (k) { return col[k] >= 0 && col[k] < r.length ? str(r[col[k]]) : ""; };
    var date = day(g("date"));
    if (!date) return { other: true };                 // notes and disclaimers under the list
    var act = g("action").toUpperCase().replace(/\s+/g, " ");
    // "EXPIRED ... as of 2026-10-16": the day it really happened, not the
    // Monday the line was posted.
    var asOf = act.match(/\bAS OF (\d{4}-\d{2}-\d{2}|\d{1,2}\/\d{1,2}\/\d{2,4})/);
    if (asOf && day(asOf[1])) date = day(asOf[1]);
    var o = occ(g("symbol")), d = described(g("description")) || described(act);
    if (!o && d && /^-/.test(g("symbol"))) o = d;
    if (!o && /^REINVESTMENT\b/.test(act) && g("symbol") && !cashLike(g("symbol"), g("description"))) {
      return { reinvest: true, date: date, ticker: g("symbol").replace(/\s/g, "").toUpperCase(),
               qty: Math.abs(num(g("quantity")) || 0), price: num(g("price")), amount: num(g("amount")),
               acctName: g("account"), acctNum: g("number"), symbol: g("symbol").replace(/\s/g, ""), text: g("action"),
               company: titleCase(g("description")) };
    }
    // Shares moved between accounts (a rollover, a Roth conversion): no price,
    // and the broker keeps their first purchase date, so they are counted but
    // not given a date of their own.
    if (!o && /^(TRANSFERRED (FROM|TO)|ROTH CONVERSION|CONV\. TO ROTH)\b/.test(act) && g("symbol") && !cashLike(g("symbol"), g("description"))) {
      var moved = num(g("quantity")) || 0;
      if (!moved) return { other: true };
      return { transfer: true, date: date, ticker: g("symbol").replace(/\s/g, "").toUpperCase(), qty: moved,
               acctName: g("account"), acctNum: g("number"), symbol: g("symbol").replace(/\s/g, ""), text: g("action"),
               company: titleCase(g("description")) };
    }
    if (!o) {
      if (!/\bYOU (BOUGHT|SOLD)\b/.test(act) || !g("symbol")) return { other: true };
      // Shares of an assigned option come with the option line; cash funds are cash.
      if (/\bASSIGNED\b/.test(act) || cashLike(g("symbol"), g("description"))) return { stock: true };
      return { stock: true, trade: true, side: /\bYOU BOUGHT\b/.test(act) ? "B" : "S", date: date,
               ticker: g("symbol").replace(/\s/g, "").toUpperCase(), qty: Math.abs(num(g("quantity")) || 0),
               price: num(g("price")), amount: num(g("amount")), acctName: g("account"), acctNum: g("number"),
               symbol: g("symbol").replace(/\s/g, ""), text: g("action"), company: titleCase(g("description")) };
    }
    var kind = /\bEXPIRED\b/.test(act) ? "expire"
             : /\bASSIGNED\b/.test(act) ? "assign"
             : /\bOPENING TRANSACTION\b/.test(act) ? "open"
             : /\bCLOSING TRANSACTION\b/.test(act) ? "close" : "";
    var qty = Math.abs(Math.round(num(g("quantity")) || 0));
    var ev = {
      date: date, ticker: o.ticker, cp: o.cp, strike: o.strike, expDate: o.expDate,
      company: d && d.company ? titleCase(d.company) : "",
      acctName: g("account"), acctNum: g("number"), symbol: g("symbol").replace(/\s/g, ""),
      kind: kind, qty: qty, price: num(g("price")), amount: num(g("amount")), text: g("action")
    };
    // The side of the trade the line is about: an opening sale starts a sold
    // option; a closing purchase ends one. Expiry and assignment don't say.
    ev.side = kind === "open" ? (/\bYOU SOLD\b/.test(act) ? "S" : "B")
            : kind === "close" ? (/\bYOU BOUGHT\b/.test(act) ? "S" : "B")
            : kind === "assign" ? "S" : "";
    if (!kind) ev.why = /EXERCIS/.test(act) ? "an option you exercised" : "OptionIQ doesn't know this kind of line yet";
    else if (!qty) ev.why = "no quantity";
    return ev;
  }

  var BROKERS = [{
    name: "Fidelity",
    detect: function (rows) { return fidHeader(rows) >= 0; },
    events: function (rows) {
      var hr = fidHeader(rows), col = fidColumns(rows[hr]), out = { events: [], reinvest: [], stocks: [], transfers: [], stock: 0, other: 0, review: [] };
      for (var i = hr + 1; i < rows.length; i++) {
        if (!rows[i].some(function (v) { return str(v); })) continue;
        var e = fidEvent(rows[i], col);
        if (e.other) { out.other++; continue; }
        e.row = i + 1;
        if (e.stock) { if (e.trade && e.qty) out.stocks.push(e); else out.stock++; continue; }
        if (e.reinvest) { if (e.qty) out.reinvest.push(e); continue; }
        if (e.transfer) { out.transfers.push(e); continue; }
        if (e.why) { out.review.push({ row: e.row, text: e.text, why: e.why }); continue; }
        out.events.push(e);
      }
      return out;
    }
  }];

  function detect(rows) {
    var b = BROKERS.filter(function (x) { return x.detect(rows || []); })[0];
    return b ? b.name : "";
  }

  // ── Accounts ────────────────────────────────────────────────
  // A broker account the person doesn't track in OptionIQ.
  var SKIP = "(skip)";
  // A new OptionIQ account named after the broker's one ("➕ New account" in
  // the lists); the account itself is made when the results are saved.
  var NEW = "(new) ";
  function isNew(m) { return typeof m === "string" && m.indexOf(NEW) === 0; }
  function real(m) { return isNew(m) ? m.slice(NEW.length) : m; }
  var ACRONYM = /^(IRA|HSA|SEP|TOD|JTWROS|LLC|UTMA|UGMA|BDA|CMA|401K|403B|529)$/;
  function newName(name, number) {
    var n = str(name).trim().split(/\s+/).filter(Boolean).map(function (w) {
      return ACRONYM.test(w.toUpperCase()) ? w.toUpperCase() : w.toLowerCase().replace(/[a-z]/, function (c) { return c.toUpperCase(); });
    }).join(" ");
    return n || ("Account " + str(number).slice(-4)).trim();
  }
  // Each broker account in a list gets its "new account" name; two with the
  // same name (two Roth IRAs) are told apart by their last digits.
  function nameNew(list) {
    var count = {};
    list.forEach(function (a) { var n = newName(a.name, a.number).toLowerCase(); count[n] = (count[n] || 0) + 1; });
    list.forEach(function (a) {
      var n = newName(a.name, a.number);
      a.newAccount = NEW + n + (count[n.toLowerCase()] > 1 && a.number ? " " + str(a.number).slice(-4) : "");
    });
    return list;
  }
  function validPick(m, accounts) { return m === SKIP || isNew(m) || accounts.indexOf(m) >= 0; }
  function acctKey(e) { return (e.acctName + "|" + e.acctNum).replace(/^\|$/, ""); }
  // Which OptionIQ account a broker account goes into: the one chosen last
  // time, else one with the same name or ending digits, else the first.
  function guessAccount(name, number, accounts, remembered) {
    var key = (name + "|" + number).replace(/^\|$/, "");
    if (remembered && accounts.indexOf(remembered[key]) >= 0) return { account: remembered[key], sure: true };
    // Chosen before as a new account that the app hasn't shown yet (it
    // appears after the reload once every file is done).
    if (remembered && remembered[key] && remembered[key] !== SKIP && !isNew(remembered[key]))
      return { account: NEW + remembered[key], sure: true };
    var n = norm(name), last4 = str(number).slice(-4);
    var named = accounts.filter(function (a) { return norm(a) === n && n; })[0];
    if (named) return { account: named, sure: true };
    var hit = accounts.filter(function (a) { return last4 && a.indexOf(last4) >= 0; })[0] ||
              accounts.filter(function (a) {
                var A = norm(a);
                return n && A && (A.indexOf(n) >= 0 || n.indexOf(A) >= 0);
              })[0];
    return hit ? { account: hit, sure: false } : { account: accounts[0], sure: false, none: true };
  }
  // Better than the name: the OptionIQ account that already holds the most
  // of the trades opened in this broker account.
  function byTrades(events, trades, accounts) {
    var score = {};
    events.forEach(function (e) {
      if (e.kind !== "open") return;
      var k = acctKey(e);
      trades.forEach(function (t) {
        if (accounts.indexOf(t.account) < 0 || !same(t, e, t.account) || t.sb !== e.side) return;
        if (t.date && daysApart(t.date, e.date) > 3) return;
        score[k] = score[k] || {};
        score[k][t.account] = (score[k][t.account] || 0) + 1;
      });
    });
    var best = {};
    Object.keys(score).forEach(function (k) {
      var top = Object.keys(score[k]).sort(function (a, b) { return score[k][b] - score[k][a]; })[0];
      if (score[k][top] >= 2) best[k] = top;
    });
    return best;
  }
  function listAccounts(events, accounts, remembered, trades) {
    var seen = {}, out = [], learned = byTrades(events, trades || [], accounts);
    events.forEach(function (e) {
      var k = acctKey(e);
      if (!seen[k]) {
        var g = guessAccount(e.acctName, e.acctNum, accounts, remembered);
        if (!g.sure && learned[k]) g = { account: learned[k], sure: true };
        // Only reinvested dividends and nothing to go on: likely an account not
        // kept in OptionIQ, so it starts left out.
        var optionLines = events.some(function (x) { return !x.reinvest && acctKey(x) === k; });
        if (!g.sure && !optionLines && !(remembered && remembered[k] === SKIP)) g = { account: SKIP, sure: false };
        if (remembered && remembered[k] === SKIP) g = { account: SKIP, sure: true };
        seen[k] = { key: k, name: e.acctName, number: e.acctNum, lines: 0, account: g.account, sure: g.sure, none: g.none };
        out.push(seen[k]);
      }
      seen[k].lines++;
    });
    // Nothing in OptionIQ looks like it: a new account rather than a wrong one.
    nameNew(out).forEach(function (a) { if (a.none && a.account !== SKIP) a.account = a.newAccount; delete a.none; });
    return out;
  }

  // ── Pairing lines into trades ───────────────────────────────
  function label(t) {
    return str(t.ticker).toUpperCase() + " $" + str(t.strike) + " " + (t.cp === "C" ? "call" : "put") +
           " exp " + shortDay(t.expDate) + (t.account ? " (" + t.account + ")" : "");
  }
  function isOpen(t) { return !t.action || t.action === "Open"; }
  function same(t, e, acct) {
    return str(t.account) === acct && str(t.ticker).toUpperCase() === e.ticker && t.cp === e.cp &&
           t.expDate === e.expDate && Math.abs((num(t.strike) || 0) - e.strike) < 0.001;
  }
  var ENDINGS = ["Expired", "Assigned", "Called Away"];
  function closingAction(e, side) {
    if (e.kind === "expire") return "Expired";
    if (e.kind === "assign") return e.cp === "P" ? "Assigned" : "Called Away";
    return side === "B" ? "Sold to Close" : "Bought to Close";
  }
  // Trades that together hold exactly qty contracts (one trade of 2, or two
  // of 1 when they were typed in separately), else null.
  function pick(list, qty) {
    var exact = list.filter(function (t) { return (parseInt(t.contracts, 10) || 0) === qty; })[0];
    if (exact) return [exact];
    var got = 0, use = [];
    list.forEach(function (t) {
      var q = parseInt(t.contracts, 10) || 0;
      if (q && got + q <= qty) { got += q; use.push(t); }
    });
    return use.length && got === qty ? use : null;
  }
  function finish(t, h) {
    t.total = round((t.sells || 0) + (t.buys || 0), 2);
    t.netPL = h.calcNetPL(t.total, t.closePremium, t.action || "Open");
    t.moneyOnHold = h.calcMOH(t);
    return t;
  }

  // rows: the file as rows of cells. trades/stocks: what OptionIQ holds now.
  // opt: { accounts, map: {broker account key: OptionIQ account}, seen: [line
  // keys imported before], idBase, h: the logger's sums + shareEffect }.
  function analyze(rows, trades, stocks, opt) {
    var broker = BROKERS.filter(function (x) { return x.detect(rows || []); })[0];
    if (!broker) return null;
    var h = opt.h, read = broker.events(rows);
    var accounts = listAccounts(read.events.concat(read.reinvest, read.stocks.concat(read.transfers || []).map(function (e) { return Object.assign({ reinvest: true }, e); })),
                                opt.accounts, opt.map, trades);
    var mapTo = {};
    accounts.forEach(function (a) {
      var m = opt.map && opt.map[a.key];
      if (validPick(m, opt.accounts)) a.account = m;
      mapTo[a.key] = real(a.account);
    });

    var res = { broker: broker.name, accounts: accounts, add: [], changed: {}, stocks: stocks.slice(),
                added: [], closed: [], already: [], differs: [], review: read.review.slice(), notes: [], keys: [],
                stockLines: read.stock, otherLines: read.other, earlier: 0, leftOut: 0 };
    var seenKeys = {};
    (opt.seen || []).forEach(function (k) { seenKeys[k] = true; });

    // A key for each line, so a file imported again is recognised exactly.
    var count = {};
    read.events.forEach(function (e) {
      var k = [broker.name, acctKey(e), e.date, e.symbol, e.kind, e.side, e.qty, e.amount].join("|");
      count[k] = (count[k] || 0) + 1;
      e.key = k + "#" + count[k];
      e.account = mapTo[acctKey(e)];
    });
    var events = read.events.filter(function (e) {
      if (e.account === SKIP) { res.leftOut++; return false; }
      if (seenKeys[e.key]) { res.earlier++; return false; }
      return true;
    });

    // Several fills of one order on one day are one trade.
    var groups = {}, merged = [];
    events.forEach(function (e) {
      var g = [e.account, e.date, e.symbol, e.kind, e.side].join("|");
      if (!groups[g]) { groups[g] = Object.assign({}, e, { keys: [e.key], rows: [e.row], cash: e.price != null ? e.price * e.qty : null }); merged.push(groups[g]); return; }
      var m = groups[g];
      m.qty += e.qty; m.keys.push(e.key); m.rows.push(e.row);
      m.amount = m.amount == null || e.amount == null ? null : round(m.amount + e.amount, 2);
      m.cash = m.cash == null || e.price == null ? null : m.cash + e.price * e.qty;
    });
    merged.forEach(function (m) { if (m.cash != null && m.qty) m.price = round(m.cash / m.qty, 4); });
    // Oldest first; on one day, openings before closings.
    var order = { open: 0, close: 1, expire: 2, assign: 2 };
    merged.sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : order[a.kind] - order[b.kind]; });

    // A trade already in OptionIQ answers for its opening line once and for
    // its closing line once.
    var n = 0, claimed = { open: {}, close: {}, part: {} };
    // One trade in OptionIQ for an option the file has on other days or in
    // several fills: the nearest by date with enough contracts not yet
    // matched. A trade is fully claimed once all its contracts are.
    var loose = function (list, e, kind, dateKey) {
      var tag = kind === "open" ? "" : "c";
      var free = function (t) { return (parseInt(t.contracts, 10) || 0) - (claimed.part[t.id + tag] || 0); };
      var t = list.filter(function (x) { return free(x) >= e.qty; }).sort(function (a, b) {
        return daysApart(a[dateKey] || e.date, e.date) - daysApart(b[dateKey] || e.date, e.date);
      })[0];
      if (!t) return null;
      claimed.part[t.id + tag] = (claimed.part[t.id + tag] || 0) + e.qty;
      if (free(t) <= 0) { claimed[kind][t.id] = true; delete claimed.part[t.id + tag]; }
      return [t];
    };
    var nextId = function () { n++; return (opt.idBase || Date.now()) + n; };
    // Share changes from before the Positions check (already in its totals),
    // kept so splitLots can tell which lots those totals are made of.
    var preIn = [], preOut = [];
    var preSeq = {};
    var preShares = function (closed, action, e) {
      var checked = opt.synced && opt.synced[acctKey(e)];
      if (!checked || e.date > checked || !h.shareEffect) return false;
      var part = Object.assign({}, closed, { contracts: String(e.qty) });
      var made = h.shareEffect(part, action, e.date, [], h, 0, []);
      var acctTo = str(closed.account), tkTo = str(closed.ticker).toUpperCase();
      var key = e.keys[0] + "|" + (preSeq[e.keys[0]] = (preSeq[e.keys[0]] || 0) + 1);
      if (action === "Assigned" && made.length)
        preIn.push({ key: key, acct: acctTo, ticker: tkTo, qty: parseFloat(made[0].shares) || 0, date: e.date, cost: parseFloat(made[0].costBasis) || 0, status: "Assigned" });
      else if (action === "Called Away") preOut.push({ key: key, acct: acctTo, ticker: tkTo, qty: e.qty * 100, date: e.date });
      return true;
    };
    var current = function () {
      return trades.map(function (t) { return res.changed[t.id] || t; }).concat(res.add);
    };
    var put = function (t) {
      if (res.add.indexOf(t) >= 0) return;
      for (var i = 0; i < res.add.length; i++) if (res.add[i].id === t.id) { res.add[i] = t; return; }
      res.changed[t.id] = t;
    };
    var closedToday = [];

    merged.forEach(function (e) {
      res.keys = res.keys.concat(e.keys);

      if (e.kind === "open") {
        // Typed in by hand already (or imported another way)?
        var mine = pick(trades.filter(function (t) {
          return !claimed.open[t.id] && !claimed.part[t.id] && same(t, e, e.account) && t.sb === e.side &&
                 (!t.date || t.fromPositions || daysApart(t.date, e.date) <= 3);
        }), e.qty);
        // Typed in on another day, or as one trade for fills on several days
        // (5 contracts typed once, sold as 1 and then 4): the same option in
        // the same account, with contracts still unaccounted for, is the one.
        if (!mine) mine = loose(trades.filter(function (t) {
          return !claimed.open[t.id] && same(t, e, e.account) && t.sb === e.side;
        }), e, "open", "date");
        if (mine) {
          mine.forEach(function (t) {
            if (!claimed.part[t.id]) claimed.open[t.id] = true;
            if (!t.fromPositions) return;
            // Added from a Positions file: now the real day and premium are known.
            var u = Object.assign({}, t, { date: e.date });
            delete u.fromPositions;
            if (e.price != null) u.sellPremium = String(round(Math.abs(e.price), 4));
            u.sells = h.calcSells(u.sb, u.sellPremium, u.contracts); u.buys = h.calcBuys(u.sb, u.sellPremium, u.contracts);
            put(finish(u, h));
          });
          res.already.push("Opened " + e.qty + " × " + label(mine[0]) + " on " + shortDay(e.date));
          return;
        }
        var t = {
          id: nextId(), account: e.account, date: e.date,
          company: (h.tickerName && h.tickerName(e.ticker)) || e.company, ticker: e.ticker,
          strike: String(e.strike), currentStock: "", expDate: e.expDate,
          sellPremium: e.price != null ? String(round(Math.abs(e.price), 4)) : "", contracts: String(e.qty),
          cp: e.cp, sb: e.side, action: "Open", closeDate: "", closePremium: "", fromBroker: res.broker
        };
        // The money that actually moved, fees included, when the file says.
        if (e.amount != null) { t.sells = e.side === "S" ? round(e.amount, 2) : 0; t.buys = e.side === "B" ? round(e.amount, 2) : 0; }
        else { t.sells = h.calcSells(t.sb, t.sellPremium, t.contracts); t.buys = h.calcBuys(t.sb, t.sellPremium, t.contracts); }
        res.add.push(finish(t, h));
        res.added.push((e.side === "S" ? "Sold " : "Bought ") + e.qty + " × " + label(t) + " on " + shortDay(e.date) +
                       " for " + dollars(t.total));
        return;
      }

      // Closed, expired or assigned. Already recorded that way in OptionIQ,
      // as one trade or as several smaller ones?
      var use = pick(trades.filter(function (t) {
        return !claimed.close[t.id] && same(t, e, e.account) && (!e.side || t.sb === e.side) &&
               (t.action === closingAction(e, t.sb) || (e.kind === "close" && t.action === "Rolled") ||
                // an expiry or assignment typed in by hand with another ending
                // (a called-away call is often saved as "Assigned")
                (e.kind !== "close" && ENDINGS.indexOf(t.action) >= 0)) &&
               (!t.closeDate || daysApart(t.closeDate, e.date) <= 3);
      }), e.qty);
      if (!use) use = loose(trades.filter(function (t) {
        return !claimed.close[t.id] && same(t, e, e.account) && (!e.side || t.sb === e.side) && t.closeDate &&
               (t.action === closingAction(e, t.sb) || (e.kind === "close" && t.action === "Rolled") ||
                (e.kind !== "close" && ENDINGS.indexOf(t.action) >= 0));
      }), e, "close", "closeDate");
      if (use) {
        use.forEach(function (t) { if (!claimed.part[t.id + "c"]) claimed.close[t.id] = true; });
        // Shares from an assignment typed in by hand: before the Positions
        // check they are in its totals; note them so the lots split right.
        if (e.kind === "assign") preShares(use[0], closingAction(e, use[0].sb), e);
        // Typed in as expired but the broker says assigned, or the other way round.
        if ((e.kind === "expire") !== (use[0].action === "Expired")) {
          res.differs.push(label(use[0]) + " on " + shortDay(e.date) + ": OptionIQ has it as " + use[0].action + ", " + res.broker +
                           " says " + (e.kind === "expire" ? "it expired" : e.cp === "C" ? "it was assigned (shares called away)" : "it was assigned (shares bought)") +
                           ". Nothing was changed; check the trade" + (e.kind === "expire" ? "." : " and your 🏦 Stocks tab."));
        }
        res.already.push(closingAction(e, use[0].sb) + " " + e.qty + " × " + label(use[0]) + " on " + shortDay(e.date));
        return;
      }

      var open = current().filter(function (t) {
        return isOpen(t) && same(t, e, e.account) && (!e.side || t.sb === e.side);
      }).sort(function (a, b) {
        if (!e.side && a.sb !== b.sb) return a.sb === "S" ? -1 : 1;  // expiry: sold options first
        return str(a.date).localeCompare(str(b.date));
      });
      var left = e.qty;
      open.forEach(function (t) {
        if (left <= 0) return;
        var have = parseInt(t.contracts, 10) || 1, take = Math.min(have, left);
        var action = closingAction(e, t.sb), part = take / e.qty;
        var closePremium = e.kind === "close" && e.amount != null ? String(round(e.amount * part, 2)) : "";
        var closed;
        if (take === have) {
          closed = Object.assign({}, t);
        } else {
          // Only some contracts closed: the rest stay open as their own trade.
          var keep = Object.assign({}, t, { contracts: String(have - take),
            sells: round((t.sells || 0) * (have - take) / have, 2), buys: round((t.buys || 0) * (have - take) / have, 2) });
          put(finish(keep, h));
          closed = Object.assign({}, t, { id: nextId(), contracts: String(take),
            sells: round((t.sells || 0) * take / have, 2), buys: round((t.buys || 0) * take / have, 2) });
          delete closed.rolledToId;
          res.add.push(closed);
        }
        closed.action = action; closed.closeDate = e.date; closed.closePremium = closePremium;
        put(finish(closed, h));
        left -= take;
        var mine = res.add.some(function (a) { return a.id === t.id; });
        var verb = action === "Expired" ? "Expired" : action === "Assigned" ? "Assigned" : action === "Called Away" ? "Called away"
                 : action === "Bought to Close" ? "Bought back" : "Sold";
        res.closed.push(verb + " " + take + " × " + label(closed) + " on " + shortDay(e.date) +
                        (closePremium ? " for " + dollars(closePremium) : "") + (mine ? "" : " (a trade already in OptionIQ)"));
        if (e.kind === "assign" && h.shareEffect) {
          // Shares held on the day of the Positions check are already counted
          // there; only an assignment after that day changes them.
          if (preShares(closed, action, Object.assign({}, e, { qty: take }))) {
            res.notes.push("Shares from " + label(closed) + " on " + shortDay(e.date) +
                           " are already counted in your Positions check, so they were not added again.");
          } else if (opt.stocksOnly) {
            res.notes.push("Shares from " + label(closed) + " on " + shortDay(e.date) + " were not added: you chose stocks only. Record the assignment in OptionIQ to add them.");
          } else {
            res.stocks = h.shareEffect(closed, action, e.date, res.stocks, h, nextId() + 10, res.notes);
            n += 20;
          }
        }
        if (e.kind === "close") closedToday.push({ trade: closed, date: e.date });
      });
      if (left > 0) {
        // Not remembered as done, so it is read again once the opening is in.
        if (left === e.qty) res.keys = res.keys.filter(function (k) { return e.keys.indexOf(k) < 0; });
        res.review.push({ row: e.rows[0], text: e.text,
          why: (left === e.qty ? "" : left + " of the " + e.qty + " contracts: ") +
               "no open " + label({ ticker: e.ticker, strike: e.strike, cp: e.cp, expDate: e.expDate, account: e.account }) +
               " to close. It was probably opened before the dates in this file." });
      }
    });

    // Dividends reinvested: a fraction of a share added to the holding. Only
    // for accounts whose share counts were checked against a Positions file
    // (opt.synced: broker account -> date), so shares already typed in by
    // hand are not counted twice; lines up to that date are in the totals.
    res.shares = []; res.sharesCounted = 0; res.sharesWaiting = [];
    read.reinvest.forEach(function (e) {
      var k = [broker.name, acctKey(e), e.date, e.symbol, "reinvest", e.qty, e.amount].join("|");
      count[k] = (count[k] || 0) + 1; e.key = k + "#" + count[k];
      var acct = mapTo[acctKey(e)];
      if (acct === SKIP) { res.leftOut++; return; }
      if (seenKeys[e.key]) { res.earlier++; return; }
      var since = opt.synced && opt.synced[acctKey(e)];
      if (!since) { res.sharesWaiting.push(e.qty + " " + e.ticker + " (" + acct + ") on " + shortDay(e.date)); return; }
      res.keys.push(e.key);
      var price = e.price != null ? e.price : (e.amount != null && e.qty ? Math.abs(e.amount) / e.qty : 0);
      // Reinvested shares cost no new money (opt.reinvestAtPrice: count them
      // at the price the dividend paid instead, the way the broker does).
      var paid = opt.reinvestAtPrice ? price : 0;
      if (e.date <= since) {
        res.sharesCounted++;
        preIn.push({ key: e.key, acct: acct, ticker: e.ticker, qty: e.qty, date: e.date, cost: paid, company: e.company });
        return;
      }
      // Each reinvestment is its own lot, with its own date (stock lots).
      var like = res.stocks.filter(function (x) {
        return str(x.account) === acct && str(x.ticker).toUpperCase() === e.ticker && x.status !== "Sold";
      })[0];
      res.stocks = res.stocks.concat([{ id: nextId(), account: acct, ticker: e.ticker,
        company: (like && like.company) || (h.tickerName && h.tickerName(e.ticker)) || e.company, shares: String(e.qty), dateAcquired: e.date,
        costBasis: paid.toFixed(2), currentPrice: ((like && parseFloat(like.currentPrice)) || price).toFixed(2), status: "Held", soldDate: "", soldPrice: "" }]);
      res.shares.push("Reinvested dividend: +" + e.qty + " " + e.ticker + " (" + acct + ") on " + shortDay(e.date) + " at $" + price.toFixed(2));
    });

    // Shares moved in or out (rollovers, Roth conversions). Before the
    // Positions check they are in its totals: kept so later sales are taken
    // from them, not from shares with a date. After it, only listed.
    res.transfers = [];
    (read.transfers || []).forEach(function (e) {
      var k = [broker.name, acctKey(e), e.date, e.symbol, "transfer", e.qty].join("|");
      count[k] = (count[k] || 0) + 1; e.key = k + "#" + count[k];
      var acct = mapTo[acctKey(e)];
      if (acct === SKIP) { res.leftOut++; return; }
      if (seenKeys[e.key]) { res.earlier++; return; }
      var since = opt.synced && opt.synced[acctKey(e)];
      if (!since) return;
      res.keys.push(e.key);
      if (e.date <= since) {
        if (e.qty > 0) preIn.push({ key: e.key, acct: acct, ticker: e.ticker, qty: e.qty, date: e.date, cost: 0, transfer: true });
        else preOut.push({ key: e.key, acct: acct, ticker: e.ticker, qty: -e.qty, date: e.date });
        return;
      }
      res.transfers.push((e.qty > 0 ? "Moved in: " : "Moved out: ") + round(Math.abs(e.qty), 6) + " " + e.ticker + " (" + acct + ") on " + shortDay(e.date) +
                         ". Add or take away these shares in the Stocks tab.");
    });

    // Stock bought and sold. After the Positions check (opt.synced) a buy adds
    // a holding and a sale marks shares Sold, oldest first. Before it, the
    // shares held now are already counted, so only history is added: a sale
    // paired with a buy in these files (or an earlier file: opt.openBuys)
    // becomes a Sold record. A sale whose buy is older than every file has
    // no cost to go on, so it is listed, not guessed.
    res.stockAdded = []; res.stockAlready = 0; res.stockWaiting = []; res.stockReview = [];
    res.openBuys = (opt.openBuys || []).map(function (b) { return Object.assign({}, b); });
    var near = function (a, b) { return a && b && daysApart(a, b) <= 3; };
    var sameQty = function (a, b) { return Math.abs((parseFloat(a) || 0) - b) < 0.001; };
    var money = function (x) { return "$" + (x || 0).toFixed(2); };
    // A sale in a later file can show that a lot made from an earlier file's
    // history (splitLots) was sold before the Positions check: those shares
    // go back into the "earlier shares" lot, so the totals stay right.
    var unsplit = function (acct, t, b, take) {
      var lot = res.stocks.filter(function (x) {
        return x.fromHistory && x.status !== "Sold" && str(x.account) === acct && str(x.ticker).toUpperCase() === t &&
               x.dateAcquired === b.date && Math.abs((parseFloat(x.costBasis) || 0) - b.price) < 0.006;
      })[0];
      if (!lot) return;
      var hv = parseFloat(lot.shares) || 0, back = Math.min(hv, take);
      var early = res.stocks.filter(function (x) { return x.earlierShares && x.status !== "Sold" && str(x.account) === acct && str(x.ticker).toUpperCase() === t; })[0];
      var put = early ? (function () {
        var eh = parseFloat(early.shares) || 0, ec = parseFloat(early.costBasis) || 0;
        return Object.assign({}, early, { shares: String(round(eh + back, 6)), costBasis: ((eh * ec + back * b.price) / (eh + back)).toFixed(2) });
      })() : Object.assign({}, lot, { id: nextId(), shares: String(round(back, 6)), dateAcquired: "", earlierShares: true, fromHistory: false });
      res.stocks = res.stocks.map(function (x) {
        if (x === lot) return hv - back > 0.0000001 ? Object.assign({}, x, { shares: String(round(hv - back, 6)) }) : null;
        return early && x === early ? put : x;
      }).filter(Boolean);
      if (!early) res.stocks.push(put);
    };
    var lotsOf = function (acct, t) {
      return res.stocks.filter(function (x) {
        return str(x.account) === acct && str(x.ticker).toUpperCase() === t && x.status !== "Sold" && (parseFloat(x.shares) || 0) > 0;
      }).sort(lotOrder(saleMethod(acct)));
    };
    read.stocks.slice().sort(function (a, b) { return a.date.localeCompare(b.date) || (a.side === "B" ? 0 : 1) - (b.side === "B" ? 0 : 1); })
      .forEach(function (e) {
        var k = [broker.name, acctKey(e), e.date, e.symbol, "stock", e.side, e.qty, e.amount].join("|");
        count[k] = (count[k] || 0) + 1; e.key = k + "#" + count[k];
        var acct = mapTo[acctKey(e)], t = e.ticker, price = e.price != null ? e.price : (e.amount && e.qty ? Math.abs(e.amount) / e.qty : 0);
        var what = (e.side === "B" ? "Bought " : "Sold ") + round(e.qty, 6) + " " + t + " (" + acct + ") on " + shortDay(e.date) + " at " + money(price);
        if (acct === SKIP) { res.leftOut++; return; }
        if (seenKeys[e.key]) { res.earlier++; return; }
        var since = opt.synced && opt.synced[acctKey(e)];
        if (!since) { res.stockWaiting.push(what); return; }
        // Typed in by hand already?
        var dup = e.side === "B"
          ? res.stocks.some(function (x) { return str(x.account) === acct && str(x.ticker).toUpperCase() === t && sameQty(x.shares, e.qty) && near(x.dateAcquired, e.date); })
          : res.stocks.some(function (x) { return str(x.account) === acct && str(x.ticker).toUpperCase() === t && x.status === "Sold" && sameQty(x.shares, e.qty) && near(x.soldDate, e.date); });
        var pool = res.openBuys.filter(function (b) { return b.acct === acctKey(e) && b.ticker === t && b.qty > 0.0000001; });
        if (e.date <= since) {
          res.keys.push(e.key);
          if (e.side === "B") {
            res.openBuys.push({ acct: acctKey(e), ticker: t, qty: e.qty, price: price, date: e.date, company: e.company });
            return;
          }
          var left = e.qty, made = [];
          pool.forEach(function (b) {
            if (left <= 0.0000001) return;
            var take = Math.min(b.qty, left); b.qty = round(b.qty - take, 6); left = round(left - take, 6);
            unsplit(acct, t, b, take);
            made.push({ id: nextId(), account: acct, ticker: t, company: (h.tickerName && h.tickerName(t)) || b.company || e.company,
                        shares: String(round(take, 6)), dateAcquired: b.date, costBasis: b.price.toFixed(2), currentPrice: price.toFixed(2),
                        status: "Sold", soldDate: e.date, soldPrice: price.toFixed(2) });
          });
          if (dup) { res.stockAlready++; return; }
          if (made.length) {
            res.stocks = res.stocks.concat(made);
            res.stockAdded.push(what + " (bought " + made.map(function (m) { return shortDay(m.dateAcquired) + " at $" + m.costBasis; }).join(", ") + ")");
          }
          if (left > 0.0000001) preOut.push({ key: e.key, acct: acct, ticker: t, qty: left, date: e.date });
          if (left > 0.0000001) res.stockReview.push(what + ": " + round(left, 6) + " of these shares were bought before the dates in your files, so OptionIQ can't tell their cost. Add the sale in the Stocks tab if you want it in your history.");
          return;
        }
        if (dup) { res.keys.push(e.key); res.stockAlready++; return; }
        if (e.side === "B") {
          res.keys.push(e.key);
          res.stocks = res.stocks.concat([{ id: nextId(), account: acct, ticker: t, company: (h.tickerName && h.tickerName(t)) || e.company,
            shares: String(round(e.qty, 6)), dateAcquired: e.date, costBasis: price.toFixed(2), currentPrice: price.toFixed(2),
            status: "Held", soldDate: "", soldPrice: "" }]);
          res.stockAdded.push(what);
          return;
        }
        var lots = lotsOf(acct, t), have = lots.reduce(function (s, x) { return s + (parseFloat(x.shares) || 0); }, 0);
        if (have + 0.0000001 < e.qty) {
          res.stockReview.push(what + ": OptionIQ shows only " + round(have, 6) + " " + t + " shares in " + acct + ". Check the Stocks tab.");
          return;
        }
        res.keys.push(e.key);
        var remaining = e.qty, patch = {}, adds = [];
        lots.forEach(function (lot) {
          if (remaining <= 0.0000001) return;
          var hv = parseFloat(lot.shares) || 0, take = Math.min(hv, remaining);
          remaining = round(remaining - take, 6);
          var how = lots.length > 1 ? saleMethod(acct) : "";
          if (take >= hv - 0.0000001) patch[lot.id] = Object.assign({}, lot, { status: "Sold", wasStatus: lot.wasStatus || lot.status || "Held", soldDate: e.date, soldPrice: price.toFixed(2), saleMethod: how });
          else {
            patch[lot.id] = Object.assign({}, lot, { shares: String(round(hv - take, 6)) });
            adds.push(Object.assign({}, lot, { id: nextId(), shares: String(round(take, 6)), status: "Sold", wasStatus: lot.wasStatus || lot.status || "Held", soldDate: e.date, soldPrice: price.toFixed(2), saleMethod: how }));
          }
        });
        res.stocks = res.stocks.map(function (x) { return patch[x.id] || x; }).concat(adds);
        res.stockAdded.push(what);
      });
    res.openBuys = res.openBuys.filter(function (b) { return b.qty > 0.0000001; });
    // Every share change from before the Positions check, from this file and
    // earlier ones (opt.preMoves), so a sale in one file can use up a
    // dividend share bought in another.
    var have = {}, touched = {};
    res.preMoves = (opt.preMoves || []).slice();
    res.preMoves.forEach(function (m) { if (m.key) have[m.key] = true; });
    preIn.map(function (m) { return Object.assign({ dir: "in" }, m); }).concat(preOut.map(function (m) { return Object.assign({ dir: "out" }, m); }))
      .forEach(function (m) {
        if (m.key && have[m.key]) return;
        have[m.key] = true; res.preMoves.push(m); touched[m.acct + "|" + m.ticker] = true;
      });
    read.stocks.forEach(function (e) {
      var acct = mapTo[acctKey(e)], since = opt.synced && opt.synced[acctKey(e)];
      if (acct && acct !== SKIP && since && e.date <= since && !seenKeys[e.key]) touched[acct + "|" + e.ticker] = true;
    });
    splitLots(res, res.preMoves, function (k) { return mapTo[k] || (opt.map && opt.map[k] ? real(opt.map[k]) : ""); }, nextId, touched);

    // A buy-back and a new sale of the same stock, same day, same account is
    // a roll: link them the way the Roll dialog does.
    var used = {};
    closedToday.forEach(function (c) {
      var t = c.trade;
      var next = res.add.filter(function (a) {
        return !used[a.id] && a.date === c.date && isOpen(a) && a.account === t.account && a.ticker === t.ticker &&
               a.cp === t.cp && a.sb === t.sb && !(a.expDate === t.expDate && a.strike === t.strike);
      })[0];
      if (!next) return;
      used[next.id] = true;
      var r = Object.assign({}, res.changed[t.id] || res.add.filter(function (a) { return a.id === t.id; })[0] || t,
                            { action: "Rolled", rolledToId: next.id });
      put(finish(r, h));
      next.rolledFromId = t.id;
      res.closed.push("🔁 " + label(t) + " was rolled into the $" + next.strike + " exp " + shortDay(next.expDate));
    });

    res.changedList = Object.keys(res.changed).map(function (k) { return res.changed[k]; });
    return res;
  }

  // The trades and holdings after the import.
  function apply(trades, res) {
    return trades.map(function (t) { return res.changed[t.id] || t; }).concat(res.add);
  }

  // ── Positions file: what the broker says you hold right now ─────
  // Fidelity's Portfolio Positions download (Portfolio_Positions_<date>.csv).
  // Compared with OptionIQ's holdings and open options, account by account;
  // each difference is offered as a fix the person ticks. Nothing else changes.
  var POS_COLS = { number: ["accountnumber"], account: ["accountname"], symbol: ["symbol"], description: ["description"],
                   quantity: ["quantity"], avgCost: ["averagecostbasis"], price: ["lastprice"], costTotal: ["costbasistotal"] };
  function posHeader(rows) {
    for (var i = 0; i < Math.min(rows.length, 30); i++) {
      var h = rows[i].map(norm);
      if (h.indexOf("accountnumber") >= 0 && h.indexOf("symbol") >= 0 && h.indexOf("quantity") >= 0 && h.indexOf("action") < 0) return i;
    }
    return -1;
  }
  function detectPositions(rows) { return posHeader(rows || []) >= 0 ? "Fidelity" : ""; }
  function posAsOf(rows) {
    for (var i = rows.length - 1; i >= 0 && i > rows.length - 15; i--) {
      var m = str(rows[i][0]).match(/Date downloaded\s+([A-Za-z]{3})-(\d{1,2})-(\d{4})/);
      if (m && MON[m[1].toUpperCase()]) return m[3] + "-" + p2(MON[m[1].toUpperCase()]) + "-" + p2(m[2]);
      m = str(rows[i][0]).match(/Date downloaded\s+(\d{1,2}\/\d{1,2}\/\d{4})/);
      if (m) return day(m[1]);
    }
    return "";
  }
  // Stock lots. Which shares a sale takes first, per account (Settings):
  // fifo (oldest first), lifo (newest first) or high (highest cost first).
  // "pick" (by hand) can't be asked here, so files use oldest first for it.
  function saleMethod(acct) {
    var m = {};
    try { m = JSON.parse(root.localStorage.getItem("sale_method_v1") || "{}") || {}; } catch (e) { m = {}; }
    var v = m[str(acct)];
    return v === "lifo" || v === "high" ? v : "fifo";
  }
  function lotOrder(method) {
    var d = function (x) { return str(x.dateAcquired); };
    if (method === "lifo") return function (a, b) { return (d(b) || "0000").localeCompare(d(a) || "0000"); };
    if (method === "high") return function (a, b) { return (parseFloat(b.costBasis) || 0) - (parseFloat(a.costBasis) || 0) || (d(a) || "9999").localeCompare(d(b) || "9999"); };
    return function (a, b) { return (d(a) || "9999-12-31").localeCompare(d(b) || "9999-12-31"); };
  }
  // Shares counted by the Positions check arrive as one holding, marked
  // earlierShares (or a stock's only holding). Buys and reinvested dividends
  // in the activity files from before that check, still held, become their
  // own lots taken out of it, each with its own date and cost. What the files
  // don't explain stays as "earlier shares", costed so the total cost is
  // unchanged. Buys that already have a lot of their own are left alone.
  function splitLots(res, moves, acctOf, nextId, touched) {
    var known = {}, outs = {};
    var add = function (acct, t, x) { var k = acct + "|" + t; (known[k] = known[k] || []).push(x); };
    res.openBuys.forEach(function (b) {
      var acct = acctOf(b.acct);
      if (!acct || acct === SKIP || !(b.qty > 0.0000001)) return;
      add(acct, b.ticker, { qty: b.qty, date: b.date, cost: b.price, company: b.company });
    });
    // Assigned puts, reinvested dividends and shares moved in, from before the check.
    moves.forEach(function (m) {
      if (m.dir === "in") add(m.acct, m.ticker, Object.assign({}, m));
      else (outs[m.acct + "|" + m.ticker] = outs[m.acct + "|" + m.ticker] || []).push(m);
    });
    Object.keys(known).forEach(function (k) {
      if (touched && !touched[k]) return;
      var acct = k.split("|")[0], t = k.slice(acct.length + 1);
      var ins = known[k].sort(function (a, b) { return a.date.localeCompare(b.date); });
      // Shares that left before the check (called away, sold with no buy in
      // these files, moved out) came out of these, oldest first.
      (outs[k] || []).slice().sort(function (a, b) { return a.date.localeCompare(b.date); }).forEach(function (o) {
        var left = o.qty;
        ins.forEach(function (b) {
          if (left <= 0.0000001 || b.date > o.date || !(b.qty > 0)) return;
          var take = Math.min(b.qty, left); b.qty = round(b.qty - take, 6); left = round(left - take, 6);
        });
      });
      // Shares moved in keep their first purchase date at the broker, which
      // the file doesn't give: they stay with the earlier shares.
      var items = ins.filter(function (b) { return b.qty > 0.0000001 && !b.transfer; });
      var held = heldShares(res.stocks, acct, t);
      var src = held.filter(function (x) { return x.earlierShares || x.fromHistory; });
      if (!src.length && held.length === 1) src = held; // an assigned lot keeps its status; only dividends/buys come out of it
      if (!src.length) return;
      var like = function (x, b) { return Math.abs((parseFloat(x.shares) || 0) - b.qty) < 0.001 && x.dateAcquired && daysApart(x.dateAcquired, b.date) <= 3; };
      // Already a lot of its own (typed in, or made by an earlier import): left as it is.
      var others = res.stocks.filter(function (x) { return str(x.account) === acct && str(x.ticker).toUpperCase() === t && src.indexOf(x) < 0; });
      var pool = src.slice();
      items = items.filter(function (b) {
        if (others.some(function (x) { return like(x, b); })) return false;
        var i = -1;
        pool.forEach(function (x, j) { if (i < 0 && !x.earlierShares && like(x, b)) i = j; });
        if (i < 0) return true;
        pool.splice(i, 1); return false;
      });
      // Nothing new to split, and no lot left that the history no longer explains.
      if (!items.length && !pool.some(function (x) { return x.fromHistory; })) return;
      if (!pool.length) return;
      var S = pool.reduce(function (s, x) { return s + (parseFloat(x.shares) || 0); }, 0);
      var K = items.reduce(function (s, b) { return s + b.qty; }, 0);
      if (K > S + 0.0005) return; // more than OptionIQ holds: some were sold, can't tell which
      var srcCost = pool.reduce(function (s, x) { return s + (parseFloat(x.shares) || 0) * (parseFloat(x.costBasis) || 0); }, 0);
      var remShares = round(S - K, 6), remCost = srcCost - items.reduce(function (s, b) { return s + b.qty * b.cost; }, 0);
      // The dated lots cost more than OptionIQ's total for the stock (often
      // the broker counts assigned shares at the strike less the premium):
      // the earlier shares get $0 and the person is told.
      if (remShares > 0.0005 && remCost < -0.5)
        res.notes.push(acct + " " + t + ": the lots in your history cost more than OptionIQ's total cost for this stock, so the " + remShares +
                       " earlier shares were set to $0 a share. Check the cost on the Stocks tab.");
      var base = pool.filter(function (x) { return x.earlierShares; })[0] || pool[0], gone = {};
      pool.forEach(function (x) { gone[x.id] = true; });
      var made = items.map(function (b) {
        return { id: nextId(), account: acct, ticker: t, company: base.company || b.company, shares: String(round(b.qty, 6)),
                 dateAcquired: b.date, costBasis: b.cost.toFixed(2), currentPrice: base.currentPrice, status: b.status || "Held", soldDate: "", soldPrice: "", fromHistory: true };
      });
      if (remShares > 0.0005) {
        var rest = Object.assign({}, base, { shares: String(remShares), earlierShares: true, costBasis: Math.max(0, remCost / remShares).toFixed(2) });
        delete rest.fromHistory;
        if (base.fromHistory) { rest.id = nextId(); rest.dateAcquired = ""; rest.status = "Held"; }
        // The assigned shares came out as their own lot: what's left wasn't assigned.
        if (items.some(function (b) { return b.status === "Assigned"; })) rest.status = "Held";
        made.unshift(rest);
      }
      var before = pool.map(function (x) { return x.shares + "@" + x.dateAcquired; }).sort().join(), after = made.map(function (x) { return x.shares + "@" + x.dateAcquired; }).sort().join();
      if (before === after) return;
      res.stocks = res.stocks.filter(function (x) { return !gone[x.id]; }).concat(made);
      if (items.length) res.stockAdded.push(acct + " " + t + ": " + items.length + " lot" + (items.length === 1 ? "" : "s") + " with their own dates from your history" +
        (remShares > 0.0005 ? " (" + remShares + " earlier shares bought before these files stay as one lot)" : ""));
    });
  }
  function heldShares(stocks, acct, ticker) {
    return stocks.filter(function (x) {
      return str(x.account) === acct && str(x.ticker).toUpperCase() === ticker && x.status !== "Sold" && (parseFloat(x.shares) || 0) > 0;
    });
  }
  function optionKey(t) {
    return str(t.ticker).toUpperCase() + "|" + t.expDate + "|" + t.cp + "|" + (num(t.strike) || 0);
  }
  // opt: { accounts, map, idBase, h }
  function comparePositions(rows, trades, stocks, opt) {
    var hr = posHeader(rows || []);
    if (hr < 0) return null;
    var h = rows[hr].map(norm), col = {};
    Object.keys(POS_COLS).forEach(function (k) { col[k] = -1; POS_COLS[k].some(function (n) { col[k] = h.indexOf(n); return col[k] >= 0; }); });
    var g = function (r, k) { return col[k] >= 0 && col[k] < r.length ? str(r[col[k]]) : ""; };
    var lines = [];
    for (var i = hr + 1; i < rows.length; i++) {
      var r = rows[i], sym = g(r, "symbol").replace(/\s/g, "");
      if (!sym || !g(r, "number") || cashLike(sym, g(r, "description"))) continue;
      var q = num(g(r, "quantity"));
      if (q == null) continue;
      var o = occ(sym);
      lines.push({ acctName: g(r, "account"), acctNum: g(r, "number"), symbol: sym, qty: q, option: o,
                   avgCost: num(g(r, "avgCost")), price: num(g(r, "price")), costTotal: num(g(r, "costTotal")),
                   company: titleCase(g(r, "description")) });
    }
    // Which OptionIQ account each broker account is: chosen before, else the
    // one whose holdings and open options agree with it most.
    var keys = [], byKey = {};
    lines.forEach(function (l) { var k = acctKey(l); if (!byKey[k]) { byKey[k] = []; keys.push(k); } byKey[k].push(l); });
    var openOpts = trades.filter(isOpen);
    var accounts = keys.map(function (k) {
      var first = byKey[k][0], g0 = guessAccount(first.acctName, first.acctNum, opt.accounts, opt.map);
      if (!g0.sure) {
        var best = null, bestN = 1;
        opt.accounts.forEach(function (a) {
          var n = 0;
          byKey[k].forEach(function (l) {
            if (l.option) {
              n += openOpts.some(function (t) { return t.account === a && optionKey(t) === optionKey(l.option); }) ? 1 : 0;
            } else {
              var have = heldShares(stocks, a, l.symbol.toUpperCase()).reduce(function (s, x) { return s + (parseFloat(x.shares) || 0); }, 0);
              n += have && Math.abs(have - l.qty) < 1 ? 1 : 0;
            }
          });
          if (n > bestN) { best = a; bestN = n; }
        });
        // No holdings agree: most likely an account not kept in OptionIQ, so it
        // starts left out rather than filling a wrong account with its shares.
        // Someone just starting (nothing in OptionIQ yet) gets it as a new account.
        var guess = g0;
        g0 = best ? { account: best, sure: true } : { account: SKIP, sure: false };
        if (!best && !trades.length && !stocks.length) g0 = { account: guess.none ? "new" : guess.account, sure: false };
      }
      var m = opt.map && opt.map[k];
      return { key: k, name: first.acctName, number: first.acctNum, lines: byKey[k].length,
               account: validPick(m, opt.accounts) ? m : g0.account, sure: g0.sure };
    });
    nameNew(accounts).forEach(function (a) { if (a.account === "new") a.account = a.newAccount; });
    var res = { broker: "Fidelity", asOf: posAsOf(rows), accounts: accounts, fixes: [], costFixes: [], premiumGaps: [], optionNotes: [], newOptions: [], sameShares: 0, sameOptions: 0, sameCost: 0, notTracked: [] };
    var n = 0;
    accounts.forEach(function (a) {
      if (a.account === SKIP) return;
      var acct = real(a.account), mine = byKey[a.key];
      // Shares.
      var tickers = {};
      mine.forEach(function (l) { if (!l.option) tickers[l.symbol.toUpperCase()] = l; });
      stocks.forEach(function (x) {
        var t = str(x.ticker).toUpperCase();
        if (str(x.account) === acct && x.status !== "Sold" && (parseFloat(x.shares) || 0) > 0 && !tickers[t]) tickers[t] = null;
      });
      Object.keys(tickers).sort().forEach(function (t) {
        var l = tickers[t], lots = heldShares(stocks, acct, t);
        var have = round(lots.reduce(function (s, x) { return s + (parseFloat(x.shares) || 0); }, 0), 6);
        var want = l ? l.qty : 0, diff = round(want - have, 6);
        // Cost per share, after the share fix below (added shares cost $0).
        // "small" = rounding-sized (a few cents), safe to copy.
        if (l && lots.length && l.avgCost != null && have > 0) {
          var total = lots.reduce(function (s, x) { return s + (parseFloat(x.shares) || 0) * (parseFloat(x.costBasis) || 0); }, 0);
          var avg = round(total / (diff > 0 ? want : have), 2), gap = round(l.avgCost - avg, 2);
          // A gap that is just the put money of an assignment: the broker took
          // the premium off the cost. Shown only when the person chose that.
          // (All of that stock's assigned puts in the account, since one lot can
          // hold the shares of several assignments.)
          var premSum = trades.reduce(function (sum, x) {
            if (x.action !== "Assigned" || x.cp !== "P" || str(x.account) !== acct || str(x.ticker).toUpperCase() !== t) return sum;
            var c = parseInt(x.contracts, 10) || 1;
            return sum + (num(x.sellPremium) || 0) * c * 100 - 0.67 * c;
          }, 0);
          var gapTotal = total - l.avgCost * (diff > 0 ? want : have);
          var byPremium = premSum > 0 && Math.abs(gapTotal - premSum) <= Math.max(1.5, premSum * 0.01, 0.006 * (diff > 0 ? want : have)) ||
            // or one assignment's shares at its strike, less its put money
            trades.some(function (x) {
              if (x.action !== "Assigned" || x.cp !== "P" || str(x.account) !== acct || str(x.ticker).toUpperCase() !== t) return false;
              var c = parseInt(x.contracts, 10) || 1, k = num(x.strike) || 0, tol = Math.max(0.05, k * 0.005);
              var prem = (num(x.sellPremium) || 0) * c * 100 - 0.67 * c;
              return Math.abs(k - avg) < tol && Math.abs(l.avgCost - (k - prem / (c * 100))) < tol;
            });
          if (Math.abs(gap) < 0.01) res.sameCost++;
          else if (byPremium && !opt.assignedNet) res.premiumGaps.push(acct + " " + t);
          else res.costFixes.push({ id: "c" + (res.costFixes.length + 1), account: acct, ticker: t, have: avg, want: l.avgCost,
                                    small: byPremium || Math.abs(gap) <= Math.max(0.05, avg * 0.0025), lots: lots.length,
                                    text: acct + " " + t + ": OptionIQ $" + avg.toFixed(2) + ", " + res.broker + " $" + l.avgCost.toFixed(2) +
                                          " (" + (gap > 0 ? "+" : "−") + "$" + Math.abs(gap).toFixed(2) + ")" });
        }
        if (Math.abs(diff) < 0.0005) { res.sameShares++; return; }
        n++;
        if (!l) {
          res.optionNotes.push(acct + ": OptionIQ shows " + have + " " + t + " shares, but " + res.broker +
                               " shows none. If they were sold, mark them sold in the Stocks tab.");
          return;
        }
        var newest = lots.slice().sort(function (x, y) { return str(y.dateAcquired).localeCompare(str(x.dateAcquired)); })[0];
        res.fixes.push({ id: "s" + n, account: acct, ticker: t, have: have, want: want, diff: diff,
                         lotId: newest ? newest.id : null, avgCost: l.avgCost, price: l.price, company: l.company,
                         text: acct + " " + t + ": OptionIQ " + have + ", " + res.broker + " " + want +
                               (newest ? " (" + (diff > 0 ? "+" : "") + diff + ")" : " (not in OptionIQ yet)") });
      });
      // Open options. One OptionIQ doesn't have at all is offered as a new
      // trade (opened before the activity files go back); other differences
      // are reported only (closing a trade needs its price).
      var want = {}, have = {}, line = {};
      mine.forEach(function (l) { if (l.option) { var k = optionKey(l.option); want[k] = (want[k] || 0) + Math.round(l.qty); line[k] = l; } });
      openOpts.forEach(function (t) {
        if (t.account !== acct) return;
        var k = optionKey(t);
        have[k] = (have[k] || 0) + (t.sb === "S" ? -1 : 1) * (parseInt(t.contracts, 10) || 1);
      });
      Object.keys(want).concat(Object.keys(have)).filter(function (k, i, all) { return all.indexOf(k) === i; }).forEach(function (k) {
        var w = want[k] || 0, hv = have[k] || 0, p = k.split("|");
        if (w === hv) { res.sameOptions++; return; }
        var lab = p[0] + " $" + p[3] + " " + (p[2] === "C" ? "call" : "put") + " exp " + shortDay(p[1]);
        var says = function (q) { return q === 0 ? "none" : (q < 0 ? "sold " : "bought ") + Math.abs(q); };
        if (hv === 0 && line[k]) {
          var l = line[k], o = l.option, q = Math.abs(w), sb = w < 0 ? "S" : "B";
          // Premium per share before the fee: from the money in or out (cost
          // basis total, fees taken off), else the average cost.
          var prem = l.costTotal != null ? (Math.abs(l.costTotal) + (sb === "S" ? 0.67 : -0.67) * q) / (100 * q) : Math.abs(l.avgCost || 0);
          // Ticked unless OptionIQ has other open options on that stock in this
          // account (then it may be one of those, typed in differently).
          var near = openOpts.some(function (t) { return t.account === acct && str(t.ticker).toUpperCase() === o.ticker; });
          res.newOptions.push({ id: "o" + (++n), account: acct, ticker: o.ticker, strike: o.strike, cp: o.cp, expDate: o.expDate,
                                contracts: q, sb: sb, premium: round(prem, 2), company: l.company, tick: !near,
                                text: acct + " " + lab + ": " + (sb === "S" ? "sold " : "bought ") + q + " at $" + round(prem, 2).toFixed(2) +
                                      " a share (from " + res.broker + "'s cost)" });
          return;
        }
        res.optionNotes.push(acct + " " + lab + ": OptionIQ " + says(hv) + ", " + res.broker + " " + says(w) + ".");
      });
    });
    return res;
  }
  // Open options from the Positions file, as trades. The day they were opened
  // isn't in that file: they carry its date until an activity file has the
  // opening line, which then fills in the real day and premium.
  function positionTrades(res, ticked, idBase, h) {
    var n = 0;
    return (res.newOptions || []).filter(function (o) { return ticked[o.id]; }).map(function (o) {
      n++;
      var t = { id: (idBase || Date.now()) + 500 + n, account: o.account, date: res.asOf || "", company: (h.tickerName && h.tickerName(o.ticker)) || o.company,
                ticker: o.ticker, strike: String(o.strike), currentStock: "", expDate: o.expDate, sellPremium: String(o.premium),
                contracts: String(o.contracts), cp: o.cp, sb: o.sb, action: "Open", closeDate: "", closePremium: "",
                fromBroker: res.broker, fromPositions: true };
      t.sells = h.calcSells(t.sb, t.sellPremium, t.contracts); t.buys = h.calcBuys(t.sb, t.sellPremium, t.contracts);
      return finish(t, h);
    });
  }
  // The holdings after the ticked fixes: the difference goes on the newest
  // lot (reinvested fractions belong there), or a new holding is added.
  function applyPositions(stocks, res, ticked, idBase, atPrice) {
    var out = stocks.slice(), n = 0;
    res.fixes.forEach(function (f) {
      if (!ticked[f.id]) return;
      if (f.lotId != null && f.diff < 0) {
        // Fewer shares at the broker. When one lot alone holds what the broker
        // shows, the other lots are counted twice: remove them. Otherwise take
        // shares off the newest lots first; a lot that runs out is removed
        // (never left below zero).
        var take = -f.diff, gone = {}, cut = {}, lots = heldShares(out, f.account, f.ticker);
        var whole = lots.filter(function (x) { return Math.abs((parseFloat(x.shares) || 0) - f.want) < 0.0005; })[0];
        if (whole) lots = lots.filter(function (x) { return x !== whole; });
        lots.sort(function (a, b) { return str(b.dateAcquired).localeCompare(str(a.dateAcquired)); })
          .forEach(function (x) {
            if (take <= 0.0000001) return;
            var hv = parseFloat(x.shares) || 0;
            if (hv <= take + 0.0000001) { gone[x.id] = true; take = round(take - hv, 6); }
            else { cut[x.id] = String(round(hv - take, 6)); take = 0; }
          });
        out = out.filter(function (x) { return !gone[x.id]; }).map(function (x) {
          return cut[x.id] != null ? Object.assign({}, x, { shares: cut[x.id] }) : x;
        });
      } else if (f.lotId != null) {
        // Shares added are most likely reinvested dividends: no new money (or,
        // with atPrice, about today's price). They are a lot of their own,
        // "earlier shares", which an activity file can split into dated lots.
        var lot = out.filter(function (x) { return x.id === f.lotId; })[0] || {};
        n++;
        // Their cost: what makes the stock's total cost match the broker's
        // (whole shares are rarely dividends); else a dividend's cost.
        var paid = atPrice ? (f.price || 0) : 0;
        if (f.avgCost != null && f.diff >= 1) {
          var hl = heldShares(out, f.account, f.ticker);
          var tot = hl.reduce(function (s, x) { return s + (parseFloat(x.shares) || 0) * (parseFloat(x.costBasis) || 0); }, 0);
          var c = (f.avgCost * f.want - tot) / f.diff;
          if (c >= 0) paid = c;
        }
        out.push({ id: (idBase || Date.now()) + n, account: f.account, ticker: f.ticker, company: lot.company || f.company,
                   shares: String(round(f.diff, 6)), dateAcquired: res.asOf || "", costBasis: paid.toFixed(2),
                   currentPrice: lot.currentPrice || (f.price || 0).toFixed(2), status: "Held", soldDate: "", soldPrice: "", earlierShares: true });
      } else {
        n++;
        var px = f.avgCost || f.price || 0;
        out.push({ id: (idBase || Date.now()) + n, account: f.account, ticker: f.ticker, company: f.company,
                   shares: String(f.want), dateAcquired: res.asOf || "", costBasis: px.toFixed(2),
                   currentPrice: (f.price || px).toFixed(2), status: "Held", soldDate: "", soldPrice: "", earlierShares: true });
      }
    });
    // Cost per share taken from the broker: every held lot of that stock gets
    // the broker's average, so the holding's average matches it.
    (res.costFixes || []).forEach(function (f) {
      if (!ticked[f.id]) return;
      // With several lots, each keeps its own cost and the whole gap goes on
      // the "earlier shares" lot (else the biggest), so the average matches.
      var lots = heldShares(out, f.account, f.ticker);
      var sh = lots.reduce(function (s, x) { return s + (parseFloat(x.shares) || 0); }, 0);
      var tot = lots.reduce(function (s, x) { return s + (parseFloat(x.shares) || 0) * (parseFloat(x.costBasis) || 0); }, 0);
      var gapTot = f.want * sh - tot;
      var into = lots.filter(function (x) { return x.earlierShares; })[0] ||
                 lots.slice().sort(function (a, b) { return (parseFloat(b.shares) || 0) - (parseFloat(a.shares) || 0); })[0];
      var intoSh = into ? parseFloat(into.shares) || 0 : 0;
      var intoCost = into && intoSh ? (parseFloat(into.costBasis) || 0) + gapTot / intoSh : -1;
      out = out.map(function (x) {
        if (str(x.account) !== f.account || str(x.ticker).toUpperCase() !== f.ticker || x.status === "Sold" || !((parseFloat(x.shares) || 0) > 0)) return x;
        if (lots.length > 1 && intoCost >= 0) return x === into ? Object.assign({}, x, { costBasis: intoCost.toFixed(2) }) : x;
        return Object.assign({}, x, { costBasis: f.want.toFixed(2) });
      });
    });
    return out;
  }

  // The person's cost choices (setup / Settings), kept in the data file:
  // reinvest "zero" (dividends paid for them) or "price"; assigned "strike"
  // (put money counted as option profit) or "net" (strike less put money).
  function costPrefs() {
    var p = {};
    try { p = JSON.parse(root.localStorage.getItem("cost_prefs_v1") || "{}") || {}; } catch (e) { p = {}; }
    return { reinvest: p.reinvest === "price" ? "price" : "zero", assigned: p.assigned === "net" ? "net" : "strike" };
  }

  root.OptionIQBroker = { costPrefs: costPrefs, detect: detect, analyze: analyze, apply: apply, guessAccount: guessAccount, SKIP: SKIP, isNew: isNew, real: real, brokers: ["Fidelity"],
                          detectPositions: detectPositions, positionsDate: posAsOf, comparePositions: comparePositions, applyPositions: applyPositions, positionTrades: positionTrades };
  if (typeof module !== "undefined") module.exports = root.OptionIQBroker;
})(typeof window !== "undefined" ? window : globalThis);
