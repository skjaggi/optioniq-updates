// Desktop storage shim.
//
// The Options Trade Logger screens keep everything in the browser's
// localStorage. In the desktop app that data belongs in a file in the user's
// tracker folder, so this replaces localStorage with an object that reads and
// writes through the local tracker service. It must load before the app.
//
// Reads come from a copy fetched once at startup. Writes go straight to the
// service and wait for it (a local call, a few milliseconds), so nothing is
// lost if the window is closed right after an edit.
(function () {
  "use strict";

  function request(method, path, body) {
    var xhr = new XMLHttpRequest();
    xhr.open(method, path, false); // synchronous on purpose, see above
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(body === undefined ? null : JSON.stringify(body));
    if (xhr.status < 200 || xhr.status >= 300) {
      throw new Error("Tracker service " + xhr.status + ": " + xhr.responseText);
    }
    return xhr.responseText ? JSON.parse(xhr.responseText) : null;
  }

  var boot = request("GET", "/api/kv");
  var items = boot.items || {};
  var accountsAtStart = (boot.accounts || []).slice();
  var reloadPending = false, held = [];

  function reloadFor(names) {
    reloadPending = true;
    setTimeout(function () {
      alert("Added account" + (names.length > 1 ? "s" : "") + " from your data: " +
            names.join(", ") + ".\n\nThe app will reload to show " +
            (names.length > 1 ? "them" : "it") + ". You can rename accounts in ⚙ Settings.");
      location.reload();
    }, 50);
  }

  function write(key, value) {
    try {
      var r = request("POST", "/api/kv", { key: key, value: value });
      // Data brought in from a backup can use account names this person
      // hasn't set up yet. The service adds them; reload so they show
      // (held back while broker files are still being worked through).
      if (r && r.newAccounts && r.newAccounts.length && !reloadPending) {
        if (window.__TRACKER__ && window.__TRACKER__.holdReload) held = held.concat(r.newAccounts);
        else reloadFor(r.newAccounts);
      }
    } catch (err) {
      alert("Your change could not be saved: " + err.message +
            "\n\nIf this keeps happening, close the app and start it again.");
      throw err;
    }
  }

  var store = {
    getItem: function (k) { k = String(k); return Object.prototype.hasOwnProperty.call(items, k) ? items[k] : null; },
    setItem: function (k, v) { k = String(k); v = String(v); if (items[k] === v) return; items[k] = v; write(k, v); },
    removeItem: function (k) { k = String(k); if (!(k in items)) return; delete items[k]; write(k, null); },
    clear: function () { Object.keys(items).forEach(function (k) { store.removeItem(k); }); },
    key: function (i) { return Object.keys(items)[i] || null; },
    get length() { return Object.keys(items).length; }
  };

  Object.defineProperty(window, "localStorage", { value: store, configurable: true });

  window.__TRACKER__ = {
    accounts: accountsAtStart.length ? accountsAtStart : ["My Account"],
    portable: !!boot.portable,
    brand: boot.brand || { app: "OptionIQ", owner: "", notice: "" },
    termsAccepted: !!boot.termsAccepted,
    request: request,
    holdReload: false,
    releaseReload: function () {
      window.__TRACKER__.holdReload = false;
      if (held.length && !reloadPending) reloadFor(held);
      held = [];
    },
    // The logger's 💾 Save Data button: keep a dated copy in My Data\Backups.
    saveBackup: function (json) {
      var r = request("POST", "/api/backup", { content: json });
      if (window.__TRACKER_EXTRAS__) window.__TRACKER_EXTRAS__.refresh();
      return r;
    }
  };
})();

// Tell OptionIQ when its window closes, so on a Mac it can end soon after
// (a reload asks for something again at once, which cancels this).
if (window.top === window && navigator.sendBeacon) {
  window.addEventListener("pagehide", function () { try { navigator.sendBeacon("/api/bye", "{}"); } catch (e) {} });
}
