"""
options_screener.py
-------------------
Core engine for an option-selling / option-buying screener.

Data layer is yfinance (free, delayed). Greeks are computed locally with
Black-Scholes-Merton so they are consistent across every row, rather than
trusting whatever a vendor happens to publish.

The data layer is deliberately isolated in `fetch_ticker_snapshot()` and
`fetch_chain()` -- swap those two functions to move to a paid feed
(Tradier, Polygon, IBKR, Tastytrade) without touching the screening logic.
"""

from __future__ import annotations

import math
import os
import re
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field, asdict
from datetime import date, datetime, timedelta
from typing import Callable, Iterable

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

try:
    import yfinance as yf
except ImportError:  # pragma: no cover
    yf = None


# ----------------------------------------------------------------------------
# Black-Scholes-Merton
# ----------------------------------------------------------------------------

SQRT_2PI = math.sqrt(2.0 * math.pi)


def _norm_cdf(x: float) -> float:
    """Standard normal CDF via erf -- avoids a scipy dependency."""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _norm_pdf(x: float) -> float:
    return math.exp(-0.5 * x * x) / SQRT_2PI


def black_scholes_greeks(
    spot: float,
    strike: float,
    t_years: float,
    vol: float,
    rate: float = 0.04,
    div_yield: float = 0.0,
    kind: str = "put",
) -> dict:
    """
    Return price and Greeks for a European option.

    delta  -- per $1 move in the underlying (calls positive, puts negative)
    gamma  -- change in delta per $1 move
    theta  -- $ decay per calendar day
    vega   -- $ change per 1 volatility point (i.e. per 1%, not per 1.00)
    """
    out = {"model_price": np.nan, "delta": np.nan, "gamma": np.nan,
           "theta": np.nan, "vega": np.nan, "rho": np.nan}

    if not all(np.isfinite([spot, strike, t_years, vol])):
        return out
    if spot <= 0 or strike <= 0 or t_years <= 0 or vol <= 0:
        return out

    sqrt_t = math.sqrt(t_years)
    d1 = (math.log(spot / strike) + (rate - div_yield + 0.5 * vol * vol) * t_years) / (vol * sqrt_t)
    d2 = d1 - vol * sqrt_t

    disc_r = math.exp(-rate * t_years)
    disc_q = math.exp(-div_yield * t_years)
    pdf_d1 = _norm_pdf(d1)

    gamma = disc_q * pdf_d1 / (spot * vol * sqrt_t)
    vega = spot * disc_q * pdf_d1 * sqrt_t / 100.0  # per 1 vol point

    if kind.lower().startswith("c"):
        price = spot * disc_q * _norm_cdf(d1) - strike * disc_r * _norm_cdf(d2)
        delta = disc_q * _norm_cdf(d1)
        theta = (
            -spot * disc_q * pdf_d1 * vol / (2.0 * sqrt_t)
            - rate * strike * disc_r * _norm_cdf(d2)
            + div_yield * spot * disc_q * _norm_cdf(d1)
        ) / 365.0
        rho = strike * t_years * disc_r * _norm_cdf(d2) / 100.0
    else:
        price = strike * disc_r * _norm_cdf(-d2) - spot * disc_q * _norm_cdf(-d1)
        delta = disc_q * (_norm_cdf(d1) - 1.0)
        theta = (
            -spot * disc_q * pdf_d1 * vol / (2.0 * sqrt_t)
            + rate * strike * disc_r * _norm_cdf(-d2)
            - div_yield * spot * disc_q * _norm_cdf(-d1)
        ) / 365.0
        rho = -strike * t_years * disc_r * _norm_cdf(-d2) / 100.0

    return {"model_price": price, "delta": delta, "gamma": gamma,
            "theta": theta, "vega": vega, "rho": rho}


def implied_vol_bisect(
    target_price: float,
    spot: float,
    strike: float,
    t_years: float,
    rate: float = 0.04,
    div_yield: float = 0.0,
    kind: str = "put",
    lo: float = 0.005,
    hi: float = 5.0,
    tol: float = 1e-5,
    max_iter: int = 100,
) -> float:
    """
    Fallback IV solver, used when the feed's own IV is missing or absurd.
    Bisection is slower than Newton but never diverges, which matters when
    screening thousands of illiquid strikes with stale marks.
    """
    if not all(np.isfinite([target_price, spot, strike, t_years])) or target_price <= 0:
        return np.nan
    if t_years <= 0:
        return np.nan

    def price_at(v):
        return black_scholes_greeks(spot, strike, t_years, v, rate, div_yield, kind)["model_price"]

    p_lo, p_hi = price_at(lo), price_at(hi)
    if not (np.isfinite(p_lo) and np.isfinite(p_hi)):
        return np.nan
    if target_price < p_lo or target_price > p_hi:
        return np.nan  # price outside the no-arbitrage band the model can reach

    for _ in range(max_iter):
        mid = 0.5 * (lo + hi)
        p_mid = price_at(mid)
        if abs(p_mid - target_price) < tol:
            return mid
        if p_mid < target_price:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


# ----------------------------------------------------------------------------
# Request pacing
#
# Yahoo throttles hard. Firing 500 symbols at it through 8 threads earns a wall
# of "Too Many Requests", and because every call then fails the scan looks like
# a screening problem rather than a network one. Everything that touches the
# network goes through _paced() so there is a single place that controls rate.
# ----------------------------------------------------------------------------

import random
import threading
import time

_RATE_LOCK = threading.Lock()
# Adaptive pacing. Run at the rate you asked for; halve it the moment Yahoo
# pushes back; creep back up once it stops. A fixed conservative rate makes
# every scan slow to protect against a limit you usually aren't near.
_RATE = {
    "target_interval": 0.10,   # what you asked for
    "interval": 0.10,          # what we're actually using right now
    "next_at": 0.0,
    "ok_streak": 0,
    "slowdowns": 0,
    "speedups": 0,
}
_FLOOR_INTERVAL = 1.0 / 30.0   # never faster than 30/sec
_CEIL_INTERVAL = 2.0           # never slower than one every 2s
_RECOVER_AFTER = 20            # clean calls before easing back up
_RL_STATS = {"hits": 0, "retries": 0, "gave_up": 0, "circuit_open": False}
# Once Yahoo is refusing us consistently, retrying every symbol through a full
# backoff ladder turns a 5-minute scan into an hour of waiting for failures.
# After this many symbols give up entirely, stop retrying and fail fast so the
# scan finishes and can report the problem.
_CIRCUIT_TRIP = 5
_MAX_BACKOFF = 8.0


def set_request_rate(per_second: float) -> None:
    """
    Set the rate to aim for. Pacing then adapts downward from here if Yahoo
    starts refusing, and climbs back toward it when things are clean.
    0 or less disables pacing entirely.
    """
    with _RATE_LOCK:
        iv = 0.0 if per_second <= 0 else max(1.0 / float(per_second), _FLOOR_INTERVAL)
        _RATE["target_interval"] = iv
        _RATE["interval"] = iv
        _RATE["ok_streak"] = 0
        _RATE["slowdowns"] = 0
        _RATE["speedups"] = 0


def _note_throttled() -> None:
    """Back off hard: the cost of being wrong upward is a failed scan."""
    with _RATE_LOCK:
        if _RATE["target_interval"] <= 0:
            return
        _RATE["interval"] = min(max(_RATE["interval"] * 2.0, _FLOOR_INTERVAL), _CEIL_INTERVAL)
        _RATE["ok_streak"] = 0
        _RATE["slowdowns"] += 1


def _note_ok() -> None:
    """Ease back toward the target after a clean run of calls."""
    with _RATE_LOCK:
        if _RATE["target_interval"] <= 0 or _RATE["interval"] <= _RATE["target_interval"]:
            return
        _RATE["ok_streak"] += 1
        if _RATE["ok_streak"] >= _RECOVER_AFTER:
            _RATE["ok_streak"] = 0
            _RATE["interval"] = max(_RATE["interval"] * 0.7, _RATE["target_interval"])
            _RATE["speedups"] += 1


def reset_rate_stats() -> None:
    with _RATE_LOCK:
        _RL_STATS.update(hits=0, retries=0, gave_up=0, circuit_open=False)
        _RATE["slowdowns"] = 0
        _RATE["speedups"] = 0
        _RATE["ok_streak"] = 0


def get_rate_stats() -> dict:
    with _RATE_LOCK:
        s = dict(_RL_STATS)
        iv, tv = _RATE["interval"], _RATE["target_interval"]
        s["requested_rate"] = round(1.0 / tv, 1) if tv > 0 else 0
        s["effective_rate"] = round(1.0 / iv, 1) if iv > 0 else 0
        s["slowdowns"] = _RATE["slowdowns"]
        s["speedups"] = _RATE["speedups"]
        s["throttled_down"] = bool(tv > 0 and iv > tv * 1.01)
        return s


def _is_rate_limited(exc: Exception) -> bool:
    s = str(exc).lower()
    return ("too many requests" in s or "rate limit" in s
            or "429" in s or "temporarily blocked" in s)


def _wait_turn() -> None:
    """Space requests out across every worker thread, at the current rate."""
    with _RATE_LOCK:
        gap = _RATE["interval"]
        if _RATE["target_interval"] <= 0 or gap <= 0:
            return
        now = time.monotonic()
        start = max(now, _RATE["next_at"])
        _RATE["next_at"] = start + gap
        delay = start - now
    if delay > 0:
        time.sleep(delay)


def _paced(fn, *, tries: int = 3, base: float = 1.5):
    """
    Run a network call politely: wait for a slot, and on a rate-limit response
    back off and try again rather than treating it as missing data.
    """
    with _RATE_LOCK:
        # Circuit already tripped: one polite attempt, then move on.
        if _RL_STATS["circuit_open"]:
            tries = 1
    last = None
    for attempt in range(tries):
        _wait_turn()
        try:
            result = fn()
            _note_ok()
            return result
        except Exception as exc:
            last = exc
            if not _is_rate_limited(exc):
                raise
            _note_throttled()
            with _RATE_LOCK:
                _RL_STATS["hits"] += 1
                if attempt == tries - 1:
                    _RL_STATS["gave_up"] += 1
                    if _RL_STATS["gave_up"] >= _CIRCUIT_TRIP:
                        _RL_STATS["circuit_open"] = True
                    raise
                _RL_STATS["retries"] += 1
            time.sleep(min(base * (2 ** attempt), _MAX_BACKOFF)
                       + random.uniform(0.0, 0.75))
    raise last  # pragma: no cover


# ----------------------------------------------------------------------------
# Universe
# ----------------------------------------------------------------------------

_SP500_URL = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"

# Fallback slice of large, liquid, heavily-optioned names. Used if the
# Wikipedia scrape fails (no network to that host, layout change, etc.).
_FALLBACK_UNIVERSE = [
    "AAPL", "MSFT", "NVDA", "AMZN", "GOOGL", "META", "TSLA", "BRK-B", "AVGO", "JPM",
    "LLY", "V", "XOM", "UNH", "MA", "COST", "HD", "PG", "JNJ", "WMT",
    "NFLX", "BAC", "CRM", "ORCL", "AMD", "CVX", "KO", "PEP", "ADBE", "TMO",
    "MRK", "ABBV", "CSCO", "ACN", "MCD", "LIN", "PFE", "DIS", "INTC", "IBM",
    "QCOM", "TXN", "GE", "CAT", "VZ", "NOW", "INTU", "AMAT", "MU", "BKNG",
    "GS", "SPGI", "UBER", "RTX", "HON", "AXP", "LOW", "BLK", "PLTR", "T",
    "SBUX", "MDT", "BA", "DE", "SCHW", "C", "MS", "ELV", "GILD", "LMT",
    "MMM", "F", "GM", "PYPL", "SHOP", "SQ", "COIN", "MARA", "RIVN", "SOFI",
]


_SP500_CACHE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sp500_cache.csv")


def _clean_symbol(raw) -> str:
    """Convert to the ticker form Yahoo expects, or '' if it isn't one."""
    t = str(raw).strip().upper().replace(".", "-")   # BRK.B -> BRK-B
    if not t or len(t) > 6 or not re.fullmatch(r"[A-Z\-]+", t):
        return ""
    return t


def _dedupe_pairs(pairs) -> list:
    out, seen = [], set()
    for sym, sector in pairs:
        if not sym or sym in seen:
            continue
        seen.add(sym)
        out.append((sym, sector or ""))
    return out


def _normalise_symbols(syms) -> list[str]:
    """Clean and de-duplicate a bare list of tickers."""
    return [s for s, _ in _dedupe_pairs((_clean_symbol(x), "") for x in syms)]


def _sp500_via_pandas() -> list[tuple]:
    """Needs lxml, html5lib or bs4 — whichever pandas can find."""
    tables = pd.read_html(_SP500_URL)
    for tbl in tables:
        if "Symbol" not in tbl.columns:
            continue
        sec_col = next((c for c in tbl.columns if "sector" in str(c).lower()), None)
        pairs = []
        for _, r in tbl.iterrows():
            sym = _clean_symbol(r["Symbol"])
            if not sym:
                continue
            pairs.append((sym, str(r[sec_col]).strip() if sec_col else ""))
        pairs = _dedupe_pairs(pairs)
        if len(pairs) > 400:
            return pairs
    raise ValueError("S&P 500 table not found in the page")


def _strip_tags(html_fragment: str) -> str:
    return re.sub(r"<[^>]+>", "", html_fragment).replace("&amp;", "&").strip()


def _sp500_via_regex() -> list[tuple]:
    """
    Same page, no HTML-parser dependency. Walks the table row by row so the
    GICS sector can be read alongside the ticker -- knowing the sector before
    any Yahoo call is what lets a sector-limited scan skip requests entirely.
    """
    import urllib.request
    req = urllib.request.Request(
        _SP500_URL, headers={"User-Agent": "Mozilla/5.0 (options-screener)"})
    with urllib.request.urlopen(req, timeout=25) as r:
        html = r.read().decode("utf-8", "replace")

    pairs = []
    for row in re.split(r"<tr[^>]*>", html):
        cells = re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, re.S)
        if len(cells) < 3:
            continue
        sym = _clean_symbol(_strip_tags(cells[0]))
        if not sym:
            continue
        # Column order on that page: Symbol | Security | GICS Sector | ...
        sector = _strip_tags(cells[2])
        if len(sector) > 40:
            sector = ""
        pairs.append((sym, sector))
    pairs = _dedupe_pairs(pairs)
    if len(pairs) > 400:
        return pairs

    # Fallback: symbols only, if the row structure has shifted.
    syms = _normalise_symbols(
        re.findall(r'<a[^>]+rel="nofollow"[^>]*>([A-Z][A-Z.\-]{0,5})</a>', html))
    if len(syms) > 400:
        return [(x, "") for x in syms]
    raise ValueError(f"only found {len(pairs)} rows / {len(syms)} symbols in the page")


def _sp500_from_cache() -> list[tuple]:
    """Reads the current SYMBOL,Sector format and the older symbols-only one."""
    with open(_SP500_CACHE, "r", encoding="utf-8") as f:
        text = f.read()
    pairs = []
    if "\n" in text.strip():
        for line in text.splitlines():
            if not line.strip():
                continue
            bits = line.split(",", 1)
            sym = _clean_symbol(bits[0])
            if sym:
                pairs.append((sym, bits[1].strip() if len(bits) > 1 else ""))
    else:
        pairs = [(x, "") for x in _normalise_symbols(text.split(","))]
    pairs = _dedupe_pairs(pairs)
    if len(pairs) > 400:
        return pairs
    raise ValueError("cache too small")


def _write_sp500_cache(pairs) -> None:
    try:
        with open(_SP500_CACHE, "w", encoding="utf-8") as f:
            f.write("\n".join(f"{sym},{sector}" for sym, sector in pairs))
    except Exception:
        pass   # a read-only folder shouldn't break a scan


def get_sp500_universe(use_fallback_on_error: bool = True) -> tuple:
    """
    Current S&P 500 constituents as (symbols, {symbol: GICS sector}, source).

    Tried in order of preference:
      1. pandas.read_html      -- needs lxml/html5lib/bs4
      2. urllib + regex        -- no parser dependency at all
      3. sp500_cache.csv       -- last good result, so this works offline
      4. the built-in ~80 name list (no sectors)

    A successful live fetch refreshes the cache. Sectors come from the
    constituent table itself, which means a sector-limited scan can skip
    symbols without ever asking the data provider about them.
    """
    errors = []
    for fn, label in ((_sp500_via_pandas, "S&P 500 (live)"),
                      (_sp500_via_regex, "S&P 500 (live, direct fetch)")):
        try:
            pairs = fn()
            _write_sp500_cache(pairs)
            return ([p[0] for p in pairs], {p[0]: p[1] for p in pairs}, label)
        except Exception as exc:
            errors.append(f"{fn.__name__}: {type(exc).__name__}: {exc}")

    try:
        pairs = _sp500_from_cache()
        stamp = ""
        try:
            stamp = datetime.fromtimestamp(
                os.path.getmtime(_SP500_CACHE)).strftime("%Y-%m-%d")
        except Exception:
            pass
        label = f"S&P 500 (cached{' ' + stamp if stamp else ''}) — live lookup unavailable"
        return ([p[0] for p in pairs], {p[0]: p[1] for p in pairs}, label)
    except Exception as exc:
        errors.append(f"cache: {type(exc).__name__}: {exc}")

    if not use_fallback_on_error:
        raise RuntimeError("S&P 500 lookup failed:\n  " + "\n  ".join(errors))

    syms = list(_FALLBACK_UNIVERSE)
    label = (f"built-in fallback list ({len(syms)} large caps) — every S&P 500 "
             "lookup failed: " + " | ".join(errors[:2]))
    return (syms, {}, label)


def get_sp500_tickers(use_fallback_on_error: bool = True,
                      with_source: bool = False):
    """Symbols only. Kept for the CLI and anything that doesn't need sectors."""
    syms, _sectors, label = get_sp500_universe(use_fallback_on_error)
    return (syms, label) if with_source else syms


def get_risk_free_rate(default: float = 0.043) -> float:
    """13-week T-bill yield (^IRX) as the short-rate proxy."""
    if yf is None:
        return default
    try:
        hist = _paced(lambda: yf.Ticker("^IRX").history(period="5d"), tries=2)
        if len(hist):
            r = float(hist["Close"].dropna().iloc[-1]) / 100.0
            if 0.0 <= r < 0.25:
                return r
    except Exception:
        pass
    return default


# ----------------------------------------------------------------------------
# Data layer  (replace these two functions to change provider)
# ----------------------------------------------------------------------------

@dataclass
class Snapshot:
    ticker: str
    spot: float = np.nan
    pe: float = np.nan            # trailing P/E
    forward_pe: float = np.nan
    div_yield: float = 0.0
    market_cap: float = np.nan
    beta: float = np.nan
    sector: str = ""
    name: str = ""
    prev_close: float = np.nan    # previous session's close, for today's move
    next_earnings: date | None = None
    error: str = ""
    # --- quality metrics, all from the same get_info() call ---
    profit_margin: float = np.nan     # net margin, as a fraction
    roe: float = np.nan               # return on equity, as a fraction
    revenue_growth: float = np.nan    # yoy, as a fraction
    earnings_growth: float = np.nan   # yoy, as a fraction
    eps: float = np.nan               # trailing EPS
    avg_volume: float = np.nan        # shares/day, a liquidity proxy

    @property
    def day_change(self) -> float:
        """Today's move in dollars. NaN if either end is unknown."""
        if np.isfinite(self.spot) and np.isfinite(self.prev_close):
            return self.spot - self.prev_close
        return np.nan

    @property
    def day_change_pct(self) -> float:
        if np.isfinite(self.day_change) and np.isfinite(self.prev_close) and self.prev_close > 0:
            return self.day_change / self.prev_close * 100.0
        return np.nan


def fetch_ticker_snapshot(ticker: str, want_earnings: bool = True) -> Snapshot:
    """Fundamentals + last price for one symbol."""
    snap = Snapshot(ticker=ticker)
    if yf is None:
        snap.error = "yfinance not installed"
        return snap
    try:
        tk = yf.Ticker(ticker)
        info = {}
        try:
            info = _paced(lambda: tk.get_info()) or {}
        except Exception as exc:
            if _is_rate_limited(exc):
                snap.error = "rate limited"
                return snap
            try:
                info = getattr(tk, "info", {}) or {}
            except Exception:
                info = {}

        # One history call at most, shared by the price and previous-close
        # lookups, so adding day change costs no extra requests.
        _hist = {}

        def closes():
            if "c" not in _hist:
                try:
                    h = _paced(lambda: tk.history(period="5d"))
                    _hist["c"] = h["Close"].dropna() if len(h) else pd.Series(dtype=float)
                except Exception:
                    _hist["c"] = pd.Series(dtype=float)
            return _hist["c"]

        spot = info.get("currentPrice") or info.get("regularMarketPrice")
        if not spot:
            c = closes()
            if len(c):
                spot = float(c.iloc[-1])
        snap.spot = float(spot) if spot else np.nan

        prev = _safe_float(info.get("regularMarketPreviousClose")
                           or info.get("previousClose"))
        if not np.isfinite(prev):
            c = closes()
            # Second-to-last close, since the last one is today.
            if len(c) >= 2:
                prev = float(c.iloc[-2])
        snap.prev_close = prev

        snap.pe = _safe_float(info.get("trailingPE"))
        snap.forward_pe = _safe_float(info.get("forwardPE"))
        # Needs the price, so this must come after spot is resolved.
        snap.div_yield = _dividend_yield(info, snap.spot)
        snap.market_cap = _safe_float(info.get("marketCap"))
        snap.beta = _safe_float(info.get("beta"))
        snap.sector = info.get("sector") or ""
        snap.name = info.get("shortName") or info.get("longName") or ticker

        snap.profit_margin = _safe_float(info.get("profitMargins"))
        snap.roe = _safe_float(info.get("returnOnEquity"))
        snap.revenue_growth = _safe_float(info.get("revenueGrowth"))
        snap.earnings_growth = _safe_float(info.get("earningsGrowth")
                                           or info.get("earningsQuarterlyGrowth"))
        snap.eps = _safe_float(info.get("trailingEps"))
        snap.avg_volume = _safe_float(info.get("averageVolume")
                                      or info.get("averageDailyVolume10Day"))

        if want_earnings:
            snap.next_earnings = _next_earnings_date(tk, info)
    except Exception as exc:
        snap.error = f"{type(exc).__name__}: {exc}"
    return snap


def _expected_prev_session(d: date):
    """
    The session that should precede `d`, ignoring holidays. Weekend-aware only,
    so the day after a holiday looks like a gap and triggers a lookup that
    quietly finds nothing -- which costs one request and reports honestly,
    rather than presenting a two-day move as a day change.
    """
    try:
        wd = d.weekday()          # Mon=0
        if wd == 0:
            return d - timedelta(days=3)
        if wd in (1, 2, 3, 4):
            return d - timedelta(days=1)
        return None               # a bar dated on a weekend is not trustworthy
    except Exception:
        return None


def _close_from_minutes(ticker: str, want: date):
    """
    That session's closing price, taken from the last 1-minute bar of the day.
    Returns (close, date) or (None, None).
    """
    try:
        m = _paced(lambda: yf.Ticker(ticker).history(period="5d", interval="1m"))
    except Exception:
        return None, None
    if m is None or not len(m) or "Close" not in m:
        return None, None
    try:
        s = m["Close"].dropna()
        day = s[s.index.date == want]
        if not len(day):
            return None, None
        return round(float(day.iloc[-1]), 4), want
    except Exception:
        return None, None


def quote_stocks(tickers: Iterable[str], max_workers: int = 6) -> dict:
    """
    Last price and previous close for a list of symbols.

    Exists because the browser fetches stock quotes straight from Finnhub, and
    a real-time US quote is an exchange-licensed product -- a free key can be
    served a stale last-close depending on where the request comes from, with
    no error to show for it. This path goes through the same yfinance history
    endpoint the screener already uses, so it works wherever the screener does.

    Returns the bar timestamp with every quote so the caller can tell a live
    price from Friday's close instead of having to assume.
    """
    syms = [str(t).strip().upper() for t in dict.fromkeys(tickers) if str(t).strip()]
    quotes: dict = {}
    errors: dict = {}
    if yf is None:
        return {"quotes": {}, "errors": {s: "yfinance not installed" for s in syms}}

    def one(tkr: str) -> dict:
        try:
            # auto_adjust=False matters here. Adjusted closes restate every past
            # bar for dividends and splits, so on an ex-dividend morning the
            # "previous close" would be the adjusted one and the day change
            # would disagree with every quote screen you can compare it to.
            # Day change has to be measured against the raw printed close.
            # A month, not five days. Yahoo's 5d window has been observed
            # returning four bars with a session missing from the middle --
            # ARM on 2026-08-28 came back absent, so the "previous close" was
            # Thursday's and the day change silently spanned three sessions.
            # A longer window costs the same one request and survives a gap.
            h = _paced(lambda: yf.Ticker(tkr).history(
                period="1mo", interval="1d", auto_adjust=False))
        except Exception as exc:
            return {"error": "rate limited" if _is_rate_limited(exc)
                    else f"{type(exc).__name__}: {exc}"}
        if h is None or not len(h):
            return {"error": "no price data"}
        c = h["Close"].dropna()
        if not len(c):
            return {"error": "no price data"}
        last = float(c.iloc[-1])
        ts = c.index[-1]
        # The prior *session*, chosen by date rather than by position. Identical
        # to iloc[-2] when the series is complete, and correct when it isn't.
        prev = np.nan
        try:
            prior = c[c.index.date < ts.date()]
            if len(prior):
                prev = float(prior.iloc[-1])
        except Exception:
            prev = float(c.iloc[-2]) if len(c) >= 2 else np.nan
        if not np.isfinite(prev) and len(c) >= 2:
            prev = float(c.iloc[-2])
        prev_date = None
        try:
            prior = c[c.index.date < ts.date()]
            if len(prior):
                prev_date = prior.index[-1].date().isoformat()
        except Exception:
            pass

        # Yahoo's daily series drops sessions. ARM has no 2026-08-28 bar at all,
        # so the "previous close" fell back to Thursday and the day change
        # silently covered three sessions.
        #
        # The session is not actually missing from Yahoo -- only from the daily
        # array. The minute bars still have it, and the last minute close of a
        # session IS that session's close. So when there is a hole, go and get
        # it. One extra request, and only for the symbols that need one.
        prev_source = "daily bar"
        expected = _expected_prev_session(ts.date())
        if expected is not None and (prev_date is None
                                     or date.fromisoformat(prev_date) < expected):
            rec_close, rec_date = _close_from_minutes(tkr, expected)
            if rec_close is not None:
                prev, prev_date = rec_close, rec_date.isoformat()
                prev_source = "recovered from 1-minute bars"
            else:
                prev_source = (f"gap in Yahoo's daily data — no {expected.isoformat()} "
                               f"bar, so this is measured from {prev_date}")
        hi = np.nan
        try:
            hh = h["High"].dropna()
            if len(hh):
                hi = float(hh.iloc[-1])
        except Exception:
            pass
        return {
            "price": round(last, 4),
            "prev_close": round(prev, 4) if np.isfinite(prev) else None,
            "prev_date": prev_date,
            "prev_source": prev_source,
            # Session high, so the all-time-high ratchet keeps working on this
            # path instead of silently never advancing.
            "high": round(hi, 4) if np.isfinite(hi) else None,
            "bars": int(len(c)),
            # Exchange-local date of the bar. If this is not today, the feed is
            # not giving you a live price, whatever the number says.
            "asof": ts.isoformat(),
            "asof_date": ts.date().isoformat(),
        }

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futs = {pool.submit(one, s): s for s in syms}
        for fut in as_completed(futs):
            s = futs[fut]
            try:
                r = fut.result()
            except Exception as exc:
                r = {"error": f"{type(exc).__name__}: {exc}"}
            if r.get("error"):
                errors[s] = r["error"]
            else:
                quotes[s] = r

    return {"quotes": quotes, "errors": errors,
            "requested": len(syms), "returned": len(quotes)}


def benchmark_returns(start: str, end: str,
                      symbols: Iterable[str] = ("SPY", "QQQ")) -> dict:
    """
    Total return of each benchmark between two dates, for comparing an option
    book against simply having held the index.

    Uses adjusted closes -- auto_adjust=True here, deliberately, and the
    opposite of what quote_stocks wants. A day change must be measured against
    the raw printed close, but a multi-month return has to include the
    dividends you would have received, or the index is understated.
    """
    out: dict = {}
    if yf is None:
        return {"error": "yfinance not installed"}
    try:
        s = pd.Timestamp(start).normalize()
        e = pd.Timestamp(end).normalize()
    except Exception as exc:
        return {"error": f"bad dates: {exc}"}
    if e <= s:
        return {"error": "end date must be after the start date"}

    for sym in symbols:
        sym = str(sym).strip().upper()
        try:
            # A few days of padding either side so a weekend or holiday start
            # still finds a bar to anchor on.
            h = _paced(lambda: yf.Ticker(sym).history(
                start=(s - pd.Timedelta(days=7)).date().isoformat(),
                end=(e + pd.Timedelta(days=2)).date().isoformat(),
                interval="1d", auto_adjust=True))
            if h is None or not len(h):
                out[sym] = {"error": "no price data"}
                continue
            c = h["Close"].dropna()
            if getattr(c.index, "tz", None) is not None:
                c.index = c.index.tz_localize(None)
            at_or_before = c[c.index <= s]
            first = at_or_before.iloc[-1] if len(at_or_before) else c.iloc[0]
            first_d = (at_or_before.index[-1] if len(at_or_before) else c.index[0]).date()
            upto = c[c.index <= e]
            last = upto.iloc[-1] if len(upto) else c.iloc[-1]
            last_d = (upto.index[-1] if len(upto) else c.index[-1]).date()
            days = max((last_d - first_d).days, 1)
            total = (float(last) / float(first) - 1.0) * 100.0
            out[sym] = {
                "start": first_d.isoformat(), "end": last_d.isoformat(),
                "startPrice": round(float(first), 4),
                "endPrice": round(float(last), 4),
                "days": days,
                "totalPct": round(total, 2),
                "annualizedPct": round(total * 365.0 / days, 2),
            }
        except Exception as exc:
            out[sym] = {"error": "rate limited" if _is_rate_limited(exc)
                        else f"{type(exc).__name__}: {exc}"}
    return out


def fetch_chain(ticker: str, expiry: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return (calls, puts) DataFrames for one expiration."""
    tk = yf.Ticker(ticker)
    chain = _paced(lambda: tk.option_chain(expiry))
    return chain.calls, chain.puts


def _safe_float(x) -> float:
    try:
        v = float(x)
        return v if np.isfinite(v) else np.nan
    except (TypeError, ValueError):
        return np.nan


def _dividend_yield(info: dict, spot: float) -> float:
    """
    Annual dividend yield as a fraction: 0.0046 means 0.46%.

    Yahoo's `dividendYield` has shipped in both units over the years -- 0.0046
    and 0.46 for the same 0.46% stock -- so guessing from magnitude is
    unreliable, and it fails exactly where it hurts: on low-yield names, which
    is most of them. A 0.46% yielder came out as 46%, which then fed straight
    into the Black-Scholes carry term.

    So derive it instead. Dollars of dividend over share price is unambiguous
    whatever units the yield field happens to be in today.
    """
    rate = _safe_float(info.get("dividendRate"))
    if not np.isfinite(rate):
        rate = _safe_float(info.get("trailingAnnualDividendRate"))
    if np.isfinite(rate) and rate > 0 and np.isfinite(spot) and spot > 0:
        y = rate / spot
        if 0.0 <= y < 0.5:          # >50% is a data error, not a dividend
            return y

    # This one has consistently been a true fraction.
    y = _safe_float(info.get("trailingAnnualDividendYield"))
    if np.isfinite(y) and 0.0 <= y < 0.5:
        return y

    # Last resort: the ambiguous field. Real yields above ~25% do not exist,
    # so a value that large is percent-encoded rather than a fraction.
    v = _safe_float(info.get("dividendYield"))
    if not np.isfinite(v) or v <= 0:
        return 0.0
    if v > 0.25:
        v = v / 100.0
    return v if 0.0 <= v < 0.5 else 0.0


def _next_earnings_date(tk, info: dict) -> date | None:
    try:
        cal = tk.calendar
        if isinstance(cal, dict):
            vals = cal.get("Earnings Date") or []
            if vals:
                d = vals[0]
                return d if isinstance(d, date) else pd.Timestamp(d).date()
        elif isinstance(cal, pd.DataFrame) and "Earnings Date" in cal.index:
            return pd.Timestamp(cal.loc["Earnings Date"].iloc[0]).date()
    except Exception:
        pass
    ts = info.get("earningsTimestamp") or info.get("earningsTimestampStart")
    if ts:
        try:
            return datetime.utcfromtimestamp(int(ts)).date()
        except Exception:
            return None
    return None


# ----------------------------------------------------------------------------
# Screening criteria
# ----------------------------------------------------------------------------

@dataclass
class Criteria:
    # --- what we're looking for ---
    side: str = "put"                    # "put" (CSP) or "call" (covered call)
    action: str = "sell"                 # "sell" (premium collection) or "buy"

    # --- underlying filters ---
    pe_min: float = 0.0
    pe_max: float = 60.0
    allow_missing_pe: bool = False       # unprofitable / no-PE names
    price_min: float = 20.0
    price_max: float = 1000.0
    market_cap_min: float = 2e9

    # --- contract filters ---
    dte_min: int = 21
    dte_max: int = 60
    iv_min: float = 0.20                 # decimal, 0.20 = 20%
    iv_max: float = 1.50
    delta_min: float = 0.10              # absolute delta
    delta_max: float = 0.35

    # --- liquidity filters ---
    min_open_interest: int = 100
    min_volume: int = 0
    max_spread_pct: float = 0.15         # (ask-bid)/mid
    min_bid: float = 0.10

    # --- return filters ---
    min_annualized_yield: float = 0.15   # 15% annualized on collateral
    min_premium: float = 0.20            # $ per share

    # --- risk hygiene ---
    exclude_earnings_before_expiry: bool = False
    # Look up earnings dates so contracts spanning one can be flagged, even when
    # you are not filtering them out. Kept separate from the filter above: if
    # fetching were tied to filtering, the warning would silently never appear
    # for anyone who left the filter off. Costs one extra request per symbol.
    flag_earnings: bool = True
    max_results_per_ticker: int = 3

    # Cap on how many expiries inside the DTE window get fetched per symbol.
    # 0 means every one of them. Only matters for wide windows or big scans.
    max_expiries: int = 0

    # --- position awareness (covered calls) ---
    enforce_cost_basis_floor: bool = True
    # Strike must be at least this much above cost basis, as a fraction.
    # 0.0 = strike may equal cost basis; 0.05 = require 5% above.
    cost_basis_margin: float = 0.0


@dataclass
class Position:
    """
    What the user actually owns in one underlying, aggregated across accounts.

    committed_contracts is the number of short calls already open against
    these shares -- each one ties up 100 shares, so it reduces how many more
    calls can be covered.
    """
    ticker: str
    shares: float = 0.0
    cost_basis: float = np.nan          # weighted average, per share
    committed_contracts: int = 0
    accounts: list = field(default_factory=list)

    @property
    def total_contracts(self) -> int:
        return int(self.shares // 100)

    @property
    def available_contracts(self) -> int:
        return max(self.total_contracts - self.committed_contracts, 0)


def build_positions(holdings: list[dict], open_calls: list[dict]) -> dict[str, Position]:
    """
    Collapse the app's holdings and open short calls into one Position per ticker.

    holdings:   [{ticker, shares, costBasis, account, status}, ...]
    open_calls: [{ticker, contracts, account}, ...]   (short calls still open)

    Cost basis is share-weighted, so two lots bought at different prices give
    the blended number rather than whichever happened to be last.
    """
    pos: dict[str, Position] = {}

    for h in holdings or []:
        tkr = str(h.get("ticker", "")).strip().upper()
        if not tkr:
            continue
        if str(h.get("status", "Held")) == "Sold":
            continue
        shares = _safe_float(h.get("shares"))
        if not np.isfinite(shares) or shares <= 0:
            continue
        cb = _safe_float(h.get("costBasis"))

        p = pos.setdefault(tkr, Position(ticker=tkr, cost_basis=0.0))
        # running share-weighted cost basis
        prior_shares = p.shares
        prior_cost = (p.cost_basis or 0.0) * prior_shares
        add_cost = (cb if np.isfinite(cb) else 0.0) * shares
        p.shares = prior_shares + shares
        p.cost_basis = (prior_cost + add_cost) / p.shares if p.shares else np.nan

        acct = h.get("account")
        if acct and acct not in p.accounts:
            p.accounts.append(acct)

    for c in open_calls or []:
        tkr = str(c.get("ticker", "")).strip().upper()
        if not tkr or tkr not in pos:
            continue
        n = _safe_float(c.get("contracts"))
        pos[tkr].committed_contracts += int(n) if np.isfinite(n) and n > 0 else 0

    return pos


def _clean_num(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def screen_ticker(
    snap: Snapshot,
    crit: Criteria,
    rate: float,
    today: date | None = None,
    position: "Position | None" = None,
) -> list[dict]:
    """
    Run the full contract-level screen for a single underlying.

    `position` is only consulted for covered calls. When supplied, the screen
    refuses to show a call you cannot actually cover with shares you own, and
    (if enforce_cost_basis_floor is on) refuses strikes that would have you
    sell below what you paid.
    """
    if yf is None or snap.error or not np.isfinite(snap.spot):
        return []

    today = today or date.today()

    # --- position gates (covered calls only) ---
    cb_floor = -np.inf
    avail_contracts = None
    if crit.side == "call" and position is not None:
        avail_contracts = position.available_contracts
        if avail_contracts < 1:
            return []  # every lot is already written against
        if crit.enforce_cost_basis_floor and np.isfinite(position.cost_basis) \
                and position.cost_basis > 0:
            cb_floor = position.cost_basis * (1.0 + crit.cost_basis_margin)

    # --- underlying-level gates (cheap, do them first) ---
    if not (crit.price_min <= snap.spot <= crit.price_max):
        return []
    if np.isfinite(snap.market_cap) and snap.market_cap < crit.market_cap_min:
        return []
    if np.isfinite(snap.pe):
        if not (crit.pe_min <= snap.pe <= crit.pe_max):
            return []
    elif not crit.allow_missing_pe:
        return []

    try:
        expiries = _paced(lambda: yf.Ticker(snap.ticker).options) or []
    except Exception:
        return []

    # Work out which expiries qualify before fetching anything. A wide DTE
    # window can cover half a dozen expiries, and each one is a request -- over
    # a few hundred stocks that is the difference between a quick scan and a
    # rate-limited one. max_expiries caps it, keeping those nearest the middle
    # of your window.
    eligible = []
    for expiry in expiries:
        try:
            exp_date = datetime.strptime(expiry, "%Y-%m-%d").date()
        except ValueError:
            continue
        dte = (exp_date - today).days
        if not (crit.dte_min <= dte <= crit.dte_max):
            continue
        if crit.exclude_earnings_before_expiry and snap.next_earnings:
            if today <= snap.next_earnings <= exp_date:
                continue
        eligible.append((expiry, exp_date, dte))

    if crit.max_expiries and len(eligible) > crit.max_expiries:
        mid = (crit.dte_min + crit.dte_max) / 2.0
        eligible.sort(key=lambda e: abs(e[2] - mid))
        eligible = sorted(eligible[:crit.max_expiries], key=lambda e: e[2])

    rows: list[dict] = []
    for expiry, exp_date, dte in eligible:

        try:
            calls, puts = fetch_chain(snap.ticker, expiry)
        except Exception:
            continue

        df = calls if crit.side == "call" else puts
        if df is None or df.empty:
            continue
        df = df.copy()

        for col in ("bid", "ask", "lastPrice", "strike", "impliedVolatility", "volume", "openInterest"):
            if col not in df.columns:
                df[col] = np.nan
            df[col] = _clean_num(df[col])
        df["volume"] = df["volume"].fillna(0)
        df["openInterest"] = df["openInterest"].fillna(0)

        # Mid price; fall back to last trade when one side of the book is empty.
        mid = (df["bid"] + df["ask"]) / 2.0
        mid = mid.where((df["bid"] > 0) & (df["ask"] > 0), df["lastPrice"])
        df["mid"] = mid
        df["spread_pct"] = np.where(
            (df["bid"] > 0) & (df["ask"] > 0) & (mid > 0),
            (df["ask"] - df["bid"]) / mid,
            np.nan,
        )

        # --- liquidity gates ---
        df = df[df["mid"] >= crit.min_premium]
        df = df[df["bid"].fillna(0) >= crit.min_bid]
        df = df[df["openInterest"] >= crit.min_open_interest]
        df = df[df["volume"] >= crit.min_volume]
        df = df[(df["spread_pct"].isna()) | (df["spread_pct"] <= crit.max_spread_pct)]
        if df.empty:
            continue

        t_years = max(dte, 1) / 365.0

        for _, r in df.iterrows():
            strike = float(r["strike"])
            premium = float(r["mid"])
            if not np.isfinite(strike) or strike <= 0:
                continue

            # Never suggest calling away shares below what they cost.
            if strike < cb_floor:
                continue

            iv = _safe_float(r["impliedVolatility"])
            if not np.isfinite(iv) or iv <= 0.01 or iv > 5.0:
                iv = implied_vol_bisect(
                    premium, snap.spot, strike, t_years, rate, snap.div_yield, crit.side
                )
            if not np.isfinite(iv) or not (crit.iv_min <= iv <= crit.iv_max):
                continue

            g = black_scholes_greeks(
                snap.spot, strike, t_years, iv, rate, snap.div_yield, crit.side
            )
            delta = g["delta"]
            if not np.isfinite(delta):
                continue
            abs_delta = abs(delta)
            if not (crit.delta_min <= abs_delta <= crit.delta_max):
                continue

            # --- return math ---
            if crit.side == "put":
                collateral = strike                      # cash-secured
                breakeven = strike - premium
                moneyness = (snap.spot - strike) / snap.spot      # % OTM cushion
                max_profit = premium
                assign_note = f"Own at {breakeven:.2f} ({(breakeven/snap.spot - 1)*100:+.1f}% vs spot)"
            else:
                collateral = snap.spot                   # covered by shares
                breakeven = snap.spot - premium
                moneyness = (strike - snap.spot) / snap.spot
                max_profit = premium + max(strike - snap.spot, 0.0)
                assign_note = f"Called away at {strike:.2f} ({(strike/snap.spot - 1)*100:+.1f}% vs spot)"

            static_yield = premium / collateral
            annualized = static_yield * (365.0 / max(dte, 1))
            if annualized < crit.min_annualized_yield:
                continue

            # If assigned at expiry on a call, total return includes cap gain.
            if_called = (max_profit / collateral) * (365.0 / max(dte, 1)) if crit.side == "call" else annualized

            rows.append({
                "Ticker": snap.ticker,
                "Name": snap.name,
                "Sector": snap.sector,
                "Spot": round(snap.spot, 2),
                "Prev Close": round(snap.prev_close, 2) if np.isfinite(snap.prev_close) else None,
                "Day $": round(snap.day_change, 2) if np.isfinite(snap.day_change) else None,
                "Day %": round(snap.day_change_pct, 2) if np.isfinite(snap.day_change_pct) else None,
                "PE": round(snap.pe, 1) if np.isfinite(snap.pe) else None,
                "Side": "PUT" if crit.side == "put" else "CALL",
                "Expiry": expiry,
                "DTE": dte,
                "Strike": strike,
                "Bid": _r(r["bid"]),
                "Ask": _r(r["ask"]),
                "Mid": round(premium, 2),
                "IV": round(iv, 4),
                "Delta": round(delta, 3),
                "AbsDelta": round(abs_delta, 3),
                "Gamma": round(g["gamma"], 4),
                "Theta/day": round(g["theta"], 3),
                "Vega": round(g["vega"], 3),
                "PoP (est)": round(1 - abs_delta, 3),
                "OTM %": round(moneyness * 100, 2),
                "Breakeven": round(breakeven, 2),
                "Static Yield %": round(static_yield * 100, 2),
                "Annualized %": round(annualized * 100, 2),
                "Ann. If Called %": round(if_called * 100, 2),
                "Collateral $": round(collateral * 100, 0),
                "Premium $": round(premium * 100, 0),
                "OI": int(r["openInterest"]),
                "Volume": int(r["volume"]),
                "Spread %": round(r["spread_pct"] * 100, 1) if np.isfinite(r["spread_pct"]) else None,
                "Model Edge %": round((premium / g["model_price"] - 1) * 100, 1)
                                if np.isfinite(g["model_price"]) and g["model_price"] > 0.01 else None,
                "Earnings Before Exp": bool(
                    snap.next_earnings and today <= snap.next_earnings <= exp_date
                ),
                "Next Earnings": snap.next_earnings.isoformat() if snap.next_earnings else "",
                "Note": assign_note,
                # --- position context (covered calls) ---
                "Shares": round(position.shares, 0) if position else None,
                "Cost Basis": round(position.cost_basis, 2)
                              if position and np.isfinite(position.cost_basis) else None,
                "Contracts Avail": avail_contracts,
                "Accounts": ", ".join(position.accounts) if position and position.accounts else "",
                "Gain vs Basis %": round((strike / position.cost_basis - 1) * 100, 1)
                                   if (crit.side == "call" and position
                                       and np.isfinite(position.cost_basis)
                                       and position.cost_basis > 0) else None,
            })

    if not rows:
        return []

    rows.sort(key=lambda x: x["Annualized %"], reverse=True)
    return rows[: crit.max_results_per_ticker]


def _r(x, nd=2):
    v = _safe_float(x)
    return round(v, nd) if np.isfinite(v) else None


# ----------------------------------------------------------------------------
# Orchestration
# ----------------------------------------------------------------------------

def run_screen(
    tickers: Iterable[str],
    crit: Criteria,
    rate: float | None = None,
    max_workers: int = 8,
    progress_cb: Callable[[int, int, str], None] | None = None,
    positions: dict | None = None,
) -> pd.DataFrame:
    """
    Screen a list of tickers concurrently.

    progress_cb(done, total, current_ticker) is called after each symbol so a
    UI can render a progress bar.

    positions maps TICKER -> Position and is used for covered-call coverage
    and cost-basis checks. Tickers with no position are still screened for
    puts; for calls they are skipped, since you cannot cover them.
    """
    tickers = [t for t in dict.fromkeys(tickers) if t]  # de-dup, keep order
    total = len(tickers)
    if rate is None:
        rate = get_risk_free_rate()

    want_earnings = crit.exclude_earnings_before_expiry or crit.flag_earnings
    all_rows: list[dict] = []
    done = 0

    def work(tkr: str) -> list[dict]:
        pos = (positions or {}).get(tkr)
        if crit.side == "call" and positions is not None and pos is None:
            return []
        snap = fetch_ticker_snapshot(tkr, want_earnings=want_earnings)
        return screen_ticker(snap, crit, rate, position=pos)

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(work, t): t for t in tickers}
        for fut in as_completed(futures):
            tkr = futures[fut]
            try:
                all_rows.extend(fut.result())
            except Exception:
                pass
            done += 1
            if progress_cb:
                progress_cb(done, total, tkr)

    if not all_rows:
        return pd.DataFrame()

    df = pd.DataFrame(all_rows)
    return df.sort_values("Annualized %", ascending=False).reset_index(drop=True)


# ----------------------------------------------------------------------------
# Discovery — find new candidates across a large universe
# ----------------------------------------------------------------------------

@dataclass
class DiscoverCriteria:
    """
    Stock-level screen. Deliberately separate from Criteria: this is about
    finding names worth adding to a watchlist, not about picking a contract.
    """
    # --- stage 1: fundamentals (one request per symbol) ---
    price_min: float = 20.0
    price_max: float = 600.0
    market_cap_min: float = 5e9
    pe_min: float = 0.0
    pe_max: float = 60.0
    require_positive_eps: bool = True
    profit_margin_min: float = 0.05      # 5% net margin
    roe_min: float = 0.10                # 10% return on equity
    revenue_growth_min: float = 0.0      # not shrinking
    avg_volume_min: float = 1_000_000    # shares/day
    # Metrics Yahoo simply doesn't publish for some names. When True a missing
    # value passes rather than silently excluding half the index.
    allow_missing_metrics: bool = True

    # --- stage 2: contracts (only for stage-1 survivors) ---
    # These mirror the Screener tab exactly, so a name that shows up here will
    # behave the same way when you screen it properly later.
    side: str = "put"
    dte_min: int = 21
    dte_max: int = 45
    delta_min: float = 0.15
    delta_max: float = 0.30
    iv_min: float = 0.30
    iv_max: float = 1.50
    min_open_interest: int = 500
    min_volume: int = 0
    max_spread_pct: float = 0.15
    min_bid: float = 0.10
    min_premium: float = 0.20
    min_annualized_yield: float = 0.15
    max_results_per_ticker: int = 1
    # Each expiry inside the DTE window is a separate request. Across a few
    # hundred survivors that adds up fast, so cap it.
    max_expiries: int = 2
    exclude_earnings_before_expiry: bool = False
    flag_earnings: bool = False

    def to_contract_criteria(self) -> "Criteria":
        """The stage-2 screen, expressed as the same Criteria the Screener uses."""
        return Criteria(
            side=self.side,
            pe_min=0.0, pe_max=1e9, allow_missing_pe=True,
            price_min=0.0, price_max=1e9, market_cap_min=0.0,
            dte_min=self.dte_min, dte_max=self.dte_max,
            iv_min=self.iv_min, iv_max=self.iv_max,
            delta_min=self.delta_min, delta_max=self.delta_max,
            min_open_interest=self.min_open_interest,
            min_volume=self.min_volume,
            max_spread_pct=self.max_spread_pct,
            min_bid=self.min_bid,
            min_annualized_yield=self.min_annualized_yield,
            min_premium=self.min_premium,
            exclude_earnings_before_expiry=self.exclude_earnings_before_expiry,
            flag_earnings=self.flag_earnings,
            max_results_per_ticker=self.max_results_per_ticker,
            max_expiries=self.max_expiries,
        )


def discover_stocks(
    tickers: Iterable[str],
    crit: DiscoverCriteria,
    rate: float | None = None,
    max_workers: int = 8,
    progress_cb: Callable[[str, int, int, str], None] | None = None,
    should_stop: Callable[[], bool] | None = None,
) -> dict:
    """
    Two-stage scan.

    Stage 1 pulls fundamentals for every symbol and drops the ones that fail
    on price, size, valuation or quality. Stage 2 fetches option chains only
    for the survivors, which is what keeps a 500-name scan to minutes rather
    than half an hour.

    progress_cb(stage, done, total, ticker) drives the UI.
    Returns {rows, stats}.
    """
    tickers = [str(t).strip().upper() for t in dict.fromkeys(tickers) if str(t).strip()]
    reset_rate_stats()
    if rate is None:
        rate = get_risk_free_rate()

    stats = {"universe": len(tickers), "stage1_pass": 0, "stage2_pass": 0,
             "errors": 0, "stopped": False, "rejects": {}, "observed": None,
             "rate_limited_stage1": 0, "rate_limited_stage2": 0, "rate": None}
    rejects: dict[str, int] = {}
    # Every IV and yield we actually measured, whether or not it passed. When a
    # scan comes back empty this is what turns "nothing matched" into "here is
    # the range you are screening against, and your floor sits above it".
    observed_iv: list[float] = []
    observed_yield: list[float] = []

    def reject(reason):
        rejects[reason] = rejects.get(reason, 0) + 1

    def ok(v, lo=None, hi=None, missing_ok=True):
        """Range test that treats missing data per the criteria's policy."""
        if not np.isfinite(v):
            return missing_ok and crit.allow_missing_metrics
        if lo is not None and v < lo:
            return False
        if hi is not None and v > hi:
            return False
        return True

    # ---------------- stage 1 ----------------
    survivors: list[Snapshot] = []
    done = 0
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futs = {pool.submit(fetch_ticker_snapshot, t, False): t for t in tickers}
        for fut in as_completed(futs):
            if should_stop and should_stop():
                stats["stopped"] = True
                break
            t = futs[fut]
            done += 1
            if progress_cb:
                progress_cb("fundamentals", done, len(tickers), t)
            try:
                snap = fut.result()
            except Exception:
                stats["errors"] += 1
                reject("fetch failed")
                continue
            if snap.error or not np.isfinite(snap.spot):
                stats["errors"] += 1
                # A throttled request is a network problem, not a stock that
                # failed your criteria. Keeping them apart matters: lumping
                # them together made a rate-limited scan look like a strict one.
                if "rate limit" in (snap.error or "").lower():
                    stats["rate_limited_stage1"] += 1
                    reject("⚠ rate limited by Yahoo (not a criteria failure)")
                else:
                    reject("no price data")
                continue
            if not (crit.price_min <= snap.spot <= crit.price_max):
                reject("share price"); continue
            if not ok(snap.market_cap, lo=crit.market_cap_min):
                reject("market cap"); continue
            if not ok(snap.pe, lo=crit.pe_min, hi=crit.pe_max):
                reject("P/E"); continue
            if crit.require_positive_eps and np.isfinite(snap.eps) and snap.eps <= 0:
                reject("negative EPS"); continue
            if not ok(snap.profit_margin, lo=crit.profit_margin_min):
                reject("profit margin"); continue
            if not ok(snap.roe, lo=crit.roe_min):
                reject("return on equity"); continue
            if not ok(snap.revenue_growth, lo=crit.revenue_growth_min):
                reject("revenue growth"); continue
            if not ok(snap.avg_volume, lo=crit.avg_volume_min):
                reject("average volume"); continue
            survivors.append(snap)

    stats["stage1_pass"] = len(survivors)

    # ---------------- stage 2 ----------------
    # The same contract screen the Screener tab runs, on the survivors only.
    rows: list[dict] = []
    done = 0
    contract_crit = crit.to_contract_criteria()
    if not stats["stopped"]:
        def work(snap):
            found = screen_ticker(snap, contract_crit, rate)
            return snap, found

        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futs = {pool.submit(work, s): s for s in survivors}
            for fut in as_completed(futs):
                if should_stop and should_stop():
                    stats["stopped"] = True
                    break
                snap = futs[fut]
                done += 1
                if progress_cb:
                    progress_cb("options", done, len(survivors), snap.ticker)
                try:
                    snap, found = fut.result()
                except Exception as exc:
                    if _is_rate_limited(exc):
                        stats["rate_limited_stage2"] += 1
                        reject("\u26a0 rate limited by Yahoo (not a criteria failure)")
                    else:
                        reject("chain error")
                    continue

                if not found:
                    reject("no contract met the option criteria")
                    continue

                for r in found:
                    iv = r.get("IV")
                    if iv is not None:
                        observed_iv.append(float(iv))
                    ann = r.get("Annualized %")
                    if ann is not None:
                        observed_yield.append(float(ann) / 100.0)
                    # Contract row first, then the fundamentals that got it here.
                    rows.append({
                        **r,
                        "Name": snap.name,
                        "Sector": snap.sector,
                        "Price": round(snap.spot, 2),
                        "Margin %": round(snap.profit_margin * 100, 1) if np.isfinite(snap.profit_margin) else None,
                        "ROE %": round(snap.roe * 100, 1) if np.isfinite(snap.roe) else None,
                        "Rev Growth %": round(snap.revenue_growth * 100, 1) if np.isfinite(snap.revenue_growth) else None,
                        "EPS Growth %": round(snap.earnings_growth * 100, 1) if np.isfinite(snap.earnings_growth) else None,
                        "EPS": round(snap.eps, 2) if np.isfinite(snap.eps) else None,
                        "Mkt Cap $B": round(snap.market_cap / 1e9, 1) if np.isfinite(snap.market_cap) else None,
                        "Avg Vol M": round(snap.avg_volume / 1e6, 1) if np.isfinite(snap.avg_volume) else None,
                        "Beta": round(snap.beta, 2) if np.isfinite(snap.beta) else None,
                        "Div %": round(snap.div_yield * 100, 2) if np.isfinite(snap.div_yield) else None,
                    })

    stats["stage2_pass"] = len(rows)
    stats["rejects"] = dict(sorted(rejects.items(), key=lambda kv: -kv[1]))

    def _spread(vals):
        if not vals:
            return None
        a = np.sort(np.array(vals, dtype=float))
        return {"n": len(a),
                "min": float(a[0]),
                "p50": float(np.percentile(a, 50)),
                "p90": float(np.percentile(a, 90)),
                "max": float(a[-1])}

    stats["observed"] = {"iv": _spread(observed_iv), "yield": _spread(observed_yield),
                         "ivFloor": crit.iv_min, "ivCeiling": crit.iv_max}
    stats["rate"] = get_rate_stats()
    rl = stats["rate_limited_stage1"] + stats["rate_limited_stage2"]
    stats["rate_limited"] = rl
    # If throttling touched a meaningful slice, the numbers below it are not a
    # verdict on your criteria and should not be read as one.
    stats["rate_limit_severe"] = bool(
        rl >= max(10, 0.1 * max(stats["universe"], 1))
        or stats["rate"].get("gave_up", 0) > 0)
    rows.sort(key=lambda r: (r.get("Annualized %") is None, -(r.get("Annualized %") or 0)))
    return {"rows": rows, "stats": stats}


# ----------------------------------------------------------------------------
# Quotes for specific contracts you already hold
# ----------------------------------------------------------------------------

def quote_contracts(contracts: Iterable[dict],
                    progress_cb: Callable[[int, int, str], None] | None = None) -> list[dict]:
    """
    Price a list of specific option contracts.

    contracts: [{ticker, expiry ("YYYY-MM-DD"), strike, cp ("P"/"C")}, ...]

    Grouped by (ticker, expiry) so a chain is fetched once no matter how many
    of your positions sit in it -- four strikes on the same expiry cost one
    request, not four.
    """
    by_chain: dict = {}
    for c in contracts or []:
        tkr = str(c.get("ticker", "")).strip().upper()
        exp = str(c.get("expiry", "")).strip()[:10]
        strike = _safe_float(c.get("strike"))
        cp = str(c.get("cp", "P")).strip().upper()[:1] or "P"
        if not tkr or not exp or not np.isfinite(strike):
            continue
        by_chain.setdefault((tkr, exp), []).append((strike, cp, c.get("id")))

    out: list[dict] = []
    done, total = 0, len(by_chain)
    today = date.today()

    for (tkr, exp), wanted in by_chain.items():
        done += 1
        if progress_cb:
            progress_cb(done, total, tkr)

        # An expiry in the past has no market. Say so rather than fetching a
        # chain that cannot contain it -- these are usually positions that
        # expired and were never marked closed in the log.
        try:
            expired = datetime.strptime(exp, "%Y-%m-%d").date() < today
        except ValueError:
            expired = False
        if expired:
            for strike, cp, cid in wanted:
                out.append({"id": cid, "ticker": tkr, "expiry": exp,
                            "strike": round(strike, 2), "cp": cp, "spot": None,
                            "last": None, "bid": None, "ask": None, "mid": None,
                            "lastTrade": None, "lastStale": None, "offMarket": False,
                            "iv": None, "openInterest": None, "volume": None,
                            "expired": True,
                            "error": "expired — still marked open in your log"})
            continue

        spot = np.nan
        try:
            snap = fetch_ticker_snapshot(tkr, want_earnings=False)
            spot = snap.spot
        except Exception:
            pass

        calls = puts = None
        err = ""
        listed: list = []
        try:
            calls, puts = fetch_chain(tkr, exp)
        except Exception as exc:
            if _is_rate_limited(exc):
                err = "rate limited"
            else:
                # Almost always the expiry simply isn't one this ticker lists.
                # Saying which dates *are* available turns a dead end into a fix.
                try:
                    listed = list(_paced(lambda: yf.Ticker(tkr).options) or [])
                except Exception:
                    listed = []

                def _d(v):
                    """Parse a date, or None. Must never raise: one bad date
                    here would abort the whole batch and blank every row."""
                    try:
                        return datetime.strptime(str(v), "%Y-%m-%d").date()
                    except Exception:
                        return None

                want = _d(exp)
                if want is None:
                    err = (f"expiry '{exp}' isn't a valid YYYY-MM-DD date — "
                           "check the Exp Date on this trade")
                elif listed and exp not in listed:
                    near = sorted(
                        [e for e in listed if _d(e)],
                        key=lambda e: abs((_d(e) - want).days),
                    )[:5]
                    err = (f"{tkr} has no {exp} expiry. It lists {len(listed)} "
                           f"expiries; nearest: {', '.join(sorted(near))}")
                elif not listed:
                    err = f"{tkr}: couldn't read the expiry list ({exc})"
                else:
                    err = f"{type(exc).__name__}: {exc}"

        for strike, cp, cid in wanted:
            rec = {"id": cid, "ticker": tkr, "expiry": exp, "strike": round(strike, 2),
                   "cp": cp, "spot": round(spot, 2) if np.isfinite(spot) else None,
                   "last": None, "bid": None, "ask": None, "mid": None,
                   "lastTrade": None, "lastStale": None, "offMarket": False,
                   "iv": None, "openInterest": None, "volume": None, "error": err}
            df = calls if cp == "C" else puts
            if df is None or getattr(df, "empty", True):
                if not rec["error"]:
                    rec["error"] = "no chain for that expiry"
                out.append(rec)
                continue

            d = df.copy()
            d["strike"] = pd.to_numeric(d["strike"], errors="coerce")
            # Strikes are floats from a feed; match on the nearest within a cent.
            d["gap"] = (d["strike"] - strike).abs()
            hit = d.sort_values("gap").iloc[0] if len(d) else None
            if hit is None or not np.isfinite(hit["gap"]) or hit["gap"] > 0.01:
                avail = sorted(d["strike"].dropna().tolist())
                near = [x for x in avail if abs(x - strike) <= max(strike * 0.06, 5)][:6]
                rec["error"] = (
                    f"no ${strike:g} {'call' if cp == 'C' else 'put'} at {exp}"
                    + (f" — nearest strikes: {', '.join(f'{x:g}' for x in near)}" if near else "")
                )
                out.append(rec)
                continue

            g = lambda k: _safe_float(hit[k]) if k in hit.index else np.nan
            last, bid, ask = g("lastPrice"), g("bid"), g("ask")
            mid = (bid + ask) / 2.0 if (np.isfinite(bid) and np.isfinite(ask)
                                        and bid > 0 and ask > 0) else np.nan

            # When the last trade actually happened. Most option strikes go days
            # or weeks without trading, so lastPrice on its own is not a current
            # value -- it is a fossil. Without this timestamp there is no way to
            # tell a live print from a stale one, and the app was showing both
            # as if they were the same thing.
            lt_iso, lt_stale = None, None
            if "lastTradeDate" in hit.index:
                try:
                    lt = pd.Timestamp(hit["lastTradeDate"])
                    if pd.notna(lt):
                        if lt.tzinfo is None:
                            lt = lt.tz_localize("UTC")
                        lt_iso = lt.isoformat()
                        age_h = (pd.Timestamp.now(tz="UTC") - lt).total_seconds() / 3600.0
                        lt_stale = bool(age_h > 24.0)
                except Exception:
                    pass

            # A last price outside the current bid/ask is stale by definition:
            # nobody would trade there now. 10% beyond either side, plus two
            # cents so penny strikes are not flagged on rounding alone. ARM's
            # 620 put printed 238.85 against a 336.25 bid -- 29% below, which a
            # looser rule missed entirely, and that print was marking the
            # position at two thirds of its real value.
            off_market = bool(
                np.isfinite(last) and np.isfinite(bid) and np.isfinite(ask) and ask > 0
                and (last < bid * 0.9 - 0.02 or last > ask * 1.1 + 0.02)
            )

            rec.update(
                last=round(last, 2) if np.isfinite(last) else None,
                bid=round(bid, 2) if np.isfinite(bid) else None,
                ask=round(ask, 2) if np.isfinite(ask) else None,
                mid=round(mid, 2) if np.isfinite(mid) else None,
                lastTrade=lt_iso,
                lastStale=lt_stale,
                offMarket=off_market,
                iv=round(g("impliedVolatility"), 4) if np.isfinite(g("impliedVolatility")) else None,
                openInterest=int(g("openInterest")) if np.isfinite(g("openInterest")) else None,
                volume=int(g("volume")) if np.isfinite(g("volume")) else None,
                error="",
            )
            out.append(rec)

    return out


# ----------------------------------------------------------------------------
# Position analysis — fundamentals and technicals, scored transparently
#
# Every signal records why it fired. The composite is a plain count of signals,
# not a weighted model pretending to be more than it is: an indicator scorecard
# is a summary of what the numbers say today, and the numbers disagree with each
# other often. Nothing here is advice.
# ----------------------------------------------------------------------------

def _rsi(closes: pd.Series, period: int = 14) -> float:
    """
    Wilder's RSI on the last bar. NaN if there isn't enough history.

    Wilder seeds the averages with a simple mean of the first `period` moves
    and only then applies his smoothing. Starting an EMA at the first delta
    instead gives noticeably different values on short series -- it read 50.7
    where the textbook example gives 70.5 -- so the seeding is done explicitly.
    """
    closes = pd.to_numeric(closes, errors="coerce").dropna()
    if len(closes) < period + 1:
        return np.nan
    delta = closes.diff().dropna()
    gain = delta.clip(lower=0.0).tolist()
    loss = (-delta.clip(upper=0.0)).tolist()

    avg_gain = sum(gain[:period]) / period
    avg_loss = sum(loss[:period]) / period
    for g, l in zip(gain[period:], loss[period:]):
        avg_gain = (avg_gain * (period - 1) + g) / period
        avg_loss = (avg_loss * (period - 1) + l) / period

    if avg_loss == 0:
        return 100.0 if avg_gain > 0 else 50.0
    rs = avg_gain / avg_loss
    return float(100.0 - (100.0 / (1.0 + rs)))


def _macd(closes: pd.Series, fast: int = 12, slow: int = 26, sig: int = 9) -> tuple:
    """Returns (macd, signal, histogram) on the last bar."""
    if len(closes) < slow + sig:
        return (np.nan, np.nan, np.nan)
    ef = closes.ewm(span=fast, adjust=False).mean()
    es = closes.ewm(span=slow, adjust=False).mean()
    macd = ef - es
    signal = macd.ewm(span=sig, adjust=False).mean()
    return (float(macd.iloc[-1]), float(signal.iloc[-1]),
            float(macd.iloc[-1] - signal.iloc[-1]))


def _pct_change_over(closes: pd.Series, sessions: int) -> float:
    if len(closes) <= sessions:
        return np.nan
    then, now = closes.iloc[-1 - sessions], closes.iloc[-1]
    if not (np.isfinite(then) and then > 0):
        return np.nan
    return float((now / then - 1.0) * 100.0)


def _bollinger(closes: pd.Series, period: int = 20, mult: float = 2.0) -> dict:
    """20-period bands and %B: 0 sits on the lower band, 1 on the upper."""
    out = {"bb_upper": np.nan, "bb_lower": np.nan, "bb_mid": np.nan, "bb_pct": np.nan}
    if len(closes) < period:
        return out
    mid = closes.rolling(period).mean().iloc[-1]
    # Population std, which is the convention for Bollinger bands.
    sd = closes.rolling(period).std(ddof=0).iloc[-1]
    if not np.isfinite(mid) or not np.isfinite(sd) or sd <= 0:
        return out
    up, lo = mid + mult * sd, mid - mult * sd
    price = float(closes.iloc[-1])
    return {"bb_upper": float(up), "bb_lower": float(lo), "bb_mid": float(mid),
            "bb_pct": float((price - lo) / (up - lo))}


def _swing_pivots(highs, lows, left: int = 5, right: int = 5):
    """
    Local extremes: a bar whose high is the highest of its neighbourhood is a
    swing high, and vice versa. `right` bars must have printed after it, so the
    most recent few sessions can never form a pivot -- deliberate, since a level
    nobody has traded away from yet isn't a level.
    """
    hs, ls = [], []
    n = len(highs)
    for i in range(left, n - right):
        window_h = highs[i - left:i + right + 1]
        window_l = lows[i - left:i + right + 1]
        if highs[i] >= window_h.max():
            hs.append(float(highs[i]))
        if lows[i] <= window_l.min():
            ls.append(float(lows[i]))
    return hs, ls


def _cluster_levels(levels, tol: float = 0.02):
    """
    Merge levels within `tol` of each other. Price revisiting the same area
    repeatedly is what makes a level meaningful, so the touch count travels
    with it.
    """
    out = []
    for lv in sorted(float(x) for x in levels if np.isfinite(x) and x > 0):
        if out and abs(lv - out[-1]["level"]) / out[-1]["level"] <= tol:
            c = out[-1]
            c["vals"].append(lv)
            c["level"] = sum(c["vals"]) / len(c["vals"])
            c["touches"] = len(c["vals"])
        else:
            out.append({"level": lv, "vals": [lv], "touches": 1})
    for c in out:
        c.pop("vals", None)
    return out


def compute_levels(df: pd.DataFrame, price: float) -> dict:
    """
    Support and resistance from swing pivots, plus the 52-week extremes.
    Returns the nearest level either side of the current price.
    """
    out = {"support": None, "resistance": None, "support_touches": 0,
           "resistance_touches": 0, "levels": [],
           "hi52": np.nan, "lo52": np.nan, "pos52": np.nan}
    if df is None or len(df) < 30 or not np.isfinite(price) or price <= 0:
        return out
    cols = {c.lower(): c for c in df.columns}
    hi_col = cols.get("high")
    lo_col = cols.get("low")
    if hi_col is None or lo_col is None:
        return out

    highs = pd.to_numeric(df[hi_col], errors="coerce").dropna()
    lows = pd.to_numeric(df[lo_col], errors="coerce").dropna()
    if len(highs) < 30 or len(lows) < 30:
        return out

    window = highs.iloc[-252:], lows.iloc[-252:]
    out["hi52"] = float(window[0].max())
    out["lo52"] = float(window[1].min())
    rng = out["hi52"] - out["lo52"]
    if rng > 0:
        out["pos52"] = float((price - out["lo52"]) / rng * 100.0)

    ph, pl = _swing_pivots(highs.values, lows.values)
    # The 52-week extremes are levels in their own right.
    clusters = _cluster_levels(ph + pl + [out["hi52"], out["lo52"]])
    if not clusters:
        return out

    below = [c for c in clusters if c["level"] < price * 0.995]
    above = [c for c in clusters if c["level"] > price * 1.005]
    if below:
        s = max(below, key=lambda c: c["level"])
        out["support"] = round(s["level"], 2)
        out["support_touches"] = s["touches"]
    if above:
        r = min(above, key=lambda c: c["level"])
        out["resistance"] = round(r["level"], 2)
        out["resistance_touches"] = r["touches"]

    # A handful of the best-attested levels, nearest to price first.
    ranked = sorted(clusters, key=lambda c: (-c["touches"], abs(c["level"] - price)))[:6]
    out["levels"] = [{"level": round(c["level"], 2), "touches": c["touches"],
                      "dist": round((c["level"] / price - 1) * 100, 1)}
                     for c in sorted(ranked, key=lambda c: c["level"])]
    return out


def classify_zone(rsi: float, bb_pct: float, pos52: float) -> dict:
    """
    Overbought / oversold as a composite. RSI alone is famous for calling a
    strong trend overbought for weeks on end, so a stock only earns the label
    when at least two independent readings agree.
    """
    hot = cold = 0
    parts = []
    if np.isfinite(rsi):
        if rsi >= 70:
            hot += 1; parts.append(f"RSI {rsi:.0f}")
        elif rsi <= 30:
            cold += 1; parts.append(f"RSI {rsi:.0f}")
    if np.isfinite(bb_pct):
        if bb_pct >= 1.0:
            hot += 1; parts.append("above upper Bollinger band")
        elif bb_pct <= 0.0:
            cold += 1; parts.append("below lower Bollinger band")
    if np.isfinite(pos52):
        if pos52 >= 95:
            hot += 1; parts.append(f"{pos52:.0f}% of 52-week range")
        elif pos52 <= 5:
            cold += 1; parts.append(f"{pos52:.0f}% of 52-week range")

    if hot >= 2:
        state, tone = "Overbought", "hot"
    elif cold >= 2:
        state, tone = "Oversold", "cold"
    elif hot == 1:
        state, tone = "Stretched high", "warm"
    elif cold == 1:
        state, tone = "Stretched low", "cool"
    else:
        state, tone = "Neutral", "neutral"
    return {"zone": state, "tone": tone, "hot": hot, "cold": cold,
            "why": ", ".join(parts)}


def compute_technicals(closes) -> dict:
    """Trend and momentum readings from a daily close series."""
    out = {"price": np.nan, "sma50": np.nan, "sma200": np.nan, "rsi": np.nan,
           "macd": np.nan, "macd_signal": np.nan, "macd_hist": np.nan,
           "mom1m": np.nan, "mom3m": np.nan, "mom6m": np.nan,
           "vs_sma50": np.nan, "vs_sma200": np.nan, "cross": "", "bars": 0,
           "bb_upper": np.nan, "bb_lower": np.nan, "bb_mid": np.nan, "bb_pct": np.nan,
           "hi52": np.nan, "lo52": np.nan, "pos52": np.nan,
           "zone": "", "zone_tone": "neutral", "zone_why": "",
           "support": None, "resistance": None,
           "support_touches": 0, "resistance_touches": 0, "levels": []}

    # Accepts either a full OHLC frame (so support/resistance can be found) or
    # a bare close series, in which case the level work is simply skipped.
    frame = closes if isinstance(closes, pd.DataFrame) else None
    if frame is not None:
        col = {c.lower(): c for c in frame.columns}.get("close")
        closes = frame[col] if col else frame.iloc[:, 0]

    closes = pd.to_numeric(closes, errors="coerce").dropna()
    out["bars"] = int(len(closes))
    if len(closes) < 30:
        return out

    price = float(closes.iloc[-1])
    out["price"] = price
    if len(closes) >= 50:
        out["sma50"] = float(closes.rolling(50).mean().iloc[-1])
        out["vs_sma50"] = (price / out["sma50"] - 1.0) * 100.0
    if len(closes) >= 200:
        out["sma200"] = float(closes.rolling(200).mean().iloc[-1])
        out["vs_sma200"] = (price / out["sma200"] - 1.0) * 100.0
        # Golden / death cross, judged over the last month of bars
        s50 = closes.rolling(50).mean()
        s200 = closes.rolling(200).mean()
        recent = min(21, len(s50) - 1)
        now_above = s50.iloc[-1] > s200.iloc[-1]
        was_above = s50.iloc[-1 - recent] > s200.iloc[-1 - recent]
        if now_above and not was_above:
            out["cross"] = "golden"
        elif was_above and not now_above:
            out["cross"] = "death"

    out["rsi"] = _rsi(closes)
    out["macd"], out["macd_signal"], out["macd_hist"] = _macd(closes)
    out["mom1m"] = _pct_change_over(closes, 21)
    out["mom3m"] = _pct_change_over(closes, 63)
    out["mom6m"] = _pct_change_over(closes, 126)

    out.update(_bollinger(closes))

    if frame is not None:
        out.update({k: v for k, v in compute_levels(frame, price).items()})
    else:
        # No highs and lows: the 52-week range can still come from closes.
        w = closes.iloc[-252:]
        out["hi52"], out["lo52"] = float(w.max()), float(w.min())
        rng = out["hi52"] - out["lo52"]
        if rng > 0:
            out["pos52"] = float((price - out["lo52"]) / rng * 100.0)

    z = classify_zone(out["rsi"], out["bb_pct"], out["pos52"])
    out["zone"], out["zone_tone"], out["zone_why"] = z["zone"], z["tone"], z["why"]
    return out


def _sig(text: str, why: str) -> dict:
    """A signal plus the rule that classified it, so a colour is never mute."""
    return {"t": text, "w": why}


def score_technicals(t: dict) -> dict:
    """
    Turn readings into +1 / -1 signals, each carrying the threshold that
    produced it. Deliberately simple and equally weighted -- a weighted model
    would imply a precision that indicator scoring does not have.
    """
    bull, bear, neutral = [], [], []

    v50, v200 = t.get("vs_sma50"), t.get("vs_sma200")
    if np.isfinite(v50):
        why = ("Price versus its 50-day average. Above is treated as a positive "
               "short-term trend, below as negative. A widely used line, but it "
               "says nothing about how far above or how durable the move is.")
        (bull if v50 > 0 else bear).append(
            _sig(f"{'above' if v50 > 0 else 'below'} 50-day ({v50:+.1f}%)", why))
    if np.isfinite(v200):
        why = ("Price versus its 200-day average — the usual dividing line "
               "between a long-term uptrend and downtrend. Slow to turn, which "
               "makes it steadier than the 50-day but late at inflections.")
        (bull if v200 > 0 else bear).append(
            _sig(f"{'above' if v200 > 0 else 'below'} 200-day ({v200:+.1f}%)", why))

    if t.get("cross") == "golden":
        bull.append(_sig("golden cross in the last month",
                         "The 50-day average rose through the 200-day within the "
                         "last 21 sessions. A popular trend-change marker; it is "
                         "a lagging one by construction."))
    elif t.get("cross") == "death":
        bear.append(_sig("death cross in the last month",
                         "The 50-day average fell through the 200-day within the "
                         "last 21 sessions. Lagging by construction, and prone to "
                         "firing after much of the move has happened."))

    rsi = t.get("rsi")
    if np.isfinite(rsi):
        why = ("Wilder's RSI(14), 0-100. Here: 70+ counts negative (overbought), "
               "30 or below positive (oversold), 55-70 positive, 30-45 negative, "
               "45-55 neutral. A strong trend can hold above 70 for weeks, so "
               "overbought is not the same as due to fall.")
        if rsi >= 70:
            bear.append(_sig(f"RSI {rsi:.0f} — overbought", why))
        elif rsi <= 30:
            bull.append(_sig(f"RSI {rsi:.0f} — oversold", why))
        elif rsi >= 55:
            bull.append(_sig(f"RSI {rsi:.0f} — firm", why))
        elif rsi <= 45:
            bear.append(_sig(f"RSI {rsi:.0f} — soft", why))
        else:
            neutral.append(_sig(f"RSI {rsi:.0f} — mid-range", why))

    mh = t.get("macd_hist")
    if np.isfinite(mh):
        why = ("MACD (12/26) against its 9-period signal line. Above signal "
               "counts positive, below negative. It measures whether momentum is "
               "accelerating, and whipsaws in sideways markets.")
        (bull if mh > 0 else bear).append(
            _sig(f"MACD {'above' if mh > 0 else 'below'} signal", why))

    for key, label, days in (("mom1m", "1m", 21), ("mom3m", "3m", 63), ("mom6m", "6m", 126)):
        m = t.get(key)
        if np.isfinite(m):
            why = (f"Price change over the last {days} sessions. Beyond +2% counts "
                   f"positive, beyond -2% negative, and anything between is treated "
                   f"as flat. Momentum has historically persisted over months, but "
                   f"it reverses hard and without warning.")
            if m > 2.0:
                bull.append(_sig(f"{label} momentum {m:+.1f}%", why))
            elif m < -2.0:
                bear.append(_sig(f"{label} momentum {m:+.1f}%", why))
            else:
                neutral.append(_sig(f"{label} momentum flat ({m:+.1f}%)", why))

    zone = t.get("zone") or ""
    if zone:
        why = ("Overbought / oversold, judged on three readings at once: RSI, "
               "position against the Bollinger bands, and where price sits in "
               "its 52-week range. Two must agree before the label is applied — "
               "RSI alone calls a strong trend overbought for weeks. "
               + (f"Here: {t.get('zone_why')}." if t.get("zone_why") else ""))
        if zone == "Overbought":
            bear.append(_sig("overbought", why))
        elif zone == "Oversold":
            bull.append(_sig("oversold", why))
        elif zone in ("Stretched high", "Stretched low"):
            neutral.append(_sig(zone.lower(), why))

    price = t.get("price")
    sup, res = t.get("support"), t.get("resistance")
    if np.isfinite(price) and price > 0:
        if sup:
            d = (price / sup - 1) * 100
            why = ("Nearest price level below, found from swing lows and highs "
                   "over the past year and merged where they cluster within 2%. "
                   f"Touched {t.get('support_touches', 0)} times. Levels are "
                   "descriptive, not physics — they hold until they don't, and "
                   "a break through one often runs.")
            if d <= 3:
                neutral.append(_sig(f"sitting on support {sup:g} ({d:+.1f}%)", why))
        if res:
            d = (res / price - 1) * 100
            why = ("Nearest price level above, found from swing highs and lows "
                   "over the past year and merged where they cluster within 2%. "
                   f"Touched {t.get('resistance_touches', 0)} times. Useful for "
                   "picking covered-call strikes: a level with several touches "
                   "is where rallies have stalled before.")
            if d <= 3:
                neutral.append(_sig(f"pressing resistance {res:g} ({d:+.1f}% away)", why))

    total = len(bull) + len(bear)
    return {"bull": bull, "bear": bear, "neutral": neutral,
            "bull_n": len(bull), "bear_n": len(bear),
            "score": len(bull) - len(bear),
            "pct": round(len(bull) / total * 100, 0) if total else None}


def score_fundamentals(snap: "Snapshot", info: dict) -> dict:
    """
    Valuation, quality, growth, balance sheet and the analyst consensus.
    Every signal states the threshold that classified it -- these cut-offs are
    reasonable conventions, not laws, and they ignore sector norms entirely.
    """
    good, bad, neutral = [], [], []

    def num(k):
        return _safe_float(info.get(k))

    pe, fpe = snap.pe, snap.forward_pe
    if np.isfinite(pe):
        why = ("Trailing P/E. Under 20 counts positive, over 45 negative, "
               "20-45 neutral. Applied identically across every sector, so a "
               "utility and a software company are judged on the same scale — "
               "which is exactly where a blunt rule like this misleads.")
        if pe <= 0:
            bad.append(_sig("negative earnings",
                            "The company lost money over the trailing twelve "
                            "months, so P/E is meaningless. Counted negative."))
        elif pe < 20:
            good.append(_sig(f"P/E {pe:.0f}", why))
        elif pe > 45:
            bad.append(_sig(f"P/E {pe:.0f} — rich", why))
        else:
            neutral.append(_sig(f"P/E {pe:.0f}", why))
    if np.isfinite(fpe) and np.isfinite(pe) and fpe > 0 and pe > 0:
        why = ("Forward P/E against trailing. More than 10% below counts "
               "positive (analysts expect earnings to rise), more than 10% "
               "above negative. Rests entirely on analyst estimates, which are "
               "routinely too optimistic a year out.")
        if fpe < pe * 0.9:
            good.append(_sig(f"forward P/E {fpe:.0f} below trailing — earnings expected to grow", why))
        elif fpe > pe * 1.1:
            bad.append(_sig(f"forward P/E {fpe:.0f} above trailing — earnings expected to fall", why))

    peg = num("pegRatio") or num("trailingPegRatio")
    if np.isfinite(peg) and peg > 0:
        why = ("P/E divided by the growth rate. Below 1.2 counts positive, "
               "above 2.5 negative. The idea is that a high multiple is "
               "defensible if growth is fast enough; it is very sensitive to "
               "whichever growth figure the data provider used.")
        if peg < 1.2:
            good.append(_sig(f"PEG {peg:.2f}", why))
        elif peg > 2.5:
            bad.append(_sig(f"PEG {peg:.2f} — growth looks priced in", why))

    pb = num("priceToBook")
    if np.isfinite(pb) and pb > 0:
        why = ("Price relative to book value. Under 3 counts positive, over 10 "
               "negative. Informative for banks and asset-heavy businesses, "
               "close to meaningless for software or pharma, where the real "
               "assets never appear on the balance sheet.")
        if pb < 3:
            good.append(_sig(f"price/book {pb:.1f}", why))
        elif pb > 10:
            bad.append(_sig(f"price/book {pb:.1f}", why))

    if np.isfinite(snap.profit_margin):
        m = snap.profit_margin * 100
        why = ("Net profit margin. 15%+ counts positive, under 5% negative, "
               "5-15% neutral. Varies enormously by industry — a supermarket "
               "at 3% may be run better than a software firm at 12%.")
        if m >= 15:
            good.append(_sig(f"net margin {m:.0f}%", why))
        elif m < 5:
            bad.append(_sig(f"net margin {m:.0f}%", why))
        else:
            neutral.append(_sig(f"net margin {m:.0f}%", why))
    if np.isfinite(snap.roe):
        r = snap.roe * 100
        why = ("Return on equity: profit as a share of shareholders' capital. "
               "20%+ counts positive, under 8% negative. Debt inflates it, so a "
               "heavily leveraged company can post a fine ROE on weak "
               "economics — read it next to debt/equity.")
        if r >= 20:
            good.append(_sig(f"ROE {r:.0f}%", why))
        elif r < 8:
            bad.append(_sig(f"ROE {r:.0f}%", why))
        else:
            neutral.append(_sig(f"ROE {r:.0f}%", why))

    if np.isfinite(snap.revenue_growth):
        g = snap.revenue_growth * 100
        why = ("Year-over-year revenue growth. 10%+ counts positive, negative "
               "growth counts negative, 0-10% neutral. A single year, so one "
               "weak comparison quarter can swing it.")
        if g >= 10:
            good.append(_sig(f"revenue +{g:.0f}%", why))
        elif g < 0:
            bad.append(_sig(f"revenue {g:.0f}%", why))
        else:
            neutral.append(_sig(f"revenue +{g:.0f}%", why))
    if np.isfinite(snap.earnings_growth):
        g = snap.earnings_growth * 100
        why = ("Year-over-year earnings growth. 10%+ positive, negative counts "
               "negative. Noisier than revenue because one-off charges and tax "
               "effects land straight in it.")
        if g >= 10:
            good.append(_sig(f"earnings +{g:.0f}%", why))
        elif g < 0:
            bad.append(_sig(f"earnings {g:.0f}%", why))

    de = num("debtToEquity")
    if np.isfinite(de):
        why = ("Debt as a percentage of equity. Under 80 counts positive, over "
               "200 negative. Matters most if you may be assigned the shares: "
               "leverage is what turns a bad quarter into a crisis. Banks and "
               "utilities run high by nature and are unfairly penalised here.")
        if de < 80:
            good.append(_sig(f"debt/equity {de:.0f}", why))
        elif de > 200:
            bad.append(_sig(f"debt/equity {de:.0f} — leveraged", why))
    cr = num("currentRatio")
    if np.isfinite(cr):
        why = ("Current assets over current liabilities. 1.5+ counts positive, "
               "under 1.0 negative — below 1.0 means short-term obligations "
               "exceed short-term assets, which is fine for some business "
               "models and a warning in others.")
        if cr >= 1.5:
            good.append(_sig(f"current ratio {cr:.1f}", why))
        elif cr < 1.0:
            bad.append(_sig(f"current ratio {cr:.1f} — tight liquidity", why))
    fcf = num("freeCashflow")
    if np.isfinite(fcf):
        why = ("Free cash flow: cash left after running and reinvesting in the "
               "business. Positive counts positive, negative counts negative. "
               "Harder to massage than reported earnings, which is why it is "
               "worth looking at separately.")
        if fcf > 0:
            good.append(_sig("positive free cash flow", why))
        else:
            bad.append(_sig("negative free cash flow", why))

    # --- analyst view, shown as third-party data ---
    rec = str(info.get("recommendationKey") or "").lower()
    n_an = num("numberOfAnalystOpinions")
    target = num("targetMeanPrice")
    upside = np.nan
    if np.isfinite(target) and np.isfinite(snap.spot) and snap.spot > 0:
        upside = (target / snap.spot - 1.0) * 100.0
    if rec:
        pretty = rec.replace("_", " ")
        cnt = f" ({n_an:.0f} analysts)" if np.isfinite(n_an) else ""
        why = ("Yahoo's summary of sell-side ratings. Buy or strong buy counts "
               "positive, sell or underperform negative, hold neutral. This is "
               "other people's opinion reported as data, not a judgement of "
               "mine — and sell ratings are famously rare.")
        if rec in ("strong_buy", "buy"):
            good.append(_sig(f"analyst consensus: {pretty}{cnt}", why))
        elif rec in ("sell", "strong_sell", "underperform"):
            bad.append(_sig(f"analyst consensus: {pretty}{cnt}", why))
        else:
            neutral.append(_sig(f"analyst consensus: {pretty}{cnt}", why))
    if np.isfinite(upside):
        why = ("Mean analyst price target against the current price. 10%+ above "
               "counts positive, 5%+ below negative. Targets are usually set "
               "12 months out and tend to follow the price rather than lead it.")
        if upside >= 10:
            good.append(_sig(f"mean target {upside:+.0f}% above price", why))
        elif upside <= -5:
            bad.append(_sig(f"mean target {upside:+.0f}% below price", why))
        else:
            neutral.append(_sig(f"mean target {upside:+.0f}% vs price", why))

    total = len(good) + len(bad)
    return {"good": good, "bad": bad, "neutral": neutral,
            "good_n": len(good), "bad_n": len(bad),
            "score": len(good) - len(bad),
            "pct": round(len(good) / total * 100, 0) if total else None,
            "target": round(target, 2) if np.isfinite(target) else None,
            "upside": round(upside, 1) if np.isfinite(upside) else None,
            "rec": rec or "", "analysts": int(n_an) if np.isfinite(n_an) else None}


# ----------------------------------------------------------------------------
# Fair value
#
# Read this before trusting a number that comes out of it.
#
# There is no such thing as "the" fair value of a share. Every method below is
# a rule of thumb resting on an assumption that may not hold, and the honest
# output is not a price but a RANGE plus a measure of how much the methods
# disagree. So that is what this returns: each anchor separately, the median of
# them, the spread, and a confidence that drops when they diverge.
#
# Deliberately NOT folded into the buy/sell verdict. The fundamentals and
# technicals scorecards are built from observable facts; this is built from
# assumptions, and averaging the two would quietly contaminate the part that
# is solid.
# ----------------------------------------------------------------------------

_MARKET_PE = 18.0          # rough long-run S&P 500 average
_MAX_HIST_PE = 60.0        # cap on the historical multiple anchor
_FCF_TARGET_YIELD = 0.05   # the FCF yield a buyer might demand


def _annual_eps_history(tk) -> list[tuple[pd.Timestamp, float]]:
    """
    Diluted EPS by fiscal year end, newest first. One extra request.

    Needed because a historical P/E cannot be built from today's EPS: dividing
    2021 prices by 2026 earnings measures nothing at all.
    """
    try:
        stmt = _paced(lambda: tk.income_stmt)
    except Exception:
        return []
    if stmt is None or not hasattr(stmt, "index") or not len(stmt):
        return []

    rows = {str(i).strip().lower(): i for i in stmt.index}
    out: list[tuple[pd.Timestamp, float]] = []

    key = next((rows[c] for c in ("diluted eps", "basic eps") if c in rows), None)
    if key is not None:
        for col in stmt.columns:
            v = _safe_float(stmt.loc[key, col])
            if np.isfinite(v):
                out.append((pd.Timestamp(col), v))
    else:
        ni = next((rows[c] for c in ("net income common stockholders", "net income")
                   if c in rows), None)
        sh = next((rows[c] for c in ("diluted average shares", "basic average shares")
                   if c in rows), None)
        if ni is not None and sh is not None:
            for col in stmt.columns:
                n, s = _safe_float(stmt.loc[ni, col]), _safe_float(stmt.loc[sh, col])
                if np.isfinite(n) and np.isfinite(s) and s > 0:
                    out.append((pd.Timestamp(col), n / s))

    out = [(d, v) for d, v in out if pd.notna(d)]
    out.sort(key=lambda x: x[0], reverse=True)
    return out


def _naive_closes(bars) -> pd.Series:
    """Close series with a timezone-naive index, so date maths does not throw."""
    if bars is None or not len(bars):
        return pd.Series(dtype=float)
    s = bars["Close"] if isinstance(bars, pd.DataFrame) else bars
    s = s.dropna()
    try:
        if getattr(s.index, "tz", None) is not None:
            s.index = s.index.tz_localize(None)
    except Exception:
        pass
    return s


def historical_pe_series(bars, eps_hist) -> list[float]:
    """
    What the market actually paid for each fiscal year's earnings: the mean
    close over the twelve months ending at that year end, over that year's EPS.

    Mean rather than year-end price, because a single closing print on an
    arbitrary date is not representative of a whole year's valuation.
    """
    closes = _naive_closes(bars)
    if not len(closes) or not eps_hist:
        return []
    pes = []
    for dt, eps in eps_hist:
        if not (np.isfinite(eps) and eps > 0):
            continue          # loss-making years have no meaningful P/E
        try:
            win = closes[(closes.index >= dt - pd.Timedelta(days=365))
                         & (closes.index <= dt)]
        except Exception:
            continue
        if len(win) < 60:     # under ~3 months of prices is not a year's average
            continue
        pe = float(win.mean()) / eps
        if 2.0 < pe < 200.0:
            pes.append(pe)
    return pes


def estimate_fair_value(snap: "Snapshot", info: dict, bars=None,
                        eps_hist=None) -> dict:
    """
    Several independent valuation anchors, blended by median.

    Median rather than mean on purpose: with only a handful of anchors, one
    method blowing up should not drag the answer with it. Where they disagree
    badly, the spread says so rather than the blend hiding it.
    """
    def num(k):
        return _safe_float(info.get(k))

    price = snap.spot
    anchors: list[dict] = []

    def add(name, value, why, basis=""):
        v = _safe_float(value)
        if not (np.isfinite(v) and v > 0):
            return
        if np.isfinite(price) and price > 0 and (v > price * 8 or v < price * 0.12):
            return            # an 8x disagreement is a broken input, not a view
        anchors.append({
            "name": name,
            "value": round(v, 2),
            "gap": round((v / price - 1.0) * 100.0, 1) if np.isfinite(price) and price > 0 else None,
            "basis": basis,
            "why": why,
        })

    eps_fwd, eps_ttm = num("forwardEps"), snap.eps
    use_fwd = np.isfinite(eps_fwd) and eps_fwd > 0
    base_eps = eps_fwd if use_fwd else eps_ttm
    eps_label = "forward EPS" if use_fwd else "trailing EPS"
    have_eps = np.isfinite(base_eps) and base_eps > 0

    # 1. Reversion to the company's own historical multiple -----------------
    pes = historical_pe_series(bars, eps_hist or [])
    if len(pes) >= 2 and have_eps:
        med_pe = float(np.median(pes))
        capped = min(med_pe, _MAX_HIST_PE)
        add("Own historical P/E", base_eps * capped,
            f"What the market has actually paid for this company's earnings over "
            f"the past {len(pes)} fiscal years — a median P/E of {med_pe:.0f}"
            + (f", capped at {_MAX_HIST_PE:.0f} for this estimate" if capped < med_pe else "")
            + f" — applied to {eps_label} of ${base_eps:.2f}. The assumption is that "
              "the multiple returns to its own norm. It will not if the business "
              "has structurally changed, and a few years is a short history.",
            basis=f"{len(pes)}y median P/E {med_pe:.0f} × ${base_eps:.2f}")

    # 2. The market's own multiple ------------------------------------------
    if have_eps:
        add(f"Market multiple ({_MARKET_PE:.0f}x)", base_eps * _MARKET_PE,
            f"{eps_label.capitalize()} of ${base_eps:.2f} at {_MARKET_PE:.0f}x, roughly the "
            "long-run S&P 500 average. A blunt instrument: it takes no account "
            "of growth, quality or sector, so it will call every fast grower "
            "expensive and every declining business cheap.",
            basis=f"${base_eps:.2f} × {_MARKET_PE:.0f}")

    # 3. Growth-justified multiple (PEG = 1) --------------------------------
    g = snap.earnings_growth
    if not np.isfinite(g):
        g = snap.revenue_growth
    if have_eps and np.isfinite(g):
        gp = g * 100.0
        if 5.0 <= gp <= 40.0:
            add("Growth-justified (PEG 1)", base_eps * gp,
                f"The old rule that a fair P/E is roughly the growth rate — here "
                f"{gp:.0f}% growth implies a {gp:.0f}x multiple on {eps_label} of "
                f"${base_eps:.2f}. Only applied between 5% and 40% growth, because "
                "outside that band the rule produces nonsense. It rests on a single "
                "year-over-year figure that one odd quarter can distort.",
                basis=f"{gp:.0f}% growth → {gp:.0f}x")

    # 4. Dividend yield reversion -------------------------------------------
    rate = num("dividendRate") or num("trailingAnnualDividendRate")
    avg_y = num("fiveYearAvgDividendYield")      # Yahoo ships this as a percent
    if np.isfinite(rate) and rate > 0 and np.isfinite(avg_y) and 0.2 < avg_y < 25:
        add("Dividend yield reversion", rate / (avg_y / 100.0),
            f"The price at which the ${rate:.2f} annual dividend would yield "
            f"{avg_y:.2f}%, this stock's own five-year average yield. No growth "
            "assumption, which makes it cleaner than a dividend discount model — "
            "but it only holds if the dividend is safe and the payout policy "
            "unchanged.",
            basis=f"${rate:.2f} ÷ {avg_y:.2f}%")

    # 5. Free cash flow yield ------------------------------------------------
    fcf, shares = num("freeCashflow"), num("sharesOutstanding")
    if np.isfinite(fcf) and fcf > 0 and np.isfinite(shares) and shares > 0:
        fcfps = fcf / shares
        add(f"FCF yield at {_FCF_TARGET_YIELD*100:.0f}%", fcfps / _FCF_TARGET_YIELD,
            f"Free cash flow of ${fcfps:.2f} per share priced to yield "
            f"{_FCF_TARGET_YIELD*100:.0f}%. Cash is harder to massage than reported "
            "earnings, which is the appeal — but the target yield is a choice, not "
            "a fact, and it is the crudest anchor here. A single year's capex swing "
            "moves it a long way.",
            basis=f"${fcfps:.2f} FCF/share ÷ {_FCF_TARGET_YIELD*100:.0f}%")

    if not anchors:
        return {"fair": None, "low": None, "high": None, "gap": None,
                "label": "", "tone": "neutral", "confidence": "none",
                "spread": None, "anchors": [], "n": 0,
                "note": "Not enough data to value this one — no usable earnings, "
                        "cash flow or dividend history came back."}

    vals = sorted(a["value"] for a in anchors)
    fair = float(np.median(vals))
    lo, hi = vals[0], vals[-1]
    spread = (hi - lo) / fair * 100.0 if fair > 0 else np.nan
    gap = (fair / price - 1.0) * 100.0 if np.isfinite(price) and price > 0 else np.nan

    # Confidence is about agreement, not accuracy. Anchors that agree can still
    # all be wrong together -- they lean on overlapping inputs.
    n = len(anchors)
    if n >= 4 and spread <= 40:
        conf = "high"
    elif n >= 3 and spread <= 70:
        conf = "medium"
    else:
        conf = "low"

    if not np.isfinite(gap):
        label, tone = "", "neutral"
    elif gap >= 25:
        label, tone = "Cheap", "good"
    elif gap >= 10:
        label, tone = "Below fair", "good"
    elif gap > -10:
        label, tone = "Fair", "neutral"
    elif gap > -25:
        label, tone = "Above fair", "bad"
    else:
        label, tone = "Expensive", "bad"

    note = (f"Median of {n} method{'s' if n != 1 else ''} spanning "
            f"${lo:,.2f}–${hi:,.2f}. ")
    if conf == "low":
        note += ("The methods disagree widely, so treat the midpoint as barely "
                 "informative and read the individual anchors instead.")
    elif spread > 40:
        note += "A wide spread — the range matters more than the midpoint."
    else:
        note += "The methods broadly agree, which is worth something but is not proof."

    return {
        "fair": round(fair, 2), "low": round(lo, 2), "high": round(hi, 2),
        "gap": round(gap, 1) if np.isfinite(gap) else None,
        "label": label, "tone": tone, "confidence": conf,
        "spread": round(spread, 0) if np.isfinite(spread) else None,
        "anchors": anchors, "n": n, "note": note,
    }


def combined_verdict(f: dict, t: dict) -> dict:
    """
    A plain reading of the two scorecards. Both must lean the same way for a
    directional label -- when they disagree, that disagreement IS the finding,
    and saying "mixed" is more useful than averaging it away.
    """
    fs = f["score"] if f["good_n"] + f["bad_n"] else 0
    ts = t["score"] if t["bull_n"] + t["bear_n"] else 0
    fp = (f["pct"] if f["pct"] is not None else 50)
    tp = (t["pct"] if t["pct"] is not None else 50)

    strong_f, weak_f = fp >= 65, fp <= 35
    strong_t, weak_t = tp >= 65, tp <= 35

    if strong_f and strong_t:
        label, note = "BUY", "fundamentals and trend both constructive"
    elif weak_f and weak_t:
        label, note = "TRIM", "fundamentals and trend both deteriorating"
    elif strong_f and weak_t:
        label, note = "MIXED", "sound business, weak trend — a falling knife or an entry, depending on your horizon"
    elif weak_f and strong_t:
        label, note = "MIXED", "strong trend on weak fundamentals — momentum without support underneath"
    elif fp >= 55 and tp >= 55:
        label, note = "HOLD+", "modestly positive on both"
    elif fp <= 45 and tp <= 45:
        label, note = "HOLD-", "modestly negative on both"
    else:
        label, note = "HOLD", "no clear signal either way"

    return {"label": label, "note": note,
            "fund_score": fs, "tech_score": ts,
            "fund_pct": fp, "tech_pct": tp}


_LOOKBACK_BARS = {"3mo": 63, "6mo": 126, "1y": 252, "2y": 504, "5y": 1260}


def analyze_stocks(
    tickers: Iterable[str],
    lookback: str = "1y",
    max_workers: int = 6,
    progress_cb: Callable[[int, int, str], None] | None = None,
    should_stop: Callable[[], bool] | None = None,
    want_value: bool = True,
) -> dict:
    """
    Fundamentals + technicals + a fair-value estimate for each ticker.

    Three requests per symbol: the info blob, five years of daily bars, and the
    income statement. The five years cost nothing extra over one -- it is the
    same call with a longer period -- and the technicals are computed from the
    tail of it, so the 52-week readings are unaffected.
    """
    tickers = [str(t).strip().upper() for t in dict.fromkeys(tickers) if str(t).strip()]
    reset_rate_stats()
    rows: list[dict] = []
    errors: dict = {}
    done = 0

    tech_bars_n = _LOOKBACK_BARS.get(lookback, 252)
    # Valuation wants years of price history; the technicals want the window the
    # user asked for. One request serves both.
    fetch_period = lookback if tech_bars_n > 1260 else "5y"

    def work(tkr: str) -> dict:
        snap = fetch_ticker_snapshot(tkr, want_earnings=True)
        if snap.error or not np.isfinite(snap.spot):
            return {"ticker": tkr, "error": snap.error or "no price data"}
        tk = yf.Ticker(tkr)
        info = {}
        try:
            info = _paced(lambda: tk.get_info()) or {}
        except Exception:
            info = {}
        bars = None
        try:
            h = _paced(lambda: tk.history(period=fetch_period))
            if h is not None and len(h):
                bars = h            # full OHLC, so levels can be derived
        except Exception as exc:
            if _is_rate_limited(exc):
                return {"ticker": tkr, "error": "rate limited"}

        tech_bars = bars.tail(tech_bars_n) if bars is not None else pd.Series(dtype=float)

        val = {"fair": None, "gap": None, "label": "", "tone": "neutral",
               "confidence": "none", "anchors": [], "n": 0, "note": "",
               "low": None, "high": None, "spread": None}
        if want_value:
            eps_hist = _annual_eps_history(tk)
            try:
                val = estimate_fair_value(snap, info, bars, eps_hist)
            except Exception as exc:
                val["note"] = f"valuation failed: {type(exc).__name__}: {exc}"

        tech = compute_technicals(tech_bars)
        ts = score_technicals(tech)
        fs = score_fundamentals(snap, info)
        verdict = combined_verdict(fs, ts)
        return {
            "ticker": tkr, "error": "",
            "name": snap.name, "sector": snap.sector,
            "price": round(snap.spot, 2),
            "verdict": verdict["label"], "note": verdict["note"],
            "fund_pct": verdict["fund_pct"], "tech_pct": verdict["tech_pct"],
            "fund_score": fs["score"], "tech_score": ts["score"],
            "good": fs["good"], "bad": fs["bad"], "fund_neutral": fs["neutral"],
            "bull": ts["bull"], "bear": ts["bear"], "tech_neutral": ts["neutral"],
            "pe": round(snap.pe, 1) if np.isfinite(snap.pe) else None,
            "target": fs["target"], "upside": fs["upside"],
            "rec": fs["rec"], "analysts": fs["analysts"],
            "rsi": round(tech["rsi"], 1) if np.isfinite(tech["rsi"]) else None,
            "sma50": round(tech["sma50"], 2) if np.isfinite(tech["sma50"]) else None,
            "sma200": round(tech["sma200"], 2) if np.isfinite(tech["sma200"]) else None,
            "vs50": round(tech["vs_sma50"], 1) if np.isfinite(tech["vs_sma50"]) else None,
            "vs200": round(tech["vs_sma200"], 1) if np.isfinite(tech["vs_sma200"]) else None,
            "macd_hist": round(tech["macd_hist"], 3) if np.isfinite(tech["macd_hist"]) else None,
            "cross": tech["cross"],
            "mom1m": round(tech["mom1m"], 1) if np.isfinite(tech["mom1m"]) else None,
            "mom3m": round(tech["mom3m"], 1) if np.isfinite(tech["mom3m"]) else None,
            "mom6m": round(tech["mom6m"], 1) if np.isfinite(tech["mom6m"]) else None,
            "bars": tech["bars"],
            "zone": tech.get("zone") or "",
            "zone_tone": tech.get("zone_tone") or "neutral",
            "zone_why": tech.get("zone_why") or "",
            "bb_pct": round(tech["bb_pct"], 2) if np.isfinite(tech.get("bb_pct", np.nan)) else None,
            "bb_upper": round(tech["bb_upper"], 2) if np.isfinite(tech.get("bb_upper", np.nan)) else None,
            "bb_lower": round(tech["bb_lower"], 2) if np.isfinite(tech.get("bb_lower", np.nan)) else None,
            "hi52": round(tech["hi52"], 2) if np.isfinite(tech.get("hi52", np.nan)) else None,
            "lo52": round(tech["lo52"], 2) if np.isfinite(tech.get("lo52", np.nan)) else None,
            "pos52": round(tech["pos52"], 0) if np.isfinite(tech.get("pos52", np.nan)) else None,
            "support": tech.get("support"),
            "resistance": tech.get("resistance"),
            "support_touches": tech.get("support_touches", 0),
            "resistance_touches": tech.get("resistance_touches", 0),
            "levels": tech.get("levels") or [],
            "next_earnings": snap.next_earnings.isoformat() if snap.next_earnings else "",
            # --- fair value ---
            "fair": val["fair"], "fair_low": val["low"], "fair_high": val["high"],
            "fair_gap": val["gap"], "fair_label": val["label"],
            "fair_tone": val["tone"], "fair_conf": val["confidence"],
            "fair_spread": val["spread"], "fair_n": val["n"],
            "fair_note": val["note"], "fair_anchors": val["anchors"],
        }

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futs = {pool.submit(work, t): t for t in tickers}
        for fut in as_completed(futs):
            if should_stop and should_stop():
                break
            tkr = futs[fut]
            done += 1
            if progress_cb:
                progress_cb(done, len(tickers), tkr)
            try:
                r = fut.result()
            except Exception as exc:
                errors[tkr] = str(exc)
                continue
            if r.get("error"):
                errors[tkr] = r["error"]
            else:
                rows.append(r)

    order = {"BUY": 0, "HOLD+": 1, "HOLD": 2, "MIXED": 3, "HOLD-": 4, "TRIM": 5}
    rows.sort(key=lambda r: (order.get(r["verdict"], 9),
                             -(r["fund_pct"] + r["tech_pct"])))
    rate = get_rate_stats()
    return {"rows": rows, "errors": errors,
            "stats": {"requested": len(tickers), "analysed": len(rows),
                      "failed": len(errors), "rate": rate,
                      "rate_limited": bool(rate.get("hits")),
                      "ranAt": datetime.now().isoformat(timespec="seconds")}}


COLUMN_HELP = {
    "IV": "Implied volatility from the chain; re-solved locally if the feed's value is missing or nonsensical.",
    "Delta": "Black-Scholes delta. For a short put, |delta| is a rough probability of assignment.",
    "PoP (est)": "1 - |delta|. A crude probability the option expires worthless. Not a guarantee.",
    "Static Yield %": "Premium / collateral, for the life of the trade.",
    "Annualized %": "Static yield scaled to 365 days. Only meaningful if you can repeat the trade.",
    "Ann. If Called %": "Covered calls: annualized return including capital gain up to the strike.",
    "Model Edge %": "Market mid vs. Black-Scholes fair value at the quoted IV. Large values usually mean a stale or wide quote, not free money.",
    "OTM %": "How far out of the money the strike sits, as a % of spot.",
}


if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser(description="Options screener (CLI mode)")
    p.add_argument("--side", choices=["put", "call"], default="put")
    p.add_argument("--tickers", default="", help="Comma-separated. Default: S&P 500")
    p.add_argument("--limit", type=int, default=60, help="Max tickers to scan")
    p.add_argument("--out", default="screen_results.csv")
    args = p.parse_args()

    universe = (
        [t.strip().upper() for t in args.tickers.split(",") if t.strip()]
        if args.tickers else get_sp500_tickers()[: args.limit]
    )
    c = Criteria(side=args.side)
    print(f"Scanning {len(universe)} tickers for {args.side}s...")
    res = run_screen(
        universe, c,
        progress_cb=lambda d, t, s: print(f"  [{d}/{t}] {s}", end="\r"),
    )
    print()
    if res.empty:
        print("No contracts matched. Loosen the criteria.")
    else:
        cols = ["Ticker", "Side", "Expiry", "DTE", "Strike", "Mid", "IV",
                "Delta", "Annualized %", "OI", "PE"]
        print(res[cols].head(25).to_string(index=False))
        res.to_csv(args.out, index=False)
        print(f"\nSaved {len(res)} rows -> {args.out}")
