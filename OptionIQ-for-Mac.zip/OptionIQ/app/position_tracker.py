"""OptionIQ by Quantum Nexus LLC. — desktop app entry point.

The screens are the Options Trade Logger's own (web/app/, built from the
original HTML by build_ui.py). This program serves them on 127.0.0.1 only,
keeps their data in a file instead of the browser, starts the Screener
service next to them, and shows them in their own window.

    python position_tracker.py              # app window (Edge app mode or pywebview)
    python position_tracker.py --browser    # use the default browser instead
    python position_tracker.py --serve-only # no window, for testing
    python position_tracker.py --portable   # shareable build: everything stays in this folder
"""
from __future__ import annotations

import sys


def _startup_failed(exc: BaseException) -> None:
    """Started with pythonw there is no console, so a failure here would be
    invisible: say so in a message box and in a file next to the Start file."""
    import os
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    msg = ("OptionIQ could not start.\n\n"
           "If you have just unzipped it, wait until the unzipping has completely "
           "finished, then double-click Start OptionIQ again.\n\n"
           "If it still does not start, unzip the whole zip file again into an empty "
           "folder. The details are in \"OptionIQ startup error.txt\".")
    try:
        import traceback
        detail = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    except Exception:
        detail = repr(exc)
    try:
        with open(os.path.join(root, "OptionIQ startup error.txt"), "w", encoding="utf-8") as fh:
            fh.write(msg + "\n\n" + detail)
    except OSError:
        pass
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, msg, "OptionIQ", 0x30)
        except Exception:
            pass
    elif sys.platform == "darwin":
        try:
            import subprocess
            subprocess.run(["osascript", "-e", "on run argv\ndisplay alert \"OptionIQ\" message (item 1 of argv) as warning\nend run",
                            msg.replace("double-click Start OptionIQ", "double-click Start OptionIQ.command")], timeout=600)
        except Exception:
            pass


try:
    import argparse
    import json
    import mimetypes
    import os
    import socket
    import subprocess
    import threading
    import time
    import urllib.error
    import urllib.request
    import webbrowser
    from datetime import date
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from pathlib import Path
    from urllib.parse import urlparse

    HERE = Path(__file__).resolve().parent
    sys.path.insert(0, str(HERE))

    from tracker import addons, brand, config, downloads, kvstore, notify, phone, shortcut, updates  # noqa: E402
    from tracker.kvstore import KVStore  # noqa: E402
    from tracker.prices import finnhub_price  # noqa: E402
except Exception as _exc:  # files missing, e.g. started before unzipping finished
    _startup_failed(_exc)
    raise

WEB = HERE / "web"
SCREENER_DIR = HERE / "screener"
DEFAULT_PORT = 8766  # the screener service uses 8765
APP_TITLE = brand.APP_NAME
TERMS_FILE = HERE / "TERMS OF USE.txt"

_last_request = [time.monotonic()]
_bye = [0.0]          # when the app page last said it was closing
_show_window = []     # set by main(): opens one more app window
# With no word from the page for this long, the window is taken to be gone.
# Long on purpose: a minimized or sleeping window can stay quiet for hours,
# and its server must still be there when it wakes. A copy left running is
# harmless: starting OptionIQ again reuses it (running_copy).
QUIET_LIMIT = 12 * 3600


def window_closed() -> bool:
    """The app page said it was closing a few seconds ago and nothing has
    asked for anything since (a reload asks again at once), or it has been
    silent for QUIET_LIMIT."""
    now = time.monotonic()
    said_bye = _bye[0] and _last_request[0] <= _bye[0] and now - _bye[0] > 8
    return bool(said_bye) or now - _last_request[0] > QUIET_LIMIT

FOLDER_PICKER_PS = r"""
Add-Type -AssemblyName System.Windows.Forms
$owner = New-Object System.Windows.Forms.Form -Property @{TopMost = $true}
$d = New-Object System.Windows.Forms.FolderBrowserDialog
$d.Description = 'Choose where to keep your tracker data'
$d.ShowNewFolderButton = $true
if ($d.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Out.Write($d.SelectedPath) }
"""


def choose_folder_windows() -> str | None:
    """Windows' own folder picker, shown through PowerShell (built in)."""
    out = subprocess.run(
        ["powershell", "-STA", "-NoProfile", "-NonInteractive", "-Command", FOLDER_PICKER_PS],
        capture_output=True, text=True, timeout=600,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    return out.stdout.strip() or None


def choose_folder_mac() -> str | None:
    """The Mac's own folder picker, shown through AppleScript (built in)."""
    script = 'POSIX path of (choose folder with prompt "Choose where to keep your tracker data")'
    out = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=600)
    return out.stdout.strip().rstrip("/") or None


def choose_folder() -> str | None:
    if sys.platform == "win32":
        return choose_folder_windows()
    if sys.platform == "darwin":
        return choose_folder_mac()
    return None


def setup_info(store: KVStore) -> dict:
    st = store.load()
    return {
        "setupDone": bool(st["settings"].get("setupDone")),
        "accounts": st["settings"]["accounts"],
        "usage": store.account_usage(),
        "settings": st["settings"],
        "dataFile": str(store.path),
        "dataDir": str(store.path.parent),
        "locations": config.suggested_locations(),
        "canBrowse": sys.platform in ("win32", "darwin"),
        "platform": "mac" if sys.platform == "darwin" else ("windows" if sys.platform == "win32" else "other"),
        "portable": bool(config.PORTABLE_ROOT),
        "brand": brand.info(),
        "termsAccepted": terms_accepted(st),
    }


def terms_accepted(state: dict) -> bool:
    return (state["settings"].get("termsAccepted") or {}).get("version") == brand.TERMS_VERSION


def terms_text() -> str:
    try:
        return TERMS_FILE.read_text(encoding="utf-8")
    except OSError:
        return brand.notice()


PHONE_KEYS = {kvstore.TRADES_KEY, kvstore.STOCKS_KEY, kvstore.WATCHLIST_KEY, phone.APPLIED_KEY, phone.SUMMARY_KEY, phone.PRICES_KEY}


def make_handler(store: KVStore, phone_copy: "phone.CopyWriter | None" = None):
    def poke_phone():
        if phone_copy:
            phone_copy.poke()

    class Handler(BaseHTTPRequestHandler):
        server_version = "OptionIQ/" + brand.VERSION

        def log_message(self, fmt, *args):  # keep the console quiet
            pass

        # ---- helpers ---------------------------------------------------
        def _host_ok(self) -> bool:
            _last_request[0] = time.monotonic()
            host = (self.headers.get("Host") or "").split(":")[0]
            return host in ("127.0.0.1", "localhost")

        def _json(self, payload, status=200):
            body = json.dumps(payload).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _redirect(self, to):
            self.send_response(302)
            self.send_header("Location", to)
            self.send_header("Content-Length", "0")
            self.end_headers()

        def _body(self):
            n = int(self.headers.get("Content-Length") or 0)
            if n > 50_000_000:
                raise ValueError("Request too large")
            return json.loads(self.rfile.read(n) or b"{}")

        def _route(self):
            return [p for p in urlparse(self.path).path.split("/") if p]

        def _static(self, rel):
            target = (WEB / rel).resolve()
            if target.is_dir():
                target = target / "index.html"
            if WEB not in target.parents or not target.is_file():
                return self._json({"error": "not found"}, 404)
            data = target.read_bytes()
            self.send_response(200)
            ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
            if ctype.startswith("text/") or ctype.endswith("javascript"):
                ctype += "; charset=utf-8"
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        # ---- verbs -----------------------------------------------------
        def do_GET(self):
            if not self._host_ok():
                return self._json({"error": "forbidden"}, 403)
            parts = self._route()
            if not parts:
                done = store.load()["settings"].get("setupDone")
                return self._redirect("/app/" if done else "/setup.html")
            if parts[0] != "api":
                return self._static("/".join(parts))
            if parts == ["api", "health"]:
                return self._json({"ok": True, "root": str(config.PORTABLE_ROOT or "")})
            if parts == ["api", "kv"]:
                # Everything the page keeps in "localStorage", plus the
                # account list and this person's own price key.
                st = store.load()
                items = dict(st["kv"])
                key = config.get_keys().get("finnhub")
                if key:
                    items["finnhub_key"] = key
                return self._json({"items": items, "accounts": st["settings"]["accounts"],
                                   "portable": bool(config.PORTABLE_ROOT), "brand": brand.info(),
                                   "termsAccepted": terms_accepted(st)})
            if parts == ["api", "setup"]:
                return self._json(setup_info(store))
            if parts == ["api", "terms"]:
                return self._json({"text": terms_text(), "brand": brand.info(),
                                   "accepted": terms_accepted(store.load())})
            if parts == ["api", "addons"]:
                return self._json(addons.status())
            if parts == ["api", "update"]:
                return self._json(updates.check())
            if parts == ["api", "update", "status"]:
                return self._json(updates.status())
            if parts == ["api", "status"]:
                return self._json(kvstore.status(store.load(), date.today()))
            if parts == ["api", "keys"]:
                return self._json({k: config.masked(v) for k, v in config.get_keys().items()})
            if parts == ["api", "phone", "inbox"]:
                # Changes made on the phone, for the page to add (phone_inbox.js).
                return self._json({"items": phone.read_inbox(store)})
            return self._json({"error": "not found"}, 404)

        def do_POST(self):
            if not self._host_ok():
                return self._json({"error": "forbidden"}, 403)
            parts = self._route()
            try:
                body = self._body()
                if parts == ["api", "bye"]:
                    # The app window is closing (or reloading: then the page
                    # asks for something again within a second).
                    _bye[0] = time.monotonic()
                    return self._json({"ok": True})
                if parts == ["api", "show"]:
                    # OptionIQ was started again while already running: open
                    # a window on this one instead of a second copy.
                    _bye[0] = 0.0
                    for show in _show_window:
                        threading.Thread(target=show, daemon=True).start()
                    return self._json({"ok": bool(_show_window)})
                if parts == ["api", "kv"]:
                    key = body["key"]
                    if key == "finnhub_key":
                        config.set_keys({"finnhub": body.get("value") or ""})
                        poke_phone()
                        return self._json({"ok": True})
                    added = store.set_item(key, body.get("value"))
                    if key in PHONE_KEYS:
                        poke_phone()
                    return self._json({"ok": True, "newAccounts": added})
                if parts[:2] == ["api", "accounts"] or parts in (["api", "setup"], ["api", "datadir"], ["api", "settings"]):
                    poke_phone()  # written a few seconds later, after this change is saved
                if parts == ["api", "setup"]:
                    found = use_data_dir(store, body.get("dataDir"), carry_over=False)
                    if found:
                        return self._json({"ok": True, "existing": True})
                    return self._json({"ok": True, "settings": store.finish_setup(body.get("accounts") or [])})
                if parts == ["api", "terms"]:
                    if body.get("accept") is not True:
                        raise ValueError("Please tick the box to agree to the Terms of Use")
                    store.accept_terms(brand.TERMS_VERSION)
                    return self._json({"ok": True})
                if parts == ["api", "settings"]:
                    return self._json(store.update_settings(body))
                if parts == ["api", "datadir"]:
                    found = use_data_dir(store, body.get("dataDir"), carry_over=True)
                    return self._json({"ok": True, "existing": found, "dataFile": str(store.path)})
                if parts == ["api", "accounts"]:
                    return self._json({"accounts": store.add_account(body.get("name"))})
                if parts == ["api", "accounts", "rename"]:
                    return self._json({"accounts": store.rename_account(body.get("from"), body.get("to"))})
                if parts == ["api", "accounts", "remove"]:
                    return self._json({"accounts": store.remove_account(body.get("name"))})
                if parts == ["api", "backup"]:
                    return self._json(store.backup(body.get("content")))
                if parts == ["api", "choose-folder"]:
                    return self._json({"folder": choose_folder()})
                if parts == ["api", "phone", "done"]:
                    moved = phone.mark_done(store, body.get("files") or [])
                    poke_phone()
                    return self._json({"ok": True, "moved": moved})
                if parts == ["api", "keys"]:
                    keys = config.set_keys(body)
                    poke_phone()
                    return self._json({k: config.masked(v) for k, v in keys.items()})
                if parts == ["api", "keys", "test"]:
                    return self._json(test_key(body))
                if parts == ["api", "addons"]:
                    if addons.status()["state"] == "failed":
                        start_addons(no_screener=False)
                    return self._json(addons.status())
                if parts == ["api", "update", "check"]:
                    return self._json(updates.check(force=True))
                if parts == ["api", "update", "install"]:
                    updates.install(store, close_for_update)
                    return self._json(updates.status())
                if parts == ["api", "desktop-icon"]:
                    try:
                        return self._json({"ok": True, "where": shortcut.make()})
                    except OSError as exc:
                        raise ValueError(f"Couldn't make the desktop icon: {exc}") from exc
                if parts == ["api", "broker", "open"]:
                    # The broker's own download pages, in the person's browser.
                    for _, link in downloads.pages(str(body.get("broker") or "")):
                        webbrowser.open(link)
                    return self._json({"ok": True, "pages": [n for n, _ in downloads.pages(str(body.get("broker")))]})
                if parts == ["api", "broker", "downloads"]:
                    return self._json({"files": downloads.new_files(float(body.get("since") or 0))})
                if parts == ["api", "fundamentals"]:
                    from tracker import fundamentals
                    return self._json(fundamentals.lookup(body.get("tickers") or []))
                return self._json({"error": "not found"}, 404)
            except (ValueError, KeyError, TypeError) as exc:
                return self._json({"error": str(exc)}, 400)
            except OSError as exc:
                return self._json({"error": f"Couldn't use that folder: {exc.strerror or exc}"}, 400)

    return Handler


def test_key(body: dict) -> dict:
    key = str(body.get("finnhub") or "").strip() or config.get_keys()["finnhub"]
    if not key:
        return {"ok": False, "error": "Enter a key first."}
    try:
        px = finnhub_price("AAPL", key)
        return {"ok": True, "message": f"The key works. Apple is at ${px:,.2f}."}
    except urllib.error.HTTPError as exc:
        return {"ok": False, "error": ("Finnhub didn't accept that key. Check it was copied in full."
                                       if exc.code in (401, 403) else f"Finnhub answered with an error ({exc.code}). Try again later.")}
    except Exception:
        return {"ok": False, "error": "Couldn't reach Finnhub. Check your internet connection and try again."}


def use_data_dir(store: KVStore, folder, carry_over: bool) -> bool:
    """Switch the data file to <folder>/tracker_data.json and remember the
    choice. Returns True when that folder already had tracker data, which is
    then used instead of the current data. Otherwise, with carry_over, the
    current data is copied there."""
    if not folder:
        return False
    folder = Path(str(folder).strip().strip('"')).expanduser()
    if not folder.is_absolute():
        example = "/Users/you/Documents/OptionIQ" if sys.platform == "darwin" else "C:\\Users\\you\\Documents\\OptionIQ"
        raise ValueError("Please give the full folder location, for example " + example)
    target = folder / config.DATA_FILE
    if target.resolve() == store.path.resolve():
        config.remember_data_dir(folder)
        return target.exists() and not carry_over and bool(store.load()["settings"].get("setupDone"))
    folder.mkdir(parents=True, exist_ok=True)
    existing = target.exists()
    current = store.load() if carry_over and store.exists() else None
    store.relocate(target)
    if not existing and current is not None:
        store.save(current)
    config.remember_data_dir(folder)
    return existing


def describe(r: dict) -> str:
    when = "today" if r["dte"] == 0 else ("tomorrow" if r["dte"] == 1 else f"in {r['dte']} days")
    side = "sold" if r.get("sb") == "S" else "bought"
    kind = "call" if r.get("cp") == "C" else "put"
    return f"{r['ticker']} {r['strike']} {kind} ({side}) expires {when}"


def reminder_loop(store: KVStore, interval: int = 3600):
    """Once an hour, a Windows or Mac notification for options expiring within the
    reminder window, at most once per option per day."""
    while True:
        try:
            st = store.load()
            if st["settings"].get("setupDone") and st["settings"].get("desktopNotifications", True):
                today = date.today().isoformat()
                due = kvstore.status(st, date.today())["expiring"]
                ids = {f"{r['account']}|{r['ticker']}|{r['strike']}|{r['cp']}|{r['expDate']}": r for r in due}
                fresh = [r for k, r in ids.items() if st["notified"].get(k) != today]
                if fresh:
                    title = f"{len(fresh)} option{'s' if len(fresh) > 1 else ''} expiring soon"
                    text = "\n".join(describe(r) for r in fresh[:4])
                    if len(fresh) > 4:
                        text += f"\n…and {len(fresh) - 4} more"
                    notify.toast(f"{brand.APP_NAME}: {title}", text)
                    st = store.load()
                    for k in ids:
                        st["notified"][k] = today
                    store.save(st)
        except Exception as exc:  # never let reminders take the app down
            print(f"reminder check failed: {exc}", file=sys.stderr)
        time.sleep(interval)


_screener = []


def start_addons(no_screener: bool) -> None:
    """First start of a shareable build: fetch the Screener's libraries, then
    start the Screener. Otherwise just start the Screener."""
    def run():
        if addons.needed() and not addons.install():
            return
        if not no_screener:
            try:
                proc = start_screener()
                if proc:
                    _screener.append(proc)
            except OSError as exc:
                print(f"Screener service didn't start: {exc}")
    threading.Thread(target=run, daemon=True).start()


def _port_busy(port: int) -> bool:
    with socket.socket() as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


def _running_screener_version() -> str:
    try:
        with urllib.request.urlopen("http://127.0.0.1:8765/health", timeout=3) as r:
            return str(json.loads(r.read() or b"{}").get("version") or "")
    except Exception:
        return ""


def _bundled_screener_version(script: Path) -> str:
    import re
    m = re.search(r'^VERSION = "([^"]+)"', script.read_text(encoding="utf-8"), re.M)
    return m.group(1) if m else ""


def _stop_port_owner(port: int) -> None:
    """End whichever program is listening on this port on this computer."""
    try:
        if sys.platform == "win32":
            out = subprocess.run(["netstat", "-ano", "-p", "TCP"], capture_output=True, text=True,
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
            pids = {ln.split()[-1] for ln in out.splitlines()
                    if f"127.0.0.1:{port} " in ln and "LISTENING" in ln}
            for pid in pids:
                subprocess.run(["taskkill", "/PID", pid, "/F"], capture_output=True,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        else:
            out = subprocess.run(["lsof", "-ti", f"tcp:{port}", "-sTCP:LISTEN"],
                                 capture_output=True, text=True).stdout
            for pid in out.split():
                subprocess.run(["kill", pid], capture_output=True)
    except OSError as exc:
        print(f"Couldn't stop the old Screener: {exc}")


def start_screener() -> subprocess.Popen | None:
    """Run the Screener service (Screener, Analysis and Discover tabs) next to
    the app with the same Python. If the same version is already running on
    its port, that one is used; an older one is replaced."""
    script = SCREENER_DIR / "Screener_Service.pyw"
    if not script.exists():
        return None
    if _port_busy(8765):
        running = _running_screener_version()
        if running == _bundled_screener_version(script):
            return None
        # An older Screener left running (by an earlier version, or by a copy
        # of OptionIQ in another folder) would answer every request with old
        # code. Stop it and start this one.
        print(f"Screener {running or '?'} is already running; replacing it with this version.")
        _stop_port_owner(8765)
        for _ in range(20):
            if not _port_busy(8765):
                break
            time.sleep(0.5)
        else:
            print("Couldn't stop the old Screener; using it as it is.")
            return None
    log = open(config.config_dir() / "screener.log", "a", encoding="utf-8")
    exe = sys.executable
    if exe.lower().endswith("pythonw.exe"):
        exe = exe[:-5] + ".exe"  # python.exe, but with no console window below
    # The Screener's IV history lives with the settings, so it survives updates.
    env = dict(os.environ, OPTIONIQ_IV_DB=str(config.config_dir() / "iv_history.sqlite"))
    return subprocess.Popen([exe, str(script), "--headless"], cwd=str(SCREENER_DIR), env=env,
                            stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def close_for_update() -> None:
    """The update helper copies the new files in once this app has closed.
    The Screener runs on the app's own Python, so it has to stop too."""
    for proc in _screener:
        try:
            proc.terminate()
            proc.wait(timeout=10)
        except Exception:
            pass

    def bye():
        time.sleep(2)  # let the page see "restarting" first
        os._exit(0)
    threading.Thread(target=bye, daemon=True).start()


def running_copy() -> int | None:
    """The port of an OptionIQ from this same folder that is already running."""
    try:
        info = json.loads((config.config_dir() / "running.json").read_text(encoding="utf-8"))
        port = int(info["port"])
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=3) as r:
            health = json.loads(r.read() or b"{}")
    except (OSError, ValueError, KeyError, TypeError):
        return None
    return port if health.get("ok") and health.get("root") == str(config.PORTABLE_ROOT or "") else None


def show_running(port: int) -> bool:
    """Ask the running copy to open its window. True if it did."""
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{port}/api/show", data=b"{}", method="POST",
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as r:
            return bool(json.loads(r.read() or b"{}").get("ok"))
    except (OSError, ValueError):
        return False


def free_port(preferred: int) -> int:
    with socket.socket() as s:
        try:
            s.bind(("127.0.0.1", preferred))
            return preferred
        except OSError:
            s.bind(("127.0.0.1", 0))
            return s.getsockname()[1]


def find_app_browser() -> list | None:
    """A Chromium browser that can show the app as its own window (no tabs or
    address bar). Edge ships with Windows 10 and 11. A Mac needs Chrome, Edge,
    Brave or Chromium installed; without one the app opens in Safari."""
    import shutil
    candidates = []
    if sys.platform == "darwin":
        for apps in (Path("/Applications"), Path.home() / "Applications"):
            for app, exe in (("Google Chrome", "Google Chrome"), ("Microsoft Edge", "Microsoft Edge"),
                             ("Brave Browser", "Brave Browser"), ("Chromium", "Chromium")):
                candidates.append(apps / f"{app}.app" / "Contents" / "MacOS" / exe)
    for env in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA"):
        base = os.environ.get(env)
        if base:
            candidates += [Path(base) / "Microsoft/Edge/Application/msedge.exe",
                           Path(base) / "Google/Chrome/Application/chrome.exe"]
    for c in candidates:
        if c.is_file():
            return [str(c)]
    for name in ("msedge", "microsoft-edge", "google-chrome", "chromium", "chromium-browser"):
        found = shutil.which(name)
        if found:
            return [found]
    return None


# The app window has its own browser profile, so on a fresh install Edge would
# otherwise run its welcome steps: sign in with the Windows account, announce
# sync, then sync the user's extensions, which open their own sign-up tabs.
QUIET_BROWSER_FLAGS = [
    "--no-first-run", "--no-default-browser-check",
    "--disable-sync", "--disable-extensions", "--disable-component-extensions-with-background-pages",
    "--disable-features=msImplicitSignin,msEdgeSyncConsent,msShowSyncPromo,EdgeSigninPromo",
]


def _quiet_profile(profile_dir: Path) -> None:
    """Turn off browser sign-in in the app's profile."""
    try:
        prefs_path = profile_dir / "Default" / "Preferences"
        prefs_path.parent.mkdir(parents=True, exist_ok=True)
        prefs = json.loads(prefs_path.read_text(encoding="utf-8")) if prefs_path.exists() else {}
        prefs.setdefault("signin", {})["allowed"] = False
        prefs_path.write_text(json.dumps(prefs), encoding="utf-8")
    except (OSError, ValueError):
        pass


def open_app_window(url: str, profile_dir: Path) -> bool:
    """Open the app in its own window and wait until it's closed. A separate
    browser profile keeps it independent of normal browsing, so closing the
    window is what ends the app."""
    exe = find_app_browser()
    if not exe:
        return False
    profile_dir.mkdir(parents=True, exist_ok=True)
    downloads = (config.PORTABLE_ROOT / "My Data" / "Exports") if config.PORTABLE_ROOT else None
    if downloads:
        _set_download_folder(profile_dir, downloads)
    _quiet_profile(profile_dir)
    started = time.monotonic()
    args = exe + [f"--app={url}", f"--user-data-dir={profile_dir}", *QUIET_BROWSER_FLAGS]
    proc = subprocess.Popen(args + ["--start-maximized"])
    _show_window.append(lambda: subprocess.Popen(args))
    if sys.platform == "darwin":
        # On a Mac, closing the last window leaves the browser running in the
        # Dock. So the app ends when the browser is quit (Cmd+Q) or a few
        # seconds after the window says it is closing.
        while proc.poll() is None:
            if window_closed():
                proc.terminate()
                return True
            time.sleep(1)
        # Handed to a browser window that was already open: keep serving.
        return time.monotonic() - started > 5
    proc.wait()
    # If an app window was already open, the browser hands this one to it and
    # returns at once. Then keep serving until the page goes quiet.
    return time.monotonic() - started > 5


def _set_download_folder(profile_dir: Path, folder: Path) -> None:
    """Excel and CSV exports from the app window land in My Data\\Exports."""
    try:
        folder.mkdir(parents=True, exist_ok=True)
        prefs_path = profile_dir / "Default" / "Preferences"
        prefs_path.parent.mkdir(parents=True, exist_ok=True)
        prefs = json.loads(prefs_path.read_text(encoding="utf-8")) if prefs_path.exists() else {}
        prefs.setdefault("download", {}).update({"default_directory": str(folder), "prompt_for_download": False,
                                                 "directory_upgrade": True})
        prefs.setdefault("savefile", {})["default_directory"] = str(folder)
        prefs_path.write_text(json.dumps(prefs), encoding="utf-8")
    except (OSError, ValueError):
        pass


def _log_to_file(path: Path) -> None:
    """pythonw has no console; keep a small log so problems can be reported."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists() and path.stat().st_size > 1_000_000:
            path.unlink()
        fh = open(path, "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = fh
    except OSError:
        pass


def main(argv=None):
    ap = argparse.ArgumentParser(description=APP_TITLE)
    ap.add_argument("--port", type=int, default=DEFAULT_PORT)
    ap.add_argument("--data", help="use this data file instead of the one chosen during setup")
    ap.add_argument("--browser", action="store_true", help="open in the default browser instead of a window")
    ap.add_argument("--serve-only", action="store_true", help="start the server without opening anything")
    ap.add_argument("--portable", action="store_true", help="keep settings and data in the folder above this app")
    ap.add_argument("--no-screener", action="store_true", help="don't start the Screener service")
    args = ap.parse_args(argv)

    if args.portable:
        # Layout of the shareable zip:  <their folder>/app/position_tracker.py
        config.set_portable(HERE.parent)
    config.config_dir().mkdir(parents=True, exist_ok=True)
    updates.cleanup()
    if sys.stdout is None or args.portable:
        _log_to_file(config.config_dir() / "tracker.log")
    print(f"--- started {time.strftime('%Y-%m-%d %H:%M:%S')}")

    if args.portable and not args.serve_only and not args.browser:
        # Started again (say, from the desktop icon) while this folder's
        # OptionIQ is still running: bring up its window instead.
        running = running_copy()
        if running and show_running(running):
            print(f"Already running on port {running}; opened its window.")
            return

    data_file = Path(args.data) if args.data else (config.saved_data_file() or config.default_data_dir() / config.DATA_FILE)
    store = KVStore(data_file)
    print(f"Data file: {data_file}" + ("" if store.exists() else " (not created yet; setup runs in the app)"))

    port = free_port(args.port)
    phone_copy = phone.CopyWriter(store)
    server = ThreadingHTTPServer(("127.0.0.1", port), make_handler(store, phone_copy))
    url = f"http://127.0.0.1:{port}/"
    threading.Thread(target=server.serve_forever, daemon=True).start()
    running_file = config.config_dir() / "running.json"
    try:
        running_file.write_text(json.dumps({"port": port, "pid": os.getpid()}), encoding="utf-8")
    except OSError:
        pass
    if not args.serve_only:
        threading.Thread(target=reminder_loop, args=(store,), daemon=True).start()
    phone_copy.poke()  # a fresh phone copy at every start
    start_addons(args.no_screener)
    if args.portable and not args.serve_only:
        # Also reaches people updating from a version that didn't make one.
        threading.Thread(target=shortcut.ensure, daemon=True).start()
    print(f"{APP_TITLE} running at {url}")

    try:
        if args.serve_only:
            while True:
                time.sleep(3600)

        if not args.browser:
            try:
                import webview  # type: ignore
            except ImportError:
                webview = None
            if webview is None:
                if open_app_window(url, config.config_dir() / "window"):
                    return
                if find_app_browser():
                    args.browser = None  # window handed to an existing one; just stay up
                else:
                    print("No app-window browser found, opening in the default browser instead.")
            else:
                class Api:
                    def choose_folder(self):
                        picked = window.create_file_dialog(webview.FOLDER_DIALOG)
                        return picked[0] if picked else None

                window = webview.create_window(APP_TITLE, url, width=1500, height=950, min_size=(1100, 700), js_api=Api())
                webview.start()
                return

        if args.browser is not None:
            webbrowser.open(url)
            _show_window.append(lambda: webbrowser.open(url))
        print("Close this window (or press Ctrl+C) to stop.")
        # The window belongs to a browser that was already running, so stop
        # when the page says it is closing (not after a quiet spell: a
        # window left idle or asleep still needs its server).
        while not window_closed():
            time.sleep(2)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            if json.loads(running_file.read_text(encoding="utf-8")).get("pid") == os.getpid():
                running_file.unlink()
        except (OSError, ValueError):
            pass
        server.shutdown()
        for proc in _screener:
            proc.terminate()


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, SystemExit):
        raise
    except Exception as exc:
        _startup_failed(exc)
        raise
