#!/bin/bash
# OptionIQ by Quantum Nexus LLC. - double-click to start (Mac).
# Everything (the app, its settings and your data) is kept in this folder.

cd "$(dirname "$0")" || exit 1
ROOT="$(pwd)"

# Files unzipped from a download are marked as "from the internet", and the
# Mac would ask about each one. This Start file has already been allowed, so
# clear that mark from the rest of the folder.
xattr -dr com.apple.quarantine "$ROOT" 2>/dev/null

say_and_wait() {
    echo
    echo "$1"
    echo
    read -r -p "Press Return to close this window. " _
    exit 1
}

for f in app/position_tracker.py app/web/app/index.html app/tracker/kvstore.py; do
    [ -f "$f" ] || say_and_wait "  OptionIQ is not fully unzipped yet. Wait until unzipping has
  completely finished, then double-click Start OptionIQ again.
  If you only copied this file, unzip the whole download first."
done

# OptionIQ's own copy of Python, fetched once on the first start.
# (Filled in by build_package_mac.py.)
PY_ARM64_URL="https://github.com/astral-sh/python-build-standalone/releases/download/20260807/cpython-3.12.13%2B20260807-aarch64-apple-darwin-install_only_stripped.tar.gz"
PY_ARM64_SHA="25baa97c65b3f0aa90e21131b4f9e80aef8899e8144006db8a9d2c1ab9e807e3"
PY_X86_URL="https://github.com/astral-sh/python-build-standalone/releases/download/20260807/cpython-3.12.13%2B20260807-x86_64-apple-darwin-install_only_stripped.tar.gz"
PY_X86_SHA="127053f1736f721e391ddb46f07585d05756e15bb8d757d3bbc0519738998ba1"
PY="app/python/bin/python3"

if [ ! -x "$PY" ]; then
    if [ "$(sysctl -n hw.optional.arm64 2>/dev/null)" = "1" ]; then
        URL="$PY_ARM64_URL"; SHA="$PY_ARM64_SHA"
    else
        URL="$PY_X86_URL"; SHA="$PY_X86_SHA"
    fi
    echo
    echo "  First start: OptionIQ is getting its own copy of Python"
    echo "  (about 20 MB, one time only). Please wait..."
    echo
    rm -rf app/python.download app/python
    mkdir -p app/python.download
    curl -fL --retry 3 --progress-bar -o app/python.download/python.tar.gz "$URL" \
        || say_and_wait "  The download didn't work. Check your internet connection, then
  double-click Start OptionIQ again."
    echo "$SHA  app/python.download/python.tar.gz" | shasum -a 256 -c - >/dev/null 2>&1 \
        || say_and_wait "  The download didn't arrive complete. Double-click Start OptionIQ
  again to try once more."
    tar -xzf app/python.download/python.tar.gz -C app/python.download \
        && mv app/python.download/python app/python \
        || say_and_wait "  Python couldn't be unpacked. Make sure there is some free disk
  space, then double-click Start OptionIQ again."
    rm -rf app/python.download
fi

# Use the Mac's own list of trusted web certificates for downloads.
if [ -z "$SSL_CERT_FILE" ] && [ -f /etc/ssl/cert.pem ]; then
    export SSL_CERT_FILE=/etc/ssl/cert.pem
fi

mkdir -p Settings
# Run it in its own session, so closing this Terminal window leaves it running.
nohup "$PY" -c 'import os, sys; os.setsid(); os.execv(sys.argv[1], sys.argv[1:])' \
    "$PY" app/position_tracker.py --portable </dev/null >>"Settings/start.log" 2>&1 &

echo
echo "  OptionIQ is starting and opens in its own window in a few seconds."
echo "  You can close this Terminal window."
echo
exit 0
