@echo off
REM OptionIQ by Quantum Nexus LLC. - double-click to start.
REM Everything (settings and your data) is kept in this folder.
cd /d "%~dp0"
set READY=1
if not exist "app\python\pythonw.exe" set READY=0
if not exist "app\position_tracker.py" set READY=0
if not exist "app\web\app\index.html" set READY=0
if not exist "app\tracker\kvstore.py" set READY=0
if "%READY%"=="0" (
    echo.
    echo   OptionIQ is not fully unzipped yet. Wait until unzipping has
    echo   completely finished, then double-click this file again.
    echo   If you only copied this file, unzip the whole download first.
    echo.
    pause
    exit /b 1
)
start "" "app\python\pythonw.exe" "app\position_tracker.py" --portable
exit /b 0
