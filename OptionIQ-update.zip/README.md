# OptionIQ: User Guide

*by Quantum Nexus LLC. · © 2026 Quantum Nexus LLC. All rights reserved. See TERMS OF USE.txt.*

OptionIQ is a log of the options you sell or buy and the stocks you own,
in each of your brokerage accounts. It shows your profit and loss, what's
expiring soon, a calendar of expiry dates, and it can screen the market for
new trade ideas.

You don't need to be a computer expert or a finance expert to use it. This
guide walks through everything step by step.

---

## 1. Installing it

You only need the file **OptionIQ.zip** and a Windows 10 or 11
computer. Nothing else has to be installed.

1. **Make a new folder** for the app. For example, right-click your Desktop,
   choose **New → Folder**, and call it `OptionIQ`.
2. **Put the zip file in that folder.**
3. **Right-click the zip file** and choose **Extract All…**. When it asks
   where, pick the same folder and click **Extract**.
4. In the folder, **double-click `Start OptionIQ`**.
   - If a blue box says **"Windows protected your PC"**, click
     **More info**, then **Run anyway**. Windows shows this for any program
     that came from the internet. You only see it the first time.
5. The app opens in its own window. To close it, close the window.
6. **The first time only**, the app downloads the parts the Screener needs
   (about 30 MB, usually a minute or two). A blue message at the bottom shows
   its progress. Your trades work as normal meanwhile; the **Screener**,
   **Analysis**, **Discover** and **Watchlist** tabs work once it's done. You
   need an internet connection for this.

**Tip:** to start it faster next time, right-click `Start OptionIQ`
and choose **Send to → Desktop (create shortcut)**.

---

## 2. First-time setup

The first time it opens, the app shows its **Terms of Use**. Read them, tick
**I have read and agree**, and click **Get started**. Then it asks three
things. You can change any of them later with the **⚙ Settings** button at
the top.

1. **Your free price key** (see section 3). You can skip it and add it later.
2. **How many accounts you have**, and a name for each. An *account* is
   wherever you hold investments, such as a Roth IRA, a regular brokerage
   account, or a spouse's IRA. Each account gets its own colour.
3. **Where to keep your information.** Choose **Inside the tracker's own
   folder** (recommended), so everything stays together in one folder.

---

## 3. Getting your free price key (Finnhub)

### What is a key, and do I need one?

A key (also called an *API key*) is like a password that lets the app ask a
price service for today's stock prices on your behalf. The **🔄 Prices** and
**🏔 Check ATH** buttons use a free service called **Finnhub**, and it needs
your own key. Everything else works without one, and the **Screener**,
**Analysis**, **Discover** and **Watchlist** tabs use Yahoo Finance, which
needs no key at all.

Each person gets their own key, for free. **Never share your key, and never
use someone else's.** The app never comes with a key in it.

### How to get one (about 2 minutes)

1. Open your web browser and go to **https://finnhub.io/register**
2. Fill in your email address and a password, then click **Sign up**.
   - If Finnhub sends you an email, open it and click the link to confirm.
3. Sign in. You land on your **Dashboard**.
4. Near the top you'll see **API Key** followed by a long line of letters and
   numbers. **Copy it**: select it with your mouse, right-click, and choose
   **Copy**.
5. Back in the app, **paste** it into the key box (right-click → **Paste**).
   The box is in the first-time setup, or later in **⚙ Settings → Price key**.
6. Click **Test key**.
   - **"The key works"**: it's saved. Done.
   - **"Finnhub didn't accept that key"**: the key was probably copied only
     partly. Copy it again and paste it again.
   - **"Couldn't reach Finnhub"**: check your internet connection and try
     again.

The free Finnhub plan is plenty. You never need to enter payment details.

### Where is my key kept?

Only on your computer, in the app's **Settings** folder. It is never put in
your trade information, your backups or your exports. To remove it, go to
**⚙ Settings → Price key → Remove key**.

---

## 4. Everyday use

The buttons along the top open each screen.

| Button | What it does |
|---|---|
| **📋 Options** | Every option trade. **+ New Trade** adds one, and you can edit or close trades from the list. |
| **🏦 Stocks** | The shares you own, what you paid, and what they're worth now. |
| **📈 Analytics** | Charts of your profit and loss over time, by account and by ticker. |
| **🏅 Scorecard** | How your trades have turned out: win rate, average return, and more. |
| **🎯 Screener** | Looks for new put and covered-call ideas on the tickers in your watchlist, using your own criteria. |
| **🔬 Analysis** | A closer look at one ticker. |
| **🔭 Discover** | Looks across the S&P 500 for ideas outside your watchlist. |
| **👁 Watchlist** | A card for each ticker you watch or hold, with simple green / red / grey signals (P/E, profit margin, debt, volatility). Click a card for details. |
| **📅 Calendar** | A month view with every open option on the day it expires. Click a day to see details. |
| **⬇ CSV / 📊 Excel** | Save your trades as a spreadsheet. |
| **⬆ Import** | Bring trades in from a spreadsheet (CSV) file. |
| **💾 Save Data** | Make a backup now (see section 5). |
| **📂 Load Data** | Bring in a backup file. |
| **🔄 Prices** | Get the latest stock prices (needs your price key). |
| **⚙ Settings** | Accounts, backups, reminders, price key, and where your information is kept. |

The coloured tabs under the buttons pick which accounts you're looking at.

### Reminders

- A **🔔 button** in the bottom-right corner shows how many options expire
  within 7 days (you can change the number of days in Settings), and any
  options past their expiry date that are still marked open, so you can close
  or roll them. Click it to see the list.
- While the app is open, Windows also shows a small pop-up once a day.
- The 🔔 button also says **Backup due** when your last backup is more than a
  week old.

---

## 5. Your information and backups

- Everything stays in your app folder. **My Data** holds your trades and
  backups. **Settings** holds your choices and your price key.
- **Back up** with **💾 Save Data** (or **⚙ Settings → Back up now**). Each
  backup is a dated file in **My Data → Backups**. The newest 30 are kept.
  To keep a copy somewhere safe, copy that file to a USB stick, email or
  cloud drive.
- **To move the app**, or copy it to a new computer, move or copy the whole
  folder. Everything comes with it.
- Nothing is sent anywhere, except ticker symbols when the app looks up
  prices.

### Coming from the browser version (Options Trade Logger)?

Press **📂 Load Data** and choose your backup file (for example
`options_trades_backup_2026-09-21.json`). All your trades, stocks and your
watchlist come in exactly as they were. Any account names in the file that
you haven't set up are added for you; rename them in ⚙ Settings if you like.

---

### New versions

When a new version is ready, a green note appears at the top right of the app saying which version it is and what's new. Click **Update now**. OptionIQ backs up your data, downloads the new version, checks it arrived complete, then closes and opens again on its own. Your trades, accounts, price key and folder choices stay exactly as they are, and nothing is asked again.

Click **Later** to be reminded next time you start the app. To check yourself, open **⚙ Settings → About → Check for updates**. If an update ever can't download, the note offers **Download it myself**: unzip that file over your OptionIQ folder (Windows: Extract All into the same folder and choose Replace; Mac: move your **My Data** and **Settings** folders into the new OptionIQ folder).

## 6. If something goes wrong

- **Nothing happens when I double-click Start OptionIQ.** Make sure the
  unzipping has completely finished before you start it (step 1.3); it takes
  a minute or two. There must be an `app` folder next to the Start file. If
  it still won't start, OptionIQ shows a message and leaves a file called
  `OptionIQ startup error.txt` in the folder: send that file to whoever
  shared the app with you.
- **The Screener says the service isn't connected.** If the blue "Getting
  the Screener ready" message is showing, wait for it to finish. If a red
  message says the download didn't work, check your internet and click
  **Try again**. Otherwise close the app and start it again. The
  screener starts with it and takes a few seconds.
- **Prices didn't update.** Check your internet connection and your price key
  (⚙ Settings → Price key → Test key).
- **I need to report a problem.** Send the files `Settings\tracker.log` and
  `Settings\screener.log` from your app folder to whoever shared the app with
  you. They contain no trades and no keys.

---

## Terms of use and ownership

OptionIQ is © 2026 Quantum Nexus LLC. All rights reserved. You may
use it free for your own investments. Please don't sell it, change it, or
pass it on to others without permission from Quantum Nexus LLC. The full
terms are in **TERMS OF USE.txt**, and the app asks you to agree to them the
first time it opens. OptionIQ is a record-keeping tool, not financial
advice.

---

## For developers

- `position_tracker.py` serves the screens on `127.0.0.1:8766` and keeps the
  data in `tracker_data.json`; it also starts `screener/Screener_Service.pyw
  --headless` on port 8765. Options: `--portable`, `--browser`,
  `--serve-only`, `--no-screener`, `--data FILE`, `--port N`.
- The screens are the original Options Trade Logger
  (`logger_src/options_logger1.html`). `python build_ui.py` applies the small
  desktop changes (listed in `PATCHES`), compiles the JSX with
  `tools/babel.min.js` (needs Node) and writes `web/app/`. `web/app/shim.js`
  replaces `localStorage` with the local service, so the price key goes to
  `Settings/config.json` and never into the data file.
- `python build_package.py --python <win python> --wheels <win wheels> --out
  <zip>` builds the shareable zip with its own Windows Python 3.12 and the
  Screener's libraries (numpy, pandas, yfinance).
- Owner name, year and version live in `tracker/brand.py` (and the text in
  `TERMS OF USE.txt`); change them there and rebuild.
- Tests: `python -m unittest discover -s tests`
