// 🧭 Portfolio Review: the rules.
//
// One pass over every stock and every open option in all accounts, giving
// each one a plain recommendation and a one-line reason, a "this week" to-do
// list, and cash-secured put ideas for spare cash. Nothing here places a
// trade or changes a record: it only reads the app's data and returns rows.
//
// Pure functions only (no screen, no storage), so the same file runs in the
// app window and in tests/portfolio_review_test.js under Node.
(function (root) {
  "use strict";

  var DEFAULTS = {
    profitTarget: 50,      // % of the premium earned (the app's 🎯 target)
    maxStock: 10,          // % of the portfolio in one stock
    maxSector: 35,         // % of the portfolio in one group
    expiringSoon: 3,       // days
    ccMinDays: 14,         // covered-call window
    ccMaxDays: 28,
    lossFlag: 30,          // % down from cost counts as a risk flag
    lightSector: 3,        // a group under this % of the portfolio is "light"
    plannedCallDays: 120,  // a call sold this many days before expiry = planned call-away
    rate: 0.04,            // interest rate for Black-Scholes estimates
    maxSuggested: 10
  };

  // Groups used for the 35% limit. Yahoo puts most of these under
  // "Technology", which is too broad to be useful; anything not listed here
  // keeps its Yahoo sector. Changeable in the review's settings.
  var GROUPS = {
    "AI chips & hardware": "NVDA AMD AVGO ARM MRVL MU AMAT LRCX KLAC TER CRDO COHR AAOI SMCI DELL HPE SOXX SMH SOXQ SKHY Q CBRS GLW INTC QCOM TXN ADI MCHP ON NXPI ASML SNPS CDNS ALAB ANET VRT CRWV NBIS LITE CIEN WDC STX SNDK MPWR ONTO ENTG",
    "Chip foundry (Taiwan)": "TSM UMC",
    "Cybersecurity": "PANW CRWD ZS FTNT S OKTA NET CYBR CHKP QLYS TENB RPD HACK CIBR BUG",
    "Broad market fund": "SPY VOO IVV VTI DIA IWM QQQ QQQM RSP SPLG SCHB SCHX ITOT VT VTV VUG",
    "Gold & metals": "GLD GLDM IAU SGOL SLV PPLT",
    "Tech fund": "FTEC XLK VGT IYW",
    "Quantum computing": "QBTS IONQ RGTI QUBT"
  };
  // Leveraged funds: never sell puts on them (too risky to own if assigned).
  var LEVERAGED = "SOXL SOXS TQQQ SQQQ UPRO SPXL SPXU SPXS SSO QLD TNA TZA LABU LABD NVDL NVDX NVDU TSLL TSLQ TSLT FNGU FNGD TECL TECS UDOW SDOW YINN YANG USD ROM UVXY SVXY BOIL KOLD NUGT DUST JNUG FAS FAZ ERX CONL MSTU MSTX AMDL BITX".split(" ");
  // Market holidays that fall on a Friday: options expire on the Thursday.
  var FRIDAY_HOLIDAYS = ["2026-07-03", "2026-12-25", "2027-03-26", "2027-06-18", "2027-12-24", "2028-04-14", "2028-11-24"];

  // ── small helpers ────────────────────────────────────────
  function num(v) { var n = parseFloat(v); return isFinite(n) ? n : null; }
  function up(s) { return String(s || "").trim().toUpperCase(); }
  function parseDate(s) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(s || "")); return m ? Date.UTC(+m[1], +m[2] - 1, +m[3]) : null; }
  function iso(ms) { return new Date(ms).toISOString().slice(0, 10); }
  function addDays(d, n) { return iso(parseDate(d) + n * 864e5); }
  function daysBetween(a, b) { return Math.round((parseDate(b) - parseDate(a)) / 864e5); }
  function dow(d) { return new Date(parseDate(d)).getUTCDay(); }
  var MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  function md(d) { var p = parseDate(d); if (p == null) return ""; var x = new Date(p); return MONTHS[x.getUTCMonth()] + " " + x.getUTCDate(); }
  function mdPad(d) { var p = parseDate(d); if (p == null) return ""; var x = new Date(p); var dd = x.getUTCDate(); return MONTHS[x.getUTCMonth()] + " " + (dd < 10 ? "0" : "") + dd; }
  function wd(d) { return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][dow(d)]; }
  function money(v, dp) { if (v == null || !isFinite(v)) return "—"; var s = Math.abs(v).toLocaleString("en-US", { minimumFractionDigits: dp || 0, maximumFractionDigits: dp || 0 }); return (v < 0 ? "-$" : "$") + s; }
  function strikeTxt(k) { return (Math.round(k * 100) / 100).toString(); }
  function plural(n, w) { return n + " " + w + (n === 1 ? "" : "s"); }
  function cleanCompany(s) { return String(s || "").replace(/\s*\([A-Z]+:[A-Z.\-]+\)\s*$/, "").trim(); }
  function quoteKey(tk, exp, strike, cp) { return up(tk) + "|" + String(exp || "").slice(0, 10) + "|" + (+strike).toFixed(2) + "|" + up(cp || "P"); }

  // A Friday expiry (Thursday when the Friday is a market holiday).
  function expiryOn(friday) { return FRIDAY_HOLIDAYS.indexOf(friday) >= 0 ? addDays(friday, -1) : friday; }
  function fridayOnOrAfter(d) { var k = (5 - dow(d) + 7) % 7; return addDays(d, k); }
  function fridayBefore(d) { var k = (dow(d) - 5 + 7) % 7; return addDays(d, k === 0 ? -7 : -k); }
  function thisFriday(today) { return fridayOnOrAfter(today); }

  // Standard strikes: $1 under $50, $2.50 under $150, $5 above.
  function strikeStep(p) { return p < 50 ? 1 : p < 150 ? 2.5 : 5; }
  function floorStrike(p) { var s = strikeStep(p); return Math.floor(p / s + 1e-9) * s; }

  // ── Black-Scholes (estimates when there is no live quote) ─
  function ncdf(x) {
    var t = 1 / (1 + 0.2316419 * Math.abs(x));
    var d = 0.3989422804014327 * Math.exp(-x * x / 2);
    var p = d * t * (0.319381530 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
    return x > 0 ? 1 - p : p;
  }
  function bs(S, K, days, iv, r, cp) {
    if (!(S > 0 && K > 0 && iv > 0 && days > 0)) return null;
    var T = days / 365, sq = iv * Math.sqrt(T);
    var d1 = (Math.log(S / K) + (r + iv * iv / 2) * T) / sq, d2 = d1 - sq;
    if (cp === "C") return { price: S * ncdf(d1) - K * Math.exp(-r * T) * ncdf(d2), delta: ncdf(d1) };
    return { price: K * Math.exp(-r * T) * ncdf(-d2) - S * ncdf(-d1), delta: ncdf(d1) - 1 };
  }

  // ── groups ───────────────────────────────────────────────
  function buildGroupMap(extraText) {
    var map = {};
    Object.keys(GROUPS).forEach(function (g) { GROUPS[g].split(/\s+/).forEach(function (t) { if (t) map[t] = g; }); });
    String(extraText || "").split(/\r?\n/).forEach(function (line) {
      var m = /^\s*([A-Za-z.\-]+)\s*[=:]\s*(.+?)\s*$/.exec(line);
      if (m) map[up(m[1])] = m[2];
    });
    return map;
  }
  function isLeveraged(tk, name) {
    return LEVERAGED.indexOf(tk) >= 0 || /\b(2x|3x|-1x|-2x|-3x|ultra(pro)?|leveraged|daily bull|daily bear)\b/i.test(name || "");
  }

  // ── research (Stock Analysis) facts for one ticker ───────
  function facts(row, price, today) {
    var out = { de: null, fcfNeg: false, loss: false, dilution: false, lockup: null, belowAvgs: false, pe: null };
    if (!row) return out;
    var texts = [].concat(row.bad || [], row.good || [], row.fund_neutral || []).map(function (x) { return String(x && x.t || ""); });
    texts.forEach(function (t) {
      var m;
      if ((m = /debt\/equity\s+(-?[\d.,]+)/i.exec(t))) out.de = num(m[1].replace(/,/g, ""));
      if (/negative free cash flow/i.test(t)) out.fcfNeg = true;
      if ((m = /net margin\s+(-?[\d.]+)%/i.exec(t)) && num(m[1]) < 0) out.loss = true;
      if ((m = /\bROE\s+(-?[\d.]+)%/i.exec(t)) && num(m[1]) < 0) out.loss = true;
      if (/\beps\s+-|net loss/i.test(t)) out.loss = true;
      if ((m = /(shares outstanding|share count)\s*\+?([\d.]+)%/i.exec(t)) && num(m[2]) > 10) out.dilution = true;
      if (/dilut/i.test(t) && !/no dilut/i.test(t)) out.dilution = true;
    });
    if (row.dilution === true || num(row.share_growth) > 10) out.dilution = true;
    var p = price || num(row.price);
    var s50 = num(row.sma50), s200 = num(row.sma200);
    if (p && s50 && s200) out.belowAvgs = p < s50 && p < s200;
    // A year of prices is 252 trading days; fewer means it listed less than a
    // year ago. Lockups usually end 180 days after the listing.
    var bars = num(row.bars);
    if (bars != null && bars > 0 && bars < 240 && today) {
      var listed = addDays(today, -Math.round(bars * 365 / 252));
      var lockEnd = addDays(listed, 180);
      var d = daysBetween(today, lockEnd);
      if (d >= -5 && d <= 60) out.lockup = lockEnd;
    }
    return out;
  }

  var ORDER = { "BUY MORE": 0, "HOLD": 1, "REDUCE": 2, "SELL": 3 };
  function worse(a, b) { return ORDER[a] >= ORDER[b] ? a : b; }
  function fromVerdict(v) {
    v = up(v);
    if (v === "BUY" || v === "STRONG BUY") return "BUY MORE";
    if (v === "SELL" || v === "AVOID" || v === "STRONG SELL") return "SELL";
    return "HOLD";
  }

  // ── main ─────────────────────────────────────────────────
  // input: {today, trades, stocks, quotes, analysis:{rows,ranAt}, iv:{SYM:{iv30,close,date}},
  //         accounts, settings, overrides, live:{quoteKey:{mid,bid,ask,iv}}, cspInputs}
  function review(input) {
    var S = Object.assign({}, DEFAULTS, input.settings || {});
    ["profitTarget", "maxStock", "maxSector", "expiringSoon", "ccMinDays", "ccMaxDays", "lossFlag", "lightSector"].forEach(function (k) {
      var v = num(S[k]); S[k] = v == null ? DEFAULTS[k] : v;
    });
    var today = input.today;
    var friday = thisFriday(today);
    var quotes = input.quotes || {}, live = input.live || {};
    var iv = input.iv || {};
    var anRows = (input.analysis && input.analysis.rows) || [];
    var an = {};
    anRows.forEach(function (r) { if (r && r.ticker && !r.error) an[up(r.ticker)] = r; });
    var groupMap = buildGroupMap(S.groups);
    var ownEnough = {}; (S.ownEnough || []).forEach(function (t) { ownEnough[up(t)] = true; });
    var planned = S.plannedCalls || {};
    var overrides = input.overrides || {};
    var notes = [];

    function groupOf(tk) {
      if (groupMap[tk]) return groupMap[tk];
      var r = an[tk];
      return (r && r.sector) || "Other";
    }
    function earnings(tk) {
      var e = an[tk] && an[tk].next_earnings;
      return e && parseDate(e) != null ? String(e).slice(0, 10) : null;
    }
    function upcomingEarnings(tk) { var e = earnings(tk); return e && e >= today ? e : null; }

    // ── stocks: lots → one row per account + ticker ──
    var trades = (input.trades || []).filter(function (t) { return t && t.ticker; });
    var open = trades.filter(function (t) { return !t.action || t.action === "Open"; });
    var lots = (input.stocks || []).filter(function (s) { return s && s.ticker && s.status !== "Sold" && !s.soldDate && (num(s.shares) || 0) > 0; });
    var rowsBy = {}, tickerTot = {}, total = 0, totalCost = 0;
    lots.forEach(function (s) {
      var tk = up(s.ticker), key = s.account + "|" + tk;
      var sh = num(s.shares) || 0, cost = num(s.costBasis) || 0;
      var r = rowsBy[key] || (rowsBy[key] = { account: s.account, ticker: tk, company: "", shares: 0, cost: 0, price: null, statuses: {}, firstDate: null });
      r.shares += sh; r.cost += sh * cost;
      var px = num(s.currentPrice);
      if (px) r.price = px;
      if (!r.company && s.company) r.company = cleanCompany(s.company);
      r.statuses[s.status === "Assigned" ? "Assigned" : "Bought"] = true;
      var d = String(s.dateAcquired || "").slice(0, 10);
      if (parseDate(d) != null && (!r.firstDate || d < r.firstDate)) r.firstDate = d;
    });
    var stockRows = Object.keys(rowsBy).map(function (k) { return rowsBy[k]; });
    stockRows.forEach(function (r) {
      if (!r.price) r.price = (an[r.ticker] && num(an[r.ticker].price)) || (iv[r.ticker] && iv[r.ticker].close) || 0;
      r.value = r.shares * r.price;
      r.avgCost = r.shares ? r.cost / r.shares : 0;
      r.gain = r.value - r.cost;
      r.gainPct = r.cost ? r.gain / r.cost : null;
      if (!r.company && an[r.ticker]) r.company = an[r.ticker].name || "";
      total += r.value; totalCost += r.cost;
      var t = tickerTot[r.ticker] || (tickerTot[r.ticker] = { value: 0, cost: 0, shares: 0 });
      t.value += r.value; t.cost += r.cost; t.shares += r.shares;
    });
    var groupTot = {};
    Object.keys(tickerTot).forEach(function (tk) { var g = groupOf(tk); groupTot[g] = (groupTot[g] || 0) + tickerTot[tk].value; });
    function pctOf(v) { return total > 0 ? v / total * 100 : 0; }
    function groupPct(tk) { return pctOf(groupTot[groupOf(tk)] || 0); }
    function tickerPct(tk) { return pctOf((tickerTot[tk] || {}).value || 0); }
    function isIndexFund(tk) { return groupOf(tk) === "Broad market fund"; }
    var overGroups = Object.keys(groupTot).filter(function (g) { return g !== "Broad market fund" && pctOf(groupTot[g]) > S.maxSector; });

    // ── rating per ticker (the same in every account) ──
    var ratings = {};
    function rate(tk) {
      if (ratings[tk]) return ratings[tk];
      var r = an[tk], price = (tickerTot[tk] && tickerTot[tk].shares) ? tickerTot[tk].value / tickerTot[tk].shares : (iv[tk] && iv[tk].close) || (r && num(r.price));
      var f = facts(r, price, today), flags = [];
      if (f.de != null && f.de > 200) flags.push("heavy debt (debt/equity " + Math.round(f.de) + ")");
      if (f.fcfNeg) flags.push("burning cash (negative free cash flow)");
      if (f.loss) flags.push("losing money");
      if (f.dilution) flags.push("issuing lots of new shares");
      if (f.lockup) flags.push("recent IPO, insiders can sell from about " + md(f.lockup));
      if (f.belowAvgs) flags.push("price below its 50-day and 200-day averages");
      var tt = tickerTot[tk];
      if (tt && tt.cost > 0 && tt.value / tt.cost - 1 < -S.lossFlag / 100) flags.push("down " + Math.round((1 - tt.value / tt.cost) * 100) + "% from your cost");
      var base = r ? fromVerdict(r.verdict) : "HOLD", rec = base, why = [];
      if (r && r.note) why.push("App rating " + r.verdict + ": " + r.note + ".");
      else if (!r) why.push("No Stock Analysis data for this ticker, so the rating stays HOLD.");
      if (flags.length >= 3) rec = worse(rec, "SELL");
      else if (flags.length === 2) rec = worse(rec, "REDUCE");
      if (flags.length) why.push("Risk flags: " + flags.join("; ") + ".");
      var capped = "";
      if (rec === "BUY MORE") {
        if (!isIndexFund(tk) && tickerPct(tk) > S.maxStock) { rec = "HOLD"; capped = "Already " + tickerPct(tk).toFixed(1) + "% of your portfolio (limit " + S.maxStock + "%), so no adding."; }
        else if (overGroups.indexOf(groupOf(tk)) >= 0) { rec = "HOLD"; capped = groupOf(tk) + " is already " + groupPct(tk).toFixed(0) + "% of your portfolio (limit " + S.maxSector + "%), so no adding."; }
      }
      if (capped) why.push(capped);
      var company = { de: f.de != null && f.de > 200, loss: f.loss, dilution: f.dilution, lockup: !!f.lockup };
      ratings[tk] = { rec: rec, auto: rec, base: base, flags: flags, why: why.join(" "), facts: f, company: company,
        verdict: r ? r.verdict : "", fund: r ? num(r.fund_score) : null, tech: r ? num(r.tech_score) : null };
      return ratings[tk];
    }
    Object.keys(tickerTot).forEach(rate);
    // Hand changes (✎) win until the next run.
    Object.keys(overrides).forEach(function (k) {
      var m = /^stock\|(.+)$/.exec(k);
      if (m && ratings[m[1]] && ORDER[overrides[k]] != null) { ratings[m[1]].rec = overrides[k]; ratings[m[1]].overridden = true; }
    });

    // ── option helpers ──
    function optPrice(t) {
      var q = quotes[quoteKey(t.ticker, t.expDate, t.strike, t.cp)];
      if (!q || q.expired) return null;
      var v = q.mid != null ? q.mid : q.last;
      return v != null && isFinite(v) ? +v : null;
    }
    function ivFor(tk, exp) {
      var best = null, bestD = 1e9;
      Object.keys(quotes).forEach(function (k) {
        var p = k.split("|"); if (p[0] !== tk) return;
        var q = quotes[k]; if (!q || !(q.iv > 0.01)) return;
        var d = Math.abs(daysBetween(exp || today, p[1]));
        if (d < bestD) { bestD = d; best = q.iv; }
      });
      if (best) return { iv: best, from: "option prices" };
      if (iv[tk] && iv[tk].iv30 > 0) return { iv: iv[tk].iv30, from: "30-day IV" };
      return null;
    }
    function stockPrice(tk, t) {
      var tt = tickerTot[tk];
      if (tt && tt.shares) return tt.value / tt.shares;
      var p = t && num(t.currentStock);
      if (p) return p;
      return (iv[tk] && iv[tk].close) || (an[tk] && num(an[tk].price)) || null;
    }
    function openCalls(acct, tk) {
      return open.filter(function (t) { return t.account === acct && up(t.ticker) === tk && t.cp === "C" && t.sb === "S"; });
    }
    function sharesIn(acct, tk) { var r = rowsBy[acct + "|" + tk]; return r ? r.shares : 0; }

    // Covered-call exit: first Friday 2–4 weeks out that is before earnings.
    function ccExpiry(tk) {
      var e = upcomingEarnings(tk);
      var d = fridayOnOrAfter(addDays(today, S.ccMinDays));
      for (; daysBetween(today, d) <= S.ccMaxDays; d = addDays(d, 7)) {
        var x = expiryOn(d);
        if (!e || x < e) return x;
      }
      return null;
    }

    // ── stock rows: recommendation + how to exit ──
    var shown = stockRows.filter(function (r) { return r.shares >= 0.5; });
    shown.forEach(function (r) {
      var R = rate(r.ticker);
      r.rec = R.rec; r.overridden = !!R.overridden; r.why = R.why || "";
      r.pct = pctOf(r.value);
      r.group = groupOf(r.ticker);
      var e = upcomingEarnings(r.ticker);
      r.nextEvent = e ? "Earnings " + md(e) : (R.facts.lockup ? "Lockup ends ~" + md(R.facts.lockup) : "—");
      r.boughtAssigned = r.statuses.Assigned && r.statuses.Bought ? "Assigned/Bought" : r.statuses.Assigned ? "Assigned" : "Bought";
      var calls = openCalls(r.account, r.ticker);
      r.callsSold = calls.length ? calls.map(function (c) { return (parseInt(c.contracts) || 1) + "× " + strikeTxt(+c.strike) + " call exp " + String(c.expDate).slice(5, 10); }).join("; ") : "—";
      r.how = "—"; r.plan = ""; r.exit = null;
      if (r.rec !== "SELL" && r.rec !== "REDUCE") {
        if (!r.why) r.why = "Nothing stands out.";
        return;
      }
      var reduce = r.rec === "REDUCE";
      // REDUCE = about half, in whole 100-share lots where there are enough shares.
      var qty = reduce ? (r.shares >= 200 ? Math.floor(r.shares / 200) * 100 : Math.round(r.shares / 2)) : r.shares;
      var qtyTxt = (Math.round(qty * 1000) / 1000).toLocaleString("en-US");
      var dToE = e ? daysBetween(today, e) : null;
      var companyIssue = R.company.loss || R.company.dilution || R.company.lockup;
      var exp = ccExpiry(r.ticker);
      var reason = null;
      if (r.shares < 100) reason = "fewer than 100 shares here, too few for a covered call";
      else if (qty < 100) reason = "selling " + Math.round(qty) + " shares, too few for a covered call";
      else if (companyIssue) reason = "the company has its own problems (" + R.flags.filter(function (f) { return /losing|issuing|IPO|debt/.test(f); }).join("; ") + ")";
      else if (dToE != null && dToE <= 7) reason = dToE === 0 ? "earnings are today" : dToE === 1 ? "earnings are tomorrow" : "earnings are only " + plural(dToE, "day") + " away";
      else if (!exp) reason = "earnings (" + md(e) + ") come before a 2–4 week covered call could expire";
      // Calls about to expire worthless are left alone; sell the shares after.
      var dying = calls.filter(function (c) { return +c.strike > r.price && daysBetween(today, c.expDate) <= S.expiringSoon; });
      var live2 = calls.filter(function (c) { return dying.indexOf(c) < 0; });
      var far = live2.filter(function (c) { return +c.strike > r.price * 1.10; });
      var near = live2.filter(function (c) { return +c.strike <= r.price * 1.10; });
      var steps = [];
      function buyBack(c, why) {
        var p = optPrice(c);
        steps.push("Buy back the " + strikeTxt(+c.strike) + " call (" + md(c.expDate) + (p != null ? ", ~" + money(p, 2) : "") + ")" + (why || "") + ".");
      }
      if (dying.length) steps.push("Let the " + dying.map(function (c) { return strikeTxt(+c.strike) + " call"; }).join(" and ") + " expire on " + md(dying[0].expDate) + " (worthless), then go on.");
      if (reason) {
        live2.forEach(function (c) { buyBack(c, ""); });
        r.how = "Sell outright";
        var whenTxt = dying.length ? " on " + wd(addDays(dying[0].expDate, 3)) + " " + md(addDays(dying[0].expDate, 3)) : e && dToE >= 1 && dToE <= 14 ? " before earnings on " + md(e) : " now";
        steps.push((live2.length ? "Then sell " : "Sell ") + qtyTxt + " shares" + (reduce && qty < r.shares ? " (about half)" : "") + whenTxt + ": " + reason + ".");
        r.exit = { how: "outright", qty: qty, calls: live2.map(function (c) { return c.id; }), after: dying.length ? addDays(dying[0].expDate, 3) : null };
      } else if (near.length && near.every(function (c) { return !e || c.expDate < e; })) {
        r.how = "Covered call (already set)";
        far.forEach(function (c) { buyBack(c, "; it is more than 10% above the price"); });
        steps.push("Keep the " + near.map(function (c) { return strikeTxt(+c.strike) + " call (" + md(c.expDate) + ")"; }).join(" and ") + ": this is your exit. If the price is above the strike at expiry, the shares are sold there.");
        r.exit = { how: "cc-set", qty: qty };
      } else {
        far.forEach(function (c) { buyBack(c, "; it is more than 10% above the price, so it won't sell the shares"); });
        var k = floorStrike(r.price), contracts = Math.max(1, Math.floor(qty / 100));
        var q = live[quoteKey(r.ticker, exp, k, "C")], prem = null, est = false;
        if (q && (q.mid != null)) prem = q.mid;
        else { var v = ivFor(r.ticker, exp), b = v && bs(r.price, k, daysBetween(today, exp), v.iv, S.rate, "C"); if (b) { prem = b.price; est = true; } }
        r.how = "Covered call";
        steps.push((far.length ? "Then sell " : "Sell ") + plural(contracts, "call") + ": " + strikeTxt(k) + " strike, " + md(exp) +
          (prem != null ? " (" + (est ? "estimated " : "") + "~" + money(prem, 2) + " a share)" : " (price unavailable)") + ".");
        steps.push("If " + r.ticker + " is above $" + strikeTxt(k) + " on " + md(exp) + ", " + (contracts * 100) + " shares sell at about " + (prem != null ? money(k + prem, 2) : "$" + strikeTxt(k)) + " a share counting the premium" +
          (e ? "; that is before earnings on " + md(e) + "." : "."));
        if (reduce) steps.push("Keep the rest; sell covered calls on it as usual.");
        r.exit = { how: "cc", qty: qty, strike: k, expiry: exp, premium: prem, estimate: est, contracts: contracts };
      }
      r.plan = steps.join(" ");
    });
    var order = { "BUY MORE": 0, "HOLD": 1, "REDUCE": 2, "SELL": 3 };
    shown.sort(function (a, b) { return order[a.rec] - order[b.rec] || a.ticker.localeCompare(b.ticker) || a.account.localeCompare(b.account); });

    // ── options: one row per open leg ──
    var optionRows = open.map(function (t) {
      var tk = up(t.ticker), K = +t.strike, n = parseInt(t.contracts) || 1;
      var sold = t.sb !== "B", put = t.cp !== "C";
      var px = stockPrice(tk, t);
      var now = optPrice(t);
      var prem = num(t.sellPremium); if (prem == null) prem = num(t.buyPremium);
      if (prem == null) prem = Math.abs(num(t.total) || 0) / (100 * n);
      var days = daysBetween(today, String(t.expDate).slice(0, 10));
      var itm = px != null ? (put ? px < K : px > K) : null;
      var far = px != null && K ? Math.abs(px / K - 1) : null;
      var profitPct = sold && now != null && prem > 0 ? (prem - now) / prem * 100 : null;
      var pl = now != null ? (sold ? prem - now : now - prem) * 100 * n : null;
      var R = rate(tk), owned = !!tickerTot[tk];
      var want = (R.rec === "BUY MORE" || R.rec === "HOLD") && overGroups.indexOf(groupOf(tk)) < 0;
      var bad = R.rec === "SELL" || R.rec === "REDUCE";
      var e = upcomingEarnings(tk), earnBefore = e && e <= String(t.expDate).slice(0, 10);
      var row = { id: t.id, account: t.account, ticker: tk, what: (sold ? "Sold " : "Bought ") + (put ? "Put" : "Call"),
        strike: K, expires: String(t.expDate).slice(0, 10), days: days, contracts: n, stockPrice: px, itm: itm, howFar: far,
        premium: prem, priceNow: now, profitPct: profitPct, pl: pl, costToClose: now != null ? now * 100 * n : null,
        rating: R.rec, owned: owned, earnings: e, action: "HOLD", why: "", roll: "", sold: sold, put: put };
      var stockRow = rowsBy[t.account + "|" + tk];
      var exitRow = shown.filter(function (s) { return s.account === t.account && s.ticker === tk; })[0];
      var covered = sold && !put && sharesIn(t.account, tk) >= 100 * n - 0.001;
      var plannedCall = !put && sold && (planned[t.id] === true || (planned[t.id] !== false && daysBetween(String(t.date || "").slice(0, 10), row.expires) > S.plannedCallDays));
      function act(a, w, roll) { row.action = a; row.why = w; if (roll) row.roll = roll; }
      if (!sold) act("HOLD", "Bought option. Keep while the reason you bought it holds; review monthly.");
      else if (itm === false && days <= S.expiringSoon && days >= 0) act("LET EXPIRE", "Out of the money with " + plural(days, "day") + " left; should expire worthless. Do nothing.");
      else if (covered && exitRow && exitRow.exit && exitRow.exit.how === "outright") act("BUY BACK", "The plan for these shares is to sell them outright, so buy this call back first.");
      else if (profitPct != null && profitPct >= S.profitTarget && !(itm && !put)) act("TAKE PROFIT", Math.round(profitPct) + "% of the premium earned (target " + S.profitTarget + "%). Buy it back and keep the profit.");
      else if (put && itm) {
        if (pl > 0 && !want) act("CLOSE", "In the money but still in profit, and you don't want more " + tk + ". Close it and keep the profit.");
        else if (bad) act("CLOSE", "In the money and " + tk + " is rated " + R.rec + ". Close it rather than be given the shares.");
        else if (!want) act("ROLL", "In the money and you don't want more " + tk + (overGroups.indexOf(groupOf(tk)) >= 0 ? " (" + groupOf(tk) + " is over your " + S.maxSector + "% limit)" : "") + ". Roll to a later date at the same or a lower strike, for a net credit.", "Same or lower strike, 3–5 weeks out, for a net credit");
        else if (days <= 14) act("LET ASSIGN", "In the money with " + plural(days, "day") + " left; " + tk + " is rated " + R.rec + ", so it's fine to take the shares.");
        else act("HOLD", "In the money, but " + plural(days, "day") + " left and " + tk + " is rated " + R.rec + ". Fine to own if assigned; look again a week before expiry.");
      }
      else if (put && bad && profitPct != null && profitPct >= 30) act("CLOSE", Math.round(profitPct) + "% earned and " + tk + " is rated " + R.rec + ". Close it and stop selling puts on it.");
      else if (!put && itm) {
        if (bad) act("LET ASSIGN", tk + " is rated " + R.rec + ": letting the shares be called away is your exit.");
        else if (days > 30 && plannedCall) act("LET ASSIGN", "Planned: let these shares be called away at expiry.");
        else act("ROLL", "In the money and you want to keep " + tk + ". Roll up and out (higher strike, later date) for a credit, or let the shares go.", "Higher strike, 3–5 weeks out, for a net credit");
      }
      else if (!put && bad && far != null && far > 0.10) act("BUY BACK", tk + " is rated " + R.rec + " and this call is more than 10% above the price, so it won't sell the shares. Buy it back and re-sell closer to the price.");
      else {
        var w = itm === null ? "Stock price unavailable." : (now == null ? "Option price unavailable. " : "") + "Working for you; time decay is on your side.";
        if (profitPct != null && profitPct >= 40 && profitPct < S.profitTarget) w += " Set a buy-to-close order at $" + (prem * 0.5).toFixed(2) + ".";
        act("HOLD", w);
      }
      if (sold && earnBefore && row.action === "HOLD") row.why += " Earnings on " + md(e) + " come before expiry: expect a big move.";
      if (now == null) row.priceNote = "price unavailable";
      return row;
    });
    Object.keys(overrides).forEach(function (k) {
      var m = /^option\|(.+)$/.exec(k); if (!m) return;
      optionRows.forEach(function (r) { if (String(r.id) === m[1]) { r.action = overrides[k]; r.overridden = true; } });
    });
    optionRows.sort(function (a, b) { return a.expires.localeCompare(b.expires) || a.ticker.localeCompare(b.ticker) || a.account.localeCompare(b.account); });

    // ── cash-secured puts ──
    var csp = cashSecuredPuts();
    function cspCandidateExpiry(tk) {
      var e = upcomingEarnings(tk), dToE = e ? daysBetween(today, e) : null;
      var std = expiryOn(fridayOnOrAfter(addDays(today, 21)));
      if (e && e <= friday) return { when: "After earnings (" + md(e) + ")", exp: expiryOn(fridayOnOrAfter(addDays(today, 35))), after: true };
      if (e && e <= std) {
        var fb = expiryOn(fridayBefore(e));
        if (daysBetween(today, fb) >= 14) return { when: "Now (expires before earnings)", exp: fb };
        return { when: "Wait — earnings " + mdPad(e), exp: null, wait: e };
      }
      return { when: "Now", exp: std };
    }
    function cashSecuredPuts() {
      var out = [], inputs = input.cspInputs || {};
      var itmPuts = {}, putsOn = {};
      open.forEach(function (t) {
        if (t.cp !== "P" || t.sb === "B") return;
        var tk = up(t.ticker), px = stockPrice(tk, t);
        putsOn[tk] = (putsOn[tk] || 0) + (parseInt(t.contracts) || 1);
        if (px != null && px < +t.strike) itmPuts[tk] = (itmPuts[tk] || 0) + (parseInt(t.contracts) || 1);
      });
      anRows.forEach(function (ar) {
        if (!ar || !ar.ticker || ar.error) return;
        var tk = up(ar.ticker), R = rate(tk), name = ar.name || "";
        var px = (iv[tk] && iv[tk].close) || num(ar.price);
        var ivv = iv[tk] && iv[tk].iv30;
        var g = groupOf(tk);
        var row = { ticker: tk, company: name, status: "MAYBE", reasons: [], why: "", price: px, iv30: ivv || null,
          rating: (ar.verdict || "") + " (fund " + (ar.fund_score != null ? ar.fund_score : "?") + ", trend " + (ar.tech_score != null ? ar.tech_score : "?") + ")",
          fund: num(ar.fund_score), group: g, earnings: upcomingEarnings(tk) };
        // Strike/expiry for every row that has a price, so "maybe" rows can be judged too.
        var x = cspCandidateExpiry(tk);
        row.when = x.when; row.expiry = x.exp;
        if (x.exp && px && ivv) {
          var days = daysBetween(today, x.exp), k = floorStrike(px), b = null;
          var sup = num(ar.support);
          for (var i = 0; i < 400 && k > 0; i++, k -= strikeStep(k)) {
            if (sup && k > sup) continue;
            b = bs(px, k, days, ivv, S.rate, "P");
            if (b && b.delta >= -0.22) break;
          }
          if (b && k > 0) { row.strike = Math.round(k * 100) / 100; row.estPremium = Math.round(b.price * 100) / 100; row.chance = Math.abs(b.delta); row.days = days; }
        }
        var lq = row.strike && live[quoteKey(tk, row.expiry, row.strike, "P")];
        if (lq && lq.mid != null) row.livePremium = lq.mid;
        var mine = inputs[tk] || {};
        if (mine.premium != null && mine.premium !== "") row.typedPremium = num(mine.premium);
        // status, first match wins
        var skip = [];
        if (itmPuts[tk]) skip.push("Already have " + (itmPuts[tk] === 1 ? "a put" : "puts") + " in the money");
        if (R.rec === "SELL" || R.rec === "REDUCE") skip.push("Rated " + R.rec + " in this review — no new puts");
        if (isLeveraged(tk, name)) skip.push("Leveraged fund — too risky to own if assigned");
        if (!isIndexFund(tk) && tickerPct(tk) > S.maxStock) skip.push("Already " + tickerPct(tk).toFixed(1) + "% of your portfolio");
        if (ownEnough[tk]) skip.push("Marked “own enough”");
        var later = [];
        if (x.wait) later.push("Earnings too close — revisit after " + mdPad(x.wait));
        if (overGroups.indexOf(g) >= 0) later.push(g + " is already " + pctOf(groupTot[g]).toFixed(0) + "% of your portfolio (limit " + S.maxSector + "%)");
        var good = up(ar.verdict) === "BUY" || up(ar.verdict) === "HOLD+" || up(ar.verdict) === "HOLD";
        var light = pctOf(groupTot[g] || 0) < S.lightSector && g !== "Other";
        if (skip.length) { row.status = "SKIP"; row.why = skip.join("; "); }
        else if (later.length) { row.status = "MAYBE LATER"; row.why = later.join("; "); }
        else if (R.rec === "BUY MORE") { row.status = "SUGGESTED"; row.why = "Rated BUY MORE in this review: being assigned is a good way to buy more."; }
        else if (good && row.fund != null && row.fund >= 7) { row.status = "SUGGESTED"; row.why = "Strong business (fundamentals score " + row.fund + "), app rating " + ar.verdict + "."; }
        else if (good && isIndexFund(tk)) { row.status = "SUGGESTED"; row.why = "Broad market fund, rated " + ar.verdict + ": the lowest-risk way to use cash (fundamentals scores don't apply to funds)."; }
        else if (good && light) { row.status = "SUGGESTED"; row.why = "Adds " + g + ", where you own little (" + pctOf(groupTot[g] || 0).toFixed(1) + "% of your portfolio). App rating " + ar.verdict + "."; row.light = true; }
        else {
          row.status = "MAYBE";
          row.why = !good ? "App rating " + (ar.verdict || "none") + (ar.note ? ": " + ar.note : "") + "." :
            "Rated " + ar.verdict + " but fundamentals score only " + (row.fund != null ? row.fund : "?") + "; only if you want to own it.";
        }
        if (row.status === "SUGGESTED" && !row.strike) row.why += " (No IV or price yet, so no strike: run 🔄 Update Prices or the Screener first.)";
        if (row.status === "SUGGESTED" && x.after) row.why += " Sell after earnings on " + md(row.earnings) + ".";
        if (row.status === "SUGGESTED" && /before earnings/.test(row.when)) row.why += " Expires " + md(row.expiry) + ", before earnings on " + md(row.earnings) + ".";
        out.push(row);
      });
      // Best first; at most 10 suggested.
      var sug = out.filter(function (r) { return r.status === "SUGGESTED"; });
      sug.sort(function (a, b) { return (b.fund == null ? -99 : b.fund) - (a.fund == null ? -99 : a.fund) || pctOf(groupTot[a.group] || 0) - pctOf(groupTot[b.group] || 0) || a.ticker.localeCompare(b.ticker); });
      sug.slice(S.maxSuggested).forEach(function (r) { r.status = "MAYBE"; r.why = "Good candidate, but not in the top " + S.maxSuggested + ". " + r.why; });
      var rank = { "SUGGESTED": 0, "MAYBE": 1, "MAYBE LATER": 2, "SKIP": 3 };
      out.sort(function (a, b) {
        return rank[a.status] - rank[b.status] ||
          (a.status === "SUGGESTED" ? sug.indexOf(a) - sug.indexOf(b) : a.ticker.localeCompare(b.ticker));
      });
      out.forEach(function (r) {
        var mine = inputs[r.ticker] || {};
        var c = num(mine.contracts);
        r.contracts = c != null ? Math.max(0, Math.round(c)) : (r.status === "SUGGESTED" && r.strike ? 1 : 0);
        r.premiumUsed = r.typedPremium != null ? r.typedPremium : r.livePremium != null ? r.livePremium : r.estPremium != null ? r.estPremium : null;
        r.premiumFrom = r.typedPremium != null ? "typed" : r.livePremium != null ? "live" : r.estPremium != null ? "estimate" : "";
        cspMath(r, today);
      });
      return out;
    }

    // ── summary + to-do ──
    var counts = { stocks: {}, options: {} };
    ["BUY MORE", "HOLD", "REDUCE", "SELL"].forEach(function (k) { counts.stocks[k] = { n: 0, value: 0 }; });
    shown.forEach(function (r) { counts.stocks[r.rec].n++; counts.stocks[r.rec].value += r.value; });
    ["LET EXPIRE", "TAKE PROFIT", "HOLD", "LET ASSIGN", "CLOSE", "BUY BACK", "ROLL"].forEach(function (k) { counts.options[k] = 0; });
    optionRows.forEach(function (r) { counts.options[r.action] = (counts.options[r.action] || 0) + 1; });

    var todo = [];
    function legTxt(r) { return r.ticker + " " + strikeTxt(r.strike) + " " + (r.put ? "put" : "call") + " (" + md(r.expires) + (r.contracts > 1 ? ", ×" + r.contracts : "") + ")"; }
    function legMoney(r) {
      if (r.costToClose == null) return "price unavailable";
      return r.action === "ROLL" ? "close costs ~" + money(r.costToClose) : "~" + money(r.costToClose);
    }
    var used = {};
    optionRows.forEach(function (r) {
      if ((r.action === "CLOSE" || r.action === "ROLL") && r.expires <= friday) {
        used[r.id] = 1;
        todo.push({ key: "opt|" + r.id + "|" + r.action, group: 1, when: "By " + wd(r.expires) + " " + md(r.expires),
          action: (r.action === "ROLL" ? "Roll the " : "Close the ") + legTxt(r), account: r.account, money: legMoney(r), why: r.why });
      }
    });
    shown.forEach(function (r) {
      if (r.rec !== "SELL" && r.rec !== "REDUCE") return;
      var e = upcomingEarnings(r.ticker), dToE = e ? daysBetween(today, e) : null, soon = dToE != null && dToE >= 1 && dToE <= 14;
      var x = r.exit || { how: "outright", qty: r.shares }, qtyTxt = (Math.round(x.qty * 1000) / 1000).toLocaleString("en-US");
      // Buying back the calls on these shares goes on the same line.
      var legs = optionRows.filter(function (o) { return o.account === r.account && o.ticker === r.ticker && !o.put && o.sold && o.action === "BUY BACK" && !used[o.id]; });
      legs.forEach(function (o) { used[o.id] = 1; });
      var back = legs.length ? "buy back the " + legs.map(function (o) { return strikeTxt(o.strike) + " call" + (o.costToClose != null ? " (~" + money(o.costToClose) + ")" : ""); }).join(" and ") + ", then " : "";
      var a = x.how === "cc" ? r.ticker + ": " + back + "sell " + plural(x.contracts, "covered call") + " (" + strikeTxt(x.strike) + ", " + md(x.expiry) + ")" :
        x.how === "cc-set" ? r.ticker + ": " + back + "keep the calls already sold; they are your exit" :
        r.ticker + ": " + (x.after ? "after the calls expire " + wd(addDays(x.after, -3)) + ", " : "") + back + "sell " + qtyTxt + " shares";
      var m = x.how === "cc" ? (x.premium != null ? "+~" + money(x.premium * 100 * x.contracts) + " premium" : "") : x.how === "cc-set" ? "" : "+~" + money(x.qty * r.price);
      todo.push({ key: "stk|" + r.account + "|" + r.ticker + "|" + r.rec, group: soon ? 2 : 3,
        when: x.after ? wd(x.after) + " " + md(x.after) : soon ? "Before " + md(e) : "This week",
        action: a, account: r.account, money: m, why: "Rated " + r.rec + ". " + (r.plan || "") });
    });
    optionRows.forEach(function (r) {
      if (used[r.id] || !r.earnings || r.earnings > r.expires) return;
      if (["CLOSE", "ROLL", "BUY BACK", "TAKE PROFIT"].indexOf(r.action) < 0) return;
      if (daysBetween(today, r.earnings) > 14) return;
      used[r.id] = 1;
      todo.push({ key: "opt|" + r.id + "|" + r.action, group: 2, when: "Before " + md(r.earnings),
        action: actionWord(r.action) + " the " + legTxt(r), account: r.account, money: legMoney(r), why: "Earnings on " + md(r.earnings) + ". " + r.why });
    });
    optionRows.forEach(function (r) {
      if (used[r.id] || ["CLOSE", "ROLL", "BUY BACK"].indexOf(r.action) < 0) return;
      used[r.id] = 1;
      todo.push({ key: "opt|" + r.id + "|" + r.action, group: 3, when: "This week", action: actionWord(r.action) + " the " + legTxt(r),
        account: r.account, money: legMoney(r), why: r.why });
    });
    optionRows.forEach(function (r) {
      if (used[r.id] || r.action !== "TAKE PROFIT") return;
      todo.push({ key: "opt|" + r.id + "|TAKE PROFIT", group: 4, when: "This week", action: "Take profit: buy back the " + legTxt(r),
        account: r.account, money: r.costToClose != null ? "~" + money(r.costToClose) + " (keeps ~" + money(r.pl) + ")" : "", why: r.why });
    });
    var buys = {};
    shown.forEach(function (r) { if (r.rec === "BUY MORE") (buys[r.ticker] = buys[r.ticker] || []).push(r.account); });
    Object.keys(buys).sort().forEach(function (tk) {
      var e = upcomingEarnings(tk), soon = e && daysBetween(today, e) <= 7;
      todo.push({ key: "buy|" + tk, group: 5, when: soon ? "After earnings (" + md(e) + ")" : "When ready", action: "Add to " + tk + (soon ? " after earnings on " + md(e) : ""),
        account: buys[tk].join(" / "), money: "", why: "Rated BUY MORE. " + (ratings[tk].why || "") });
    });
    var sugg = csp.filter(function (r) { return r.status === "SUGGESTED"; });
    if (sugg.length) todo.push({ key: "csp|" + today, group: 5, when: "When ready", account: "—", money: "",
      action: "Use spare cash: sell cash-secured puts from the Cash-Secured Puts tab (" + sugg.map(function (r) { return r.ticker; }).join(", ") + ")",
      why: "Earn income; buy good stocks at a discount" });
    var expire = optionRows.filter(function (r) { return r.action === "LET EXPIRE"; });
    if (expire.length) todo.push({ key: "expire|" + friday, group: 6, when: "Do nothing", account: "—", money: "",
      action: "Let expire " + wd(friday) + ": " + (function () {
        var m = {}, keys = [];
        expire.forEach(function (r) { var k = r.ticker + " " + strikeTxt(r.strike) + " " + (r.put ? "put" : "call"); if (!m[k]) { m[k] = 0; keys.push(k); } m[k] += r.contracts; });
        return keys.map(function (k) { return k + (m[k] > 1 ? "s" : ""); }).join(", ");
      })(),
      why: "Out of the money; will expire worthless" });
    todo.sort(function (a, b) { return a.group - b.group; });
    todo.forEach(function (t, i) { t.n = i + 1; });

    if (!anRows.length) notes.push("No Stock Analysis results yet, so every stock starts at HOLD. Run 🔬 Stock Research → Stock Analysis (or let the review do it) for real ratings.");
    var priced = optionRows.filter(function (r) { return r.priceNow != null; }).length;
    if (optionRows.length && priced < optionRows.length) notes.push((optionRows.length - priced) + " of " + optionRows.length + " open options have no price yet (shown as “price unavailable”). Press 🔄 Update Prices, then run the review again.");

    return {
      today: today, friday: friday, settings: S,
      totals: { value: total, cost: totalCost, gain: total - totalCost, legs: optionRows.length, stockRows: shown.length },
      overGroups: overGroups.map(function (g) { return { group: g, pct: pctOf(groupTot[g]) }; }),
      groups: Object.keys(groupTot).map(function (g) { return { group: g, pct: pctOf(groupTot[g]) }; }).sort(function (a, b) { return b.pct - a.pct; }),
      stocks: shown, options: optionRows, csp: csp, todo: todo, counts: counts, notes: notes,
      ratings: ratings, analysisAt: input.analysis && input.analysis.ranAt || null
    };
  }

  function actionWord(a) { return { "CLOSE": "Close", "ROLL": "Roll", "BUY BACK": "Buy back", "TAKE PROFIT": "Take profit on" }[a] || a; }

  // Cash needed, premium collected and returns for one put idea.
  function cspMath(r, today) {
    var k = r.strike, p = r.premiumUsed, c = r.contracts || 0;
    r.cashNeeded = k ? k * 100 * c : null;
    r.collected = p != null ? p * 100 * c : null;
    r.breakEven = k && p != null ? k - p : null;
    r.cushion = r.breakEven != null && r.price ? 1 - r.breakEven / r.price : null;
    r.periodReturn = k && p != null ? p / k : null;
    var d = r.expiry ? daysBetween(today, r.expiry) : null;
    r.yearReturn = r.periodReturn != null && d > 0 ? r.periodReturn * 365 / d : null;
    return r;
  }
  function cashBox(rows, cash) {
    var used = 0, prem = 0;
    rows.forEach(function (r) { if (r.cashNeeded) used += r.cashNeeded; if (r.collected) prem += r.collected; });
    var c = num(cash);
    return { cash: c, used: used, left: c != null ? c - used : null, premium: prem };
  }

  var RULES_TEXT = [
    "Stocks rated SELL/REDUCE: sell outright if the company has its own problems (losing money, issuing new shares, a lockup ending) or earnings are days away; otherwise exit with a covered call.",
    "Covered-call exit = sell a call at or just below today's price, expiring before the next earnings (2–4 weeks). You keep the premium; shares are sold at the strike.",
    "Fewer than 100 shares in an account = sell outright (calls need 100 shares).",
    "Sold options: take profit at the profit target. Let it expire if out of the money with 3 days or less left.",
    "Sold put in the money on a stock you DON'T want more of = close or roll for a credit. On a stock you're happy to own = OK to take the shares.",
    "Sold call in the money on a SELL/REDUCE stock = let it be called (that's your exit). On a stock you want to keep = roll up and out.",
    "No new puts on SELL/REDUCE stocks or on groups you already own too much of.",
    "New cash-secured puts: only on stocks you'd be happy to own, about a 20% chance of assignment (delta -0.20 to -0.22), never above support, 3–5 weeks out, never across an earnings date."
  ];
  var DISCLAIMER = "Research-based views, not financial advice. Check bid/ask before trading.";

  var PR = { review: review, cspMath: cspMath, cashBox: cashBox, bs: bs, quoteKey: quoteKey, md: md, money: money,
    DEFAULTS: DEFAULTS, GROUPS: GROUPS, RULES_TEXT: RULES_TEXT, DISCLAIMER: DISCLAIMER,
    _t: { fridayOnOrAfter: fridayOnOrAfter, fridayBefore: fridayBefore, floorStrike: floorStrike, facts: facts, buildGroupMap: buildGroupMap } };
  if (typeof module !== "undefined" && module.exports) module.exports = PR;
  else root.__PR_ENGINE__ = PR;
})(this);
