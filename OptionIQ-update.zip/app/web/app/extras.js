// Desktop-app additions that sit beside the Options Trade Logger screens:
// a reminder button (options expiring soon, options past expiry still marked
// Open, backup due) and the ⚙ Settings window.
(function () {
  "use strict";
  var T = window.__TRACKER__;
  var root = document.createElement("div");
  root.id = "trk-bell";
  document.body.appendChild(root);
  var open = false, last = null;

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function when(d) { return d === 0 ? "today" : d === 1 ? "tomorrow" : d < 0 ? (-d) + " days ago" : "in " + d + " days"; }
  function label(r) { return esc(r.ticker) + " " + esc(r.strike) + (r.cp === "C" ? "C" : "P") + " " + (r.sb === "S" ? "sold" : "bought") + " ×" + esc(r.contracts || 1); }

  function render() {
    var s = last;
    if (!s) { root.innerHTML = ""; return; }
    var soon = s.expiring.length, past = s.pastExpiry.length;
    var urgent = s.expiring.some(function (r) { return r.dte <= 2; });
    var tags = [];
    if (soon) tags.push('<span class="tag ' + (urgent ? "t-red" : "t-amber") + '">' + soon + " expiring</span>");
    if (past) tags.push('<span class="tag t-red">' + past + " past expiry</span>");
    if (s.backupDue) tags.push('<span class="tag t-blue">Backup due</span>');
    if (!tags.length) { root.innerHTML = ""; open = false; return; }
    var html = '<div class="pill' + (urgent || past ? " urgent" : "") + '" id="trk-pill">🔔 ' + tags.join("") + "</div>";
    if (open) {
      html += '<div class="panel">';
      if (soon) {
        html += "<h4>Expiring within " + s.reminderDays + " days</h4>" + s.expiring.map(function (r) {
          return '<div class="row"><span>' + label(r) + ' <span class="muted">· ' + esc(r.account) + "</span></span><span>" + when(r.dte) + "</span></div>";
        }).join("");
      }
      if (past) {
        html += "<h4>Past expiry but still marked Open</h4><p class=\"muted\">Close or roll these in the 📋 Options tab when you're ready.</p>" +
          s.pastExpiry.map(function (r) {
            return '<div class="row"><span>' + label(r) + ' <span class="muted">· ' + esc(r.account) + "</span></span><span>" + esc(r.expDate) + "</span></div>";
          }).join("");
      }
      if (s.backupDue) {
        html += "<h4>Backup</h4><p class=\"muted\">" + (s.lastBackupAt ? "Your last backup was " + s.daysSinceBackup + " days ago." : "You haven't made a backup yet.") +
          "</p><p style=\"margin-top:8px\"><button id=\"trk-backup\">💾 Back up now</button></p>";
      }
      html += '<p style="margin-top:12px;text-align:right"><button class="ghost" id="trk-close">Close</button></p></div>';
    }
    root.innerHTML = html;
    document.getElementById("trk-pill").onclick = function () { open = !open; render(); };
    var c = document.getElementById("trk-close"); if (c) c.onclick = function () { open = false; render(); };
    var b = document.getElementById("trk-backup");
    if (b) b.onclick = function () {
      try { var r = T.request("POST", "/api/backup", {}); alert("✅ Backup saved:\n" + r.file); } catch (e) { alert("Backup failed: " + e.message); }
      refresh();
    };
  }

  function refresh() {
    fetch("/api/status").then(function (r) { return r.json(); }).then(function (s) { last = s; render(); }).catch(function () {});
  }

  function openSettings() {
    var ov = document.createElement("div");
    ov.id = "trk-overlay";
    ov.innerHTML = '<div class="box"><div class="bar"><span>⚙ Settings</span><button id="trk-ov-close">Close</button></div>' +
      '<iframe src="/setup.html?mode=settings" title="Settings"></iframe></div>';
    document.body.appendChild(ov);
    var before = JSON.stringify(T.accounts);
    document.getElementById("trk-ov-close").onclick = function () {
      ov.remove();
      // Renamed or added accounts, or a different data folder, need the
      // screens to start again with the new information.
      var info = T.request("GET", "/api/setup");
      if (JSON.stringify(info.accounts) !== before || window.__TRACKER_RELOAD__) location.reload();
      else refresh();
    };
  }

  // Ownership notice along the bottom, and the Terms of Use.
  var foot = document.createElement("div");
  foot.id = "trk-foot";
  foot.innerHTML = '<img src="brand/qn-mark.png" alt="">' + esc(T.brand.notice) + ' · ' + esc(T.brand.app) + ' v' + esc(T.brand.version) +
    ' · <a href="#" id="trk-terms-link">Terms of Use</a>';
  document.body.appendChild(foot);
  document.getElementById("trk-terms-link").onclick = function (e) { e.preventDefault(); showTerms(false); };

  function showTerms(mustAgree) {
    var t = T.request("GET", "/api/terms");
    var ov = document.createElement("div");
    ov.id = "trk-overlay";
    ov.innerHTML = '<div class="box terms"><div class="bar"><span>Terms of Use</span>' +
      (mustAgree ? "" : '<button id="trk-terms-close">Close</button>') + '</div>' +
      '<pre class="terms-text">' + esc(t.text) + '</pre>' +
      (mustAgree ? '<div class="agree"><label><input type="checkbox" id="trk-agree-box"> I have read and agree to the Terms of Use</label>' +
        '<button id="trk-agree" disabled>Continue</button></div>' : "") + '</div>';
    document.body.appendChild(ov);
    if (mustAgree) {
      var box = document.getElementById("trk-agree-box"), btn = document.getElementById("trk-agree");
      box.onchange = function () { btn.disabled = !box.checked; };
      btn.onclick = function () {
        try { T.request("POST", "/api/terms", { accept: true }); T.termsAccepted = true; ov.remove(); }
        catch (err) { alert("Couldn't save that: " + err.message); }
      };
    } else {
      document.getElementById("trk-terms-close").onclick = function () { ov.remove(); };
    }
  }
  // People who set up before the Terms existed (or after they change) are
  // asked once.
  if (!T.termsAccepted) showTerms(true);

  // First start of a shared copy: the Screener's parts download once.
  var addonBar = null;
  function addons() {
    fetch("/api/addons").then(function (r) { return r.json(); }).then(function (a) {
      if (a.state === "ready") { if (addonBar) { addonBar.remove(); addonBar = null; } return; }
      if (!addonBar) { addonBar = document.createElement("div"); addonBar.id = "trk-addons"; document.body.appendChild(addonBar); }
      if (a.state === "failed") {
        addonBar.className = "bad";
        addonBar.innerHTML = "The Screener, Analysis, Discover and Watchlist tabs need a one-time download, and it didn't work. " +
          "Check your internet connection, then <button id='trk-addons-retry'>Try again</button>";
        document.getElementById("trk-addons-retry").onclick = function () {
          fetch("/api/addons", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" }).then(function () { setTimeout(addons, 1000); });
        };
        return;
      }
      addonBar.className = "";
      addonBar.textContent = "Getting the Screener ready for first use (one-time download, " + a.done + " of " + a.total +
        " parts). Your trades work as normal meanwhile.";
      setTimeout(addons, 2000);
    }).catch(function () {});
  }
  addons();

  // A newer version: offer it, then download and restart on request.
  var updBar = null, updInfo = null;
  function updShow(html, cls) {
    if (!updBar) { updBar = document.createElement("div"); updBar.id = "trk-update"; document.body.appendChild(updBar); }
    updBar.className = cls || "";
    updBar.innerHTML = html;
  }
  function updOffer(u) {
    updInfo = u;
    if (!u || !u.available) { if (updBar) { updBar.remove(); updBar = null; } return; }
    // Buttons first, notes below in their own scroll area, so a long list
    // (after skipping several versions) never pushes the buttons off screen.
    updShow("<b>OptionIQ " + esc(u.latest) + " is available</b> (you have " + esc(u.current) + ")." +
      '<div class="acts"><button id="trk-upd-go">Update now</button><button class="ghost" id="trk-upd-later">Later</button></div>' +
      (u.notes ? '<div class="notes">' + esc(u.notes) + "</div>" : ""));
    document.getElementById("trk-upd-later").onclick = function () { updBar.remove(); updBar = null; };
    document.getElementById("trk-upd-go").onclick = updStart;
  }
  function updStart() {
    if (!confirm("OptionIQ will back up your data, download version " + updInfo.latest +
                 " and restart.\n\nYour trades, accounts and settings stay exactly as they are.")) return;
    fetch("/api/update/install", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })
      .then(function () { updPoll(); });
  }
  function updPoll() {
    fetch("/api/update/status").then(function (r) { return r.json(); }).then(function (s) {
      if (s.state === "failed") {
        updShow("The update didn't work: " + esc(s.error) + '<div class="acts"><button id="trk-upd-retry">Try again</button>' +
          (updInfo.manualLink ? '<button class="ghost" id="trk-upd-manual">Download it myself</button>' : "") +
          '<button class="ghost" id="trk-upd-later">Later</button></div>', "bad");
        document.getElementById("trk-upd-retry").onclick = updStart;
        document.getElementById("trk-upd-later").onclick = function () { updBar.remove(); updBar = null; };
        var m = document.getElementById("trk-upd-manual");
        if (m) m.onclick = function () { window.open(updInfo.manualLink, "_blank"); };
        return;
      }
      if (s.state === "restarting") {
        updShow("<b>OptionIQ is restarting with version " + esc(updInfo.latest) + ".</b> The new window opens in a few seconds; you can close this one.");
        setTimeout(function () { window.close(); }, 6000);
        return;
      }
      var pct = s.total ? " " + Math.round(100 * s.done / s.total) + "%" : "";
      updShow(s.state === "downloading" ? "Downloading OptionIQ " + esc(updInfo.latest) + "…" + pct :
              s.state === "unpacking" ? "Getting the new version ready…" : "Backing up your data first…");
      setTimeout(updPoll, 800);
    }).catch(function () {
      // The app has already closed for the restart.
      updShow("<b>OptionIQ is restarting with the new version.</b> The new window opens in a few seconds; you can close this one.");
    });
  }
  function checkUpdates() {
    fetch("/api/update").then(function (r) { return r.json(); }).then(updOffer).catch(function () {});
  }
  setTimeout(checkUpdates, 4000);
  setInterval(checkUpdates, 6 * 3600 * 1000);  // left open for days: still hears about new versions

  window.__TRACKER_EXTRAS__ = { refresh: refresh, openSettings: openSettings, showTerms: showTerms, offerUpdate: updOffer };
  refresh();
  setInterval(refresh, 5 * 60 * 1000);
})();
