// 🧭 Portfolio Review screen (🔬 Stock Research → 🧭 Portfolio Review).
//
// Reads the app's own data (trades, stock lots, option prices, Stock Analysis
// results, the 🎯 profit target), works out the review with
// portfolio_review_engine.js, shows it in four tabs and saves it as an Excel
// file. It never changes a trade or a holding. What it keeps of its own:
//   portfolio_review_v1           when it last ran, IV and live prices it used
//   portfolio_review_overrides_v1 ratings/actions changed by hand (✎), until the next run
//   portfolio_review_done_v1      ticked to-do lines
//   portfolio_review_settings_v1  its settings (limits, save folder, groups)
//   portfolio_review_csp_v1       cash to use, contracts and typed put prices
(function () {
  "use strict";
  var PR = window.__PR_ENGINE__;
  var T = window.__TRACKER__ || {};
  var SCREENER = "http://127.0.0.1:8765";
  var K = { state: "portfolio_review_v1", over: "portfolio_review_overrides_v1", done: "portfolio_review_done_v1",
    set: "portfolio_review_settings_v1", csp: "portfolio_review_csp_v1" };

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function load(k, dflt) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : dflt; } catch (e) { return dflt; } }
  function save(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { alert("Couldn't save: " + e.message); } }
  function todayStr() { var d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  function $(sel) { return document.querySelector(sel); }
  var money = PR.money, md = PR.md;
  function pct(v, dp) { return v == null || !isFinite(v) ? "—" : (v * 100).toFixed(dp == null ? 0 : dp) + "%"; }
  function cash2(v) { return money(v, 2); }

  var REC_COLORS = { "BUY MORE": ["#14532d", "#4ade80"], "HOLD": ["#3f3a14", "#fde047"], "REDUCE": ["#4a2a12", "#fdba74"], "SELL": ["#4c1d1d", "#fca5a5"] };
  var ACT_COLORS = { "LET EXPIRE": ["#14532d", "#4ade80"], "TAKE PROFIT": ["#14532d", "#4ade80"], "HOLD": ["#3f3a14", "#fde047"], "LET ASSIGN": ["#123c3a", "#5eead4"],
    "CLOSE": ["#4a2a12", "#fdba74"], "BUY BACK": ["#4a2a12", "#fdba74"], "ROLL": ["#1e3a5f", "#93c5fd"] };
  var CSP_COLORS = { "SUGGESTED": ["#14532d", "#4ade80"], "MAYBE": ["#3f3a14", "#fde047"], "MAYBE LATER": ["#3b3520", "#fcd34d"], "SKIP": ["#2d3748", "#94a3b8"] };
  function badge(txt, colors, extra) { var c = colors[txt] || ["#374151", "#e2e8f0"]; return '<span class="pr-badge" style="background:' + c[0] + ";color:" + c[1] + '">' + esc(txt) + "</span>" + (extra || ""); }

  // ── data ─────────────────────────────────────────────────
  function settings() {
    var s = load(K.set, {}) || {};
    var pt = parseFloat(localStorage.getItem("profit_target_v1"));
    s.profitTarget = pt > 0 && pt < 1000 ? pt : PR.DEFAULTS.profitTarget;
    return s;
  }
  function inputs(state) {
    var cspSaved = load(K.csp, {}) || {};
    return {
      today: state.today || todayStr(),
      trades: load("options_trades_v3", []) || [],
      stocks: load("stock_holdings_v1", []) || [],
      quotes: load("option_quotes_v1", {}) || {},
      analysis: load("analysis_results_v1", { rows: [] }) || { rows: [] },
      iv: state.iv || {},
      live: state.live || {},
      accounts: T.accounts || [],
      settings: settings(),
      overrides: (load(K.over, {}) || {}).map || {},
      cspInputs: cspSaved.tickers || {}
    };
  }

  var view = { tab: "summary", result: null, busy: false, status: "", input: null };

  function compute() {
    var state = load(K.state, null);
    if (!state) { view.result = null; return; }
    view.input = inputs(state);
    view.result = PR.review(view.input);
    view.state = state;
  }

  // ── the screener service (research refresh + live option prices) ──
  function alive() {
    return fetch(SCREENER + "/health", { cache: "no-store", signal: AbortSignal.timeout(2500) }).then(function (r) { return r.ok; }).catch(function () { return false; });
  }
  function heldTickers() {
    var s = {};
    (load("stock_holdings_v1", []) || []).forEach(function (h) { if (h.ticker && h.status !== "Sold" && !h.soldDate) s[h.ticker.trim().toUpperCase()] = 1; });
    (load("options_trades_v3", []) || []).forEach(function (t) { if (t.ticker && (!t.action || t.action === "Open")) s[t.ticker.trim().toUpperCase()] = 1; });
    return Object.keys(s);
  }
  function refreshResearch(force) {
    var an = load("analysis_results_v1", { rows: [] }) || { rows: [] };
    var have = {}; (an.rows || []).forEach(function (r) { if (r && r.ticker && !r.error) have[r.ticker.toUpperCase()] = 1; });
    var held = heldTickers();
    var missing = held.filter(function (t) { return !have[t]; });
    var age = an.ranAt ? (Date.now() - new Date(an.ranAt).getTime()) / 864e5 : 99;
    if (!force && age < 1 && !missing.length) return Promise.resolve("");
    var all = {};
    (an.rows || []).forEach(function (r) { if (r && r.ticker) all[r.ticker.toUpperCase()] = 1; });
    Object.keys(load("watchlist_v1", {}) || {}).forEach(function (t) { all[t.toUpperCase()] = 1; });
    held.forEach(function (t) { all[t] = 1; });
    var tickers = Object.keys(all).sort();
    return alive().then(function (ok) {
      if (!ok) return "⚠ Stock research is from " + (an.ranAt ? String(an.ranAt).slice(0, 10) : "never") + ": the screener service isn't running, so it couldn't be refreshed.";
      setStatus("Refreshing stock research for " + tickers.length + " tickers (a couple of minutes)…");
      return fetch(SCREENER + "/analyze", { method: "POST", headers: { "Content-Type": "application/json" }, signal: AbortSignal.timeout(30000),
        body: JSON.stringify({ tickers: tickers, options: { requestsPerSecond: 10, workers: 6, lookback: "1y" } }) })
        .then(function (r) { return r.json().then(function (d) { if (!r.ok || !d.ok) throw new Error(d.error || "HTTP " + r.status); }); })
        .then(function poll() {
          return new Promise(function (res) { setTimeout(res, 1500); })
            .then(function () { return fetch(SCREENER + "/analyze/status", { cache: "no-store", signal: AbortSignal.timeout(15000) }).then(function (r) { return r.json(); }); })
            .then(function (s) {
              if (s.running) { setStatus("Refreshing stock research… " + (s.done || 0) + " of " + (s.total || tickers.length) + (s.ticker ? " (" + s.ticker + ")" : "")); return poll(); }
              if (s.error) throw new Error(s.error);
              // Keep earlier rows for anything that didn't come back this time.
              var by = {}; (an.rows || []).forEach(function (r) { if (r && r.ticker) by[r.ticker.toUpperCase()] = r; });
              (s.rows || []).forEach(function (r) { if (r && r.ticker && !r.error) by[r.ticker.toUpperCase()] = r; });
              save("analysis_results_v1", { rows: Object.keys(by).map(function (k) { return by[k]; }), stats: s.stats || null, errors: s.errors || {}, ranAt: s.finished || new Date().toISOString() });
              return "";
            });
        })
        .catch(function (e) { return "⚠ Couldn't refresh stock research (" + (e.message || e) + "); using the results from " + (an.ranAt ? String(an.ranAt).slice(0, 10) : "before") + "."; });
    });
  }
  function liveQuotes(result) {
    var cons = [], seen = {};
    function add(tk, exp, k, cp) { var key = PR.quoteKey(tk, exp, k, cp); if (seen[key] || !exp || !k) return; seen[key] = 1; cons.push({ ticker: tk, expiry: exp, strike: k, cp: cp }); }
    result.csp.forEach(function (r) { if (r.strike && (r.status === "SUGGESTED" || r.status === "MAYBE")) add(r.ticker, r.expiry, r.strike, "P"); });
    result.stocks.forEach(function (r) { if (r.exit && r.exit.how === "cc") add(r.ticker, r.exit.expiry, r.exit.strike, "C"); });
    if (!cons.length) return Promise.resolve({ live: {}, note: "" });
    return alive().then(function (ok) {
      if (!ok) return { live: {}, note: "Live put prices skipped (screener service not running); premiums are estimates." };
      setStatus("Getting live prices for " + cons.length + " option ideas…");
      return fetch(SCREENER + "/quotes", { method: "POST", headers: { "Content-Type": "application/json" }, signal: AbortSignal.timeout(180000),
        body: JSON.stringify({ contracts: cons, criteria: { requestsPerSecond: 8 } }) })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          var live = {};
          (d.results || []).forEach(function (q) {
            var mid = q.mid != null ? q.mid : (q.bid != null && q.ask != null && q.ask > 0 ? (q.bid + q.ask) / 2 : null);
            if (mid != null) live[PR.quoteKey(q.ticker, q.expiry, q.strike, q.cp)] = { mid: Math.round(mid * 100) / 100, bid: q.bid, ask: q.ask, iv: q.iv };
          });
          return { live: live, note: "" };
        })
        .catch(function (e) { return { live: {}, note: "Live put prices couldn't be read (" + (e.message || e) + "); premiums are estimates." }; });
    });
  }

  function run() {
    if (view.busy) return;
    view.busy = true; render();
    var notes = [];
    var refresh = $("#pr-refresh") ? $("#pr-refresh").checked : true;
    (refresh ? refreshResearch(false) : Promise.resolve("")).then(function (n) {
      if (n) notes.push(n);
      setStatus("Reading implied volatility history…");
      return fetch("/api/review/iv", { cache: "no-store" }).then(function (r) { return r.json(); }).catch(function () { return { iv: {} }; });
    }).then(function (d) {
      var state = { ranAt: new Date().toISOString(), today: todayStr(), iv: {}, live: {} };
      // Only the tickers the review can use, so the saved copy stays small.
      var an = load("analysis_results_v1", { rows: [] }) || { rows: [] }, want = {};
      (an.rows || []).forEach(function (r) { if (r && r.ticker) want[r.ticker.toUpperCase()] = 1; });
      heldTickers().forEach(function (t) { want[t] = 1; });
      Object.keys(d.iv || {}).forEach(function (t) { if (want[t]) state.iv[t] = d.iv[t]; });
      save(K.over, {}); // hand changes last until the next run
      var first = PR.review(inputs(state));
      return liveQuotes(first).then(function (q) {
        if (q.note) notes.push(q.note);
        state.live = q.live; state.notes = notes;
        save(K.state, state);
      });
    }).then(function () {
      view.busy = false; view.status = ""; compute(); render();
    }).catch(function (e) {
      view.busy = false; view.status = "❌ " + (e.message || e); render();
    });
  }

  function setStatus(s) { view.status = s; var el = $("#pr-status"); if (el) el.textContent = s; }

  // ── screen ───────────────────────────────────────────────
  var ov = null;
  function open() {
    if (ov) return;
    ov = document.createElement("div");
    ov.id = "pr-overlay";
    document.body.appendChild(ov);
    compute();
    render();
    document.addEventListener("keydown", onKey);
  }
  function close() { if (ov) { ov.remove(); ov = null; document.removeEventListener("keydown", onKey); } }
  function onKey(e) { if (e.key === "Escape" && !$("#pr-settings")) close(); }

  function render() {
    if (!ov) return;
    var R = view.result, st = view.state;
    var last = st && st.ranAt ? new Date(st.ranAt) : null;
    var old = last && (Date.now() - last.getTime()) / 864e5 > 3;
    var h = '<div class="pr-box"><div class="pr-bar">' +
      '<span class="pr-title">🧭 Portfolio Review</span>' +
      '<span class="pr-muted">' + (last ? "Last run: " + last.toLocaleString() : "Not run yet") + "</span>" +
      '<span style="flex:1"></span>' +
      '<label class="pr-muted" title="Re-reads Stock Analysis for your stocks and watchlist when it is more than a day old"><input type="checkbox" id="pr-refresh" checked> refresh stock research if older than a day</label>' +
      '<button id="pr-run" class="pr-btn pr-primary"' + (view.busy ? " disabled" : "") + ">" + (view.busy ? "⏳ Working…" : "▶ Run review") + "</button>" +
      '<button id="pr-xl" class="pr-btn"' + (R && !view.busy ? "" : " disabled") + ">📊 Export to Excel</button>" +
      '<button id="pr-folder" class="pr-btn" title="Open the folder the Excel files are saved in">📂</button>' +
      '<button id="pr-set" class="pr-btn" title="Review settings">⚙</button>' +
      '<button id="pr-close" class="pr-btn">Close</button></div>';
    if (old) h += '<div class="pr-banner">This review is more than 3 days old. Press ▶ Run review for a fresh one.</div>';
    h += '<div id="pr-status" class="pr-status">' + esc(view.status) + "</div>";
    if (!R) {
      h += '<div class="pr-empty">' + (view.busy ? "Working on your review…" :
        "<p>One click looks at every stock and every open option in all your accounts and says what to do with each, plus a short to-do list for this week and ideas for spare cash.</p><p>Press <b>▶ Run review</b> to start. It takes a few seconds (a couple of minutes if the stock research needs refreshing).</p>") + "</div>";
    } else if (!R.stocks.length && !R.options.length) {
      h += '<div class="pr-empty"><p>There are no stocks or open options to review yet.</p><p>Add your holdings in 🏦 Stocks and your trades in 📋 Options (or bring them in with 🏦 Broker files), then run the review again.</p>' +
        (R.csp.length ? "<p>Cash-secured put ideas from your watchlist are still in the last tab.</p>" : "") + "</div>";
      h += tabs(R);
    } else {
      h += tabs(R);
    }
    h += "</div>";
    ov.innerHTML = h;
    $("#pr-run").onclick = run;
    $("#pr-close").onclick = close;
    $("#pr-set").onclick = openSettings;
    $("#pr-folder").onclick = function () {
      try { T.request("POST", "/api/review/open-folder", { folder: (load(K.set, {}) || {}).folder || "" }); } catch (e) { alert(e.message); }
    };
    var xl = $("#pr-xl"); if (xl) xl.onclick = exportExcel;
    wire();
  }

  function tabs(R) {
    var names = [["summary", "Summary"], ["stocks", "Stocks (" + R.stocks.length + ")"], ["options", "Options (" + R.options.length + ")"], ["csp", "Cash-Secured Puts"]];
    var h = '<div class="pr-tabs">' + names.map(function (n) { return '<button data-tab="' + n[0] + '" class="pr-tab' + (view.tab === n[0] ? " on" : "") + '">' + n[1] + "</button>"; }).join("") + "</div>";
    h += '<div class="pr-body">' + (view.tab === "summary" ? summary(R) : view.tab === "stocks" ? stocksTab(R) : view.tab === "options" ? optionsTab(R) : cspTab(R)) + "</div>";
    return h;
  }

  function summary(R) {
    var done = load(K.done, {}) || {};
    var h = '<div class="pr-cards">' +
      card("Stock value", money(R.totals.value)) +
      card("Stock gain / loss", money(R.totals.gain), R.totals.gain >= 0 ? "#4ade80" : "#f87171") +
      card("Open option legs", R.totals.legs) +
      card("Stocks reviewed", R.totals.stockRows + " rows") + "</div>";
    h += '<div class="pr-two"><table class="pr-t"><tr><th>Stock rating</th><th># rows</th><th>Value</th><th>% of stocks</th></tr>' +
      Object.keys(R.counts.stocks).map(function (k) { var c = R.counts.stocks[k]; return "<tr><td>" + badge(k, REC_COLORS) + "</td><td>" + c.n + "</td><td>" + money(c.value) + "</td><td>" + pct(R.totals.value ? c.value / R.totals.value : null) + "</td></tr>"; }).join("") +
      "</table><table class=\"pr-t\"><tr><th>Option action</th><th># legs</th></tr>" +
      Object.keys(R.counts.options).map(function (k) { return "<tr><td>" + badge(k, ACT_COLORS) + "</td><td>" + R.counts.options[k] + "</td></tr>"; }).join("") + "</table>" +
      '<table class="pr-t"><tr><th>Group</th><th>% of stocks</th></tr>' + R.groups.map(function (g) {
        var over = g.pct > R.settings.maxSector && g.group !== "Broad market fund";
        return "<tr><td>" + esc(g.group) + "</td><td" + (over ? ' style="color:#f87171;font-weight:700" title="Over your ' + R.settings.maxSector + '% limit"' : "") + ">" + g.pct.toFixed(1) + "%" + (over ? " ⚠" : "") + "</td></tr>";
      }).join("") + "</table></div>";
    var notes = (view.state && view.state.notes || []).concat(R.notes);
    if (notes.length) h += '<div class="pr-notes">' + notes.map(function (n) { return "<div>ℹ " + esc(n) + "</div>"; }).join("") + "</div>";
    h += "<h3>This week — to-do list (most urgent first)</h3>";
    if (!R.todo.length) h += '<p class="pr-muted">Nothing to do this week.</p>';
    else h += '<table class="pr-t pr-todo"><tr><th>#</th><th>When</th><th>Action</th><th>Account</th><th>About</th><th>Why</th><th>Done?</th></tr>' +
      R.todo.map(function (t) {
        var d = !!done[t.key];
        return '<tr class="' + (d ? "pr-done" : "") + '"><td>' + t.n + "</td><td>" + esc(t.when) + "</td><td>" + esc(t.action) + "</td><td>" + esc(t.account) + "</td><td>" + esc(t.money) +
          '</td><td class="pr-why">' + esc(t.why) + '</td><td><input type="checkbox" data-done="' + esc(t.key) + '"' + (d ? " checked" : "") + "></td></tr>";
      }).join("") + "</table>";
    h += '<div class="pr-rules"><b>Simple rules used</b><ol>' + PR.RULES_TEXT.map(function (r) { return "<li>" + esc(r) + "</li>"; }).join("") + "</ol></div>";
    h += '<p class="pr-muted">' + esc(PR.DISCLAIMER) + "</p>";
    return h;
  }
  function card(label, val, color) { return '<div class="pr-card"><div class="pr-muted">' + esc(label) + '</div><div class="pr-big"' + (color ? ' style="color:' + color + '"' : "") + ">" + esc(val) + "</div></div>"; }

  function recSelect(kind, id, cur, list, colors, overridden) {
    return '<select class="pr-sel" data-over="' + kind + "|" + esc(id) + '" title="Change it by hand (kept until the next run)" style="background:' + (colors[cur] || ["#374151"])[0] + ";color:" + (colors[cur] || ["", "#e2e8f0"])[1] + '">' +
      list.map(function (o) { return "<option" + (o === cur ? " selected" : "") + ">" + o + "</option>"; }).join("") + "</select>" + (overridden ? ' <span title="Changed by hand">✎</span>' : "");
  }

  function stocksTab(R) {
    var h = '<div class="pr-muted" style="margin-bottom:6px">One row per stock per account. Change a recommendation by hand with its drop-down (✎ marks it; it lasts until the next run). Rows under half a share are left out but counted in the totals.</div>';
    h += '<div class="pr-scroll"><table class="pr-t pr-wide"><thead><tr>' + ["Account", "Ticker", "Company", "Shares", "Avg Cost", "Price Now", "Value", "Gain/Loss $", "Gain/Loss %", "% of Portfolio", "RECOMMENDATION", "Why", "How to Exit", "Exit Plan (steps)", "Calls Already Sold", "Next Event", "Bought/Assigned", "First Date"].map(function (c) { return "<th>" + c + "</th>"; }).join("") + "</tr></thead><tbody>";
    R.stocks.forEach(function (r) {
      h += "<tr><td>" + esc(r.account) + "</td><td><b>" + esc(r.ticker) + "</b></td><td>" + esc(r.company) + "</td><td>" + (Math.round(r.shares * 1000) / 1000).toLocaleString() + "</td><td>" + cash2(r.avgCost) + "</td><td>" + cash2(r.price) + "</td><td>" + money(r.value) +
        '</td><td style="color:' + (r.gain >= 0 ? "#4ade80" : "#f87171") + '">' + money(r.gain) + "</td><td>" + pct(r.gainPct) + "</td><td>" + pct(r.pct / 100, 1) + "</td><td>" +
        recSelect("stock", r.ticker, r.rec, ["BUY MORE", "HOLD", "REDUCE", "SELL"], REC_COLORS, r.overridden) + '</td><td class="pr-why">' + esc(r.why) + "</td><td>" + esc(r.how) + '</td><td class="pr-why">' + esc(r.plan) +
        "</td><td>" + esc(r.callsSold) + "</td><td>" + esc(r.nextEvent) + "</td><td>" + esc(r.boughtAssigned) + "</td><td>" + esc(r.firstDate || "") + "</td></tr>";
    });
    h += '<tr class="pr-total"><td colspan="6">TOTAL (incl. tiny rows)</td><td>' + money(R.totals.value) + "</td><td>" + money(R.totals.gain) + '</td><td colspan="10"></td></tr></tbody></table></div>';
    return h;
  }

  function optionsTab(R) {
    var planned = (load(K.set, {}) || {}).plannedCalls || {};
    var h = '<div class="pr-muted" style="margin-bottom:6px">One row per open option. Option prices come from 🔄 Update Prices (mid-price); check bid/ask before trading. Tick 📌 on a sold call you plan to let be called away.</div>';
    h += '<div class="pr-scroll"><table class="pr-t pr-wide"><thead><tr>' + ["Account", "Ticker", "What It Is", "Strike", "Expires", "Days Left", "Contracts", "Stock Price", "In/Out of Money", "How Far", "Premium", "Option Price Now", "Profit Earned %", "Profit/Loss $", "Cost to Close $", "ACTION", "Why", "Roll Idea", "Stock Rating", "📌"].map(function (c) { return "<th>" + c + "</th>"; }).join("") + "</tr></thead><tbody>";
    var totPL = 0;
    R.options.forEach(function (r) {
      if (r.pl != null) totPL += r.pl;
      var isCall = r.sold && !r.put;
      h += "<tr><td>" + esc(r.account) + "</td><td><b>" + esc(r.ticker) + "</b></td><td>" + esc(r.what) + "</td><td>" + cash2(r.strike) + "</td><td>" + esc(md(r.expires)) + '</td><td style="' + (r.days <= 7 ? "color:#fbbf24;font-weight:700" : "") + '">' + r.days + "</td><td>" + r.contracts +
        "</td><td>" + (r.stockPrice != null ? cash2(r.stockPrice) : "—") + '</td><td style="' + (r.itm ? "color:#f87171;font-weight:700" : "") + '">' + (r.itm == null ? "—" : r.itm ? "IN the money" : "out") + "</td><td>" + pct(r.howFar, 1) +
        "</td><td>" + cash2(r.premium) + "</td><td>" + (r.priceNow != null ? cash2(r.priceNow) : '<span class="pr-muted">price unavailable</span>') + "</td><td>" + (r.profitPct != null ? Math.round(r.profitPct) + "%" : "—") +
        '</td><td style="color:' + (r.pl == null ? "" : r.pl >= 0 ? "#4ade80" : "#f87171") + '">' + (r.pl != null ? money(r.pl) : "—") + "</td><td>" + (r.costToClose != null ? money(r.costToClose) : "—") + "</td><td>" +
        recSelect("option", r.id, r.action, ["LET EXPIRE", "TAKE PROFIT", "HOLD", "LET ASSIGN", "CLOSE", "BUY BACK", "ROLL"], ACT_COLORS, r.overridden) + '</td><td class="pr-why">' + esc(r.why) + "</td><td>" + esc(r.roll || "") + "</td><td>" + esc(r.owned ? r.rating : "Not owned (" + r.rating + ")") +
        "</td><td>" + (isCall ? '<input type="checkbox" data-plan="' + esc(r.id) + '" title="I plan to let these shares be called away"' + (planned[r.id] === true || (planned[r.id] !== false && /^Planned/.test(r.why)) ? " checked" : "") + ">" : "") + "</td></tr>";
    });
    h += '<tr class="pr-total"><td colspan="13">TOTAL</td><td>' + money(totPL) + '</td><td colspan="6"></td></tr></tbody></table></div>';
    return h;
  }

  function cspTab(R) {
    var saved = load(K.csp, {}) || {};
    var box = PR.cashBox(R.csp, saved.cash);
    var h = '<div class="pr-muted">Selling a put = you get paid now; if the stock drops below the strike by expiry, you buy 100 shares at the strike (your cash is set aside for this). Ideas come from every ticker in your Stock Analysis list.</div>';
    h += '<div class="pr-cash"><label><b>Cash I want to use:</b> $<input id="pr-cash" type="number" min="0" step="1000" value="' + (box.cash != null ? box.cash : "") + '" placeholder="type an amount"></label>' +
      "<span><b>Cash used by chosen puts:</b> " + money(box.used) + "</span>" +
      '<span><b>Cash left:</b> <span style="color:' + (box.left != null && box.left < 0 ? "#f87171" : "#4ade80") + '">' + (box.left != null ? money(box.left) : "enter cash") + "</span></span>" +
      "<span><b>Premium collected:</b> " + money(box.premium) + "</span></div>";
    h += '<div class="pr-scroll"><table class="pr-t pr-wide"><thead><tr>' + ["#", "Ticker", "Company", "STATUS", "When to Sell", "Expiry", "Strike", "Est. Premium", "Live Premium (type in)", "Premium Used", "Contracts", "Cash Needed", "Premium Collected", "Break-even", "Stock Price", "Cushion", "Return for Period", "Return per Year", "Chance of Being Assigned", "App Rating", "Next Earnings", "Why", "✋"].map(function (c) { return "<th>" + c + "</th>"; }).join("") + "</tr></thead><tbody>";
    var own = {}; (settings().ownEnough || []).forEach(function (t) { own[t] = 1; });
    R.csp.forEach(function (r, i) {
      h += "<tr" + (r.status === "SKIP" ? ' class="pr-dim"' : "") + "><td>" + (i + 1) + "</td><td><b>" + esc(r.ticker) + "</b></td><td>" + esc(r.company) + "</td><td>" + badge(r.status, CSP_COLORS) + "</td><td>" + esc(r.when || "") + "</td><td>" + (r.expiry ? esc(md(r.expiry)) : "") + "</td><td>" + (r.strike ? cash2(r.strike) : "") +
        "</td><td>" + (r.estPremium != null ? cash2(r.estPremium) : "") + "</td><td>" + (r.strike ? '<input class="pr-in" data-prem="' + r.ticker + '" type="number" step="0.01" min="0" value="' + (r.typedPremium != null ? r.typedPremium : "") + '" placeholder="' + (r.livePremium != null ? r.livePremium.toFixed(2) + " live" : "") + '">' : "") +
        "</td><td>" + (r.premiumUsed != null ? cash2(r.premiumUsed) + ' <span class="pr-muted">' + esc(r.premiumFrom) + "</span>" : "") + "</td><td>" + (r.strike ? '<input class="pr-in" style="width:52px" data-ctr="' + r.ticker + '" type="number" step="1" min="0" value="' + r.contracts + '">' : "") +
        "</td><td>" + (r.cashNeeded ? money(r.cashNeeded) : "") + "</td><td>" + (r.collected ? money(r.collected) : "") + "</td><td>" + (r.breakEven != null ? cash2(r.breakEven) : "") + "</td><td>" + (r.price ? cash2(r.price) : "") + "</td><td>" + pct(r.cushion, 1) +
        "</td><td>" + pct(r.periodReturn, 1) + "</td><td>" + pct(r.yearReturn, 1) + "</td><td>" + (r.chance != null ? pct(r.chance) : "") + "</td><td>" + esc(r.rating) + "</td><td>" + (r.earnings ? esc(md(r.earnings)) : "") + '</td><td class="pr-why">' + esc(r.why) +
        '</td><td><input type="checkbox" data-own="' + r.ticker + '" title="I own enough of this: never suggest puts on it"' + (own[r.ticker] ? " checked" : "") + "></td></tr>";
    });
    h += "</tbody></table></div>";
    h += '<div class="pr-rules"><b>How the ideas were picked</b><ol><li>Only stocks you\'d be happy to own at the strike price (no SELL/REDUCE stocks, no leveraged funds).</li><li>Skip stocks where you already have puts in the money, already own more than ' + R.settings.maxStock + '% of your portfolio, or marked ✋ own enough.</li><li>Wait on groups you already own too much of (over ' + R.settings.maxSector + '%), and when earnings are too close.</li><li>Strike = about a 20% chance of being assigned (delta −0.20 to −0.22), never above the support level.</li><li>Expiry = 3–5 weeks, never across an earnings date (sell after earnings, or pick an expiry before them).</li><li>Premiums are live mid-prices when the screener service is running, otherwise estimates from the stock\'s implied volatility. Type the real price in "Live Premium" before trading.</li></ol></div>';
    return h;
  }

  function wire() {
    Array.prototype.forEach.call(ov.querySelectorAll("[data-tab]"), function (b) { b.onclick = function () { view.tab = b.getAttribute("data-tab"); render(); }; });
    Array.prototype.forEach.call(ov.querySelectorAll("[data-done]"), function (c) {
      c.onchange = function () { var d = load(K.done, {}) || {}; if (c.checked) d[c.getAttribute("data-done")] = new Date().toISOString().slice(0, 10); else delete d[c.getAttribute("data-done")]; save(K.done, d); c.closest("tr").className = c.checked ? "pr-done" : ""; };
    });
    Array.prototype.forEach.call(ov.querySelectorAll("[data-over]"), function (s) {
      s.onchange = function () {
        var o = load(K.over, {}) || {}; o.map = o.map || {}; o.map[s.getAttribute("data-over")] = s.value; save(K.over, o); compute(); render();
      };
    });
    Array.prototype.forEach.call(ov.querySelectorAll("[data-plan]"), function (c) {
      c.onchange = function () { var s = load(K.set, {}) || {}; s.plannedCalls = s.plannedCalls || {}; s.plannedCalls[c.getAttribute("data-plan")] = c.checked; save(K.set, s); compute(); render(); };
    });
    Array.prototype.forEach.call(ov.querySelectorAll("[data-own]"), function (c) {
      c.onchange = function () {
        var s = load(K.set, {}) || {}, l = s.ownEnough || [], t = c.getAttribute("data-own");
        l = l.filter(function (x) { return x !== t; }); if (c.checked) l.push(t); s.ownEnough = l; save(K.set, s); compute(); render();
      };
    });
    function cspEdit(attr, field) {
      Array.prototype.forEach.call(ov.querySelectorAll("[" + attr + "]"), function (i) {
        i.onchange = function () {
          var s = load(K.csp, {}) || {}; s.tickers = s.tickers || {}; var t = i.getAttribute(attr);
          s.tickers[t] = s.tickers[t] || {}; s.tickers[t][field] = i.value === "" ? null : i.value; save(K.csp, s); compute(); render();
        };
      });
    }
    cspEdit("data-prem", "premium"); cspEdit("data-ctr", "contracts");
    var c = $("#pr-cash");
    if (c) c.onchange = function () { var s = load(K.csp, {}) || {}; s.cash = c.value === "" ? null : parseFloat(c.value); save(K.csp, s); compute(); render(); };
  }

  // ── settings ─────────────────────────────────────────────
  function openSettings() {
    var s = load(K.set, {}) || {}, D = PR.DEFAULTS, pt = settings().profitTarget;
    function field(key, label, unit, val) { return '<label class="pr-f"><span>' + label + '</span><input data-k="' + key + '" type="number" step="1" value="' + esc(val != null ? val : "") + '"> ' + unit + "</label>"; }
    var box = document.createElement("div");
    box.id = "pr-settings";
    box.innerHTML = '<div class="pr-dialog"><h3>⚙ Portfolio Review settings</h3>' +
      field("profitTarget", "Profit target (same as the 🎯 button)", "%", pt) +
      field("maxStock", "Most in one stock", "% of portfolio", s.maxStock != null ? s.maxStock : D.maxStock) +
      field("maxSector", "Most in one group", "% of portfolio", s.maxSector != null ? s.maxSector : D.maxSector) +
      field("expiringSoon", "“Expiring soon”", "days", s.expiringSoon != null ? s.expiringSoon : D.expiringSoon) +
      field("ccMinDays", "Covered-call window from", "days", s.ccMinDays != null ? s.ccMinDays : D.ccMinDays) +
      field("ccMaxDays", "Covered-call window to", "days (always before earnings)", s.ccMaxDays != null ? s.ccMaxDays : D.ccMaxDays) +
      field("lossFlag", "Risk flag when down from cost by", "%", s.lossFlag != null ? s.lossFlag : D.lossFlag) +
      '<label class="pr-f"><span>Save Excel files in</span><input data-k="folder" type="text" style="width:320px" placeholder="My Data\\Portfolio Reviews (leave empty)" value="' + esc(s.folder || "") + '"></label>' +
      '<label class="pr-f" style="align-items:flex-start"><span>My own groups<br><span class="pr-muted">one per line, e.g.<br>TSM = AI chips &amp; hardware</span></span><textarea data-k="groups" rows="4" style="width:320px">' + esc(s.groups || "") + "</textarea></label>" +
      '<label class="pr-f"><span>Market &amp; news commentary</span><input type="checkbox" disabled> <span class="pr-muted">Off (coming later; will use your own Claude API key)</span></label>' +
      '<p class="pr-muted">Built-in groups (used for the ' + esc(String(s.maxSector || D.maxSector)) + "% limit): " + Object.keys(PR.GROUPS).map(function (g) { return "<b>" + esc(g) + "</b>: " + esc(PR.GROUPS[g]); }).join("<br>") + "</p>" +
      '<p style="text-align:right"><button class="pr-btn" id="pr-s-cancel">Cancel</button> <button class="pr-btn pr-primary" id="pr-s-save">Save</button></p></div>';
    ov.appendChild(box);
    $("#pr-s-cancel").onclick = function () { box.remove(); };
    $("#pr-s-save").onclick = function () {
      var n = load(K.set, {}) || {};
      Array.prototype.forEach.call(box.querySelectorAll("[data-k]"), function (i) {
        var k = i.getAttribute("data-k");
        if (k === "folder" || k === "groups") n[k] = i.value.trim();
        else if (k === "profitTarget") { var v = parseFloat(i.value); if (v > 0 && v < 1000) localStorage.setItem("profit_target_v1", String(v)); }
        else { var x = parseFloat(i.value); if (isFinite(x)) n[k] = x; else delete n[k]; }
      });
      save(K.set, n); box.remove(); compute(); render();
    };
  }

  // ── Excel (same layout as Portfolio_Review_2026-10-27.xlsx) ──
  var NAVY = "FF1F3864";
  var XL_REC = { "BUY MORE": "FFC6EFCE", "HOLD": "FFFFEB9C", "REDUCE": "FFF8CBAD", "SELL": "FFFF9999" };
  var XL_ACT = { "LET EXPIRE": "FFC6EFCE", "TAKE PROFIT": "FFC6EFCE", "HOLD": "FFFFEB9C", "LET ASSIGN": "FFE2EFDA", "CLOSE": "FFF8CBAD", "BUY BACK": "FFF8CBAD", "ROLL": "FFBDD7EE" };
  var XL_CSP = { "SUGGESTED": "FFC6EFCE", "MAYBE": "FFFFEB9C", "MAYBE LATER": "FFFFF2CC", "SKIP": "FFE7E6E6" };
  function xdate(s) { var p = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || ""); return p ? new Date(Date.UTC(+p[1], +p[2] - 1, +p[3])) : null; }
  function fill(c, argb) { c.fill = { type: "pattern", pattern: "solid", fgColor: { argb: argb } }; }
  function header(ws, rowNo, names) {
    var row = ws.getRow(rowNo);
    names.forEach(function (n, i) { var c = row.getCell(i + 1); c.value = n; c.font = { bold: true, color: { argb: "FFFFFFFF" }, size: 10 }; fill(c, NAVY); c.alignment = { wrapText: true, vertical: "middle" }; });
  }
  function pageSetup(ws) { ws.pageSetup = { orientation: "landscape", fitToPage: true, fitToWidth: 1, fitToHeight: 0 }; }
  function colsW(ws, w) { Object.keys(w).forEach(function (k) { ws.getColumn(k).width = w[k]; }); }

  function buildWorkbook(R) {
    var wb = new ExcelJS.Workbook();
    wb.creator = "OptionIQ";
    var sum = wb.addWorksheet("Summary"), st = wb.addWorksheet("Stocks"), op = wb.addWorksheet("Options"), cp = wb.addWorksheet("Cash-Secured Puts");
    [sum, st, op, cp].forEach(function (ws) { ws.properties.defaultRowHeight = 15; pageSetup(ws); });
    var asOf = xdate(R.today);

    // Stocks
    st.getCell("A1").value = "Stocks — what to do with each one"; st.getCell("A1").font = { bold: true, size: 14 };
    st.getCell("A2").value = "As of " + md(R.today) + ", " + R.today.slice(0, 4) + " · prices from OptionIQ · one row per stock per account"; st.getCell("A2").font = { size: 9, color: { argb: "FF595959" } };
    header(st, 4, ["Account", "Ticker", "Company", "Shares", "Avg Cost", "Price Now", "Value Now", "Gain / Loss $", "Gain / Loss %", "% of Portfolio", "RECOMMENDATION", "Why (plain English)", "How to Exit", "Exit Plan (step by step)", "Calls Already Sold on These Shares", "Next Event", "Bought / Assigned", "First Date"]);
    var s0 = 5, sN = s0 + R.stocks.length - 1, sTot = sN + 1;
    R.stocks.forEach(function (r, i) {
      var n = s0 + i, row = st.getRow(n);
      row.values = [r.account, r.ticker, r.company, Math.round(r.shares * 1000) / 1000, Math.round(r.avgCost * 100) / 100, Math.round(r.price * 100) / 100,
        { formula: "D" + n + "*F" + n }, { formula: "G" + n + "-D" + n + "*E" + n }, { formula: 'IF(D' + n + '*E' + n + '=0,"",H' + n + "/(D" + n + "*E" + n + "))" }, { formula: "G" + n + "/$G$" + sTot },
        r.rec + (r.overridden ? " ✎" : ""), r.why, r.how, r.plan, r.callsSold, r.nextEvent, r.boughtAssigned, r.firstDate || ""];
      row.font = { size: 10 };
      row.getCell(4).numFmt = "#,##0.###"; row.getCell(5).numFmt = "$#,##0.00"; row.getCell(6).numFmt = "$#,##0.00"; row.getCell(7).numFmt = "$#,##0";
      row.getCell(8).numFmt = '$#,##0;[Red]"-$"#,##0'; row.getCell(9).numFmt = "0%;[Red]\\-0%"; row.getCell(10).numFmt = "0.0%";
      var k = row.getCell(11); fill(k, XL_REC[r.rec] || "FFFFFFFF"); k.font = { bold: true, size: 10 };
      [12, 14, 15].forEach(function (c) { row.getCell(c).alignment = { wrapText: true, vertical: "top" }; });
    });
    if (R.stocks.length) {
      var tr = st.getRow(sTot);
      tr.getCell(1).value = "TOTAL"; tr.getCell(7).value = { formula: "SUM(G" + s0 + ":G" + sN + ")" }; tr.getCell(8).value = { formula: "SUM(H" + s0 + ":H" + sN + ")" };
      tr.font = { bold: true, size: 10 }; tr.getCell(7).numFmt = "$#,##0"; tr.getCell(8).numFmt = '$#,##0;[Red]"-$"#,##0';
      st.autoFilter = "A4:R" + sN;
    }
    st.views = [{ state: "frozen", xSplit: 2, ySplit: 4 }];
    colsW(st, { A: 10, B: 8, C: 20, D: 9, E: 10, F: 10, G: 12, H: 12, I: 10, J: 10, K: 15, L: 50, M: 20, N: 60, O: 30, P: 18, Q: 11, R: 11 });

    // Options
    op.getCell("A1").value = "Open Options — keep, close or roll"; op.getCell("A1").font = { bold: true, size: 14 };
    op.getCell("A2").value = "As of " + md(R.today) + ", " + R.today.slice(0, 4) + " · option prices = mid-prices from OptionIQ (blue; update before trading)"; op.getCell("A2").font = { size: 9, color: { argb: "FF595959" } };
    header(op, 4, ["Account", "Ticker", "What It Is", "Strike", "Expires", "Days Left", "Contracts", "Stock Price", "In/Out of Money", "How Far (%)", "Premium Received / Paid", "Option Price Now", "Profit Earned %", "Profit / Loss $", "Cost to Close $", "ACTION", "Why (plain English)", "Roll Idea", "Stock Rating"]);
    var o0 = 5, oN = o0 + R.options.length - 1;
    R.options.forEach(function (r, i) {
      var n = o0 + i, row = op.getRow(n);
      row.values = [r.account, r.ticker, r.what, r.strike, xdate(r.expires), { formula: "E" + n + "-Summary!$B$3" }, r.contracts, r.stockPrice != null ? Math.round(r.stockPrice * 100) / 100 : null,
        { formula: 'IF(H' + n + '="","",IF(RIGHT(C' + n + ',3)="Put",IF(H' + n + '<D' + n + ',"IN the money","out"),IF(H' + n + '>D' + n + ',"IN the money","out")))' },
        { formula: 'IF(H' + n + '="","",ABS(H' + n + "/D" + n + "-1))" }, Math.round(r.premium * 1000) / 1000, r.priceNow != null ? r.priceNow : null,
        { formula: 'IF(OR(L' + n + '="",LEFT(C' + n + ',4)<>"Sold",K' + n + '=0),"",(K' + n + "-L" + n + ")/K" + n + ")" },
        { formula: 'IF(L' + n + '="","",IF(LEFT(C' + n + ',4)="Sold",(K' + n + "-L" + n + "),(L" + n + "-K" + n + "))*100*G" + n + ")" },
        { formula: 'IF(L' + n + '="","",L' + n + "*100*G" + n + ")" },
        r.action + (r.overridden ? " ✎" : ""), r.why + (r.priceNow == null ? " (Option price unavailable.)" : ""), r.roll || "", r.owned ? r.rating : "Not owned"];
      row.font = { size: 10 };
      row.getCell(4).numFmt = "$#,##0.00"; row.getCell(5).numFmt = 'mmm d", "yyyy'; row.getCell(8).numFmt = "$#,##0.00"; row.getCell(8).font = { size: 10, color: { argb: "FF0000FF" } };
      row.getCell(10).numFmt = "0.0%"; row.getCell(11).numFmt = "$#,##0.00"; row.getCell(12).numFmt = "$#,##0.00"; row.getCell(12).font = { size: 10, color: { argb: "FF0000FF" } };
      row.getCell(13).numFmt = "0%;[Red]\\-0%"; row.getCell(14).numFmt = '$#,##0;[Red]"-$"#,##0'; row.getCell(15).numFmt = "$#,##0";
      var a = row.getCell(16); fill(a, XL_ACT[r.action] || "FFFFFFFF"); a.font = { bold: true, size: 10 };
      [17, 18].forEach(function (c) { row.getCell(c).alignment = { wrapText: true, vertical: "top" }; });
    });
    if (R.options.length) {
      var ot = op.getRow(oN + 1); ot.getCell(1).value = "TOTAL"; ot.getCell(14).value = { formula: "SUM(N" + o0 + ":N" + oN + ")" }; ot.font = { bold: true, size: 10 }; ot.getCell(14).numFmt = '$#,##0;[Red]"-$"#,##0';
      op.autoFilter = "A4:S" + oN;
      op.addConditionalFormatting({ ref: "F" + o0 + ":F" + oN, rules: [{ type: "cellIs", operator: "lessThanOrEqual", formulae: ["7"], style: { font: { bold: true, color: { argb: "FFC00000" } } } }] });
      op.addConditionalFormatting({ ref: "I" + o0 + ":I" + oN, rules: [{ type: "cellIs", operator: "equal", formulae: ['"IN the money"'], style: { font: { bold: true, color: { argb: "FFC00000" } } } }] });
    }
    op.views = [{ state: "frozen", xSplit: 2, ySplit: 4 }];
    colsW(op, { A: 10, B: 8, C: 14, D: 8, E: 12, F: 8, G: 9, H: 10, I: 11, J: 9, K: 12, L: 11, M: 10, N: 12, O: 12, P: 13, Q: 60, R: 30, S: 12 });

    // Cash-secured puts
    var csp = R.csp, saved = load(K.csp, {}) || {};
    cp.getCell("A1").value = "Cash-Secured Puts — ideas from your " + csp.length + "-stock watchlist"; cp.getCell("A1").font = { bold: true, size: 14 };
    cp.getCell("A2").value = "Selling a put = you get paid now; if the stock drops below the strike by expiry, you buy 100 shares at the strike (your cash is set aside for this)."; cp.getCell("A2").font = { size: 9, color: { argb: "FF595959" } };
    var c0 = 6, cN = c0 + csp.length - 1;
    cp.getCell("A3").value = "Cash I want to use:"; cp.getCell("A3").font = { bold: true, size: 10 };
    var cashCell = cp.getCell("C3"); cashCell.value = saved.cash != null ? saved.cash : null; fill(cashCell, "FFFFFF00"); cashCell.numFmt = "$#,##0";
    cp.getCell("D3").value = "← type your cash amount (yellow cell)"; cp.getCell("D3").font = { size: 9 };
    cp.getCell("E3").value = "Cash used by chosen puts:"; cp.getCell("E3").font = { bold: true, size: 10 };
    cp.getCell("G3").value = { formula: "SUM(L" + c0 + ":L" + Math.max(cN, c0) + ")" }; cp.getCell("G3").numFmt = "$#,##0"; cp.getCell("G3").font = { bold: true, size: 10 };
    cp.getCell("H3").value = "Cash left:"; cp.getCell("H3").font = { bold: true, size: 10 };
    cp.getCell("I3").value = { formula: 'IF(C3="","enter cash",C3-G3)' }; cp.getCell("I3").numFmt = '$#,##0;[Red]"-$"#,##0'; cp.getCell("I3").font = { bold: true, size: 10 };
    cp.getCell("K3").value = "Premium collected:"; cp.getCell("K3").font = { bold: true, size: 10 };
    cp.getCell("M3").value = { formula: "SUM(M" + c0 + ":M" + Math.max(cN, c0) + ")" }; cp.getCell("M3").numFmt = "$#,##0"; cp.getCell("M3").font = { bold: true, size: 10 };
    header(cp, 5, ["#", "Ticker", "Company", "STATUS", "When to Sell", "Expiry", "Strike", "Est. Premium (per share)", "Live Premium (type in)", "Premium Used", "Contracts (type in)", "Cash Needed", "Premium You Collect", "Break-even Price", "Stock Price", "Cushion (how far it can fall)", "Return for Period", "Return per Year", "Chance of Being Assigned", "App Rating (score)", "Next Earnings", "Why (plain English)"]);
    csp.forEach(function (r, i) {
      var n = c0 + i, row = cp.getRow(n);
      var liveVal = r.typedPremium != null ? r.typedPremium : r.livePremium != null ? r.livePremium : null;
      row.values = [i + 1, r.ticker, r.company, r.status, r.when || "", r.expiry ? xdate(r.expiry) : null, r.strike || null, r.estPremium != null ? r.estPremium : null, liveVal,
        { formula: 'IF(I' + n + '<>"",I' + n + ',H' + n + ')' }, r.strike ? r.contracts : 0,
        { formula: 'IF(G' + n + '="","",G' + n + "*100*K" + n + ")" }, { formula: 'IF(J' + n + '="","",J' + n + "*100*K" + n + ")" }, { formula: 'IF(G' + n + '="","",G' + n + "-J" + n + ")" },
        r.price != null ? Math.round(r.price * 100) / 100 : null, { formula: 'IF(OR(N' + n + '="",O' + n + '=""),"",1-N' + n + "/O" + n + ")" }, { formula: 'IF(G' + n + '="","",J' + n + "/G" + n + ")" },
        { formula: 'IF(OR(G' + n + '="",F' + n + '=""),"",J' + n + "/G" + n + "*365/(F" + n + "-Summary!$B$3))" }, r.chance != null ? Math.round(r.chance * 100) / 100 : null, r.rating, r.earnings ? xdate(r.earnings) : null, r.why];
      row.font = { size: 10 };
      var sc = row.getCell(4); fill(sc, XL_CSP[r.status] || "FFFFFFFF"); sc.font = { bold: r.status === "SUGGESTED", size: 10, color: { argb: r.status === "SKIP" ? "FF808080" : "FF000000" } };
      row.getCell(5).alignment = { wrapText: true }; row.getCell(6).numFmt = "mmm d"; [7, 8, 9, 10, 14, 15].forEach(function (c) { row.getCell(c).numFmt = "$#,##0.00"; });
      row.getCell(11).font = { size: 10, color: { argb: "FF0000FF" } }; row.getCell(9).font = { size: 10, color: { argb: "FF0000FF" } };
      row.getCell(12).numFmt = "$#,##0"; row.getCell(13).numFmt = "$#,##0"; [16, 17, 18].forEach(function (c) { row.getCell(c).numFmt = "0.0%"; }); row.getCell(19).numFmt = "0%"; row.getCell(21).numFmt = "mmm d";
      row.getCell(22).alignment = { wrapText: true, vertical: "top" };
    });
    if (csp.length) cp.autoFilter = "A5:V" + cN;
    cp.views = [{ state: "frozen", xSplit: 2, ySplit: 5 }];
    var rr = Math.max(cN, c0) + 2;
    cp.getCell("A" + rr).value = "HOW THE IDEAS WERE PICKED (simple rules)"; cp.getCell("A" + rr).font = { bold: true, size: 12 };
    ["1. Only stocks you'd be happy to own at the strike price (no SELL/REDUCE stocks, no leveraged funds).",
      "2. Skip stocks where you already have puts in the money, already own more than " + R.settings.maxStock + "% of your portfolio, or marked “own enough”.",
      "3. Wait on groups you already own more than " + R.settings.maxSector + "% of" + (R.overGroups.length ? " (now: " + R.overGroups.map(function (g) { return g.group + " ~" + Math.round(g.pct) + "%"; }).join(", ") + ")" : "") + ", and when earnings are too close.",
      "4. Strike = about a 20% chance of being assigned (delta -0.20 to -0.22), never above the support level.",
      "5. Expiry = 3–5 weeks, and NOT across an earnings date (sell after earnings, or pick an expiry before them).",
      "6. Premiums are live mid-prices when available, otherwise estimates from each stock's implied volatility (OptionIQ data). Type the real price in “Live Premium” before trading.",
      "7. Set “Contracts” to 0 or 1+ — Cash Needed and Cash left update automatically. Suggested rows start at 1 contract."].forEach(function (t, i) { cp.getCell("B" + (rr + 1 + i)).value = t; });
    colsW(cp, { A: 4, B: 10, C: 30, D: 14, E: 22, F: 10, G: 9, H: 11, I: 11, J: 10, K: 10, L: 12, M: 11, N: 11, O: 10, P: 12, Q: 10, R: 10, S: 11, T: 22, U: 12, V: 64 });

    // Summary
    sum.getCell("A1").value = "Portfolio Review"; sum.getCell("A1").font = { bold: true, size: 16 };
    sum.getCell("A3").value = "As of"; sum.getCell("B3").value = asOf; sum.getCell("B3").numFmt = 'mmm d", "yyyy'; sum.getCell("B3").font = { color: { argb: "FF0000FF" }, size: 10 };
    ["D3", "E3", "F3", "G3", "I3", "J3"].forEach(function (a, i) { var c = sum.getCell(a); c.value = ["Stock rating", "# rows", "Value", "% of stocks", "Option action", "# legs"][i]; c.font = { bold: true, color: { argb: "FFFFFFFF" }, size: 10 }; fill(c, NAVY); });
    var kr = "Stocks!K" + s0 + ":K" + Math.max(sN, s0), gr = "Stocks!G" + s0 + ":G" + Math.max(sN, s0), pr = "Options!P" + o0 + ":P" + Math.max(oN, o0);
    sum.getCell("A4").value = "Stock value"; sum.getCell("B4").value = R.stocks.length ? { formula: "Stocks!G" + sTot } : 0; sum.getCell("B4").numFmt = "$#,##0";
    sum.getCell("A5").value = "Stock gain / loss"; sum.getCell("B5").value = R.stocks.length ? { formula: "Stocks!H" + sTot } : 0; sum.getCell("B5").numFmt = '$#,##0;[Red]"-$"#,##0';
    sum.getCell("A6").value = "Open option legs"; sum.getCell("B6").value = { formula: "COUNTA(Options!A" + o0 + ":A" + Math.max(oN, o0) + ")" };
    ["BUY MORE", "HOLD", "REDUCE", "SELL"].forEach(function (k, i) {
      var n = 4 + i, d = sum.getCell("D" + n); d.value = k; fill(d, XL_REC[k]); d.font = { bold: true, size: 10 };
      sum.getCell("E" + n).value = { formula: "COUNTIF(" + kr + ",D" + n + "&\"*\")" };
      sum.getCell("F" + n).value = { formula: "SUMIFS(" + gr + "," + kr + ",D" + n + "&\"*\")" }; sum.getCell("F" + n).numFmt = "$#,##0";
      sum.getCell("G" + n).value = { formula: "IF($B$4=0,0,F" + n + "/$B$4)" }; sum.getCell("G" + n).numFmt = "0%";
    });
    ["LET EXPIRE", "TAKE PROFIT", "HOLD", "LET ASSIGN", "CLOSE", "BUY BACK", "ROLL"].forEach(function (k, i) {
      var n = 4 + i, c = sum.getCell("I" + n); c.value = k; fill(c, XL_ACT[k]); c.font = { bold: true, size: 10 };
      sum.getCell("J" + n).value = { formula: "COUNTIF(" + pr + ",I" + n + "&\"*\")" };
    });
    sum.getCell("A13").value = "THIS WEEK — TO-DO LIST (most urgent first)"; sum.getCell("A13").font = { bold: true, size: 12 };
    ["#", "When", "Action", "Account", "Why", "Done?"].forEach(function (n, i) { var c = sum.getRow(14).getCell(i + 1); c.value = n; c.font = { bold: true, color: { argb: "FFFFFFFF" }, size: 10 }; fill(c, NAVY); });
    var done = load(K.done, {}) || {};
    R.todo.forEach(function (t, i) {
      var row = sum.getRow(15 + i);
      row.values = [t.n, t.when, t.action + (t.money ? " (" + t.money + ")" : ""), t.account, t.why, done[t.key] ? "✓" : null];
      row.font = { size: 10 }; [1, 2, 3, 4, 5].forEach(function (c) { row.getCell(c).alignment = { wrapText: true, vertical: "top" }; });
      row.getCell(6).dataValidation = { type: "list", allowBlank: true, formulae: ['"✓,Skipped"'] };
    });
    var rr2 = 15 + R.todo.length + 1;
    sum.getCell("A" + rr2).value = "SIMPLE RULES USED"; sum.getCell("A" + rr2).font = { bold: true, size: 12 };
    PR.RULES_TEXT.forEach(function (t, i) { var c = sum.getCell("B" + (rr2 + 1 + i)); c.value = t; });
    var notes = (view.state && view.state.notes || []).concat(R.notes);
    var rr3 = rr2 + PR.RULES_TEXT.length + 2;
    if (notes.length) { sum.getCell("A" + rr3).value = "NOTES"; sum.getCell("A" + rr3).font = { bold: true, size: 12 }; notes.forEach(function (n, i) { sum.getCell("B" + (rr3 + 1 + i)).value = n; }); rr3 += notes.length + 2; }
    sum.getCell("A" + rr3).value = PR.DISCLAIMER + (view.state && view.state.ranAt ? " Option prices as of " + new Date(view.state.ranAt).toLocaleString() + "." : "");
    sum.getCell("A" + rr3).font = { size: 9, color: { argb: "FF595959" } };
    colsW(sum, { A: 16, B: 14, C: 62, D: 14, E: 40, F: 12, G: 11, H: 2, I: 14, J: 8 });
    return wb;
  }

  function exportExcel() {
    var R = view.result; if (!R) return;
    var btn = $("#pr-xl"); if (btn) { btn.disabled = true; btn.textContent = "⏳ Building…"; }
    var wb;
    try { wb = buildWorkbook(R); } catch (e) { alert("Excel failed: " + e.message); render(); return; }
    wb.xlsx.writeBuffer().then(function (buf) {
      var bytes = new Uint8Array(buf), bin = "";
      for (var i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
      var inp = view.input || {};
      var used = {};
      Object.keys(inp.quotes || {}).forEach(function (k) { var tk = k.split("|")[0]; if (R.options.some(function (o) { return o.ticker === tk; })) used[k] = inp.quotes[k]; });
      var r = T.request("POST", "/api/review/save", {
        folder: (load(K.set, {}) || {}).folder || "",
        xlsxName: "Portfolio_Review_" + R.today + ".xlsx", xlsx: btoa(bin),
        jsonName: "review_inputs_" + R.today + ".json",
        inputs: { note: "What the Portfolio Review of " + R.today + " was worked out from.", ranAt: view.state && view.state.ranAt, today: R.today, settings: R.settings,
          openTrades: (inp.trades || []).filter(function (t) { return !t.action || t.action === "Open"; }),
          stocks: (inp.stocks || []).filter(function (s) { return s.status !== "Sold" && !s.soldDate; }),
          optionPrices: used, ivUsed: inp.iv, livePrices: inp.live, analysis: inp.analysis, overrides: inp.overrides, cashSecuredPutInputs: load(K.csp, {}) }
      });
      alert("✅ Saved:\n" + r.files.join("\n"));
    }).catch(function (e) { alert("Excel failed: " + (e.message || e)); }).then(function () { render(); });
  }

  window.__PORTFOLIO_REVIEW__ = { open: open, close: close, buildWorkbook: buildWorkbook, _view: view };
})();
