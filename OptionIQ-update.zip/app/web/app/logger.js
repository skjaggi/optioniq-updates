// Built by build_ui.py from logger_src/options_logger1.html. Do not edit.
const {
  useState,
  useMemo,
  useEffect,
  useRef
} = React;
const {
  BarChart,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell
} = Recharts;

// ── Constants ─────────────────────────────────────────────
// Desktop app: the account list comes from first-run setup (see shim.js).
const ACCOUNTS = window.__TRACKER__.accounts;
const ACCT_PALETTE = ["#3b82f6", "#a78bfa", "#34d399", "#fbbf24", "#f472b6", "#22d3ee", "#fb923c", "#a3e635", "#e879f9", "#f87171"];
const ACCT_COLOR = Object.fromEntries(ACCOUNTS.map((a, i) => [a, ACCT_PALETTE[i % ACCT_PALETTE.length]]));
// "Assigned" is a put being exercised against you — shares arrive.
// "Called Away" is the mirror for a short call — shares leave at the strike.
// Kept as separate labels because they move your share count in opposite
// directions, and one word for both makes the log ambiguous at a glance.
const ACTIONS = ["Open", "Expired", "Assigned", "Called Away", "Bought to Close", "Sold to Close", "Rolled"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
// Log tab sortable columns: header label -> {field or accessor, type for comparison}
const TICKERS = {
  AAPL: "APPLE INC. (XNAS:AAPL)",
  NVDA: "NVIDIA CORPORATION (XNAS:NVDA)",
  MU: "MICRON TECHNOLOGY, INC. (XNAS:MU)",
  ARM: "ARM HOLDINGS PLC (XNAS:ARM)",
  TSLA: "TESLA, INC. (XNAS:TSLA)",
  MSFT: "MICROSOFT CORPORATION (XNAS:MSFT)",
  GOOGL: "ALPHABET INC. (XNAS:GOOGL)",
  AMZN: "AMAZON.COM, INC. (XNAS:AMZN)",
  AMAT: "APPLIED MATERIALS, INC. (XNAS:AMAT)",
  GLW: "CORNING INCORPORATED (XNYS:GLW)",
  PANW: "PALO ALTO NETWORKS, INC. (XNAS:PANW)",
  SPY: "State Street SPDR S&P500 (ARCX:SPY)",
  QQQ: "Invesco QQQ Trust 1 (XNAS:QQQ)",
  TSM: "Taiwan Semiconductor Mfg (XNYS:TSM)",
  INTC: "INTEL CORPORATION (XNAS:INTC)",
  NOW: "SERVICENOW, INC. (XNYS:NOW)",
  AAOI: "APPLIED OPTOELECTRONICS (XNAS:AAOI)",
  COHR: "Coherent Corp. (XNYS:COHR)",
  MRVL: "MARVELL TECHNOLOGY (XNAS:MRVL)",
  META: "META PLATFORMS (XNAS:META)",
  NFLX: "NETFLIX, INC. (XNAS:NFLX)",
  AMD: "ADVANCED MICRO DEVICES (XNAS:AMD)",
  ORCL: "ORACLE CORPORATION (XNYS:ORCL)",
  QBTS: "D-WAVE QUANTUM INC. (XNYS:QBTS)",
  Q: "QNITY ELECTRONICS, INC. (XNYS:Q)"
};
const SK = "options_trades_v3";
const STOCK_SK = "stock_holdings_v1";
// ── Screener ──────────────────────────────────────────────
// Option chains cannot be fetched from a browser (Yahoo blocks CORS, Finnhub's
// chain endpoint is paid-tier). Screener_Service.pyw does the fetching locally
// and this app talks to it over 127.0.0.1.
const SCREENER_URL = "http://127.0.0.1:8765";
const SCREENER_CFG_SK = "screener_cfg_v1";
// Your own watchlist, added from the Screener tab. Shape: {TICKER:"Company Name"}.
// Kept separate from the built-in TICKERS list above so updates to this file
// never clobber names you added yourself.
const WATCHLIST_SK = "watchlist_v1";
// Tickers sitting out of the next scan. Separate from the watchlist itself:
// unticking one skips it this run without forgetting it exists.
const EXCLUDED_SK = "screener_excluded_v1";
// Live prices for the contracts you hold, keyed TICKER|YYYY-MM-DD|STRIKE|C/P.
const OPT_QUOTES_SK = "option_quotes_v1";
const quoteKey = (tk, exp, strike, cp) => `${(tk || "").toUpperCase()}|${String(exp || "").slice(0, 10)}|${(+strike).toFixed(2)}|${(cp || "P").toUpperCase()}`;
// ── Discover: weekly S&P 500 hunt for names worth adding ──
const BENCH_SK = "benchmark_v1";
const DISCOVER_CFG_SK = "discover_cfg_v1";
// ── Analysis: fundamentals + technicals scorecard per stock ──
const ANALYSIS_RES_SK = "analysis_results_v1";
const DISCOVER_RES_SK = "discover_results_v1";
// GICS sectors exactly as the S&P 500 constituent table spells them. These are
// NOT Yahoo's sector names ("Technology", "Financial Services") — this filter is
// applied to the constituent list before any quote is requested.
const GICS_SECTORS = ["Communication Services", "Consumer Discretionary", "Consumer Staples", "Energy", "Financials", "Health Care", "Industrials", "Information Technology", "Materials", "Real Estate", "Utilities"];
const DISCOVER_DEFAULTS = {
  sectors: [],
  // empty = every sector
  priceMin: 20,
  priceMax: 600,
  marketCapMin: 5,
  // marketCapMin in $B in the UI
  peMin: 0,
  peMax: 60,
  positiveEPS: true,
  marginMin: 5,
  roeMin: 10,
  revGrowthMin: 0,
  // percentages in the UI
  avgVolumeMin: 1,
  // millions of shares
  allowMissingMetrics: true,
  // These are the values that returned 200+ candidates on a clean run. They
  // were never the problem -- the empty scans were Yahoo throttling.
  // Stage 2 is the same contract screen the Screener tab runs, so every field
  // below means exactly what it means there.
  side: "put",
  dteMin: 21,
  dteMax: 45,
  deltaMin: 0.15,
  deltaMax: 0.30,
  ivMin: 30,
  ivMax: 150,
  // percentages in the UI
  minOI: 500,
  minVolume: 0,
  maxSpreadPct: 10,
  minBid: 0.10,
  minPremium: 0.20,
  minAnnualized: 15,
  minNetPremium: 75,
  minIVHV: 0,
  // $/contract after the fee; IV÷HV floor
  maxPerTicker: 1,
  // Every expiry inside the DTE window is another request per stock. Across
  // a couple of hundred survivors that decides whether the scan is quick or
  // rate-limited.
  maxExpiries: 2,
  skipEarnings: false,
  // Yahoo throttles a 500-symbol sweep. Few workers and a request cap beat
  // many workers that all get 429'd.
  workers: 6,
  requestsPerSecond: 12
};
const SCREENER_DEFAULTS = {
  sides: "both",
  // "put" | "call" | "both"
  preset: "weekly",
  // "weekly" | "monthly" | "custom"
  dteMin: 4,
  dteMax: 14,
  deltaMin: 0.10,
  deltaMax: 0.25,
  ivMin: 15,
  ivMax: 120,
  // percent in the UI, converted on send
  peMin: 0,
  peMax: 100,
  allowMissingPE: true,
  minOI: 250,
  minVolume: 0,
  maxSpreadPct: 10,
  minBid: 0.05,
  minAnnualized: 20,
  minPremium: 0.10,
  minNetPremium: 40,
  // $ per contract after the $0.67 fee
  minIVHV: 1.1,
  // implied vs the stock's own 20-day moves
  minIVRank: 30,
  // used once 60 days of IV history exist
  minAvgVolumeM: 1,
  // underlying, millions of shares a day
  maxPerTicker: 3,
  workers: 8,
  skipEarnings: true,
  flagEarnings: true,
  costBasisFloor: true,
  costBasisMargin: 0
};
// ── Opportunity Screener: Score badge and its breakdown ──────
const SCREENER_PRESETS = {
  weekly: {
    preset: "weekly",
    dteMin: 4,
    dteMax: 14,
    deltaMin: 0.10,
    deltaMax: 0.25,
    minNetPremium: 40,
    minAnnualized: 20,
    skipEarnings: true,
    flagEarnings: true
  },
  monthly: {
    preset: "monthly",
    dteMin: 21,
    dteMax: 45,
    deltaMin: 0.15,
    deltaMax: 0.30,
    minNetPremium: 75,
    minAnnualized: 15,
    skipEarnings: false,
    flagEarnings: true
  }
};
const IVR_FULL_DAYS = 60;
const scoreColor = s => s == null ? "#4b5563" : s >= 70 ? "#4ade80" : s >= 50 ? "#fbbf24" : "#f87171";
const ivrText = r => {
  const n = r["IVR Days"] || 0,
    v = r["IV Rank"];
  if (v != null && n >= IVR_FULL_DAYS) return {
    t: v.toFixed(0),
    c: "#e2e8f0",
    tip: `IV Rank ${v.toFixed(0)}: where today's IV sits in its range over the last ${Math.min(n, 252)} trading days (0 = lowest, 100 = highest).`
  };
  if (v != null) return {
    t: `${v.toFixed(0)}*`,
    c: "#6b7280",
    tip: `Partial: only ${n} of ${IVR_FULL_DAYS} days recorded so far, so this isn't used in the Score or the filter yet.`
  };
  return {
    t: n ? `${n}d` : "—",
    c: "#4b5563",
    tip: `Building: ${n} of ${IVR_FULL_DAYS} days of IV history recorded. OptionIQ saves one reading a day while it's open.`
  };
};
function ScoreBadge({
  row
}) {
  const [tip, setTip] = useState(null);
  const p = row["Score Parts"];
  if (row.Score == null || !p) return /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#4b5563"
    }
  }, "\u2014");
  const show = e => {
    const b = e.currentTarget.getBoundingClientRect();
    const left = Math.min(b.left, window.innerWidth - 350),
      below = b.bottom + 300 < window.innerHeight;
    setTip({
      left: Math.max(8, left),
      top: below ? b.bottom + 6 : null,
      bottom: below ? null : window.innerHeight - b.top + 6
    });
  };
  const ivr = ivrText(row);
  const line = (label, val, why, w) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "88px 34px 1fr",
      gap: 8,
      alignItems: "baseline",
      padding: "3px 0"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#cbd5e1"
    }
  }, label, " ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#4b5563"
    }
  }, w)), /*#__PURE__*/React.createElement("b", {
    style: {
      color: scoreColor(val),
      textAlign: "right"
    }
  }, val), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#94a3b8"
    }
  }, why));
  return /*#__PURE__*/React.createElement("span", {
    onMouseEnter: show,
    onMouseLeave: () => setTip(null),
    style: {
      cursor: "help"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-block",
      minWidth: 30,
      textAlign: "center",
      fontWeight: 800,
      borderRadius: 6,
      padding: "2px 6px",
      background: scoreColor(row.Score) + "22",
      color: scoreColor(row.Score),
      border: "1px solid " + scoreColor(row.Score) + "66"
    }
  }, row.Score), tip && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      left: tip.left,
      top: tip.top ?? undefined,
      bottom: tip.bottom ?? undefined,
      zIndex: 300,
      width: 340,
      whiteSpace: "normal",
      background: "#1b1e29",
      border: "1px solid #3b82f6",
      borderRadius: 10,
      padding: "10px 12px",
      fontSize: 12,
      lineHeight: 1.45,
      boxShadow: "0 8px 24px rgba(0,0,0,.5)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      color: "#e2e8f0",
      marginBottom: 6
    }
  }, "Score ", row.Score, " of 100 \xB7 ", row.Ticker, " ", row.Side, " ", fmt$(row.Strike)), line("Edge", p.edge, (p.ivhv != null ? `IV is ${p.ivhv.toFixed(2)}× the stock's recent moves` : "no price history") + (p.ivrUsed ? ` · IV Rank ${p.ivr.toFixed(0)}` : ` · IV Rank ${ivr.t === "—" ? "building" : ivr.t.replace("*", " (partial)")}`), "35%"), line("Cushion", p.cushion, (p.cushionMoves != null ? `strike is ${p.cushionMoves.toFixed(2)} expected moves away` : "—") + (p.level ? ` · ${row.Side === "PUT" ? "below support" : "above resistance"} ${fmt$(p.level)} (${p.levelTouches} touches) +20` : ""), "25%"), line("Return", p.ret, `${row["Annualized %"] != null ? row["Annualized %"].toFixed(1) : "—"}% a year after fees (60% = full marks)`, "25%"), line("Liquidity", p.liq, `spread ${row["Spread %"] != null ? row["Spread %"].toFixed(0) + "%" : "—"} · open interest ${row.OI != null ? row.OI.toLocaleString() : "—"}`, "15%"), (p.adj || []).map(([why, v]) => /*#__PURE__*/React.createElement("div", {
    key: why,
    style: {
      display: "flex",
      justifyContent: "space-between",
      padding: "3px 0",
      color: v < 0 ? "#f87171" : "#4ade80"
    }
  }, /*#__PURE__*/React.createElement("span", null, why), /*#__PURE__*/React.createElement("b", null, v > 0 ? "+" : "", v))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 6,
      paddingTop: 6,
      borderTop: "1px solid #2d3748",
      color: "#6b7280",
      fontSize: 11
    }
  }, "Edge: is the option priced richly for this stock? Cushion: how far price must move to hurt. Return: yield after the $0.67 fee. Liquidity: how easy it is to get in and out.")));
}
const ScreenFlags = ({
  r
}) => /*#__PURE__*/React.createElement(React.Fragment, null, r["Ex-Div Before Exp"] && /*#__PURE__*/React.createElement("span", {
  title: "Ex-dividend " + (r["Ex-Div Date"] || "") + " is before expiry: an in-the-money call may be assigned early",
  style: {
    marginLeft: 4,
    color: "#2dd4bf"
  }
}, "\uD83D\uDCB2"), r["Concentration Flag"] && /*#__PURE__*/React.createElement("span", {
  title: `After this trade ${r["Sector Share %"]}% of your short-put money would be in ${r.Sector || "one sector"}`,
  style: {
    marginLeft: 4,
    color: "#f472b6"
  }
}, "\u2696"), r["S/R"] && /*#__PURE__*/React.createElement("span", {
  title: "Strike is " + r["S/R"] + " — a price level the stock has turned at before",
  style: {
    marginLeft: 4,
    color: "#a3e635"
  }
}, "\u26F0\uFE0F"));
// Both tabs open filtered to what you still have on. "Clear" returns here
// rather than to nothing, and the filter badge counts deviations from it.
const DEFAULT_FILTERS = {
  status: "open",
  cp: "all",
  sb: "all",
  moneyOnHold: false,
  itmOnly: false,
  ticker: "",
  dateFrom: "",
  dateTo: "",
  closeDateFrom: "",
  closeDateTo: "",
  minPL: "",
  maxPL: "",
  maxDTE: ""
};
const DEFAULT_STOCK_FILTERS = {
  status: "active",
  ticker: "",
  dateAcqFrom: "",
  dateAcqTo: "",
  soldDateFrom: "",
  soldDateTo: "",
  missingCalls: false
};
const EMPTY = {
  account: ACCOUNTS[0],
  date: "",
  company: "",
  ticker: "",
  strike: "",
  currentStock: "",
  expDate: "",
  sellPremium: "",
  contracts: "1",
  cp: "P",
  sb: "S",
  action: "Open"
};
const EMPTY_STOCK = {
  account: ACCOUNTS[0],
  ticker: "",
  company: "",
  shares: "",
  dateAcquired: "",
  costBasis: "",
  currentPrice: "",
  status: "Held",
  soldDate: "",
  soldPrice: ""
};
const INDEX_TICKERS = {
  "SPY": "S&P 500 (SPY)",
  "QQQ": "Nasdaq 100 (QQQ)"
};
// Seed values — self-updating from here: every price fetch checks live price against this and
// ratchets it upward (plus today's date) whenever a new high is observed. Never goes stale.
const ATH_PRICES = {
  "SPY": {
    price: 760.40,
    date: "2026-06-02"
  },
  "QQQ": {
    price: 748.65,
    date: "2026-06-03"
  }
};

// ── Helpers ───────────────────────────────────────────────
const fmt$ = v => v == null || v === "" ? "" : `$${Number(v).toLocaleString("en-US", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
})}`;
const fmtK = v => {
  const n = Number(v);
  return (n < 0 ? "-$" : "$") + Math.abs(n / 1000).toFixed(1) + "k";
};
const fmtPL = v => {
  if (v == null || v === "") return "";
  const n = Number(v);
  return (n >= 0 ? "$" : "-$") + Math.abs(n).toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
};
const calcSells = (sb, p, q) => sb === "S" && p && q ? parseFloat(p) * parseInt(q) * 100 - 0.67 * parseInt(q) : 0;
const calcBuys = (sb, p, q) => sb === "B" && p && q ? -(parseFloat(p) * parseInt(q) * 100 + 0.67 * parseInt(q)) : 0;
// Premium for a trade as cash: credit received less debit paid. `buys` is
// already negative, so this nets out automatically.
//
// The weekly and per-account premium figures used to count only sold contracts
// and ignore bought ones entirely. Sell MRVL puts and buy an MRVL call the same
// day and the week reported the full credit as though the call had cost nothing.
const netPremium = t => (t && t.sells || 0) + (t && t.buys || 0);
const isOpen = t => !t.action || t.action === "Open";
const calcMOH = t => {
  if (t.cp !== "P" || t.sb !== "S" || !isOpen(t) || !t.strike || !t.contracts) return 0;
  return parseFloat(t.strike) * parseInt(t.contracts) * 100;
};
// Annualized return on the premium collected, measured over the life the trade
// was written for: entry date to expiry.
//
// Premium over collateral, scaled to a year — the same shape the Screener uses,
// so a trade you took can be compared against one it is offering you. Collateral
// is the strike on both puts and calls: cash secured on a put, and on a call the
// shares that can be taken at the strike. Contracts cancel out of the ratio.
//
// This is the yield the trade was priced at when you opened it, not what you
// ended up making. Closing early or being assigned does not change it, which is
// the point — it answers "was this worth writing", and the Net P&L beside it
// answers "how did it work out".
// Open and closed trades are answering different questions, so they are
// measured differently.
//
//   Open   — premium collected, over entry to expiry. The yield the trade was
//            written at, because the outcome is not known yet.
//   Closed — net P&L, over entry to the close date. What the capital actually
//            earned, over the time it was actually tied up. A roll bought back
//            at a loss gives a negative net P&L and so a negative return, which
//            is the honest answer: that trade cost you money.
//
// Closing a 45-day trade after 10 days for most of the premium is a better
// result than the static yield implies, and using the real holding period is
// what shows it.
// ──────────────────────────────────────────────────────────────────────────
// STRATEGY SCORECARD ENGINE
//
// Pure functions over the existing trade and holding records. Nothing here
// changes how a trade is logged; it only reads what is already there. Kept at
// module scope and side-effect free so every rule below can be tested against
// hand-computed cases outside the browser.
// ──────────────────────────────────────────────────────────────────────────

const DAY_MS = 86400000;
const sc_date = s => {
  const d = new Date((s || "") + "T00:00:00");
  return isNaN(d.getTime()) ? null : d;
};
const sc_days = (a, b) => {
  const x = sc_date(a),
    y = sc_date(b);
  return x && y ? Math.max(Math.round((y - x) / DAY_MS), 1) : null;
};
const sc_num = v => {
  const n = parseFloat(v);
  return isFinite(n) ? n : NaN;
};

// --- strategy classification -------------------------------------------
//
// Legs opened on the same day, same account, same underlying and the same
// expiry are one structure. That is how they were entered and how they behave.
// Anything that doesn't group is judged on its own.
const sc_legKey = t => `${(t.account || "").trim()}|${(t.ticker || "").trim().toUpperCase()}|${String(t.expDate || "").slice(0, 10)}|${String(t.date || "").slice(0, 10)}`;
const sc_classify = (legs, sharesHeld) => {
  const n = legs.length;
  const puts = legs.filter(l => l.cp === "P"),
    calls = legs.filter(l => l.cp === "C");
  const sold = legs.filter(l => l.sb === "S"),
    bought = legs.filter(l => l.sb === "B");
  const qty = l => parseInt(l.contracts) || 0;
  if (n === 1) {
    const l = legs[0];
    if (l.sb === "B") return l.cp === "P" ? "Long put" : "Long call";
    if (l.cp === "P") return "Cash-secured put";
    // A sold call is only covered if the shares are actually there.
    return sharesHeld >= qty(l) * 100 ? "Covered call" : "Naked call";
  }
  // Four legs, two puts two calls, half sold half bought -> condor/butterfly.
  if (n === 4 && puts.length === 2 && calls.length === 2 && sold.length === 2 && bought.length === 2) return "Iron condor";
  // Two legs of the same type, one sold one bought -> vertical.
  if (n === 2 && sold.length === 1 && bought.length === 1) {
    if (puts.length === 2) return "Put spread";
    if (calls.length === 2) return "Call spread";
    return "Combo";
  }
  // A sold put and a sold call together.
  if (n === 2 && sold.length === 2 && puts.length === 1 && calls.length === 1) {
    const sameStrike = sc_num(puts[0].strike) === sc_num(calls[0].strike);
    const covered = sharesHeld >= qty(calls[0]) * 100;
    return sameStrike ? covered ? "Covered straddle" : "Short straddle" : covered ? "Covered strangle" : "Short strangle";
  }
  if (n === 2 && bought.length === 2 && puts.length === 1 && calls.length === 1) return "Long straddle/strangle";
  return `Multi-leg (${n})`;
};

// --- capital at risk ----------------------------------------------------
//
// The worst case you would have to fund, by structure. Spreads risk the width
// between the strikes, not the full notional — treating a $10-wide spread as
// $37,000 of capital would make its return look negligible when the real
// exposure is $1,000.
const sc_capital = (legs, strategy, costBasis) => {
  const qty = l => parseInt(l.contracts) || 0;
  const maxQty = Math.max(...legs.map(qty), 0);
  // Covered positions tie up the shares, so the capital at risk is what those
  // shares cost you, not the strike you happen to have sold against them.
  // Falls back to the strike when the holding is not in the log.
  if (/^Covered/.test(strategy)) {
    const cb = sc_num(costBasis);
    if (isFinite(cb) && cb > 0) return cb * 100 * maxQty;
  }
  if (/spread|condor/i.test(strategy)) {
    const byType = cp => legs.filter(l => l.cp === cp).map(l => sc_num(l.strike)).filter(isFinite).sort((a, b) => a - b);
    const width = arr => arr.length >= 2 ? Math.abs(arr[arr.length - 1] - arr[0]) : 0;
    // A condor has two wings; you can only lose on one of them.
    const w = Math.max(width(byType("P")), width(byType("C")));
    return w > 0 ? w * 100 * maxQty : 0;
  }
  if (/^Long /.test(strategy)) {
    // A bought option risks exactly what you paid for it.
    return legs.reduce((a, l) => a + Math.abs(sc_num(l.buys) || 0), 0);
  }
  // Short single legs, straddles and strangles: the strike that could be put
  // to you, or the shares that could be called away. On a straddle only one
  // side can finish in the money, so take the larger.
  const shortStrikes = legs.filter(l => l.sb === "S").map(l => sc_num(l.strike) * 100 * qty(l)).filter(isFinite);
  return shortStrikes.length ? Math.max(...shortStrikes) : 0;
};

// --- roll chains --------------------------------------------------------
//
// Rolls created by the dialog carry rolledFromId and are exact. Older ones are
// inferred: a trade marked Rolled is matched to one opened in the same account
// and ticker, same type and side, on or just after the close date. The window
// is deliberately tight, and every inferred link is flagged in the UI so a
// wrong guess is visible rather than silently folded into the totals.
const SC_ROLL_WINDOW_DAYS = 5;
const sc_buildChains = trades => {
  const byId = new Map(trades.map(t => [t.id, t]));
  const nextOf = new Map(),
    inferred = new Set();
  const claimed = new Set();

  // Explicit links first — they always win over a guess.
  trades.forEach(t => {
    if (t.rolledToId && byId.has(t.rolledToId)) {
      nextOf.set(t.id, t.rolledToId);
      claimed.add(t.rolledToId);
    }
  });
  trades.forEach(t => {
    if (t.rolledFromId && byId.has(t.rolledFromId) && !nextOf.has(t.rolledFromId)) {
      nextOf.set(t.rolledFromId, t.id);
      claimed.add(t.id);
    }
  });

  // Then infer for anything marked Rolled that still has no successor.
  trades.filter(t => t.action === "Rolled" && !nextOf.has(t.id)).forEach(t => {
    const closeD = sc_date(t.closeDate);
    if (!closeD) return;
    const cands = trades.filter(c => c.id !== t.id && !claimed.has(c.id) && (c.account || "") === (t.account || "") && (c.ticker || "").toUpperCase() === (t.ticker || "").toUpperCase() && c.cp === t.cp && c.sb === t.sb && c.date);
    let best = null,
      bestGap = Infinity;
    cands.forEach(c => {
      const d = sc_date(c.date);
      if (!d) return;
      const gap = (d - closeD) / DAY_MS;
      if (gap >= 0 && gap <= SC_ROLL_WINDOW_DAYS && gap < bestGap) {
        best = c;
        bestGap = gap;
      }
    });
    if (best) {
      nextOf.set(t.id, best.id);
      claimed.add(best.id);
      inferred.add(best.id);
    }
  });

  // Walk heads forward into chains.
  const isSuccessor = new Set([...nextOf.values()]);
  const chains = [];
  trades.filter(t => !isSuccessor.has(t.id)).forEach(head => {
    const legs = [];
    let cur = head,
      guard = 0;
    while (cur && guard++ < 50) {
      legs.push(cur);
      const nx = nextOf.get(cur.id);
      cur = nx ? byId.get(nx) : null;
    }
    if (legs.length > 1) chains.push({
      legs,
      inferred: legs.some(l => inferred.has(l.id))
    });
  });
  return {
    chains,
    nextOf,
    inferred
  };
};

// A chain's economics: every credit and debit across all its legs, and the
// elapsed time from the first open to the last close (or today if still open).
const sc_chainStats = (legs, todayStr) => {
  const credit = legs.reduce((a, l) => a + netPremium(l), 0);
  const debits = legs.reduce((a, l) => {
    const cp = sc_num(l.closePremium);
    return a + (isFinite(cp) ? cp : 0);
  }, 0);
  const net = credit + debits;
  const open = legs.some(isOpen);
  const start = legs.map(l => l.date).filter(Boolean).sort()[0] || null;
  const ends = legs.map(l => l.closeDate).filter(Boolean).sort();
  const end = open ? todayStr : ends[ends.length - 1] || todayStr;
  const days = start ? sc_days(start, end) : null;
  const cap = Math.max(...legs.map(l => sc_capital([l], l.cp === "P" && l.sb === "S" ? "Cash-secured put" : "x")), 0);
  return {
    net,
    credit,
    debits,
    open,
    start,
    end,
    days,
    ann: cap > 0 && days ? net / cap * (365 / days) * 100 : null
  };
};

// --- the scorecard itself ----------------------------------------------
//
// Everything is measured on NET premium: what you kept, after paying to buy
// positions back. Gross premium flatters a book that rolls a lot, because
// every roll pays to close one leg before opening the next — and that cost is
// real money that never reaches you.
//
// Per-contract fees are already inside `sells` and `buys` (calcSells subtracts
// $0.67 a contract), so net = gross + closePremium is already net of fees.
// Subtracting them again would double-count.
//
// `sharesFor`, `costBasisFor` and `sectorFor` are injected so this stays
// testable without the holdings state, and works whether or not an Analysis
// run has happened.
const sc_build = (trades, {
  sharesFor,
  costBasisFor,
  sectorFor,
  today
}) => {
  const todayStr = today || new Date().toISOString().slice(0, 10);
  const cbFor = costBasisFor || (() => 0);

  // 1. legs entered together are one structure
  const groups = new Map();
  trades.forEach(t => {
    const k = sc_legKey(t);
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(t);
  });
  const structures = [];
  groups.forEach(legs => {
    const acct = legs[0].account,
      tk = (legs[0].ticker || "").toUpperCase();
    const strategy = sc_classify(legs, sharesFor(acct, tk));
    structures.push({
      legs,
      strategy,
      account: acct,
      ticker: tk,
      capital: sc_capital(legs, strategy, cbFor(acct, tk))
    });
  });

  // 2. roll chains, so a rolled position is one campaign rather than several
  const {
    chains
  } = sc_buildChains(trades);
  const chainOf = new Map(),
    chainInferred = new Map();
  chains.forEach((c, i) => {
    c.legs.forEach(l => chainOf.set(l.id, i));
    chainInferred.set(i, c.inferred);
  });

  // 3. campaigns: a chain end-to-end, or a standalone structure
  const campaignMap = new Map();
  structures.forEach(st => {
    const cid = st.legs.map(l => chainOf.get(l.id)).find(x => x != null);
    const key = cid != null ? `chain:${cid}` : `st:${st.legs.map(l => l.id).join(",")}`;
    if (!campaignMap.has(key)) campaignMap.set(key, {
      key,
      isChain: cid != null,
      inferred: cid != null ? !!chainInferred.get(cid) : false,
      structures: []
    });
    campaignMap.get(key).structures.push(st);
  });
  const campaigns = [...campaignMap.values()].map(c => {
    const legs = c.structures.flatMap(s => s.legs);
    // Gross is every credit taken in across the whole campaign; paid is every
    // debit to close. A roll chain nets all of them together.
    const gross = legs.reduce((a, l) => a + netPremium(l), 0);
    const paid = legs.reduce((a, l) => {
      const v = sc_num(l.closePremium);
      return a + (isFinite(v) ? v : 0);
    }, 0);
    const net = gross + paid;
    const open = legs.some(isOpen);
    // Capital at risk is the most committed at any one time, not the sum —
    // rolling a put replaces the old collateral, it does not add to it.
    const capital = Math.max(...c.structures.map(s => s.capital), 0);
    const start = legs.map(l => l.date).filter(Boolean).sort()[0] || null;
    const closes = legs.map(l => l.closeDate).filter(Boolean).sort();
    const exps = legs.map(l => l.expDate).filter(Boolean).sort();
    // First open to final close; still-open campaigns run to their last expiry.
    const end = open ? exps[exps.length - 1] || todayStr : closes[closes.length - 1] || exps[exps.length - 1] || todayStr;
    const days = start ? sc_days(start, end) : null;
    return {
      ...c,
      legs,
      gross,
      paid,
      net,
      open,
      capital,
      start,
      end,
      days,
      strategy: c.structures[0].strategy,
      account: c.structures[0].account,
      ticker: c.structures[0].ticker,
      ann: capital > 0 && days ? net / capital * (365 / days) * 100 : null
    };
  });

  // Capital-and-days weighting. A simple mean of percentages lets a $1,000
  // spread held four days outvote a $29,000 put held two months.
  const weighted = list => {
    const denom = list.reduce((a, p) => a + (p.capital || 0) * (p.days || 0), 0);
    if (!denom) return null;
    return list.reduce((a, p) => a + (p.net || 0), 0) / denom * 365 * 100;
  };
  const sum = (arr, f) => arr.reduce((a, x) => a + (f(x) || 0), 0);

  // 4. rolled vs un-rolled. Nothing is excluded: a campaign closed for a net
  // debit carries a negative net and drags its group down, which is the point.
  const rolledC = campaigns.filter(c => c.isChain);
  const plainC = campaigns.filter(c => !c.isChain);
  const side = list => ({
    n: list.length,
    gross: sum(list, c => c.gross),
    paid: sum(list, c => c.paid),
    net: sum(list, c => c.net),
    avgDays: list.length ? sum(list, c => c.days) / list.length : null,
    wAnn: weighted(list),
    losers: list.filter(c => c.net < 0).length,
    open: list.filter(c => c.open).length
  });
  const rollCompare = {
    rolled: {
      ...side(rolledC),
      inferred: rolledC.filter(c => c.inferred).length
    },
    unrolled: side(plainC)
  };

  // 5. breakdowns, all on the same net basis
  const bucket = keyFn => {
    const m = new Map();
    campaigns.forEach(p => {
      const k = keyFn(p) || "—";
      if (!m.has(k)) m.set(k, {
        key: k,
        n: 0,
        items: []
      });
      const b = m.get(k);
      b.n++;
      b.items.push(p);
    });
    return [...m.values()].map(b => ({
      key: b.key,
      n: b.n,
      gross: sum(b.items, p => p.gross),
      paid: sum(b.items, p => p.paid),
      net: sum(b.items, p => p.net),
      capital: sum(b.items, p => p.capital),
      wAnn: weighted(b.items),
      losers: b.items.filter(p => p.net < 0).length
    })).sort((a, b) => b.net - a.net);
  };

  // 6. concentration — open short-put notional by sector
  const openShortPuts = trades.filter(t => isOpen(t) && t.cp === "P" && t.sb === "S");
  const conc = new Map();
  let concTotal = 0;
  openShortPuts.forEach(t => {
    const notional = (sc_num(t.strike) || 0) * 100 * (parseInt(t.contracts) || 0);
    if (!notional) return;
    const sec = sectorFor((t.ticker || "").toUpperCase()) || "Unclassified";
    if (!conc.has(sec)) conc.set(sec, {
      sector: sec,
      notional: 0,
      tickers: new Set(),
      accounts: new Set()
    });
    const c = conc.get(sec);
    c.notional += notional;
    c.tickers.add((t.ticker || "").toUpperCase());
    c.accounts.add(t.account);
    concTotal += notional;
  });
  const concentration = [...conc.values()].map(c => ({
    sector: c.sector,
    notional: c.notional,
    pct: concTotal > 0 ? c.notional / concTotal * 100 : 0,
    tickers: [...c.tickers].sort(),
    accounts: [...c.accounts].sort()
  })).sort((a, b) => b.notional - a.notional);
  const dates = trades.map(t => t.date).filter(Boolean).sort();
  return {
    campaigns,
    chainRows: rolledC.slice().sort((a, b) => b.net - a.net),
    rollCompare,
    concentration,
    concTotal,
    byTicker: bucket(p => p.ticker),
    byStrategy: bucket(p => p.strategy),
    byAccount: bucket(p => p.account),
    totals: {
      positions: campaigns.length,
      closed: campaigns.filter(c => !c.open).length,
      losers: campaigns.filter(c => c.net < 0).length,
      gross: sum(campaigns, c => c.gross),
      paid: sum(campaigns, c => c.paid),
      net: sum(campaigns, c => c.net),
      // Reconciles with the Options tab, which sums netPL over every trade.
      netPL: sum(trades, t => isFinite(sc_num(t.netPL)) ? sc_num(t.netPL) : 0),
      weightedAnn: weighted(campaigns),
      firstDate: dates[0] || null,
      lastDate: todayStr
    }
  };
};

// Ticker filter: exact symbol, never the company name.
//
// It used to substring-match the symbol AND the name, so "BE" returned Bloom
// Energy, Franklin Resources, Ambev and anything with "be" anywhere in its
// company name. A ticker is an exact identifier; matching it loosely makes the
// filter unusable precisely for the short symbols that need it most.
//
// Comma or space separated symbols are allowed, so "BE, ARM NVDA" works.
const matchesTicker = (rowTicker, filterText) => {
  const raw = (filterText || "").trim();
  if (!raw) return true; // empty filter = show all
  const wanted = raw.toUpperCase().split(/[\s,]+/).filter(Boolean);
  if (!wanted.length) return true;
  return wanted.includes((rowTicker || "").trim().toUpperCase());
};
const calcAnnualized = t => {
  if (!t || t.sb !== "S") return null; // nothing collected on a long
  const strike = parseFloat(t.strike);
  const qty = parseInt(t.contracts) || 0;
  if (!isFinite(strike) || strike <= 0 || !qty || !t.date) return null;
  const open = isOpen(t);
  const amount = open ? parseFloat(t.sells) : parseFloat(t.netPL);
  if (!isFinite(amount)) return null;
  if (open && amount <= 0) return null; // no premium collected yet

  // A closed trade with no close date recorded falls back to expiry rather
  // than dropping out of the column entirely.
  const endStr = open ? t.expDate : t.closeDate || t.expDate;
  if (!endStr) return null;
  const d0 = new Date(t.date + "T00:00:00"),
    d1 = new Date(endStr + "T00:00:00");
  if (isNaN(d0.getTime()) || isNaN(d1.getTime())) return null;
  // Same-day close counts as one day rather than dividing by zero.
  const days = Math.max(Math.round((d1 - d0) / 86400000), 1);
  const collateral = strike * 100 * qty;
  return {
    pct: amount / collateral * (365 / days) * 100,
    amount,
    collateral,
    days,
    open,
    endStr,
    endLabel: open ? "expiry" : "close"
  };
};
const calcNetPL = (total, cp, action) => {
  // Called away like expired and assigned: there is no buy-back, so the whole
  // premium is kept. The gain on the shares is recorded on the stock row.
  if (action === "Expired" || action === "Assigned" || action === "Called Away") return total;
  const c = (cp + "").replace(/[^0-9.\-]/g, "");
  const amt = cp === null || cp === undefined || cp === "" ? 0 : parseFloat(c);
  return isNaN(amt) ? total : total + amt;
};
const csvClean = v => (v || "").replace(/[\$,\s]/g, "").replace(/\(([^)]+)\)/, "-$1");
const csvNum = v => {
  const n = parseFloat(csvClean(v));
  return isNaN(n) ? null : n;
};
const csvDate = v => {
  const s = (v || "").trim();
  if (!s || s === "0") return "";
  const p2 = n => String(n).padStart(2, "0");
  let m = s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/);
  if (m) return `${m[1]}-${p2(m[2])}-${p2(m[3])}`;
  m = s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{2}|\d{4})$/);
  if (m) return `${m[3].length === 2 ? "20" + m[3] : m[3]}-${p2(m[1])}-${p2(m[2])}`;
  const d = new Date(s);
  return isNaN(d.getTime()) ? "" : `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
};
const csvAcct = v => {
  const s = (v || "").trim().toLowerCase().replace(/\s+/g, " ");
  // Exact names only (capitals and extra spaces don't matter). A name that
  // isn't one of this person's accounts is kept as written; ⬆ Import asks
  // before creating it. A blank name goes to the first account.
  if (!s) return ACCOUNTS[0];
  return ACCOUNTS.find(a => a.toLowerCase().replace(/\s+/g, " ") === s) || (v || "").trim().replace(/\s+/g, " ");
};
// ── ⬆ Import: read anyone's spreadsheet ──────────────────────
// People keep their trades in their own layouts. Import opens a "match your
// columns" box: OptionIQ guesses which column is which (by heading, then by
// the values in it), the person fixes any wrong guess, sees a preview, and
// only then is anything saved. The choices are remembered per layout.
const IMP_FIELDS = [{
  k: "account",
  label: "Account",
  exact: ["account", "acct", "accountname", "acctname", "accountnumber", "acctnumber", "portfolio", "broker", "accountnickname"],
  like: /account|acct|portfolio/
}, {
  k: "date",
  label: "Date opened",
  exact: ["date", "opendate", "tradedate", "dateopened", "opened", "entrydate", "datesold", "solddate", "transactiondate", "rundate", "dateopen"]
}, {
  k: "company",
  label: "Company name",
  exact: ["company", "name", "companyname", "security", "securityname", "stockname"],
  like: /company|securityname|stockname/
}, {
  k: "ticker",
  label: "Ticker (stock symbol)",
  need: true,
  exact: ["ticker", "symbol", "tickersymbol", "underlying", "underlyingsymbol", "sym", "stocksymbol", "root"],
  like: /ticker|symbol|underlying/
}, {
  k: "option",
  label: "Option (all in one, like AAPL 01/16/2026 150 P)",
  exact: ["option", "options", "optionsymbol", "optiondescription", "contract", "description", "optionname", "occsymbol"]
}, {
  k: "strike",
  label: "Strike price",
  need: true,
  exact: ["strike", "strikeprice", "strikes", "stk"],
  like: /strike/
}, {
  k: "currentStock",
  label: "Stock price",
  exact: ["currentstock", "stockprice", "stock", "currentprice", "underlyingprice", "priceofstock", "spot", "sharepricewhenopened"],
  like: /stockprice|currentstock|underlyingprice/
}, {
  k: "expDate",
  label: "Expiry date",
  need: true,
  exact: ["expdate", "exp", "expiry", "expiration", "expirationdate", "expirydate", "expires", "maturity", "expiration date"],
  like: /exp|matur/
}, {
  k: "sellPremium",
  label: "Premium",
  exact: ["prem", "premium", "sellprem", "sellpremium", "premiumpershare", "pricepershare", "price", "credit", "premiumreceived", "openprice", "fillprice", "tradeprice", "optionprice", "openingprice", "entryprice"],
  like: /prem|credit|proceeds|fillprice|tradeprice|openprice|entryprice/
}, {
  k: "contracts",
  label: "Contracts (quantity)",
  exact: ["qty", "quantity", "contracts", "contract", "noofcontracts", "numberofcontracts", "numcontracts", "lots", "shares", "size"],
  like: /qty|quant|contracts|lots/
}, {
  k: "cp",
  label: "Call or Put",
  exact: ["cp", "callput", "putcall", "pc", "type", "optiontype", "callorput", "putorcall", "right", "cpflag"],
  like: /callput|putcall|callorput|putorcall|optiontype/
}, {
  k: "sb",
  label: "Sell or Buy",
  exact: ["sb", "sellbuy", "buysell", "side", "bs", "sellorbuy", "buyorsell", "longshort", "shortlong", "direction"],
  like: /sellbuy|buysell|sellorbuy|buyorsell|side|longshort/
}, {
  k: "action",
  label: "Status",
  exact: ["action", "status", "result", "outcome", "closetype", "howclosed", "state", "disposition", "closeaction", "closedby"],
  like: /status|result|outcome|howclosed/
}, {
  k: "closeDate",
  label: "Close date",
  exact: ["closedate", "dateclosed", "closed", "closingdate", "exitdate", "dateexited", "closedon", "closeddate"],
  like: /clos.*date|date.*clos|exitdate/
}, {
  k: "closePremium",
  label: "Close amount",
  exact: ["closeprem", "closepremium", "closeprice", "closingprice", "closecost", "costtoclose", "buyback", "buybackcost", "buybackprice", "exitprice", "closeamount", "btcprice", "btccost"],
  like: /clos.*(prem|price|cost|amt|amount)|buyback|exitprice|btc/
}];
// Matched only when the heading is exactly this (OptionIQ's own ⬇ CSV files).
const IMP_HIDDEN = {
  sells: ["sells"],
  total: ["total"]
};
const impNorm = h => String(h || "").toLowerCase().replace(/[^a-z]/g, "");
const impCP = v => {
  const s = String(v || "").trim().toLowerCase();
  if (!s) return "";
  if (/^(c|call|calls|cl)$/.test(s) || s.startsWith("call")) return "C";
  if (/^(p|put|puts)$/.test(s) || s.startsWith("put")) return "P";
  return "";
};
const impSB = v => {
  const s = String(v || "").trim().toLowerCase().replace(/[^a-z]/g, "");
  if (!s) return "";
  if (/^(s|sell|sold|short|sto|selltoopen|sellopen|write|written|wrote|credit|so|sts)$/.test(s) || s.startsWith("sell")) return "S";
  if (/^(b|buy|bought|long|bto|buytoopen|buyopen|debit|bo)$/.test(s) || s.startsWith("buy")) return "B";
  // Broker wording such as "YOU SOLD OPENING TRANSACTION".
  if (/sold|sell|short|write/.test(s) && !/bought|buy/.test(s)) return "S";
  if (/bought|buy/.test(s) && !/sold|sell/.test(s)) return "B";
  return "";
};
const IMP_ACT = {
  open: "Open",
  opened: "Open",
  active: "Open",
  live: "Open",
  pending: "Open",
  expired: "Expired",
  exp: "Expired",
  expire: "Expired",
  expiredworthless: "Expired",
  worthless: "Expired",
  assigned: "Assigned",
  assign: "Assigned",
  assignment: "Assigned",
  exercised: "Assigned",
  putassigned: "Assigned",
  calledaway: "Called Away",
  called: "Called Away",
  callaway: "Called Away",
  callassigned: "Called Away",
  boughttoclose: "Bought to Close",
  btc: "Bought to Close",
  buytoclose: "Bought to Close",
  boughtback: "Bought to Close",
  buyback: "Bought to Close",
  soldtoclose: "Sold to Close",
  stc: "Sold to Close",
  selltoclose: "Sold to Close",
  rolled: "Rolled",
  roll: "Rolled",
  rolledover: "Rolled",
  rolledout: "Rolled"
};
// "Closed" says nothing about how: a sold option is closed by buying it back.
const impAction = (v, sb) => {
  const s = impNorm(v);
  if (!s) return "";
  if (IMP_ACT[s]) return IMP_ACT[s];
  if (/^(closed|close|closedout|closeout|done|exited|exit)$/.test(s)) return sb === "B" ? "Sold to Close" : "Bought to Close";
  if (/expire/.test(s)) return "Expired";
  if (/assign|exercis/.test(s)) return "Assigned";
  if (/opening|toopen/.test(s)) return "Open";
  if (/closing|toclose/.test(s)) return /sold|sell/.test(s) ? "Sold to Close" : "Bought to Close";
  return null;
};
const IMP_MON = {
  jan: 1,
  feb: 2,
  mar: 3,
  apr: 4,
  may: 5,
  jun: 6,
  jul: 7,
  aug: 8,
  sep: 9,
  sept: 9,
  oct: 10,
  nov: 11,
  dec: 12
};
const impDate = v => {
  const s = String(v || "").trim();
  if (!s) return "";
  const p2 = n => String(n).padStart(2, "0");
  const yy = y => y.length === 2 ? "20" + y : y;
  if (/^\d{5}(\.\d+)?$/.test(s)) {
    const n = parseFloat(s);
    if (n > 20000 && n < 80000) {
      const d = new Date(Date.UTC(1899, 11, 30) + Math.floor(n) * 864e5);
      return `${d.getUTCFullYear()}-${p2(d.getUTCMonth() + 1)}-${p2(d.getUTCDate())}`;
    }
  }
  let m = s.match(/^([A-Za-z]{3,4})[a-z]*\.?[\s-]+(\d{1,2})(?:st|nd|rd|th)?,?[\s-]+(\d{2}|\d{4})$/);
  if (m && IMP_MON[m[1].toLowerCase()]) return `${yy(m[3])}-${p2(IMP_MON[m[1].toLowerCase()])}-${p2(m[2])}`;
  m = s.match(/^(\d{1,2})[\s-]+([A-Za-z]{3,4})[a-z]*\.?[\s-]+(\d{2}|\d{4})$/);
  if (m && IMP_MON[m[2].toLowerCase()]) return `${yy(m[3])}-${p2(IMP_MON[m[2].toLowerCase()])}-${p2(m[1])}`;
  return csvDate(s);
};
// One cell that describes the whole option: "-AAPL260116P150" (Fidelity),
// "AAPL  260116P00150000" (OCC), "AAPL 01/16/2026 150 P",
// "PUT (AAPL) APPLE INC JAN 16 26 $150 (100 SHS)" and similar.
const impOpt = v => {
  const s = String(v || "").trim().toUpperCase();
  if (!s) return null;
  let m = s.match(/^-?\s*([A-Z][A-Z.]{0,5})\s*(\d{2})(\d{2})(\d{2})\s*([CP])\s*\$?(\d+(?:\.\d+)?)$/);
  if (m) {
    const k = m[6];
    const strike = k.length === 8 && !k.includes(".") ? parseInt(k, 10) / 1000 : parseFloat(k);
    return {
      ticker: m[1],
      expDate: `20${m[2]}-${m[3]}-${m[4]}`,
      cp: m[5],
      strike
    };
  }
  let rest = " " + s.replace(/\(\d+\s*SHS?\)/g, " ") + " ";
  const cpm = rest.match(/\b(CALL|PUT)S?\b/) || rest.match(/\s([CP])\s/);
  if (!cpm) return null;
  const cp = cpm[1][0];
  rest = rest.replace(cpm[0], " ");
  let ticker = "";
  const tp = rest.match(/\(([A-Z][A-Z.]{0,5})\)/);
  if (tp) {
    ticker = tp[1];
    rest = rest.replace(tp[0], " ");
  }
  let exp = "",
    dm;
  const dpats = [/\b\d{4}-\d{1,2}-\d{1,2}\b/, /\b\d{1,2}\/\d{1,2}\/\d{2,4}\b/, /\b[A-Z]{3,4}\.?\s+\d{1,2},?\s+\d{2,4}\b/, /\b\d{1,2}[\s-][A-Z]{3,4}[\s-]\d{2,4}\b/];
  for (const p of dpats) {
    dm = rest.match(p);
    if (dm) {
      exp = impDate(dm[0]);
      if (exp) {
        rest = rest.replace(dm[0], " ");
        break;
      }
    }
  }
  if (!exp) return null;
  const sm = rest.match(/\$\s*(\d+(?:\.\d+)?)/) || rest.match(/(?:^|\s)(\d+(?:\.\d+)?)(?=\s)/);
  if (!sm) return null;
  if (!ticker) {
    const tm = rest.trim().match(/^-?([A-Z][A-Z.]{0,5})\b/);
    if (tm) ticker = tm[1];
  }
  if (!ticker) return null;
  return {
    ticker,
    expDate: exp,
    cp,
    strike: parseFloat(sm[1])
  };
};
// CSV or tab-separated text into rows of cells (quotes and "" handled).
const impTable = text => {
  text = String(text || "").replace(/^﻿/, "");
  const sample = text.split(/\r?\n/).filter(l => l.trim()).slice(0, 10).join("\n");
  const cnt = c => sample.split(c).length;
  const d = [["\t", cnt("\t")], [",", cnt(",")], [";", cnt(";")]].sort((a, b) => b[1] - a[1])[0][0];
  const rows = [];
  let row = [],
    cur = "",
    q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          cur += '"';
          i++;
        } else q = false;
      } else cur += c;
      continue;
    }
    if (c === '"' && cur.trim() === "") {
      q = true;
      cur = "";
    } else if (c === d) {
      row.push(cur.trim());
      cur = "";
    } else if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(cur.trim());
      rows.push(row);
      row = [];
      cur = "";
    } else cur += c;
  }
  if (cur !== "" || row.length) {
    row.push(cur.trim());
    rows.push(row);
  }
  return rows.filter(r => r.some(v => v !== ""));
};
// Which row holds the headings: the one (near the top) with the most
// headings OptionIQ knows.
const impHeaderRow = rows => {
  const known = new Set(IMP_FIELDS.flatMap(f => f.exact).map(impNorm));
  let best = -1,
    bestN = 1;
  rows.slice(0, 25).forEach((r, i) => {
    const n = r.filter(c => known.has(impNorm(c))).length;
    if (n > bestN) {
      best = i;
      bestN = n;
    }
  });
  if (best >= 0) return best;
  const i = rows.slice(0, 25).findIndex(r => r.filter(c => c && isNaN(parseFloat(c))).length >= 3);
  return i < 0 ? 0 : i;
};
// First guess at which column is which: exact heading, then a heading that
// contains a telling word, then the values themselves (C/P, Sell/Buy, ...).
const impGuess = (heads, data) => {
  const H = heads.map(impNorm),
    used = new Set(),
    map = {};
  const take = (k, i) => {
    map[k] = i;
    if (i >= 0) used.add(i);
  };
  IMP_FIELDS.forEach(f => {
    const ex = f.exact.map(impNorm);
    take(f.k, H.findIndex((h, i) => !used.has(i) && h && ex.includes(h)));
  });
  // Fuzzy order matters: expiry and close before the plain date / premium.
  ["expDate", "closeDate", "closePremium", "strike", "currentStock", "account", "ticker", "company", "cp", "sb", "action", "contracts", "sellPremium"].forEach(k => {
    if (map[k] >= 0) return;
    const f = IMP_FIELDS.find(x => x.k === k);
    if (!f.like) return;
    take(k, H.findIndex((h, i) => !used.has(i) && h && f.like.test(h)));
  });
  if (map.date < 0) take("date", H.findIndex((h, i) => !used.has(i) && /date|opened|entry/.test(h)));
  const col = i => data.slice(0, 40).map(r => r[i] || "").filter(v => String(v).trim());
  const byValues = (k, test) => {
    if (map[k] >= 0) return;
    take(k, heads.findIndex((_, i) => {
      if (used.has(i)) return false;
      const vs = col(i);
      return vs.length > 0 && vs.filter(test).length >= vs.length * 0.8;
    }));
  };
  // Call/Put and Sell/Buy columns must say so ("Type" can mean "Margin").
  [["cp", impCP], ["sb", impSB]].forEach(([k, f]) => {
    if (map[k] < 0) return;
    const vs = col(map[k]);
    if (vs.length && vs.filter(v => f(v)).length < vs.length * 0.5) {
      used.delete(map[k]);
      map[k] = -1;
    }
  });
  // Number columns must hold numbers. A "Stock" column of tickers is the ticker.
  ["strike", "currentStock", "sellPremium", "contracts", "closePremium"].forEach(k => {
    if (map[k] < 0) return;
    const vs = col(map[k]);
    if (vs.length && vs.filter(v => csvNum(v) != null).length < vs.length * 0.5) {
      const i = map[k];
      map[k] = -1;
      used.delete(i);
      if (k === "currentStock" && map.ticker < 0 && vs.filter(v => /^[A-Za-z][A-Za-z.]{0,5}$/.test(String(v).trim())).length >= vs.length * 0.8) {
        map.ticker = i;
        used.add(i);
      }
    }
  });
  byValues("cp", v => !!impCP(v));
  byValues("sb", v => !!impSB(v));
  byValues("action", v => impAction(v, "S") !== null);
  // A "Status" or "Action" column that says "Sell to Open" also gives Sell or Buy.
  if (map.action >= 0 && map.sb < 0) {
    const vs = col(map.action);
    if (vs.length && vs.filter(v => impSB(v)).length >= vs.length * 0.8) map.sb = map.action;
  }
  if (map.ticker < 0 || map.strike < 0 || map.expDate < 0) byValues("option", v => !!impOpt(v));
  // A heading guessed as "option" that holds plain tickers is just the ticker.
  if (map.option >= 0 && !col(map.option).some(v => impOpt(v))) {
    if (map.ticker < 0) map.ticker = map.option;
    map.option = -1;
  }
  Object.entries(IMP_HIDDEN).forEach(([k, ex]) => {
    map[k] = H.findIndex((h, i) => !used.has(i) && ex.includes(h));
  });
  return map;
};
// The premium can be per share (1.25) or the whole trade in dollars (125):
// the heading may say so, else the numbers do (per share is rarely over 30).
const impPremTotal = (rows, hr, map) => {
  const i = map.sellPremium;
  if (i < 0) return false;
  const h = impNorm((rows[hr] || [])[i]);
  if (h === "prem" || /pershare|each/.test(h)) return false;
  if (/amount|total|proceeds|dollar|cash|net|value/.test(h)) return true;
  const per = rows.slice(hr + 1, hr + 61).map(r => {
    const p = csvNum(String(r[i] ?? ""));
    const q = map.contracts >= 0 ? Math.abs(csvNum(String(r[map.contracts] ?? "")) || 1) : 1;
    return p == null ? null : Math.abs(p) / q;
  }).filter(v => v != null && v > 0).sort((a, b) => a - b);
  return per.length > 0 && per[Math.floor(per.length / 2)] >= 30;
};
// A close column named "price" is per share; OptionIQ's own is dollars.
const impClosePerShare = h => /price|pershare|each/.test(impNorm(h)) && !/amount|total|cost|dollar/.test(impNorm(h));
const impBuild = (rows, hr, map, opt) => {
  const list = [],
    skipped = [],
    notes = {
      noCP: 0,
      badAct: {}
    };
  const g = (r, k) => map[k] >= 0 && map[k] < r.length ? String(r[map[k]] ?? "").trim() : "";
  // A close column with minus signs (like OptionIQ's own: -150 paid to buy
  // back) is taken as written. All-positive amounts get the sign from the
  // trade: paid out for a sold option, received for a bought one.
  const closeSigned = rows.slice(hr + 1).some(r => (csvNum(g(r, "closePremium")) || 0) < 0);
  for (let i = hr + 1; i < rows.length; i++) {
    const r = rows[i],
      rowNo = i + 1;
    if (!r.some(v => String(v).trim())) continue;
    let o = map.option >= 0 ? impOpt(g(r, "option")) : null;
    let rawT = g(r, "ticker");
    if (!o && /\d{6}[CP]/i.test(rawT)) o = impOpt(rawT);
    const ticker = (o && (!rawT || impOpt(rawT)) ? o.ticker : rawT).replace(/^-/, "").toUpperCase();
    if (!ticker) {
      skipped.push({
        row: rowNo,
        why: "no ticker"
      });
      continue;
    }
    if (/^(TOTAL|TOTALS|SUBTOTAL|GRANDTOTAL|SUM)$/.test(ticker.replace(/\s/g, ""))) {
      skipped.push({
        row: rowNo,
        why: "totals row"
      });
      continue;
    }
    if (!/^[A-Z][A-Z0-9.\-\/]{0,9}$/.test(ticker)) {
      skipped.push({
        row: rowNo,
        why: `"${rawT || ticker}" isn't a ticker`
      });
      continue;
    }
    const strikeN = map.strike >= 0 && g(r, "strike") ? csvNum(g(r, "strike")) : o ? o.strike : null;
    if (strikeN == null) {
      skipped.push({
        row: rowNo,
        why: "no strike price"
      });
      continue;
    }
    const expDate = map.expDate >= 0 && impDate(g(r, "expDate")) || (o ? o.expDate : "");
    if (!expDate) {
      skipped.push({
        row: rowNo,
        why: "no expiry date"
      });
      continue;
    }
    const qRaw = csvNum(g(r, "contracts"));
    const contracts = Math.max(1, Math.round(Math.abs(qRaw || 0)) || 1);
    const sb = impSB(g(r, "sb")) || (qRaw != null && qRaw < 0 ? "S" : "") || "S";
    let cp = impCP(g(r, "cp")) || (o ? o.cp : "");
    if (!cp) {
      cp = "P";
      notes.noCP++;
    }
    let prem = csvNum(g(r, "sellPremium"));
    if (prem != null) {
      prem = Math.abs(prem);
      if (opt.premTotal) prem = Math.round(prem / (contracts * 100) * 10000) / 10000;
    }
    const closeDate = impDate(g(r, "closeDate"));
    let closeRaw = csvNum(g(r, "closePremium")),
      closePremium = "";
    if (closeRaw != null) {
      let amt = Math.abs(closeRaw);
      if (opt.closePerShare) amt = amt * contracts * 100;
      amt = Math.round(amt * 100) / 100;
      closePremium = amt === 0 ? "0" : String(closeSigned ? closeRaw < 0 ? -amt : amt : sb === "S" ? -amt : amt);
    }
    let action = impAction(g(r, "action"), sb);
    if (action === null) {
      const t = g(r, "action");
      notes.badAct[t] = (notes.badAct[t] || 0) + 1;
      action = "";
    }
    if (!action) action = closeDate ? closePremium && closePremium !== "0" ? sb === "B" ? "Sold to Close" : "Bought to Close" : "Expired" : "Open";
    const sellPremium = prem;
    const sells = csvNum(g(r, "sells")) ?? calcSells(sb, sellPremium, contracts);
    const buys = calcBuys(sb, sellPremium, contracts);
    const total = csvNum(g(r, "total")) ?? sells + buys;
    const acctRaw = g(r, "account");
    const obj = {
      id: Date.now() + i + Math.random(),
      account: acctRaw ? csvAcct(acctRaw) : opt.acct,
      date: impDate(g(r, "date")),
      company: g(r, "company"),
      ticker,
      strike: String(strikeN),
      currentStock: csvNum(g(r, "currentStock"))?.toString() || "",
      expDate,
      sellPremium: sellPremium?.toString() || "",
      contracts: String(contracts),
      cp,
      sb,
      sells,
      buys,
      total,
      action,
      closeDate,
      closePremium,
      netPL: calcNetPL(total, closePremium, action),
      moneyOnHold: 0
    };
    obj.moneyOnHold = calcMOH(obj);
    list.push(obj);
  }
  return {
    list,
    skipped,
    notes
  };
};
const IMP_SAVED = "import_columns_v1";
const impSig = heads => heads.map(impNorm).join("|");
const impRecall = heads => {
  try {
    return JSON.parse(localStorage.getItem(IMP_SAVED) || "{}")[impSig(heads)] || null;
  } catch (e) {
    return null;
  }
};
const impRemember = (heads, choice) => {
  try {
    const all = JSON.parse(localStorage.getItem(IMP_SAVED) || "{}");
    all[impSig(heads)] = choice;
    localStorage.setItem(IMP_SAVED, JSON.stringify(all));
  } catch (e) {}
};
const sanitize = t => {
  const cp = (t.closePremium + "").replace(/[^0-9.\-]/g, "");
  const closePremium = isNaN(parseFloat(cp)) ? "" : cp;
  return {
    ...t,
    closePremium,
    netPL: calcNetPL(t.total, closePremium, t.action || "Open"),
    moneyOnHold: calcMOH({
      ...t,
      closePremium
    })
  };
};

// ── Excel helpers (module-level) ──────────────────────────
const XH = Object.fromEntries(ACCOUNTS.map((a, i) => [a, ["FF1F3864", "FF375623", "FF843C0C", "FF4472C4", "FF7030A0", "FF00707A", "FF9C5700", "FF4E6B1F", "FF833C8B", "FF9C2B2B"][i % 10]]));
const XB = Object.fromEntries(ACCOUNTS.map((a, i) => [a, ["FFDDEEFF", "FFDDFFDD", "FFFFE8CC", "FFE8E0F5", "FFF3E5FF", "FFDDF7F9", "FFFFF2CC", "FFEFF7DD", "FFF9E1F9", "FFFDE2E2"][i % 10]]));
const XA = {
  "Expired": {
    bg: "FFC6EFCE",
    fg: "FF375623"
  },
  "Rolled": {
    bg: "FFBDD7EE",
    fg: "FF1F497D"
  },
  "Assigned": {
    bg: "FFFFFFEB9C",
    fg: "FF9C5700"
  },
  "Bought to Close": {
    bg: "FFFCE4D6",
    fg: "FF843C0C"
  },
  "Sold to Close": {
    bg: "FFEDEDED",
    fg: "FF404040"
  },
  "Open": {
    bg: "FFE2EFDA",
    fg: "FF375623"
  }
};
const XD = {
  bg: "FFF2F2F2",
  fg: "FF404040"
};
const DK = "FF1F3864",
  WH = "FFFFFFFF",
  LG = "FFF2F2F2",
  A1 = "FF2E75B6",
  A2 = "FFED7D31",
  A3 = "FF70AD47",
  A4 = "FFFFC000";
const TN = {
  top: {
    style: "thin",
    color: {
      argb: "FFBFBFBF"
    }
  },
  bottom: {
    style: "thin",
    color: {
      argb: "FFBFBFBF"
    }
  },
  left: {
    style: "thin",
    color: {
      argb: "FFBFBFBF"
    }
  },
  right: {
    style: "thin",
    color: {
      argb: "FFBFBFBF"
    }
  }
};
const XCOLS = ["Account", "Date", "Company", "Ticker", "Strike", "Current Stock", "Exp Date", "Prem", "Qty", "C/P", "S/B", "Sells", "Total", "Action", "Close Date", "Close Prem", "Net P&L", "Money On Hold"];
const XWIDTHS = [12, 12, 42, 8, 8, 14, 12, 8, 5, 5, 5, 12, 12, 16, 12, 12, 12, 14];
const xf = a => ({
  type: "pattern",
  pattern: "solid",
  fgColor: {
    argb: a
  }
});
const xn = (a, sz = 10, bold = false) => ({
  name: "Arial",
  size: sz,
  bold,
  color: {
    argb: a
  }
});
const xa = (h = "center", wrap = false) => ({
  horizontal: h,
  vertical: "middle",
  wrapText: wrap
});
const xnum = v => {
  const f = parseFloat(String(v || "").replace(/,/g, ""));
  return isNaN(f) ? null : f;
};
function xsc(ws, r, c, val, bg, fg, o = {}) {
  const cell = ws.getCell(r, c);
  cell.value = val;
  cell.fill = xf(bg);
  cell.font = xn(fg, o.sz || 10, o.bold || false);
  cell.alignment = xa(o.h || "center", o.wrap || false);
  cell.border = TN;
  if (o.fmt) cell.numFmt = o.fmt;
  return cell;
}
const xhc = (ws, r, c, t, o = {}) => xsc(ws, r, c, t, o.bg || DK, o.fg || WH, {
  bold: true,
  sz: o.sz || 10,
  h: o.h || "center",
  wrap: o.wrap
});
function xAna(rows) {
  const cl = rows.filter(r => (r.Action || "") !== "Open"),
    op = rows.filter(r => (r.Action || "") === "Open");
  const pnls = cl.map(r => xnum(r["Net P&L"])).filter(v => v !== null);
  const wins = pnls.filter(v => v > 0),
    losses = pnls.filter(v => v <= 0);
  const sum = a => a.reduce((x, y) => x + y, 0);
  const tkP = {},
    tkT = {},
    acP = {},
    acC = {},
    moP = {};
  for (const r of cl) {
    const v = xnum(r["Net P&L"]),
      tk = (r.Ticker || "").trim(),
      ac = (r.Action || "").trim(),
      dt = (r.Date || "").trim();
    if (v !== null) {
      tkP[tk] = (tkP[tk] || 0) + v;
      tkT[tk] = (tkT[tk] || 0) + 1;
      acP[ac] = (acP[ac] || 0) + v;
      if (/^\d{4}-\d{2}-\d{2}/.test(dt)) {
        const mo = dt.slice(0, 7);
        moP[mo] = (moP[mo] || 0) + v;
      }
    }
    acC[ac] = (acC[ac] || 0) + 1;
  }
  return {
    totalPnl: sum(pnls),
    winRate: pnls.length ? wins.length / pnls.length * 100 : 0,
    avgWin: wins.length ? sum(wins) / wins.length : 0,
    avgLoss: losses.length ? sum(losses) / losses.length : 0,
    wins: wins.length,
    losses: losses.length,
    totalTrades: rows.length,
    closedTrades: cl.length,
    openTrades: op.length,
    best: pnls.length ? Math.max(...pnls) : 0,
    worst: pnls.length ? Math.min(...pnls) : 0,
    openValue: op.reduce((s, r) => s + (xnum(r.Total) || xnum(r.Sells) || 0), 0),
    tkP,
    tkT,
    acP,
    acC,
    moP
  };
}
function xWeeklyData(rows) {
  const m = {};
  rows.filter(r => (r.Action || "") !== "Open" && r["Net P&L"] != null && r["Net P&L"] !== "").forEach(r => {
    const v = xnum(r["Net P&L"]);
    if (v === null) return;
    const raw = r["Close Date"] || r["Date"];
    if (!raw) return;
    const d = new Date(raw + "T00:00:00");
    if (isNaN(d)) return;
    const day = d.getDay(),
      diffToFri = (5 - day + 7) % 7;
    const fri = new Date(d);
    fri.setDate(d.getDate() + diffToFri);
    const key = fri.toISOString().split("T")[0];
    m[key] = (m[key] || 0) + v;
  });
  const sorted = Object.entries(m).sort();
  let cum = 0;
  return sorted.map(([k, pl]) => {
    cum += pl;
    return {
      date: k,
      pl,
      cumulative: cum
    };
  });
}
function xBuildAcct(wb, acct, rows) {
  const ws = wb.addWorksheet(acct);
  ws.views = [{
    state: "frozen",
    ySplit: 2
  }];
  const hc = XH[acct] || DK;
  ws.mergeCells(1, 1, 1, XCOLS.length);
  xsc(ws, 1, 1, `${acct} — Options Trade Log`, hc, WH, {
    bold: true,
    sz: 14
  });
  ws.getRow(1).height = 26;
  XCOLS.forEach((h, i) => xhc(ws, 2, i + 1, h, {
    bg: hc,
    sz: 9,
    wrap: true
  }));
  ws.getRow(2).height = 20;
  rows.forEach((row, idx) => {
    const rn = idx + 3,
      action = (row.Action || "").trim();
    const {
      bg,
      fg
    } = XA[action] || XD;
    XCOLS.forEach((h, ci) => {
      let val = row[h] || "",
        fmt = null;
      if ([11, 12, 15, 16].includes(ci)) {
        const n = xnum(val);
        if (n !== null) {
          val = n;
          fmt = '#,##0.00;(#,##0.00);"-"';
        }
      }
      if (ci === 7) {
        const n = xnum(val);
        if (n !== null) {
          val = n;
          fmt = '#,##0.00';
        }
      }
      xsc(ws, rn, ci + 1, val, bg, fg, {
        sz: 9,
        h: ci === 2 ? "left" : "center",
        fmt
      });
    });
    ws.getRow(rn).height = 16;
  });
  XWIDTHS.forEach((w, i) => ws.getColumn(i + 1).width = w);
  if (rows.length > 0) ws.autoFilter = {
    from: {
      row: 2,
      column: 1
    },
    to: {
      row: rows.length + 2,
      column: XCOLS.length
    }
  };
}
function xBuildSummary(wb, byAcct, allRows) {
  const ws = wb.addWorksheet("Summary");
  ws.views = [{
    state: "frozen",
    ySplit: 3,
    showGridLines: false
  }];
  ws.mergeCells(1, 1, 1, 14);
  xsc(ws, 1, 1, "OptionIQ — Portfolio Summary", DK, WH, {
    bold: true,
    sz: 16
  });
  ws.getRow(1).height = 32;
  ws.mergeCells(2, 1, 2, 14);
  const sub = ws.getCell(2, 1);
  sub.value = `All Accounts  |  Generated ${new Date().toLocaleString()}`;
  sub.font = {
    name: "Arial",
    size: 10,
    color: {
      argb: "FF595959"
    },
    italic: true
  };
  sub.alignment = xa("center");
  ws.getRow(2).height = 18;
  let r = 4;
  ws.mergeCells(r, 1, r, 12);
  xhc(ws, r, 1, "ACCOUNT PERFORMANCE SUMMARY", {
    sz: 11
  });
  ws.getRow(r).height = 22;
  r++;
  ["Account", "Total Trades", "Closed", "Open", "Closed P&L ($)", "Open Premium ($)", "Combined P&L ($)", "Win Rate", "Avg Win ($)", "Avg Loss ($)", "Best Trade ($)", "Worst Trade ($)"].forEach((h, i) => xhc(ws, r, i + 1, h, {
    sz: 9
  }));
  ws.getRow(r).height = 18;
  r++;
  const allA = {};
  for (const acct of ACCOUNTS) {
    const rows = byAcct[acct] || [],
      a = xAna(rows);
    allA[acct] = a;
    const bg = XB[acct] || LG,
      hc = XH[acct] || DK,
      pc = a.totalPnl >= 0 ? "FF375623" : "FF843C0C",
      oc = "FF2E75B6",
      cc = a.totalPnl + (a.openValue || 0) >= 0 ? "FF375623" : "FF843C0C";
    xsc(ws, r, 1, acct, hc, WH, {
      bold: true,
      sz: 10
    });
    [[a.totalTrades, null, "FF404040"], [a.closedTrades, null, "FF404040"], [a.openTrades, null, "FF404040"], [a.totalPnl, '#,##0.00;(#,##0.00);"-"', pc], [a.openValue || 0, '#,##0.00;(#,##0.00);"-"', oc], [a.totalPnl + (a.openValue || 0), '#,##0.00;(#,##0.00);"-"', cc], [a.winRate / 100, "0.0%", "FF404040"], [a.avgWin, '#,##0.00;(#,##0.00);"-"', "FF375623"], [a.avgLoss, '#,##0.00;(#,##0.00);"-"', "FF843C0C"], [a.best, '#,##0.00;(#,##0.00);"-"', "FF375623"], [a.worst, '#,##0.00;(#,##0.00);"-"', "FF843C0C"]].forEach(([v, fmt, fg], i) => xsc(ws, r, i + 2, v, bg, fg, {
      fmt,
      bold: i === 3 || i === 5
    }));
    ws.getRow(r).height = 18;
    r++;
  }
  const sk = k => Object.values(allA).reduce((s, a) => s + a[k], 0);
  const tp = sk("totalPnl"),
    topv = sk("openValue");
  const clAll = allRows.filter(x => (x.Action || "") !== "Open");
  const wrAll = clAll.length ? clAll.filter(x => xnum(x["Net P&L"]) > 0).length / clAll.length : 0;
  ["PORTFOLIO TOTAL", sk("totalTrades"), sk("closedTrades"), sk("openTrades"), tp, topv, tp + topv, wrAll, "", "", "", ""].forEach((v, i) => {
    const c = ws.getCell(r, i + 1);
    c.value = v;
    c.fill = xf(DK);
    c.font = xn(WH, 10, true);
    c.alignment = xa("center");
    c.border = TN;
    if (i === 4 || i === 5 || i === 6) c.numFmt = '#,##0.00;(#,##0.00);"-"';
    if (i === 7) c.numFmt = "0.0%";
  });
  ws.getRow(r).height = 20;
  r += 2;
  ws.mergeCells(r, 1, r, 6);
  xhc(ws, r, 1, "TRADE ACTION BREAKDOWN", {
    bg: A1,
    sz: 10
  });
  ws.getRow(r).height = 20;
  r++;
  ["Action", "# Trades", "Net P&L ($)", "% of Closed", "Avg P&L ($)"].forEach((h, i) => xhc(ws, r, i + 1, h, {
    bg: A1,
    sz: 9
  }));
  ws.getRow(r).height = 16;
  r++;
  const cAP = {},
    cAC = {};
  for (const a of Object.values(allA)) {
    for (const [k, v] of Object.entries(a.acP)) cAP[k] = (cAP[k] || 0) + v;
    for (const [k, v] of Object.entries(a.acC)) cAC[k] = (cAC[k] || 0) + v;
  }
  const totCl = Object.entries(cAC).filter(([k]) => k !== "Open").reduce((s, [, v]) => s + v, 0);
  for (const act of ["Expired", "Bought to Close", "Rolled", "Assigned", "Sold to Close", "Open"]) {
    if (!cAC[act]) continue;
    const cnt = cAC[act],
      pnl = cAP[act] || 0,
      pct = act !== "Open" ? cnt / totCl : 0,
      avg = cnt ? pnl / cnt : 0;
    const {
      bg,
      fg
    } = XA[act] || XD;
    [act, cnt, pnl, pct, avg].forEach((v, i) => {
      const c = xsc(ws, r, i + 1, v, bg, fg, {
        sz: 9
      });
      if (i === 2 || i === 4) c.numFmt = '#,##0.00;(#,##0.00);"-"';
      if (i === 3) c.numFmt = "0.0%";
    });
    ws.getRow(r).height = 16;
    r++;
  }
  r++;
  ws.mergeCells(r, 1, r, 5);
  xhc(ws, r, 1, "TICKER PERFORMANCE BY ACCOUNT", {
    bg: A3,
    sz: 10
  });
  ws.getRow(r).height = 20;
  r++;
  for (const acct of ACCOUNTS) {
    const a = allA[acct];
    if (!a || !Object.keys(a.tkP).length) continue;
    const stk = Object.entries(a.tkP).sort(([, x], [, y]) => y - x);
    const hc = XH[acct] || DK;
    ws.mergeCells(r, 1, r, 5);
    xsc(ws, r, 1, acct, hc, WH, {
      bold: true,
      sz: 10,
      h: "left"
    });
    ws.getRow(r).height = 18;
    r++;
    ["Ticker", "# Trades", "Net P&L ($)", "Avg P&L ($)", "Bar"].forEach((h, i) => xhc(ws, r, i + 1, h, {
      bg: A3,
      sz: 9
    }));
    ws.getRow(r).height = 16;
    r++;
    for (const [tk, pnl] of stk) {
      const cnt = a.tkT[tk] || 1,
        avg = pnl / cnt;
      const b2 = pnl >= 0 ? "FFC6EFCE" : "FFFCE4D6",
        f2 = pnl >= 0 ? "FF375623" : "FF843C0C";
      const bar = "█".repeat(Math.min(Math.round(Math.abs(pnl) / 500), 20));
      [tk, cnt, pnl, avg, bar].forEach((v, i) => {
        const c = xsc(ws, r, i + 1, v, b2, f2, {
          sz: 9,
          h: i === 4 ? "left" : "center"
        });
        if (i === 2 || i === 3) c.numFmt = '#,##0.00;(#,##0.00);"-"';
      });
      ws.getRow(r).height = 16;
      r++;
    }
    const tot = stk.reduce((s, [, v]) => s + v, 0),
      totTr = Object.values(a.tkT).reduce((s, v) => s + v, 0);
    [`${acct} Total`, totTr, tot, "", ""].forEach((v, i) => {
      const c = xsc(ws, r, i + 1, v, hc, WH, {
        bold: true,
        sz: 9,
        h: i === 0 ? "left" : "center"
      });
      if (i === 2) c.numFmt = '#,##0.00;(#,##0.00);"-"';
    });
    ws.getRow(r).height = 16;
    r += 2;
  }
  r++;
  ws.mergeCells(r, 1, r, 4);
  xhc(ws, r, 1, "MONTHLY P&L BY ACCOUNT", {
    bg: A2,
    fg: WH,
    sz: 10
  });
  ws.getRow(r).height = 20;
  r++;
  for (const acct of ACCOUNTS) {
    const a = allA[acct];
    if (!a || !Object.keys(a.moP).length) continue;
    const hc = XH[acct] || DK;
    ws.mergeCells(r, 1, r, 4);
    xsc(ws, r, 1, acct, hc, WH, {
      bold: true,
      sz: 10,
      h: "left"
    });
    ws.getRow(r).height = 18;
    r++;
    ["Month", "Net P&L ($)", "Cumulative P&L ($)", "Performance"].forEach((h, i) => xhc(ws, r, i + 1, h, {
      bg: A2,
      fg: WH,
      sz: 9
    }));
    ws.getRow(r).height = 16;
    r++;
    let cumul = 0;
    for (const [mo, pnl] of Object.entries(a.moP).sort()) {
      cumul += pnl;
      const b3 = pnl >= 0 ? "FFC6EFCE" : "FFFCE4D6",
        f3 = pnl >= 0 ? "FF375623" : "FF843C0C";
      const bar = (pnl >= 0 ? "▲ " : "▼ ") + "█".repeat(Math.min(Math.round(Math.abs(pnl) / 300), 25));
      [mo, pnl, cumul, bar].forEach((v, i) => {
        const c = xsc(ws, r, i + 1, v, i === 0 ? LG : b3, i === 0 ? "FF404040" : f3, {
          sz: 9,
          h: i === 3 ? "left" : "center"
        });
        if (i === 1 || i === 2) c.numFmt = '#,##0.00;(#,##0.00);"-"';
      });
      ws.getRow(r).height = 16;
      r++;
    }
    const tot = Object.values(a.moP).reduce((s, v) => s + v, 0);
    [`${acct} Total`, "", tot, ""].forEach((v, i) => {
      const c = xsc(ws, r, i + 1, v, hc, WH, {
        bold: true,
        sz: 9,
        h: i === 0 ? "left" : "center"
      });
      if (i === 2) c.numFmt = '#,##0.00;(#,##0.00);"-"';
    });
    ws.getRow(r).height = 16;
    r += 2;
  }
  r++;
  ws.mergeCells(r, 1, r, 8);
  xhc(ws, r, 1, "OPEN POSITIONS", {
    bg: A4,
    fg: "FF404040",
    sz: 10
  });
  ws.getRow(r).height = 20;
  r++;
  ["Account", "Ticker", "C/P", "Strike", "Current Stock", "Exp Date", "Premium ($)", "Money On Hold ($)"].forEach((h, i) => xhc(ws, r, i + 1, h, {
    bg: A4,
    fg: "FF404040",
    sz: 9
  }));
  ws.getRow(r).height = 16;
  r++;
  for (const acct of ACCOUNTS) {
    const acctRows = allRows.filter(row => (row.Action || "") === "Open" && (row.Account || "") === acct);
    if (!acctRows.length) continue;
    const hc = XH[acct] || DK,
      bg4 = XB[acct] || LG;
    let totP = 0,
      totH = 0;
    for (const row of acctRows) {
      const sell = xnum(row.Sells),
        prem = sell && sell !== 0 ? sell : 0,
        hold = xnum(row["Money On Hold"]) || 0;
      totP += prem;
      totH += hold;
      const strikeN = xnum(row.Strike),
        stockN = xnum(row["Current Stock"]),
        cp = (row["C/P"] || "").trim().toUpperCase();
      const itm = strikeN != null && stockN != null && (cp === "C" && stockN > strikeN || cp === "P" && stockN < strikeN);
      const rowBg = itm ? "FFFCE4D6" : bg4,
        rowFg = itm ? "FF9C0006" : "FF404040";
      [acct, row.Ticker || "", row["C/P"] || "", row.Strike || "", row["Current Stock"] || "", row["Exp Date"] || "", prem, hold || ""].forEach((v, i) => {
        const c = xsc(ws, r, i + 1, v, i === 0 ? hc : rowBg, i === 0 ? WH : rowFg, {
          sz: 9,
          bold: i === 0 || itm
        });
        if ((i === 6 || i === 7) && typeof v === "number" && v !== 0) c.numFmt = '#,##0.00;(#,##0.00);"-"';
      });
      ws.getRow(r).height = 16;
      r++;
    }
    [`${acct} Subtotal (${acctRows.length})`, "", "", "", "", "", totP, totH || ""].forEach((v, i) => {
      const c = xsc(ws, r, i + 1, v, hc, WH, {
        bold: true,
        sz: 9,
        h: i === 0 ? "left" : "center"
      });
      if ((i === 6 || i === 7) && typeof v === "number") c.numFmt = '#,##0.00;(#,##0.00);"-"';
    });
    ws.getRow(r).height = 18;
    r++;
  }
  r++;
  const assignRows = allRows.filter(row => {
    if ((row.Action || "") !== "Open") return false;
    const strikeN = xnum(row.Strike),
      stockN = xnum(row["Current Stock"]);
    const cp = (row["C/P"] || "").trim().toUpperCase();
    if (strikeN == null || stockN == null) return false;
    return cp === "C" && stockN > strikeN || cp === "P" && stockN < strikeN;
  });
  const assignPuts = assignRows.filter(row => (row["C/P"] || "").trim().toUpperCase() === "P");
  const assignCalls = assignRows.filter(row => (row["C/P"] || "").trim().toUpperCase() === "C");
  const ASSIGN_RED = "FFC00000",
    ASSIGN_BG = "FFFCE4D6";
  ws.mergeCells(r, 1, r, 8);
  xhc(ws, r, 1, "POTENTIALLY ASSIGNABLE POSITIONS (ITM)", {
    bg: ASSIGN_RED,
    sz: 11
  });
  ws.getRow(r).height = 22;
  r++;
  ws.mergeCells(r, 1, r, 8);
  const noteC = ws.getCell(r, 1);
  noteC.value = "Puts: Strike > Current Stock Price   |   Calls: Strike < Current Stock Price";
  noteC.font = {
    name: "Arial",
    size: 9,
    italic: true,
    color: {
      argb: "FF595959"
    }
  };
  noteC.alignment = xa("center");
  ws.getRow(r).height = 16;
  r++;
  const buildAssignSubtable = (title, rowsSub, accentBg, showMoneyRequired) => {
    ws.mergeCells(r, 1, r, 8);
    xsc(ws, r, 1, title + ` (${rowsSub.length})`, accentBg, WH, {
      bold: true,
      sz: 10,
      h: "left"
    });
    for (let c = 2; c <= 8; c++) xsc(ws, r, c, "", accentBg, WH, {});
    ws.getRow(r).height = 18;
    r++;
    if (!rowsSub.length) {
      ws.mergeCells(r, 1, r, 8);
      const c = ws.getCell(r, 1);
      c.value = "None currently ITM";
      c.font = {
        name: "Arial",
        size: 9,
        italic: true,
        color: {
          argb: "FF9CA3AF"
        }
      };
      c.fill = xf("FFF2F2F2");
      c.alignment = xa("center");
      c.border = TN;
      ws.getRow(r).height = 16;
      r++;
      r++;
      return;
    }
    ["Account", "Ticker", "Strike", "Current Stock", "Diff ($)", "Exp Date", "Premium ($)", "Money On Hold ($)"].forEach((h, i) => xhc(ws, r, i + 1, h, {
      bg: accentBg,
      sz: 9
    }));
    ws.getRow(r).height = 16;
    r++;
    const sorted = [...rowsSub].sort((a, b) => (a["Exp Date"] || "").localeCompare(b["Exp Date"] || ""));
    let moneyRequiredTotal = 0;
    for (const row of sorted) {
      const strikeN = xnum(row.Strike),
        stockN = xnum(row["Current Stock"]),
        sell = xnum(row.Sells),
        prem = sell && sell !== 0 ? sell : 0,
        hold = xnum(row["Money On Hold"]) || 0;
      const diff = strikeN != null && stockN != null ? strikeN - stockN : null;
      const qty = xnum(row.Qty) || 1;
      if (strikeN != null) moneyRequiredTotal += qty * strikeN * 100;
      [row.Account || "", row.Ticker || "", row.Strike || "", row["Current Stock"] || "", diff, row["Exp Date"] || "", prem, hold || ""].forEach((v, i) => {
        const c = xsc(ws, r, i + 1, v, ASSIGN_BG, "FF9C0006", {
          sz: 9,
          bold: i === 4
        });
        if (i === 4 && typeof v === "number") c.numFmt = '#,##0.00;(#,##0.00);"-"';
        if ((i === 6 || i === 7) && typeof v === "number" && v !== 0) c.numFmt = '#,##0.00;(#,##0.00);"-"';
      });
      ws.getRow(r).height = 16;
      r++;
    }
    if (showMoneyRequired) {
      ws.mergeCells(r, 1, r, 4);
      const lbl = ws.getCell(r, 1);
      lbl.value = "💰 Total Money Required for Assignment";
      lbl.font = {
        name: "Arial",
        size: 10,
        bold: true,
        color: {
          argb: WH
        }
      };
      lbl.fill = xf("FFED7D31");
      lbl.alignment = xa("left");
      lbl.border = TN;
      for (let c = 2; c <= 4; c++) {
        const cc = ws.getCell(r, c);
        cc.fill = xf("FFED7D31");
        cc.border = TN;
      }
      const valC = xsc(ws, r, 5, moneyRequiredTotal, "FFED7D31", WH, {
        bold: true,
        sz: 11,
        fmt: '#,##0.00;(#,##0.00);"-"'
      });
      for (let c = 6; c <= 8; c++) {
        const cc = ws.getCell(r, c);
        cc.fill = xf("FFED7D31");
        cc.border = TN;
      }
      ws.getRow(r).height = 20;
      r++;
    }
    r++;
  };
  buildAssignSubtable("PUTS — Potentially Assignable", assignPuts, "FF9C0006", true);
  buildAssignSubtable("CALLS — Potentially Assignable", assignCalls, "FF1F497D", false);
  [18, 14, 10, 12, 14, 12, 14, 14, 14, 14, 12, 12, 12, 14].forEach((w, i) => ws.getColumn(i + 1).width = w);
}
function xBuildWeekly(wb, byAcct, allRows) {
  const ws = wb.addWorksheet("Weekly P&L");
  ws.views = [{
    state: "frozen",
    ySplit: 2
  }];
  ws.mergeCells(1, 1, 1, 5 + ACCOUNTS.length * 2);
  xsc(ws, 1, 1, "Weekly P&L — Bars & Cumulative (Friday close)", DK, WH, {
    bold: true,
    sz: 14
  });
  ws.getRow(1).height = 26;
  let r = 2;
  const portfolioWeekly = xWeeklyData(allRows);
  const headers = ["Week Ending (Fri)", "Portfolio Weekly ($)", "Portfolio Cumulative ($)", "Weekly Bar", "Cumulative Bar"];
  headers.forEach((h, i) => xhc(ws, r, i + 1, h, {
    bg: A3,
    sz: 9
  }));
  ws.getRow(r).height = 16;
  r++;
  const maxAbs = Math.max(1, ...portfolioWeekly.map(w => Math.abs(w.pl)));
  const maxCum = Math.max(1, ...portfolioWeekly.map(w => Math.abs(w.cumulative)));
  for (const w of portfolioWeekly) {
    const bg = w.pl >= 0 ? "FFC6EFCE" : "FFFCE4D6",
      fg = w.pl >= 0 ? "FF375623" : "FF843C0C";
    const cumBg = w.cumulative >= 0 ? "FFDDEEFF" : "FFFCE4D6",
      cumFg = w.cumulative >= 0 ? "FF1F497D" : "FF843C0C";
    const wbar = (w.pl >= 0 ? "▲" : "▼") + " " + "█".repeat(Math.min(Math.round(Math.abs(w.pl) / maxAbs * 20), 20));
    const cbar = (w.cumulative >= 0 ? "▲" : "▼") + " " + "█".repeat(Math.min(Math.round(Math.abs(w.cumulative) / maxCum * 20), 20));
    xsc(ws, r, 1, w.date, LG, "FF404040", {
      sz: 9
    });
    const c1 = xsc(ws, r, 2, w.pl, bg, fg, {
      sz: 9,
      bold: true
    });
    c1.numFmt = '#,##0.00;(#,##0.00);"-"';
    const c2 = xsc(ws, r, 3, w.cumulative, cumBg, cumFg, {
      sz: 9,
      bold: true
    });
    c2.numFmt = '#,##0.00;(#,##0.00);"-"';
    xsc(ws, r, 4, wbar, bg, fg, {
      sz: 9,
      h: "left"
    });
    xsc(ws, r, 5, cbar, cumBg, cumFg, {
      sz: 9,
      h: "left"
    });
    ws.getRow(r).height = 15;
    r++;
  }
  r++;
  for (const acct of ACCOUNTS) {
    const wk = xWeeklyData(byAcct[acct] || []);
    if (!wk.length) continue;
    const hc = XH[acct] || DK;
    ws.mergeCells(r, 1, r, 5);
    xsc(ws, r, 1, `${acct} — Weekly P&L`, hc, WH, {
      bold: true,
      sz: 10,
      h: "left"
    });
    ws.getRow(r).height = 18;
    r++;
    ["Week Ending (Fri)", "Weekly ($)", "Cumulative ($)", "Weekly Bar", "Cumulative Bar"].forEach((h, i) => xhc(ws, r, i + 1, h, {
      bg: hc,
      sz: 9
    }));
    ws.getRow(r).height = 16;
    r++;
    const mA = Math.max(1, ...wk.map(w => Math.abs(w.pl))),
      mC = Math.max(1, ...wk.map(w => Math.abs(w.cumulative)));
    for (const w of wk) {
      const bg = w.pl >= 0 ? "FFC6EFCE" : "FFFCE4D6",
        fg = w.pl >= 0 ? "FF375623" : "FF843C0C";
      const cumBg = w.cumulative >= 0 ? "FFDDEEFF" : "FFFCE4D6",
        cumFg = w.cumulative >= 0 ? "FF1F497D" : "FF843C0C";
      const wbar = (w.pl >= 0 ? "▲" : "▼") + " " + "█".repeat(Math.min(Math.round(Math.abs(w.pl) / mA * 15), 15));
      const cbar = (w.cumulative >= 0 ? "▲" : "▼") + " " + "█".repeat(Math.min(Math.round(Math.abs(w.cumulative) / mC * 15), 15));
      xsc(ws, r, 1, w.date, LG, "FF404040", {
        sz: 9
      });
      const c1 = xsc(ws, r, 2, w.pl, bg, fg, {
        sz: 9
      });
      c1.numFmt = '#,##0.00;(#,##0.00);"-"';
      const c2 = xsc(ws, r, 3, w.cumulative, cumBg, cumFg, {
        sz: 9
      });
      c2.numFmt = '#,##0.00;(#,##0.00);"-"';
      xsc(ws, r, 4, wbar, bg, fg, {
        sz: 9,
        h: "left"
      });
      xsc(ws, r, 5, cbar, cumBg, cumFg, {
        sz: 9,
        h: "left"
      });
      ws.getRow(r).height = 15;
      r++;
    }
    r++;
  }
  [16, 16, 18, 28, 28].forEach((w, i) => ws.getColumn(i + 1).width = w);
}
function xPremiumWeeklyData(rows) {
  const m = {};
  // Every row, not just sold ones, and Total rather than Sells — Total already
  // nets the debit paid on a bought contract, so the exported sheet agrees with
  // what the app shows on screen.
  rows.forEach(r => {
    const sellsVal = xnum(r.Total);
    if (sellsVal === null || sellsVal === 0) return;
    const raw = r.Date;
    if (!raw) return;
    const d = new Date(raw + "T00:00:00");
    if (isNaN(d)) return;
    const day = d.getDay(),
      diffToFri = (5 - day + 7) % 7;
    const fri = new Date(d);
    fri.setDate(d.getDate() + diffToFri);
    const key = fri.toISOString().split("T")[0];
    const cp = (r["C/P"] || "").trim().toUpperCase();
    if (!m[key]) m[key] = {
      puts: 0,
      calls: 0
    };
    if (cp === "P") m[key].puts += sellsVal;else if (cp === "C") m[key].calls += sellsVal;
  });
  return Object.entries(m).sort().map(([date, v]) => ({
    date,
    puts: v.puts,
    calls: v.calls,
    total: v.puts + v.calls
  }));
}
function xBuildPremiumWeekly(wb, byAcct, allRows) {
  const ws = wb.addWorksheet("Weekly Premium");
  ws.views = [{
    state: "frozen",
    ySplit: 2
  }];
  ws.mergeCells(1, 1, 1, 6);
  xsc(ws, 1, 1, "Weekly Premium Collected — Puts vs Calls (Open Date, Friday close)", DK, WH, {
    bold: true,
    sz: 14
  });
  ws.getRow(1).height = 26;
  let r = 2;
  const PREM_HDR_BG = "FF2E7D32";
  const portfolioPrem = xPremiumWeeklyData(allRows);
  ["Week Ending (Fri)", "Puts Premium ($)", "Calls Premium ($)", "Total Premium ($)", "Puts Bar", "Calls Bar"].forEach((h, i) => xhc(ws, r, i + 1, h, {
    bg: PREM_HDR_BG,
    sz: 9
  }));
  ws.getRow(r).height = 16;
  r++;
  const maxP = Math.max(1, ...portfolioPrem.map(w => w.puts));
  const maxC = Math.max(1, ...portfolioPrem.map(w => w.calls));
  let portfolioTotal = 0;
  for (const w of portfolioPrem) {
    portfolioTotal += w.total;
    const putsBar = "█".repeat(Math.min(Math.round(w.puts / maxP * 20), 20));
    const callsBar = "█".repeat(Math.min(Math.round(w.calls / maxC * 20), 20));
    xsc(ws, r, 1, w.date, LG, "FF404040", {
      sz: 9
    });
    const c1 = xsc(ws, r, 2, w.puts, "FFE5DEFF", "FF5B21B6", {
      sz: 9,
      bold: true
    });
    c1.numFmt = '#,##0.00;(#,##0.00);"-"';
    const c2 = xsc(ws, r, 3, w.calls, "FFDDEEFF", "FF1F497D", {
      sz: 9,
      bold: true
    });
    c2.numFmt = '#,##0.00;(#,##0.00);"-"';
    const c3 = xsc(ws, r, 4, w.total, "FFC6EFCE", "FF375623", {
      sz: 9,
      bold: true
    });
    c3.numFmt = '#,##0.00;(#,##0.00);"-"';
    xsc(ws, r, 5, putsBar, "FFE5DEFF", "FF5B21B6", {
      sz: 9,
      h: "left"
    });
    xsc(ws, r, 6, callsBar, "FFDDEEFF", "FF1F497D", {
      sz: 9,
      h: "left"
    });
    ws.getRow(r).height = 15;
    r++;
  }
  const totC = ws.getCell(r, 1);
  totC.value = "PORTFOLIO TOTAL";
  totC.font = xn(WH, 10, true);
  totC.fill = xf(DK);
  totC.alignment = xa("left");
  totC.border = TN;
  const tp = ws.getCell(r, 2);
  tp.value = portfolioPrem.reduce((s, w) => s + w.puts, 0);
  tp.numFmt = '#,##0.00;(#,##0.00);"-"';
  tp.font = xn(WH, 10, true);
  tp.fill = xf(DK);
  tp.alignment = xa("center");
  tp.border = TN;
  const tc = ws.getCell(r, 3);
  tc.value = portfolioPrem.reduce((s, w) => s + w.calls, 0);
  tc.numFmt = '#,##0.00;(#,##0.00);"-"';
  tc.font = xn(WH, 10, true);
  tc.fill = xf(DK);
  tc.alignment = xa("center");
  tc.border = TN;
  const tt = ws.getCell(r, 4);
  tt.value = portfolioTotal;
  tt.numFmt = '#,##0.00;(#,##0.00);"-"';
  tt.font = xn(WH, 10, true);
  tt.fill = xf(DK);
  tt.alignment = xa("center");
  tt.border = TN;
  for (const c of [5, 6]) {
    const cc = ws.getCell(r, c);
    cc.fill = xf(DK);
    cc.border = TN;
  }
  ws.getRow(r).height = 18;
  r += 2;
  for (const acct of ACCOUNTS) {
    const wk = xPremiumWeeklyData(byAcct[acct] || []);
    if (!wk.length) continue;
    const hc = XH[acct] || DK;
    ws.mergeCells(r, 1, r, 6);
    xsc(ws, r, 1, `${acct} — Weekly Premium Collected`, hc, WH, {
      bold: true,
      sz: 10,
      h: "left"
    });
    ws.getRow(r).height = 18;
    r++;
    ["Week Ending (Fri)", "Puts Premium ($)", "Calls Premium ($)", "Total Premium ($)", "Puts Bar", "Calls Bar"].forEach((h, i) => xhc(ws, r, i + 1, h, {
      bg: hc,
      sz: 9
    }));
    ws.getRow(r).height = 16;
    r++;
    const mP = Math.max(1, ...wk.map(w => w.puts)),
      mC2 = Math.max(1, ...wk.map(w => w.calls));
    let acctTotal = 0;
    for (const w of wk) {
      acctTotal += w.total;
      const putsBar = "█".repeat(Math.min(Math.round(w.puts / mP * 15), 15));
      const callsBar = "█".repeat(Math.min(Math.round(w.calls / mC2 * 15), 15));
      xsc(ws, r, 1, w.date, LG, "FF404040", {
        sz: 9
      });
      const c1 = xsc(ws, r, 2, w.puts, "FFE5DEFF", "FF5B21B6", {
        sz: 9
      });
      c1.numFmt = '#,##0.00;(#,##0.00);"-"';
      const c2 = xsc(ws, r, 3, w.calls, "FFDDEEFF", "FF1F497D", {
        sz: 9
      });
      c2.numFmt = '#,##0.00;(#,##0.00);"-"';
      const c3 = xsc(ws, r, 4, w.total, "FFC6EFCE", "FF375623", {
        sz: 9
      });
      c3.numFmt = '#,##0.00;(#,##0.00);"-"';
      xsc(ws, r, 5, putsBar, "FFE5DEFF", "FF5B21B6", {
        sz: 9,
        h: "left"
      });
      xsc(ws, r, 6, callsBar, "FFDDEEFF", "FF1F497D", {
        sz: 9,
        h: "left"
      });
      ws.getRow(r).height = 15;
      r++;
    }
    [`${acct} Total`, "", "", acctTotal, "", ""].forEach((v, i) => {
      const c = xsc(ws, r, i + 1, v, hc, WH, {
        bold: true,
        sz: 9,
        h: i === 0 ? "left" : "center"
      });
      if (i === 3) c.numFmt = '#,##0.00;(#,##0.00);"-"';
    });
    ws.getRow(r).height = 16;
    r += 2;
  }
  [16, 16, 16, 16, 26, 26].forEach((w, i) => ws.getColumn(i + 1).width = w);
}
const SCOLS = ["Ticker", "Company", "Shares", "Date Acquired", "Cost Basis", "Cost Value", "Status", "Current Price", "Sold Date", "Sold Price", "Market/Sold Value", "Net Gain/Loss", "% Gain/Loss"];
const SWIDTHS = [8, 30, 8, 12, 10, 12, 9, 11, 12, 11, 14, 14, 11];
function xStockGL(s) {
  const shares = parseFloat(s.shares) || 0,
    cb = parseFloat(s.costBasis) || 0;
  const refPrice = s.status === "Sold" ? parseFloat(s.soldPrice) || 0 : parseFloat(s.currentPrice) || 0;
  if (!shares || !cb) return null;
  return (refPrice - cb) * shares;
}
function xStockValue(s) {
  const shares = parseFloat(s.shares) || 0;
  const refPrice = s.status === "Sold" ? parseFloat(s.soldPrice) || 0 : parseFloat(s.currentPrice) || 0;
  return shares * refPrice;
}
function xStockCostValue(s) {
  return (parseFloat(s.shares) || 0) * (parseFloat(s.costBasis) || 0);
}
function xBuildStockAcct(wb, acct, rows) {
  const ws = wb.addWorksheet(acct + " Stocks");
  ws.views = [{
    state: "frozen",
    ySplit: 2
  }];
  const hc = XH[acct] || DK;
  ws.mergeCells(1, 1, 1, SCOLS.length);
  xsc(ws, 1, 1, `${acct} — Stock Holdings`, hc, WH, {
    bold: true,
    sz: 14
  });
  ws.getRow(1).height = 26;
  SCOLS.forEach((h, i) => xhc(ws, 2, i + 1, h, {
    bg: hc,
    sz: 9,
    wrap: true
  }));
  ws.getRow(2).height = 20;
  rows.forEach((s, idx) => {
    const rn = idx + 3,
      sold = s.status === "Sold";
    const gl = xStockGL(s),
      cv = xStockCostValue(s),
      mv = xStockValue(s);
    const glPct = cv > 0 && gl != null ? gl / cv * 100 : null;
    const bg = sold ? gl >= 0 ? "FFDDEEFF" : "FFFCE4D6" : s.status === "Assigned" ? gl >= 0 ? "FFE5DEFF" : "FFFCE4D6" : gl >= 0 ? "FFC6EFCE" : gl < 0 ? "FFFCE4D6" : "FFF2F2F2";
    const fg = sold ? gl >= 0 ? "FF1F497D" : "FF843C0C" : s.status === "Assigned" ? gl >= 0 ? "FF5B21B6" : "FF843C0C" : gl >= 0 ? "FF375623" : gl < 0 ? "FF843C0C" : "FF404040";
    const vals = [s.ticker || "", s.company || "", s.shares || "", s.dateAcquired || "", xnum(s.costBasis), cv, s.status || "Held", sold ? "" : xnum(s.currentPrice), sold ? s.soldDate || "" : "", sold ? xnum(s.soldPrice) : "", mv, gl, glPct != null ? glPct / 100 : ""];
    vals.forEach((v, ci) => {
      let fmt = null;
      if ([4, 5, 7, 9, 10, 11].includes(ci) && typeof v === "number") fmt = '#,##0.00;(#,##0.00);"-"';
      if (ci === 12 && v !== "") fmt = "0.0%";
      xsc(ws, rn, ci + 1, v, bg, fg, {
        sz: 9,
        h: ci === 1 ? "left" : "center",
        fmt,
        bold: ci === 11
      });
    });
    ws.getRow(rn).height = 16;
  });
  SWIDTHS.forEach((w, i) => ws.getColumn(i + 1).width = w);
  if (rows.length > 0) ws.autoFilter = {
    from: {
      row: 2,
      column: 1
    },
    to: {
      row: rows.length + 2,
      column: SCOLS.length
    }
  };
}
function xStockAnalytics(rows) {
  const held = rows.filter(s => s.status !== "Sold"),
    sold = rows.filter(s => s.status === "Sold");
  const heldGL = held.reduce((a, s) => a + (xStockGL(s) || 0), 0);
  const soldGL = sold.reduce((a, s) => a + (xStockGL(s) || 0), 0);
  const heldValue = held.reduce((a, s) => a + xStockValue(s), 0);
  const heldCost = held.reduce((a, s) => a + xStockCostValue(s), 0);
  const winsS = sold.filter(s => (xStockGL(s) || 0) > 0).length;
  const tkGL = {},
    tkSh = {};
  for (const s of rows) {
    const tk = s.ticker || "";
    const gl = xStockGL(s);
    if (gl != null) {
      tkGL[tk] = (tkGL[tk] || 0) + gl;
    }
    tkSh[tk] = (tkSh[tk] || 0) + (parseFloat(s.shares) || 0);
  }
  return {
    heldCount: held.length,
    soldCount: sold.length,
    heldGL,
    soldGL,
    heldValue,
    heldCost,
    winRate: sold.length ? winsS / sold.length * 100 : 0,
    tkGL,
    tkSh
  };
}
function xBuildStockAnalytics(wb, byAcctStocks, allStocks) {
  const ws = wb.addWorksheet("Stock Analytics");
  ws.views = [{
    state: "frozen",
    ySplit: 3,
    showGridLines: false
  }];
  ws.mergeCells(1, 1, 1, 12);
  xsc(ws, 1, 1, "Stock Holdings — Portfolio Analytics", DK, WH, {
    bold: true,
    sz: 16
  });
  ws.getRow(1).height = 32;
  ws.mergeCells(2, 1, 2, 12);
  const sub = ws.getCell(2, 1);
  sub.value = `All Accounts  |  Generated ${new Date().toLocaleString()}`;
  sub.font = {
    name: "Arial",
    size: 10,
    color: {
      argb: "FF595959"
    },
    italic: true
  };
  sub.alignment = xa("center");
  ws.getRow(2).height = 18;
  let r = 4;
  ws.mergeCells(r, 1, r, 10);
  xhc(ws, r, 1, "ACCOUNT PERFORMANCE SUMMARY", {
    sz: 11
  });
  ws.getRow(r).height = 22;
  r++;
  ["Account", "Held Positions", "Sold Positions", "Cost Value (Held)", "Market Value (Held)", "Unrealized G/L", "Realized G/L (Sold)", "Combined G/L", "Win Rate (Sold)", "# Tickers"].forEach((h, i) => xhc(ws, r, i + 1, h, {
    sz: 9
  }));
  ws.getRow(r).height = 18;
  r++;
  const allA = {};
  for (const acct of ACCOUNTS) {
    const rows = byAcctStocks[acct] || [],
      a = xStockAnalytics(rows);
    allA[acct] = a;
    const bg = XB[acct] || LG,
      hc = XH[acct] || DK;
    const uc = a.heldGL >= 0 ? "FF375623" : "FF843C0C",
      rc = a.soldGL >= 0 ? "FF375623" : "FF843C0C",
      cc = a.heldGL + a.soldGL >= 0 ? "FF375623" : "FF843C0C";
    xsc(ws, r, 1, acct, hc, WH, {
      bold: true,
      sz: 10
    });
    [[a.heldCount, null, "FF404040"], [a.soldCount, null, "FF404040"], [a.heldCost, '#,##0.00;(#,##0.00);"-"', "FF2E75B6"], [a.heldValue, '#,##0.00;(#,##0.00);"-"', "FF2E75B6"], [a.heldGL, '#,##0.00;(#,##0.00);"-"', uc], [a.soldGL, '#,##0.00;(#,##0.00);"-"', rc], [a.heldGL + a.soldGL, '#,##0.00;(#,##0.00);"-"', cc], [a.winRate / 100, "0.0%", "FF404040"], [Object.keys(a.tkSh).length, null, "FF404040"]].forEach(([v, fmt, fg], i) => xsc(ws, r, i + 2, v, bg, fg, {
      fmt,
      bold: i === 6
    }));
    ws.getRow(r).height = 18;
    r++;
  }
  const sk = k => Object.values(allA).reduce((s, a) => s + a[k], 0);
  const totHeldGL = sk("heldGL"),
    totSoldGL = sk("soldGL");
  const allSold = allStocks.filter(s => s.status === "Sold");
  const wrAll = allSold.length ? allSold.filter(s => (xStockGL(s) || 0) > 0).length / allSold.length : 0;
  ["PORTFOLIO TOTAL", sk("heldCount"), sk("soldCount"), sk("heldCost"), sk("heldValue"), totHeldGL, totSoldGL, totHeldGL + totSoldGL, wrAll, ""].forEach((v, i) => {
    const c = ws.getCell(r, i + 1);
    c.value = v;
    c.fill = xf(DK);
    c.font = xn(WH, 10, true);
    c.alignment = xa("center");
    c.border = TN;
    if ([3, 4, 5, 6, 7].includes(i)) c.numFmt = '#,##0.00;(#,##0.00);"-"';
    if (i === 8) c.numFmt = "0.0%";
  });
  ws.getRow(r).height = 20;
  r += 2;
  ws.mergeCells(r, 1, r, 5);
  xhc(ws, r, 1, "TICKER PERFORMANCE BY ACCOUNT (HELD + SOLD)", {
    bg: A3,
    sz: 10
  });
  ws.getRow(r).height = 20;
  r++;
  for (const acct of ACCOUNTS) {
    const a = allA[acct];
    if (!a || !Object.keys(a.tkGL).length) continue;
    const stk = Object.entries(a.tkGL).sort(([, x], [, y]) => y - x);
    const hc = XH[acct] || DK;
    ws.mergeCells(r, 1, r, 5);
    xsc(ws, r, 1, acct, hc, WH, {
      bold: true,
      sz: 10,
      h: "left"
    });
    ws.getRow(r).height = 18;
    r++;
    ["Ticker", "Shares Held/Traded", "Net G/L ($)", "Bar", ""].forEach((h, i) => xhc(ws, r, i + 1, h, {
      bg: A3,
      sz: 9
    }));
    ws.getRow(r).height = 16;
    r++;
    for (const [tk, gl] of stk) {
      const sh = a.tkSh[tk] || 0;
      const bg2 = gl >= 0 ? "FFC6EFCE" : "FFFCE4D6",
        fg2 = gl >= 0 ? "FF375623" : "FF843C0C";
      const bar = "█".repeat(Math.min(Math.round(Math.abs(gl) / 500), 20));
      [tk, sh, gl, bar, ""].forEach((v, i) => {
        const c = xsc(ws, r, i + 1, v, bg2, fg2, {
          sz: 9,
          h: i === 3 ? "left" : "center"
        });
        if (i === 2) c.numFmt = '#,##0.00;(#,##0.00);"-"';
      });
      ws.getRow(r).height = 16;
      r++;
    }
    const totGL = stk.reduce((s, [, v]) => s + v, 0);
    [`${acct} Total`, "", totGL, "", ""].forEach((v, i) => {
      const c = xsc(ws, r, i + 1, v, hc, WH, {
        bold: true,
        sz: 9,
        h: i === 0 ? "left" : "center"
      });
      if (i === 2) c.numFmt = '#,##0.00;(#,##0.00);"-"';
    });
    ws.getRow(r).height = 16;
    r += 2;
  }
  [16, 18, 16, 18, 8].forEach((w, i) => ws.getColumn(i + 1).width = w);
}
async function generateExcel(trades, stocks) {
  if (!trades || !trades.length) {
    alert("No trades to export.");
    return;
  }
  const rows = trades.map(t => ({
    "Account": t.account || "",
    "Date": t.date || "",
    "Company": t.company || "",
    "Ticker": t.ticker || "",
    "Strike": t.strike || "",
    "Current Stock": t.currentStock || "",
    "Exp Date": t.expDate || "",
    "Prem": t.sellPremium || "",
    "Qty": t.contracts || "",
    "C/P": t.cp || "",
    "S/B": t.sb || "",
    "Sells": t.sells != null ? t.sells.toFixed(2) : "",
    "Total": t.total != null ? t.total.toFixed(2) : "",
    "Action": t.action || "Open",
    "Close Date": t.closeDate || "",
    "Close Prem": t.closePremium || "",
    "Net P&L": t.netPL != null ? t.netPL.toFixed(2) : "",
    "Money On Hold": t.moneyOnHold || ""
  }));
  const byAcct = {};
  for (const acct of ACCOUNTS) byAcct[acct] = [];
  rows.forEach(r => {
    const a = r.Account;
    if (byAcct[a]) byAcct[a].push(r);
  });
  const wb = new ExcelJS.Workbook();
  wb.creator = "OptionIQ by Quantum Nexus LLC.";
  wb.company = "Quantum Nexus LLC.";
  wb.created = new Date();
  xBuildSummary(wb, byAcct, rows);
  xBuildWeekly(wb, byAcct, rows);
  xBuildPremiumWeekly(wb, byAcct, rows);
  for (const acct of ACCOUNTS) {
    if (byAcct[acct] && byAcct[acct].length) xBuildAcct(wb, acct, byAcct[acct]);
  }
  if (stocks && stocks.length) {
    const byAcctStocks = {};
    for (const acct of ACCOUNTS) byAcctStocks[acct] = [];
    stocks.forEach(s => {
      if (byAcctStocks[s.account]) byAcctStocks[s.account].push(s);
    });
    xBuildStockAnalytics(wb, byAcctStocks, stocks);
    for (const acct of ACCOUNTS) {
      if (byAcctStocks[acct] && byAcctStocks[acct].length) xBuildStockAcct(wb, acct, byAcctStocks[acct]);
    }
  }
  const buf = await wb.xlsx.writeBuffer();
  const blob = new Blob([buf], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `Options_Trade_Logger_${new Date().toISOString().slice(0, 10)}.xlsx`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ── App ───────────────────────────────────────────────────
function App() {
  const [trades, setTrades] = useState(() => {
    try {
      const r = localStorage.getItem(SK);
      if (!r) return [];
      return JSON.parse(r).map(sanitize);
    } catch {
      return [];
    }
  });
  const [selectedAccounts, setSelectedAccounts] = useState(new Set(ACCOUNTS));
  const allAccountsSelected = selectedAccounts.size === ACCOUNTS.length;
  const toggleAccount = acct => setSelectedAccounts(prev => {
    const next = new Set(prev);
    if (next.has(acct)) {
      if (next.size > 1) next.delete(acct);
    } else next.add(acct);
    return next;
  });
  const selectAllAccounts = () => setSelectedAccounts(new Set(ACCOUNTS));
  const acctLabel = allAccountsSelected ? "" : selectedAccounts.size === 1 ? `— ${[...selectedAccounts][0]}` : `— ${selectedAccounts.size} accounts`;
  const defaultAccountForNew = selectedAccounts.size === 1 ? [...selectedAccounts][0] : ACCOUNTS[0];
  const [mainTab, setMainTab] = useState("log");
  const [form, setForm] = useState(EMPTY);
  const [editId, setEditId] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [closeTarget, setCloseTarget] = useState(null);
  const [closeForm, setCloseForm] = useState({
    action: "Bought to Close",
    closeDate: "",
    closePremium: ""
  });
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(new Set());
  const [sortConfig, setSortConfig] = useState({
    key: "Date",
    direction: "desc"
  });
  const [stockSortConfig, setStockSortConfig] = useState({
    key: "Date Acquired",
    direction: "desc"
  });
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    ...DEFAULT_FILTERS
  });
  const [inlineEditId, setInlineEditId] = useState(null);
  const [inlineForm, setInlineForm] = useState({});
  const [fhKey, setFhKey] = useState(() => {
    try {
      return localStorage.getItem("finnhub_key") || "";
    } catch {
      return "";
    }
  });
  const [showKeyInput, setShowKeyInput] = useState(false);
  const [csvPick, setCsvPick] = useState(false);
  const [imp, setImp] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [refreshStatus, setRefreshStatus] = useState("");
  const [athChecking, setAthChecking] = useState(false);
  const [athStatus, setAthStatus] = useState("");
  const [xlBusy, setXlBusy] = useState(false);
  const [indexPrices, setIndexPrices] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("index_prices") || "null") || {};
    } catch {
      return {};
    }
  });
  const [tickerChange, setTickerChange] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("ticker_change") || "null") || {};
    } catch {
      return {};
    }
  });
  const [athPrices, setAthPrices] = useState(() => {
    try {
      const stored = JSON.parse(localStorage.getItem("ath_prices") || "null");
      return stored || {
        ...ATH_PRICES
      };
    } catch {
      return {
        ...ATH_PRICES
      };
    }
  });
  const [stocks, setStocks] = useState(() => {
    try {
      const r = localStorage.getItem(STOCK_SK);
      return r ? JSON.parse(r) : [];
    } catch {
      return [];
    }
  });
  const [stockForm, setStockForm] = useState(EMPTY_STOCK);
  const [stockEditId, setStockEditId] = useState(null);
  const [showStockForm, setShowStockForm] = useState(false);
  const [stockSelected, setStockSelected] = useState(new Set());
  const [stockInlineEditId, setStockInlineEditId] = useState(null);
  const [stockInlineForm, setStockInlineForm] = useState({});
  const [sellTarget, setSellTarget] = useState(null);
  const [sellForm, setSellForm] = useState({
    sharesToSell: "",
    soldDate: "",
    soldPrice: ""
  });
  const [buyTarget, setBuyTarget] = useState(null);
  const [quoteModalTicker, setQuoteModalTicker] = useState(null);
  const chartContainerRef = useRef(null);
  const [buyForm, setBuyForm] = useState({
    sharesToBuy: "",
    purchaseDate: "",
    newCostBasis: ""
  });
  const [stockSearch, setStockSearch] = useState("");
  const [showStockFilters, setShowStockFilters] = useState(false);
  const [stockFilters, setStockFilters] = useState({
    ...DEFAULT_STOCK_FILTERS
  });
  // ── Screener state ──────────────────────────────────────
  const [scrCfg, setScrCfg] = useState(() => {
    try {
      const r = localStorage.getItem(SCREENER_CFG_SK);
      if (!r) return {
        ...SCREENER_DEFAULTS
      };
      const s = JSON.parse(r);
      // Saved before the opportunity screener: keep only the personal choices.
      if (!s.preset) return {
        ...SCREENER_DEFAULTS,
        sides: s.sides || SCREENER_DEFAULTS.sides,
        workers: s.workers || 8,
        costBasisFloor: s.costBasisFloor !== false,
        costBasisMargin: s.costBasisMargin || 0
      };
      return {
        ...SCREENER_DEFAULTS,
        ...s
      };
    } catch {
      return {
        ...SCREENER_DEFAULTS
      };
    }
  });
  const [scrRows, setScrRows] = useState([]);
  const [scrMeta, setScrMeta] = useState(null);
  const [scrBusy, setScrBusy] = useState(false);
  const [scrStatus, setScrStatus] = useState("");
  const [scrService, setScrService] = useState("unknown"); // unknown | up | down
  const [scrSort, setScrSort] = useState({
    key: "Score",
    dir: "desc"
  });
  const [scrSideFilter, setScrSideFilter] = useState("all");
  const [scrShowCfg, setScrShowCfg] = useState(false);
  // ── Watchlist ───────────────────────────────────────────
  const [watchlist, setWatchlist] = useState(() => {
    try {
      const r = localStorage.getItem(WATCHLIST_SK);
      return r ? JSON.parse(r) : {};
    } catch {
      return {};
    }
  });
  const [wlInput, setWlInput] = useState("");
  const [wlBusy, setWlBusy] = useState(false);
  const [wlStatus, setWlStatus] = useState("");
  const [wlShow, setWlShow] = useState(false);
  const [wlExcluded, setWlExcluded] = useState(() => {
    try {
      const r = localStorage.getItem(EXCLUDED_SK);
      return new Set(r ? JSON.parse(r) : []);
    } catch {
      return new Set();
    }
  });
  const [optQuotes, setOptQuotes] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(OPT_QUOTES_SK) || "{}");
    } catch {
      return {};
    }
  });
  const [wlEditing, setWlEditing] = useState(null); // ticker whose name is being edited
  const [wlEditVal, setWlEditVal] = useState("");
  // ── Discover state ──────────────────────────────────────
  const [dsCfg, setDsCfg] = useState(() => {
    try {
      const r = localStorage.getItem(DISCOVER_CFG_SK);
      return r ? {
        ...DISCOVER_DEFAULTS,
        ...JSON.parse(r)
      } : {
        ...DISCOVER_DEFAULTS
      };
    } catch {
      return {
        ...DISCOVER_DEFAULTS
      };
    }
  });
  const [dsSaved, setDsSaved] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(DISCOVER_RES_SK) || "null");
    } catch {
      return null;
    }
  });
  const [dsRunning, setDsRunning] = useState(false);
  const [dsProgress, setDsProgress] = useState(null);
  const [dsStatus, setDsStatus] = useState("");
  const [dsShowCfg, setDsShowCfg] = useState(false);
  const [dsPicked, setDsPicked] = useState(new Set());
  const [dsSort, setDsSort] = useState({
    key: "Score",
    dir: "desc"
  });
  const [dsSector, setDsSector] = useState("all");
  const [dsHideOwned, setDsHideOwned] = useState(true);
  // ── Analysis state ──────────────────────────────────────
  const [anSaved, setAnSaved] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(ANALYSIS_RES_SK) || "null");
    } catch {
      return null;
    }
  });
  const [anRunning, setAnRunning] = useState(false);
  const [anProgress, setAnProgress] = useState(null);
  const [anStatus, setAnStatus] = useState("");
  const [anVerdict, setAnVerdict] = useState("all");
  const [anSort, setAnSort] = useState({
    key: "verdict",
    dir: "asc"
  });
  const [anOpen, setAnOpen] = useState(null); // ticker whose detail is expanded

  const save = t => {
    setTrades(t);
    try {
      localStorage.setItem(SK, JSON.stringify(t));
    } catch (e) {}
  };
  const saveStocks = s => {
    setStocks(s);
    try {
      localStorage.setItem(STOCK_SK, JSON.stringify(s));
    } catch (e) {}
  };
  const setF = (k, v) => setFilters(f => ({
    ...f,
    [k]: v
  }));
  const resetFilters = () => setFilters({
    ...DEFAULT_FILTERS
  });
  const AFC = Object.entries(filters).filter(([k, v]) => v !== DEFAULT_FILTERS[k] && v && v !== false).length;
  const handleTicker = v => {
    const t = v.toUpperCase();
    const learned = trades.find(tr => tr.ticker === t && tr.company)?.company;
    setForm(f => ({
      ...f,
      ticker: t,
      company: learned || tickerName(t) || f.company
    }));
  };
  const saveKey = k => {
    const t = k.trim();
    localStorage.setItem("finnhub_key", t);
    setFhKey(t);
    setShowKeyInput(false);
    setRefreshStatus("✅ Finnhub key saved!");
    setTimeout(() => setRefreshStatus(""), 3000);
  };

  // ── Screener ────────────────────────────────────────────
  const PRESET_KEYS = ["dteMin", "dteMax", "deltaMin", "deltaMax", "minNetPremium", "minAnnualized", "skipEarnings"];
  const setSC = (k, v) => setScrCfg(c => {
    const n = {
      ...c,
      [k]: v,
      ...(PRESET_KEYS.includes(k) ? {
        preset: "custom"
      } : {})
    };
    try {
      localStorage.setItem(SCREENER_CFG_SK, JSON.stringify(n));
    } catch (e) {}
    return n;
  });
  const resetScrCfg = () => {
    setScrCfg({
      ...SCREENER_DEFAULTS
    });
    try {
      localStorage.setItem(SCREENER_CFG_SK, JSON.stringify(SCREENER_DEFAULTS));
    } catch (e) {}
  };
  const [scrVersion, setScrVersion] = useState("");
  // The engine build this page expects. Raise it whenever the Python changes in
  // a way the page depends on.
  const NEEDS_SERVICE = "2.4";
  const serviceStale = scrVersion !== "" && scrVersion !== NEEDS_SERVICE;
  const checkScrService = async () => {
    try {
      const r = await fetch(`${SCREENER_URL}/health`, {
        signal: AbortSignal.timeout(2500),
        cache: "no-store"
      });
      setScrService(r.ok ? "up" : "down");
      // The launcher reuses a service that is already listening on 8765, so
      // updating the Python and relaunching leaves the OLD engine running --
      // silently, and every result then comes from stale code. Compare
      // versions rather than trusting that a restart happened.
      try {
        const h = await r.clone().json();
        setScrVersion(h && h.version || "");
      } catch (e) {
        setScrVersion("");
      }
      return r.ok;
    } catch {
      setScrService("down");
      setScrVersion("");
      return false;
    }
  };
  useEffect(() => {
    if (mainTab === "screener") checkScrService();
  }, [mainTab]);

  // Short calls still open — each ties up 100 shares, so the service subtracts
  // them before deciding how many more calls a holding can cover.
  const openShortCalls = useMemo(() => trades.filter(t => t.cp === "C" && t.sb === "S" && isOpen(t)).map(t => ({
    ticker: (t.ticker || "").trim().toUpperCase(),
    contracts: parseInt(t.contracts) || 0,
    account: t.account
  })), [trades]);
  const applyPreset = name => setScrCfg(c => {
    const n = {
      ...c,
      ...SCREENER_PRESETS[name]
    };
    try {
      localStorage.setItem(SCREENER_CFG_SK, JSON.stringify(n));
    } catch (e) {}
    return n;
  });
  // Open short puts, for the sector-concentration flag, and the Analysis
  // tab's verdicts (TRIM -10, BUY +5 on the Score).
  const scoreContext = () => ({
    openPuts: trades.filter(t => t.cp === "P" && t.sb === "S" && isOpen(t) && t.ticker).map(t => ({
      ticker: (t.ticker || "").trim().toUpperCase(),
      strike: +t.strike || 0,
      contracts: parseInt(t.contracts) || 1
    })),
    verdicts: Object.fromEntries((anSaved && anSaved.rows || []).filter(r => r.ticker && r.verdict).map(r => [r.ticker.toUpperCase(), r.verdict]))
  });
  // ── Roll candidates ─────────────────────────────────────
  const [scrShowRolls, setScrShowRolls] = useState(false);
  const [rollRows, setRollRows] = useState([]);
  const [rollBusy, setRollBusy] = useState(false);
  const [rollStatus, setRollStatus] = useState("");
  const [rollDebits, setRollDebits] = useState(false);
  // Which open positions to look at. Blank days or delta turns that rule off.
  const ROLL_RULES_SK = "optioniq_roll_rules";
  const [rollRules, setRollRules] = useState(() => {
    try {
      return {
        maxDays: "5",
        minDelta: "0.40",
        itm: true,
        type: "All",
        ...JSON.parse(localStorage.getItem(ROLL_RULES_SK) || "{}")
      };
    } catch {
      return {
        maxDays: "5",
        minDelta: "0.40",
        itm: true,
        type: "All"
      };
    }
  });
  const setRR = (k, v) => setRollRules(r => {
    const n = {
      ...r,
      [k]: v
    };
    try {
      localStorage.setItem(ROLL_RULES_SK, JSON.stringify(n));
    } catch (e) {}
    return n;
  });
  const runRolls = async () => {
    if (rollBusy) return;
    const rt = rollRules.type || "All";
    const open = trades.filter(t => t.sb === "S" && (t.cp === "P" || t.cp === "C") && (rt === "All" || t.cp === rt) && isOpen(t) && t.ticker && t.expDate);
    if (!open.length) {
      setRollRows([]);
      setRollStatus(rt === "P" ? "You have no open short puts." : rt === "C" ? "You have no open short calls." : "You have no open short puts or calls.");
      return;
    }
    setRollBusy(true);
    setRollStatus(`⏳ Checking ${open.length} open position${open.length > 1 ? "s" : ""}…`);
    const {
      chains
    } = sc_buildChains(trades);
    const before = new Map();
    chains.forEach(c => c.legs.forEach((l, i) => before.set(l.id, c.legs.slice(0, i))));
    const basisOf = tk => {
      const h = stocks.filter(s => (s.ticker || "").trim().toUpperCase() === tk && (s.status || "Held") !== "Sold");
      const sh = h.reduce((a, s) => a + (+s.shares || 0), 0);
      return sh ? h.reduce((a, s) => a + (+s.shares || 0) * (+s.costBasis || 0), 0) / sh : null;
    };
    const positions = open.map(t => {
      const q = parseInt(t.contracts) || 1,
        tk = (t.ticker || "").trim().toUpperCase();
      // Everything collected on this position so far, rolls included, per share.
      const prev = (before.get(t.id) || []).reduce((a, l) => a + (+l.total || netPremium(l)) + (+l.closePremium || 0), 0);
      return {
        id: t.id,
        ticker: tk,
        cp: t.cp,
        strike: +t.strike,
        expDate: t.expDate,
        contracts: q,
        sellPremium: +t.sellPremium || 0,
        chainPremium: (prev + (+t.total || netPremium(t))) / (q * 100),
        costBasis: t.cp === "C" ? basisOf(tk) : null
      };
    });
    try {
      const alive = await checkScrService();
      if (!alive) throw new Error("Can't reach the screener service.");
      const res = await fetch(`${SCREENER_URL}/rolls`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        signal: AbortSignal.timeout(600000),
        body: JSON.stringify({
          positions,
          feePerContract: 0.67,
          options: {
            requestsPerSecond: 8
          },
          rules: {
            maxDays: rollRules.maxDays === "" ? null : +rollRules.maxDays,
            minDelta: rollRules.minDelta === "" ? null : +rollRules.minDelta,
            itm: !!rollRules.itm
          }
        })
      });
      if (res.status === 404) throw new Error("The Screener running on this computer is an older version. Close OptionIQ completely and start it again.");
      const d = await res.json();
      if (!res.ok || !d.ok) throw new Error(d.error || "HTTP " + res.status);
      setRollRows(d.rows || []);
      setRollStatus((d.rows || []).length ? `✅ ${d.rows.length} position${d.rows.length > 1 ? "s" : ""} worth a look · ${d.skipped} fine for now` : `✅ None of your ${d.skipped} open position${d.skipped === 1 ? "" : "s"} match the settings above.`);
    } catch (e) {
      setRollStatus("❌ " + (e.message || String(e)));
    } finally {
      setRollBusy(false);
    }
  };
  // Open the Close / Roll form filled in from a roll candidate (or just the close).
  const closeFromRoll = (t, p, o) => {
    const q = parseInt(t.contracts) || 1;
    const cost = -(p.buyBack * 100 * q + 0.67 * q);
    setCloseTarget(t);
    setCloseForm(o ? {
      action: "Rolled",
      closeDate: new Date().toISOString().slice(0, 10),
      closePremium: cost.toFixed(2),
      rollExp: o.expiry,
      rollStrike: String(o.strike),
      rollPrem: String(o.mid),
      rollQty: String(q)
    } : {
      action: "Bought to Close",
      closeDate: new Date().toISOString().slice(0, 10),
      closePremium: cost.toFixed(2)
    });
  };
  const runScreen = async () => {
    if (scrBusy) return;
    setScrBusy(true);
    setScrStatus("Connecting to screener service…");
    const alive = await checkScrService();
    if (!alive) {
      setScrBusy(false);
      setScrStatus("❌ Can't reach the screener service on 127.0.0.1:8765 — see the checklist below.");
      return;
    }
    // Excluding every ticker is easy to do by accident (the Exclude all button)
    // and used to surface as "no contracts matched", which blames your criteria
    // for something they had nothing to do with.
    if (activeUniverse.length === 0) {
      setScrBusy(false);
      setWlShow(true);
      setScrStatus(`❌ Nothing to screen — all ${screenUniverse.length} tickers are unticked in ★ Watchlist. Press "Include all" there.`);
      return;
    }
    const sides = scrCfg.sides === "both" ? ["put", "call"] : [scrCfg.sides];
    setScrStatus(`⏳ Scanning… this takes a few seconds per symbol.`);
    const t0 = Date.now();
    try {
      const res = await fetch(`${SCREENER_URL}/screen`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        signal: AbortSignal.timeout(600000),
        body: JSON.stringify({
          sides,
          // Excluded tickers sit out entirely — both the put universe and the
          // holdings the service derives covered calls from.
          tickers: activeUniverse,
          holdings: stocks.filter(s => !wlExcluded.has((s.ticker || "").trim().toUpperCase())).map(s => ({
            ticker: s.ticker,
            shares: s.shares,
            costBasis: s.costBasis,
            account: s.account,
            status: s.status || "Held"
          })),
          openCalls: openShortCalls,
          ...scoreContext(),
          criteria: {
            feePerContract: 0.67,
            minNetPremium: +scrCfg.minNetPremium || 0,
            minIVHV: +scrCfg.minIVHV || 0,
            minIVRank: +scrCfg.minIVRank || 0,
            minAvgVolumeM: +scrCfg.minAvgVolumeM || 0,
            dteMin: +scrCfg.dteMin,
            dteMax: +scrCfg.dteMax,
            deltaMin: +scrCfg.deltaMin,
            deltaMax: +scrCfg.deltaMax,
            ivMin: +scrCfg.ivMin / 100,
            ivMax: +scrCfg.ivMax / 100,
            peMin: +scrCfg.peMin,
            peMax: +scrCfg.peMax,
            allowMissingPE: !!scrCfg.allowMissingPE,
            minOI: +scrCfg.minOI,
            minVolume: +scrCfg.minVolume,
            maxSpreadPct: +scrCfg.maxSpreadPct / 100,
            minBid: +scrCfg.minBid,
            minAnnualized: +scrCfg.minAnnualized / 100,
            minPremium: +scrCfg.minPremium,
            maxPerTicker: +scrCfg.maxPerTicker,
            workers: +scrCfg.workers,
            requestsPerSecond: 8,
            skipEarnings: !!scrCfg.skipEarnings,
            flagEarnings: !!scrCfg.flagEarnings,
            costBasisFloor: !!scrCfg.costBasisFloor,
            costBasisMargin: +scrCfg.costBasisMargin / 100,
            priceMin: 1,
            priceMax: 100000,
            marketCapMin: 0
          }
        })
      });
      const d = await res.json();
      if (!res.ok || !d.ok) throw new Error(d.error || "HTTP " + res.status);
      setScrRows(d.rows || []);
      setScrMeta(d.meta || null);
      const secs = ((Date.now() - t0) / 1000).toFixed(0);
      const rl = d.meta && d.meta.rate || {};
      const throttled = rl.hits > 0;
      setScrStatus((d.rows || []).length ? `✅ ${d.rows.length} contracts from ${d.meta?.scanned ?? "?"} symbol scans in ${secs}s` + (throttled ? `  ⚠ Yahoo throttled ${rl.hits} request(s) — some symbols may be missing.` : "") : throttled ? `⚠ No contracts returned, but Yahoo throttled ${rl.hits} request(s) (${rl.gave_up || 0} gave up). This is a rate limit, not your criteria — wait a few minutes and try again.` : `No contracts matched across ${d.meta?.scanned ?? "?"} symbol scans. Loosen the yield floor, widen the delta band, or drop the open-interest minimum.`);
    } catch (e) {
      const msg = e && e.name === "TimeoutError" ? "Timed out — try fewer symbols or a narrower DTE window." : e.message || String(e);
      setScrStatus("❌ " + msg);
    } finally {
      setScrBusy(false);
    }
  };

  // Send a screened contract straight into the trade entry form.
  const logFromScreener = row => {
    const tk = row.Ticker;
    const learned = trades.find(t => t.ticker === tk && t.company)?.company;
    setForm({
      ...EMPTY,
      account: defaultAccountForNew,
      date: new Date().toISOString().split("T")[0],
      ticker: tk,
      company: learned || tickerName(tk) || row.Name || "",
      strike: String(row.Strike ?? ""),
      currentStock: String(row.Spot ?? ""),
      expDate: row.Expiry || "",
      sellPremium: String(row.Mid ?? ""),
      contracts: "1",
      cp: row.Side === "PUT" ? "P" : "C",
      sb: "S",
      action: "Open"
    });
    setEditId(null);
    setShowForm(true);
    setMainTab("log");
  };
  const scrSorted = useMemo(() => {
    let r = scrRows;
    if (scrSideFilter !== "all") r = r.filter(x => x.Side === scrSideFilter);
    const {
        key,
        dir
      } = scrSort,
      mul = dir === "asc" ? 1 : -1;
    return [...r].sort((a, b) => {
      const av = a[key],
        bv = b[key];
      if (av == null && bv == null) return 0;
      if (av == null) return 1;
      if (bv == null) return -1;
      if (typeof av === "number" && typeof bv === "number") return (av - bv) * mul;
      return String(av).localeCompare(String(bv)) * mul;
    });
  }, [scrRows, scrSort, scrSideFilter]);
  const scrSortBy = k => setScrSort(s => ({
    key: k,
    dir: s.key === k && s.dir === "desc" ? "asc" : "desc"
  }));

  // ── Watchlist ───────────────────────────────────────────
  const saveWatchlist = w => {
    setWatchlist(w);
    try {
      localStorage.setItem(WATCHLIST_SK, JSON.stringify(w));
    } catch (e) {}
  };
  const saveOptQuotes = q => {
    setOptQuotes(q);
    try {
      localStorage.setItem(OPT_QUOTES_SK, JSON.stringify(q));
    } catch (e) {}
  };

  // ── Current value of an open contract ───────────────────
  // You asked for last traded, so that is what leads. Mid is only used when
  // there is no last at all, and the row is marked when that happens.
  const quoteFor = t => {
    if (!t || !t.ticker || !t.expDate || !t.strike) return null;
    return optQuotes[quoteKey(t.ticker, t.expDate, t.strike, t.cp)] || null;
  };
  // Marked at the mid of the live bid/ask whenever there is a two-sided market.
  //
  // You asked for last traded and I built it that way, which was wrong, and
  // your own ARM chain shows why. Every deep in-the-money put on the 25 Sep
  // expiry last printed while the stock was higher, so each one sits below its
  // current bid — the $350 put last traded at $100.75 against a $107.50 bid.
  // Marking a short put at a price nobody will sell you back at understates
  // what you owe. The last trade is somebody else's history; the mid is what
  // you could close at now, which is the number your P&L needs.
  //
  // Last is still used when there is no two-sided market to mark against, and
  // it is labelled so you know you are looking at a print rather than a quote.
  const currentContractPrice = t => {
    const q = quoteFor(t);
    if (!q) return null;
    const hasMid = q.mid != null && q.mid > 0;
    const hasLast = q.last != null && q.last > 0;
    if (hasMid) {
      const drift = hasLast ? Math.abs(q.last - q.mid) / q.mid : 0;
      return {
        price: q.mid,
        basis: drift > 0.03 ? `mid (last print ${fmt$(q.last)} is off the market)` : "mid",
        q
      };
    }
    if (hasLast) return {
      price: q.last,
      basis: q.lastStale ? "last print — no live bid, may be stale" : "last print — no live bid",
      q
    };
    return null;
  };
  // Unrealised P&L on an open position, in dollars.
  // Short: you collected the premium, so you gain as the contract cheapens.
  // Long:  the reverse.
  const unrealisedPL = t => {
    const cur = currentContractPrice(t);
    if (!cur) return null;
    const prem = parseFloat(t.sellPremium),
      qty = parseInt(t.contracts) || 0;
    if (!isFinite(prem) || !qty) return null;
    const per = t.sb === "S" ? prem - cur.price : cur.price - prem;
    return {
      pl: per * qty * 100,
      pct: prem > 0 ? per / prem * 100 : null,
      price: cur.price,
      basis: cur.basis,
      q: cur.q
    };
  };
  // How stale is this quote? Options don't trade overnight or at weekends,
  // so a "last" price can legitimately be days old on a quiet strike.
  const quoteAgeHours = t => {
    const q = quoteFor(t);
    return q && q.at ? (Date.now() - q.at) / 3600000 : null;
  };

  // Names you've already typed into the Options and Stocks tabs. Sorted so the
  // most recent entry wins, since that's the spelling you last chose.
  const learnedNames = useMemo(() => {
    const m = {};
    const put = (tk, co) => {
      const k = (tk || "").trim().toUpperCase();
      const v = (co || "").trim();
      if (k && v) m[k] = v;
    };
    [...trades].sort((a, b) => String(a.date || "").localeCompare(String(b.date || ""))).forEach(t => put(t.ticker, t.company));
    [...stocks].sort((a, b) => String(a.dateAcquired || "").localeCompare(String(b.dateAcquired || ""))).forEach(s => put(s.ticker, s.company));
    return m;
  }, [trades, stocks]);

  // Company name for a ticker. An explicit edit wins; otherwise fall back to
  // whatever you already used in your trades or holdings, then the built-in list.
  const tickerName = t => watchlist[t] || learnedNames[t] || TICKERS[t] || "";
  const nameSource = t => watchlist[t] ? "edited" : learnedNames[t] ? "from your data" : TICKERS[t] ? "built-in" : "";

  // Tickers you've traded or currently hold get screened whether or not you
  // ever added them — otherwise a name like FTEC that you own would be missed.
  const autoTickers = useMemo(() => {
    const s = new Set();
    trades.forEach(t => {
      const k = (t.ticker || "").trim().toUpperCase();
      if (k) s.add(k);
    });
    stocks.forEach(h => {
      if (h.status !== "Sold") {
        const k = (h.ticker || "").trim().toUpperCase();
        if (k) s.add(k);
      }
    });
    return s;
  }, [trades, stocks]);

  // Everything known. Excluding a ticker does not remove it from here.
  const screenUniverse = useMemo(() => {
    const s = new Set([...Object.keys(TICKERS), ...Object.keys(watchlist), ...autoTickers]);
    return [...s].filter(Boolean).sort();
  }, [watchlist, autoTickers]);

  // What the next scan will actually look at.
  const activeUniverse = useMemo(() => screenUniverse.filter(t => !wlExcluded.has(t)), [screenUniverse, wlExcluded]);
  const saveExcluded = s => {
    setWlExcluded(new Set(s));
    try {
      localStorage.setItem(EXCLUDED_SK, JSON.stringify([...s]));
    } catch (e) {}
  };
  const toggleExcluded = t => {
    const n = new Set(wlExcluded);
    n.has(t) ? n.delete(t) : n.add(t);
    saveExcluded(n);
  };
  const includeAll = () => saveExcluded(new Set());
  const excludeAll = () => saveExcluded(new Set(screenUniverse));

  // Held/traded win over "yours" so the tag says where the ticker actually
  // comes from. You can still name any of them; only manual adds are removable.
  const tickerSource = t => {
    const held = stocks.some(h => h.status !== "Sold" && (h.ticker || "").trim().toUpperCase() === t);
    if (held) return {
      label: "held",
      color: "#0d9488",
      removable: false
    };
    if (autoTickers.has(t)) return {
      label: "traded",
      color: "#4338ca",
      removable: false
    };
    if (watchlist[t] !== undefined) return {
      label: "yours",
      color: "#c2410c",
      removable: true
    };
    return {
      label: "built-in",
      color: "#4b5563",
      removable: false
    };
  };

  // Set or clear the company name for any ticker. This is what the trade and
  // holding forms autofill from.
  const setTickerName = (t, name) => {
    const v = (name || "").trim();
    const n = {
      ...watchlist
    };
    if (v) {
      n[t] = v;
    } else if (n[t] !== undefined) {
      // Clearing the name: keep the entry only if you added the ticker yourself,
      // otherwise drop the key so it doesn't look like a manual addition.
      if (tickerSource(t).removable) n[t] = "";else delete n[t];
    } else {
      return; // nothing typed on a ticker you never named — leave it alone
    }

    saveWatchlist(n);
  };
  // Ask Yahoo (via the service) for every name still blank after the fallbacks.
  const unnamedTickers = useMemo(() => screenUniverse.filter(t => !tickerName(t)), [screenUniverse, watchlist, learnedNames]);
  const fillMissingNames = async () => {
    const todo = unnamedTickers;
    if (!todo.length) {
      setWlStatus("Every ticker already has a name.");
      return;
    }
    setWlBusy(true);
    setWlStatus(`Looking up ${todo.length} name${todo.length > 1 ? "s" : ""}…`);
    const alive = await checkScrService();
    if (!alive) {
      setWlBusy(false);
      setWlStatus("❌ Screener service is offline — start it, then try again. You can still type names in by hand.");
      return;
    }
    const next = {
      ...watchlist
    };
    let found = 0,
      failed = [];
    try {
      // /verify handles 25 per call, so walk through in chunks.
      for (let i = 0; i < todo.length; i += 25) {
        const chunk = todo.slice(i, i + 25);
        setWlStatus(`Looking up names… ${Math.min(i + chunk.length, todo.length)}/${todo.length}`);
        const res = await fetch(`${SCREENER_URL}/verify`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          signal: AbortSignal.timeout(120000),
          body: JSON.stringify({
            tickers: chunk
          })
        });
        const d = await res.json();
        if (!res.ok || !d.ok) throw new Error(d.error || "HTTP " + res.status);
        (d.results || []).forEach(r => {
          if (r.ok && r.name) {
            next[r.ticker] = r.name;
            found++;
          } else failed.push(r.ticker);
        });
      }
      if (found) saveWatchlist(next);
      setWlStatus(`✅ Filled ${found} name${found === 1 ? "" : "s"}.` + (failed.length ? `  Couldn't resolve: ${failed.join(", ")} — type those in by hand.` : ""));
    } catch (e) {
      if (found) saveWatchlist(next);
      setWlStatus(`❌ Stopped after ${found} name${found === 1 ? "" : "s"}: ${e.message || e}`);
    } finally {
      setWlBusy(false);
    }
  };
  const startEditName = t => {
    setWlEditing(t);
    setWlEditVal(tickerName(t));
  };
  const commitEditName = () => {
    if (wlEditing !== null) {
      setTickerName(wlEditing, wlEditVal);
    }
    setWlEditing(null);
    setWlEditVal("");
  };
  const addWatchlistTickers = async raw => {
    const syms = [...new Set((raw || "").toUpperCase().split(/[^A-Z0-9.\-]+/).filter(Boolean))];
    if (!syms.length) {
      setWlStatus("Type one or more ticker symbols first.");
      return;
    }
    const dupes = syms.filter(s => watchlist[s]);
    const fresh = syms.filter(s => !watchlist[s]);
    if (!fresh.length) {
      setWlStatus(`Already on your list: ${dupes.join(", ")}`);
      return;
    }
    setWlBusy(true);
    setWlStatus("Verifying…");
    const alive = await checkScrService();
    if (!alive) {
      // Service down — add unverified rather than blocking you.
      const next = {
        ...watchlist
      };
      fresh.forEach(s => {
        next[s] = TICKERS[s] || "";
      });
      saveWatchlist(next);
      setWlInput("");
      setWlBusy(false);
      setWlStatus(`⚠ Added ${fresh.join(", ")} without checking — screener service is offline, so the symbols couldn't be verified.`);
      return;
    }
    try {
      const res = await fetch(`${SCREENER_URL}/verify`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        signal: AbortSignal.timeout(60000),
        body: JSON.stringify({
          tickers: fresh
        })
      });
      const d = await res.json();
      if (!res.ok || !d.ok) throw new Error(d.error || "HTTP " + res.status);
      const good = [],
        noOpts = [],
        bad = [];
      const next = {
        ...watchlist
      };
      (d.results || []).forEach(r => {
        if (r.ok && r.hasOptions) {
          next[r.ticker] = r.name || "";
          good.push(`${r.ticker} (${r.name || "?"})`);
        } else if (r.ok) {
          noOpts.push(r.ticker);
        } else {
          bad.push(r.ticker);
        }
      });
      if (good.length) saveWatchlist(next);
      const parts = [];
      if (good.length) parts.push(`✅ Added ${good.join(", ")}`);
      if (noOpts.length) parts.push(`⚠ ${noOpts.join(", ")} — real symbol but no listed options, so nothing to screen. Not added.`);
      if (bad.length) parts.push(`❌ ${bad.join(", ")} — couldn't resolve. Check the spelling.`);
      if (dupes.length) parts.push(`Already on your list: ${dupes.join(", ")}`);
      setWlStatus(parts.join("  ·  "));
      if (good.length) setWlInput("");
    } catch (e) {
      setWlStatus("❌ Verification failed: " + (e.message || String(e)));
    } finally {
      setWlBusy(false);
    }
  };

  // ── Analysis ────────────────────────────────────────────
  const saveAnResults = r => {
    setAnSaved(r);
    try {
      localStorage.setItem(ANALYSIS_RES_SK, JSON.stringify(r));
    } catch (e) {}
  };
  const pollAnalysis = async () => {
    for (;;) {
      await new Promise(r => setTimeout(r, 1200));
      let s;
      try {
        const res = await fetch(`${SCREENER_URL}/analyze/status`, {
          cache: "no-store",
          signal: AbortSignal.timeout(15000)
        });
        s = await res.json();
      } catch (e) {
        setAnStatus("❌ Lost contact with the service — is it still running?");
        setAnRunning(false);
        return;
      }
      setAnProgress({
        done: s.done,
        total: s.total,
        ticker: s.ticker
      });
      if (!s.running) {
        setAnRunning(false);
        setAnProgress(null);
        if (s.error) {
          setAnStatus("❌ " + s.error);
          return;
        }
        saveAnResults({
          rows: s.rows || [],
          stats: s.stats || null,
          errors: s.errors || {},
          ranAt: s.finished || new Date().toISOString()
        });
        const n = (s.rows || []).length;
        const st = s.stats || {};
        setAnStatus(n ? `✅ ${n} analysed` + (st.failed ? ` · ${st.failed} couldn't be read` : "") + (st.rate_limited ? " · ⚠ Yahoo throttled some requests, so a few readings may be missing" : "") : "Nothing came back — check the service log.");
        return;
      }
    }
  };
  const runAnalysis = async () => {
    if (anRunning) return;
    const universe = screenUniverse;
    if (!universe.length) {
      setAnStatus("❌ No tickers to analyse — add some in ★ Watchlist.");
      return;
    }
    setAnStatus("Connecting to screener service…");
    const alive = await checkScrService();
    if (!alive) {
      setAnStatus("❌ Screener service isn't running — close OptionIQ and start it again.");
      return;
    }
    setAnRunning(true);
    setAnStatus(`Analysing ${universe.length} stocks…`);
    setAnProgress({
      done: 0,
      total: universe.length,
      ticker: ""
    });
    try {
      const res = await fetch(`${SCREENER_URL}/analyze`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        signal: AbortSignal.timeout(30000),
        body: JSON.stringify({
          tickers: universe,
          options: {
            requestsPerSecond: 10,
            workers: 6,
            lookback: "1y"
          }
        })
      });
      const d = await res.json();
      if (!res.ok || !d.ok) throw new Error(d.error || "HTTP " + res.status);
      setAnStatus("Reading fundamentals and a year of prices — a couple of minutes. You can switch tabs.");
      pollAnalysis();
    } catch (e) {
      setAnRunning(false);
      setAnProgress(null);
      setAnStatus("❌ " + (e.message || String(e)));
    }
  };
  const cancelAnalysis = async () => {
    try {
      await fetch(`${SCREENER_URL}/analyze/cancel`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: "{}"
      });
      setAnStatus("Cancelling…");
    } catch (e) {
      setAnStatus("❌ Couldn't cancel: " + (e.message || e));
    }
  };

  // What you actually own / have written against each name, so a verdict can
  // be read next to your exposure rather than in the abstract.
  const anPosition = tk => {
    const sh = stocks.filter(s => s.status !== "Sold" && (s.ticker || "").trim().toUpperCase() === tk).reduce((a, s) => a + (parseFloat(s.shares) || 0), 0);
    const opts = trades.filter(t => isOpen(t) && (t.ticker || "").trim().toUpperCase() === tk);
    const puts = opts.filter(t => t.cp === "P").reduce((a, t) => a + (parseInt(t.contracts) || 0), 0);
    const calls = opts.filter(t => t.cp === "C").reduce((a, t) => a + (parseInt(t.contracts) || 0), 0);
    return {
      shares: sh,
      puts,
      calls,
      any: sh > 0 || puts > 0 || calls > 0
    };
  };

  // Signals used to be plain strings; they now carry the threshold that
  // classified them. Handle both so results saved before this change still show.
  const sigText = x => typeof x === "string" ? x : x && x.t || "";
  const sigWhy = x => typeof x === "string" ? "" : x && x.w || "";
  const sigList = (arr, mark, color, keyPrefix) => (arr || []).map((x, j) => {
    const why = sigWhy(x);
    // The underline goes on the text itself, not the row. A full-width element
    // here stretches to the table's scroll width and draws a rule across it.
    return /*#__PURE__*/React.createElement("div", {
      key: keyPrefix + j,
      style: {
        fontSize: 12,
        color,
        lineHeight: 1.7,
        whiteSpace: "normal"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        marginRight: 4
      }
    }, mark), /*#__PURE__*/React.createElement("span", {
      title: why || "Re-run the analysis to see the threshold behind this.",
      style: {
        cursor: why ? "help" : "default",
        borderBottom: why ? "1px dotted rgba(148,163,184,0.4)" : "none"
      }
    }, sigText(x)));
  });
  const AN_ORDER = {
    BUY: 0,
    "HOLD+": 1,
    HOLD: 2,
    MIXED: 3,
    "HOLD-": 4,
    TRIM: 5
  };
  const anRows = useMemo(() => {
    let r = anSaved && anSaved.rows || [];
    if (anVerdict !== "all") r = r.filter(x => x.verdict === anVerdict);
    const {
        key,
        dir
      } = anSort,
      mul = dir === "asc" ? 1 : -1;
    return [...r].sort((a, b) => {
      if (key === "verdict") return ((AN_ORDER[a.verdict] ?? 9) - (AN_ORDER[b.verdict] ?? 9)) * mul;
      const av = a[key],
        bv = b[key];
      if (av == null && bv == null) return 0;
      if (av == null) return 1;
      if (bv == null) return -1;
      if (typeof av === "number" && typeof bv === "number") return (av - bv) * mul;
      return String(av).localeCompare(String(bv)) * mul;
    });
  }, [anSaved, anVerdict, anSort]);
  const anSortBy = k => setAnSort(s => ({
    key: k,
    dir: s.key === k && s.dir === "asc" ? "desc" : "asc"
  }));
  const anAgeDays = useMemo(() => {
    if (!anSaved || !anSaved.ranAt) return null;
    return Math.floor((Date.now() - new Date(anSaved.ranAt).getTime()) / 86400000);
  }, [anSaved]);
  const AN_COLOR = {
    BUY: "#4ade80",
    "HOLD+": "#a3e635",
    HOLD: "#94a3b8",
    MIXED: "#fbbf24",
    "HOLD-": "#fb923c",
    TRIM: "#f87171"
  };
  const ZONE_COLOR = {
    Overbought: "#f87171",
    "Stretched high": "#fbbf24",
    Neutral: "#6b7280",
    "Stretched low": "#60a5fa",
    Oversold: "#4ade80"
  };
  const FV_COLOR = {
    Cheap: "#4ade80",
    "Below fair": "#86efac",
    Fair: "#94a3b8",
    "Above fair": "#fca5a5",
    Expensive: "#f87171"
  };
  // Sticky header cells. The bottom rule is an inset shadow rather than a
  // border because a collapsed-border table drops th borders once the cell is
  // taken out of flow by position:sticky.
  const AN_TH = {
    padding: "8px 7px",
    textAlign: "left",
    cursor: "pointer",
    userSelect: "none",
    fontWeight: 600,
    position: "sticky",
    top: 0,
    zIndex: 2,
    background: "#1b1e29",
    boxShadow: "inset 0 -1px 0 #2d3748"
  };

  // ── Discover ────────────────────────────────────────────
  const setDS = (k, v) => setDsCfg(c => {
    const n = {
      ...c,
      [k]: v
    };
    try {
      localStorage.setItem(DISCOVER_CFG_SK, JSON.stringify(n));
    } catch (e) {}
    return n;
  });
  const resetDsCfg = () => {
    setDsCfg({
      ...DISCOVER_DEFAULTS
    });
    try {
      localStorage.setItem(DISCOVER_CFG_SK, JSON.stringify(DISCOVER_DEFAULTS));
    } catch (e) {}
  };
  const saveDsResults = r => {
    setDsSaved(r);
    try {
      localStorage.setItem(DISCOVER_RES_SK, JSON.stringify(r));
    } catch (e) {}
  };
  const pollDiscover = async () => {
    // The scan runs for minutes in the service; poll rather than hold a request open.
    for (;;) {
      await new Promise(r => setTimeout(r, 1200));
      let s;
      try {
        const res = await fetch(`${SCREENER_URL}/discover/status`, {
          cache: "no-store",
          signal: AbortSignal.timeout(15000)
        });
        s = await res.json();
      } catch (e) {
        setDsStatus("❌ Lost contact with the service — is it still running?");
        setDsRunning(false);
        return;
      }
      setDsProgress({
        stage: s.stage,
        done: s.done,
        total: s.total,
        ticker: s.ticker
      });
      if (!s.running) {
        setDsRunning(false);
        setDsProgress(null);
        if (s.error) {
          setDsStatus("❌ " + s.error);
          return;
        }
        const stopped = s.stats && s.stats.stopped;
        saveDsResults({
          rows: s.rows || [],
          stats: s.stats || null,
          ranAt: s.finished || new Date().toISOString()
        });
        setDsPicked(new Set());
        // A sector chosen against the previous run may not exist in this one.
        // Leaving it set would silently hide everything.
        setDsSector("all");
        const n = (s.rows || []).length;
        setDsStatus(stopped ? `⚠ Cancelled — showing the ${n} candidate${n === 1 ? "" : "s"} found before you stopped it.` : n ? `✅ ${n} candidate${n === 1 ? "" : "s"} from ${s.stats?.universe ?? "?"} symbols.` : "No stocks matched. Loosen the IV band or the quality floors.");
        return;
      }
    }
  };
  const runDiscover = async () => {
    if (dsRunning) return;
    // Yahoo's limit is a rolling per-IP budget and one sweep spends most of it.
    // Back-to-back scans are what earn a wall of 429s, so make that visible
    // before it happens rather than explaining it afterwards.
    if (dsSaved && dsSaved.ranAt) {
      const mins = (Date.now() - new Date(dsSaved.ranAt).getTime()) / 60000;
      if (mins < 15 && !window.confirm(`Your last scan finished ${mins < 1 ? "less than a minute" : Math.round(mins) + " minutes"} ago.\n\n` + `A full sweep uses most of Yahoo's per-IP request budget, and scanning again this soon ` + `is the usual cause of a rate-limited, empty result.\n\n` + `Waiting ~15 minutes between scans avoids it. Scan anyway?`)) return;
    }
    setDsStatus("Connecting to screener service…");
    const alive = await checkScrService();
    if (!alive) {
      setDsStatus("❌ Screener service isn't running — close OptionIQ and start it again, then try again.");
      return;
    }
    setDsRunning(true);
    setDsStatus("Starting scan…");
    setDsProgress({
      stage: "starting",
      done: 0,
      total: 0,
      ticker: ""
    });
    try {
      const res = await fetch(`${SCREENER_URL}/discover`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        signal: AbortSignal.timeout(30000),
        body: JSON.stringify({
          tickers: [],
          // empty = the full S&P 500, fetched service-side
          // Applied to the constituent list before stage 1, so excluded
          // sectors cost no requests at all.
          sectors: dsCfg.sectors || [],
          ...scoreContext(),
          criteria: {
            feePerContract: 0.67,
            minNetPremium: +dsCfg.minNetPremium || 0,
            minIVHV: +dsCfg.minIVHV || 0,
            priceMin: +dsCfg.priceMin,
            priceMax: +dsCfg.priceMax,
            marketCapMin: +dsCfg.marketCapMin * 1e9,
            peMin: +dsCfg.peMin,
            peMax: +dsCfg.peMax,
            positiveEPS: !!dsCfg.positiveEPS,
            marginMin: +dsCfg.marginMin / 100,
            roeMin: +dsCfg.roeMin / 100,
            revGrowthMin: +dsCfg.revGrowthMin / 100,
            avgVolumeMin: +dsCfg.avgVolumeMin * 1e6,
            allowMissingMetrics: !!dsCfg.allowMissingMetrics,
            side: dsCfg.side || "put",
            dteMin: +dsCfg.dteMin,
            dteMax: +dsCfg.dteMax,
            deltaMin: +dsCfg.deltaMin,
            deltaMax: +dsCfg.deltaMax,
            ivMin: +dsCfg.ivMin / 100,
            ivMax: +dsCfg.ivMax / 100,
            minOI: +dsCfg.minOI,
            minVolume: +dsCfg.minVolume,
            maxSpreadPct: +dsCfg.maxSpreadPct / 100,
            minBid: +dsCfg.minBid,
            minPremium: +dsCfg.minPremium,
            minAnnualized: +dsCfg.minAnnualized / 100,
            maxPerTicker: +dsCfg.maxPerTicker,
            maxExpiries: +dsCfg.maxExpiries,
            skipEarnings: !!dsCfg.skipEarnings,
            workers: +dsCfg.workers,
            requestsPerSecond: +dsCfg.requestsPerSecond
          }
        })
      });
      const d = await res.json();
      if (!res.ok || !d.ok) throw new Error(d.error || "HTTP " + res.status);
      setDsStatus("Scanning — this takes a few minutes. You can switch tabs; it keeps running.");
      pollDiscover();
    } catch (e) {
      setDsRunning(false);
      setDsProgress(null);
      setDsStatus("❌ " + (e.message || String(e)));
    }
  };
  const cancelDiscover = async () => {
    try {
      await fetch(`${SCREENER_URL}/discover/cancel`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: "{}"
      });
      setDsStatus("Cancelling…");
    } catch (e) {
      setDsStatus("❌ Couldn't cancel: " + (e.message || e));
    }
  };

  // Candidates already on your list aren't new ideas.
  const dsOwned = t => screenUniverse.includes(t);
  const dsRows = useMemo(() => {
    let r = dsSaved && dsSaved.rows || [];
    if (dsHideOwned) r = r.filter(x => !dsOwned(x.Ticker));
    if (dsSector !== "all") r = r.filter(x => x.Sector === dsSector);
    const {
        key,
        dir
      } = dsSort,
      mul = dir === "asc" ? 1 : -1;
    return [...r].sort((a, b) => {
      const av = a[key],
        bv = b[key];
      if (av == null && bv == null) return 0;
      if (av == null) return 1;
      if (bv == null) return -1;
      if (typeof av === "number" && typeof bv === "number") return (av - bv) * mul;
      return String(av).localeCompare(String(bv)) * mul;
    });
  }, [dsSaved, dsSort, dsSector, dsHideOwned, screenUniverse]);
  const dsSortBy = k => setDsSort(s => ({
    key: k,
    dir: s.key === k && s.dir === "desc" ? "asc" : "desc"
  }));
  const dsSectors = useMemo(() => [...new Set((dsSaved && dsSaved.rows || []).map(r => r.Sector).filter(Boolean))].sort(), [dsSaved]);
  const dsAllRows = useMemo(() => dsSaved && dsSaved.rows || [], [dsSaved]);
  // How many rows each filter is responsible for hiding, so an empty table can
  // explain itself instead of just looking like the scan found nothing.
  const dsHiddenByOwned = useMemo(() => dsHideOwned ? dsAllRows.filter(r => dsOwned(r.Ticker)).length : 0, [dsAllRows, dsHideOwned, screenUniverse]);
  const dsHiddenBySector = useMemo(() => {
    if (dsSector === "all") return 0;
    const base = dsHideOwned ? dsAllRows.filter(r => !dsOwned(r.Ticker)) : dsAllRows;
    return base.filter(r => r.Sector !== dsSector).length;
  }, [dsAllRows, dsSector, dsHideOwned, screenUniverse]);
  const dsFiltersActive = dsSector !== "all" || dsHideOwned;
  const dsClearFilters = () => {
    setDsSector("all");
    setDsHideOwned(false);
  };
  // A scan that ran and found nothing is a different situation from one that
  // never ran, and needs a different explanation.
  const dsHasRun = !!(dsSaved && dsSaved.stats);
  const dsStats = dsSaved && dsSaved.stats || null;
  // Which stage emptied the funnel tells you which knob to turn.
  const dsBlame = useMemo(() => {
    if (!dsStats) return null;
    if (dsStats.stage1_pass === 0) return "stage1";
    if (dsStats.stage2_pass === 0) return "stage2";
    return null;
  }, [dsStats]);
  const dsTopRejects = useMemo(() => Object.entries(dsStats && dsStats.rejects || {}).slice(0, 6), [dsStats]);
  const dsObsIV = dsStats && dsStats.observed && dsStats.observed.iv || null;
  // Set the floor from what the scan actually saw, rather than guessing.
  const dsUseObservedIV = pct => {
    const v = Math.max(Math.floor(pct * 100), 1);
    const n = {
      ...dsCfg,
      ivMin: v,
      ivMax: Math.max(+dsCfg.ivMax, Math.ceil(dsObsIV.max * 100) + 10)
    };
    setDsCfg(n);
    try {
      localStorage.setItem(DISCOVER_CFG_SK, JSON.stringify(n));
    } catch (e) {}
    setDsStatus(`IV floor set to ${v}% from the last scan's own range. Press Scan again.`);
  };

  // Back off the request rate rather than the screening criteria.
  const dsSlowDown = () => {
    const n = {
      ...dsCfg,
      requestsPerSecond: Math.max(Math.min(+dsCfg.requestsPerSecond || 5, 3) - 1, 1),
      workers: Math.max(Math.min(+dsCfg.workers || 4, 2), 1)
    };
    setDsCfg(n);
    try {
      localStorage.setItem(DISCOVER_CFG_SK, JSON.stringify(n));
    } catch (e) {}
    setDsStatus(`Slowed to ${n.requestsPerSecond}/sec on ${n.workers} worker${n.workers === 1 ? "" : "s"}. Wait a couple of minutes for Yahoo's limit to reset, then Scan again.`);
  };

  // One-click widening of whichever stage came up empty.
  const dsLoosen = () => {
    const n = {
      ...dsCfg
    };
    if (dsBlame === "stage1") {
      n.marginMin = 0;
      n.roeMin = 0;
      n.revGrowthMin = -100;
      n.peMax = Math.max(+n.peMax, 150);
      n.marketCapMin = Math.min(+n.marketCapMin, 2);
      n.avgVolumeMin = Math.min(+n.avgVolumeMin, 0.3);
      n.priceMin = Math.min(+n.priceMin, 10);
      n.priceMax = Math.max(+n.priceMax, 2000);
      n.positiveEPS = false;
    } else {
      // Widen the contract screen: the bands first, then the liquidity floors.
      n.ivMin = Math.max(Math.min(+n.ivMin, 20) - 5, 5);
      n.ivMax = Math.max(+n.ivMax, 300);
      n.deltaMin = Math.min(+n.deltaMin, 0.05);
      n.deltaMax = Math.max(+n.deltaMax, 0.50);
      n.dteMin = Math.min(+n.dteMin, 7);
      n.dteMax = Math.max(+n.dteMax, 60);
      n.minOI = Math.min(+n.minOI, 50);
      n.maxSpreadPct = Math.max(+n.maxSpreadPct, 30);
      n.minAnnualized = 0;
      n.minPremium = Math.min(+n.minPremium, 0.05);
      n.maxExpiries = Math.max(+n.maxExpiries, 3);
    }
    setDsCfg(n);
    try {
      localStorage.setItem(DISCOVER_CFG_SK, JSON.stringify(n));
    } catch (e) {}
    setDsStatus(dsBlame === "stage1" ? "Quality floors relaxed (margin, ROE, growth, P/E, size). Press Scan again." : "Option filters relaxed (IV band, chain open interest, expiry window). Press Scan again.");
    setDsShowCfg(true);
  };
  // A sector held over from a previous run won't be in the list any more.
  const dsSectorStale = dsSector !== "all" && !dsSectors.includes(dsSector);
  const dsAgeDays = useMemo(() => {
    if (!dsSaved || !dsSaved.ranAt) return null;
    return Math.floor((Date.now() - new Date(dsSaved.ranAt).getTime()) / 86400000);
  }, [dsSaved]);
  const dsTogglePick = t => setDsPicked(p => {
    const n = new Set(p);
    n.has(t) ? n.delete(t) : n.add(t);
    return n;
  });
  const dsAddPicked = () => {
    if (!dsPicked.size) return;
    const next = {
      ...watchlist
    };
    let added = 0;
    (dsSaved && dsSaved.rows || []).forEach(r => {
      if (dsPicked.has(r.Ticker) && watchlist[r.Ticker] === undefined) {
        next[r.Ticker] = r.Name || "";
        added++;
      }
    });
    saveWatchlist(next);
    setDsStatus(`✅ Added ${added} ticker${added === 1 ? "" : "s"} to your watchlist. They'll be included in the next screen.`);
    setDsPicked(new Set());
  };
  const removeWatchlist = t => {
    const next = {
      ...watchlist
    };
    delete next[t];
    saveWatchlist(next);
    setWlStatus(`Removed ${t}.` + (autoTickers.has(t) ? " It's still screened because you hold or have traded it — untick it instead to skip it." : ""));
  };
  const ratchetATH = candidates => {
    const changes = [];
    setAthPrices(prev => {
      let changed = false;
      const next = {
        ...prev
      };
      Object.entries(candidates).forEach(([sym, price]) => {
        if (price == null || isNaN(price)) return;
        const cur = next[sym];
        if (!cur || price > cur.price) {
          changes.push({
            sym,
            from: cur ? cur.price : null,
            to: price
          });
          next[sym] = {
            price,
            date: new Date().toISOString().split("T")[0]
          };
          changed = true;
        }
      });
      if (changed) {
        try {
          localStorage.setItem("ath_prices", JSON.stringify(next));
        } catch (e) {}
      }
      return changed ? next : prev;
    });
    return changes;
  };
  const fetchIndicesOnly = async key => {
    if (!key) return [];
    const results = await Promise.allSettled(Object.keys(INDEX_TICKERS).map(async tk => {
      const res = await fetch(`https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(tk)}&token=${key}&_=${Date.now()}`, {
        signal: AbortSignal.timeout(8000),
        cache: "no-store"
      });
      if (!res.ok) throw new Error("HTTP " + res.status);
      const d = await res.json();
      return {
        tk,
        p: d?.c || d?.pc || null,
        pc: d?.pc || null,
        h: d?.h || null
      };
    }));
    const newIdx = {};
    const athCandidates = {};
    results.forEach(r => {
      if (r.status === "fulfilled" && r.value.p > 0) {
        const chg = r.value.pc ? (r.value.p - r.value.pc) / r.value.pc * 100 : null;
        newIdx[r.value.tk] = {
          name: INDEX_TICKERS[r.value.tk],
          price: r.value.p,
          changePct: chg
        };
        athCandidates[r.value.tk] = Math.max(r.value.p, r.value.h || 0);
      }
    });
    if (Object.keys(newIdx).length) {
      setIndexPrices(newIdx);
      try {
        localStorage.setItem("index_prices", JSON.stringify(newIdx));
      } catch (e) {}
      return ratchetATH(athCandidates);
    }
    return [];
  };
  useEffect(() => {
    fetchIndicesOnly(fhKey);
  }, []);
  useEffect(() => {
    if (!quoteModalTicker || !chartContainerRef.current) return;
    const container = chartContainerRef.current;
    container.innerHTML = "";
    const widgetDiv = document.createElement("div");
    widgetDiv.className = "tradingview-widget-container__widget";
    container.appendChild(widgetDiv);
    const script = document.createElement("script");
    script.type = "text/javascript";
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-symbol-overview.js";
    script.async = true;
    script.text = JSON.stringify({
      symbols: [[quoteModalTicker]],
      chartOnly: false,
      width: "100%",
      height: "480",
      locale: "en",
      colorTheme: "dark",
      autosize: true,
      showVolume: false,
      showMA: false,
      hideDateRanges: false,
      hideMarketStatus: false,
      hideSymbolLogo: false,
      scalePosition: "right",
      scaleMode: "Normal",
      fontFamily: "system-ui, sans-serif",
      fontSize: "10",
      noTimeScale: false,
      valuesTracking: "1",
      changeMode: "price-and-percent",
      lineWidth: 2,
      lineType: 0,
      dateRanges: ["1d|1", "1m|30", "3m|60", "12m|1D", "60m|1W", "all|1M"]
    });
    container.appendChild(script);
    return () => {
      container.innerHTML = "";
    };
  }, [quoteModalTicker]);
  const handleSubmit = () => {
    if (!form.date || !form.ticker || !form.strike) {
      alert("Date, Ticker, and Strike required.");
      return;
    }
    const sells = calcSells(form.sb, form.sellPremium, form.contracts);
    const buys = calcBuys(form.sb, form.sellPremium, form.contracts);
    const total = sells + buys;
    const trade = {
      id: editId || Date.now(),
      ...form,
      sells,
      buys,
      total,
      netPL: total,
      closeDate: "",
      closePremium: ""
    };
    trade.moneyOnHold = calcMOH(trade);
    save(editId ? trades.map(t => t.id === editId ? trade : t) : [...trades, trade]);
    setForm(EMPTY);
    setEditId(null);
    setShowForm(false);
  };

  // Which lots a call assignment would consume, oldest first. Pure — it works
  // out the plan without changing anything, so it can be shown for approval
  // before a single holding is touched.
  const planCalledAway = (t, soldDate) => {
    const need = (parseInt(t.contracts) || 1) * 100;
    const px = parseFloat(t.strike);
    const acct = (t.account || "").trim();
    const tk = (t.ticker || "").trim().toUpperCase();
    const lots = stocks.filter(s => (s.account || "").trim() === acct && (s.ticker || "").trim().toUpperCase() === tk && !isStockSold(s) && (parseFloat(s.shares) || 0) > 0)
    // FIFO. Undated lots sort last rather than first, so a lot with a missing
    // date is never quietly sold ahead of one you can actually date.
    .sort((a, b) => (a.dateAcquired || "9999-12-31").localeCompare(b.dateAcquired || "9999-12-31"));
    let remaining = need;
    const steps = [];
    for (const lot of lots) {
      if (remaining <= 0) break;
      const have = parseFloat(lot.shares) || 0;
      const take = Math.min(have, remaining);
      remaining -= take;
      steps.push({
        lot,
        take,
        split: take < have
      });
    }
    return {
      need,
      px,
      acct,
      tk,
      steps,
      short: remaining,
      sold: need - remaining
    };
  };

  // Both share-moving effects in one place, used by the Close dialog and by
  // inline editing alike. Returns {ok, apply}: `ok` is false only when you
  // cancel, and `apply` is called after the trade itself has been saved, so a
  // cancellation can never leave one side updated and the other not.
  //
  // `prevAction` guards against re-running. Re-saving a row that was already
  // Assigned or Called Away must not create a second holding or sell the
  // shares twice — only the transition into the status counts.
  const prepareShareEffect = (t, action, dateStr, prevAction) => {
    if (action === prevAction) return {
      ok: true,
      apply: null
    };
    if (action === "Called Away" && t.cp === "C") {
      const plan = planCalledAway(t, dateStr);
      const lines = plan.steps.map(s => `   • ${s.take} sh acquired ${s.lot.dateAcquired || "(no date)"} at cost ${fmt$(s.lot.costBasis)}` + (s.split ? `  (splitting a ${s.lot.shares} sh lot)` : ""));
      let msg = `Called away: ${t.contracts || 1} ${t.ticker} call${(parseInt(t.contracts) || 1) > 1 ? "s" : ""} ` + `at ${fmt$(t.strike)} — ${plan.need} shares from ${plan.acct}\n\n`;
      msg += plan.steps.length ? `Will sell, oldest lot first:\n${lines.join("\n")}\n\n` : "No matching shares found in that account.\n\n";
      msg += `Proceeds ${fmt$(plan.sold * plan.px)}   (${plan.sold} sh at ${fmt$(plan.px)})\n`;
      if (plan.short > 0) msg += `\n⚠ ${plan.acct} is ${plan.short} shares short of the ${plan.need} called away.\n` + `The option will still be marked Called Away — check your holdings afterwards.\n`;
      msg += `\nContinue?`;
      if (!window.confirm(msg)) return {
        ok: false,
        apply: null
      };
      return {
        ok: true,
        apply: () => {
          const patch = {},
            adds = [];
          plan.steps.forEach((s, i) => {
            if (!s.split) {
              patch[s.lot.id] = {
                ...s.lot,
                status: "Sold",
                soldDate: dateStr,
                soldPrice: plan.px.toFixed(2)
              };
            } else {
              // Part of the lot was called: the rest keeps its original cost
              // basis and acquisition date, so the remainder stays accurate.
              const left = (parseFloat(s.lot.shares) || 0) - s.take;
              patch[s.lot.id] = {
                ...s.lot,
                shares: String(left)
              };
              adds.push({
                ...s.lot,
                id: Date.now() + 2 + i,
                shares: String(s.take),
                status: "Sold",
                soldDate: dateStr,
                soldPrice: plan.px.toFixed(2)
              });
            }
          });
          saveStocks(stocks.map(s => patch[s.id] || s).concat(adds));
          if (plan.short > 0) {
            alert(`⚠ ${plan.tk}: ${plan.need} shares were called away but ${plan.acct} ` + `held only ${plan.sold}.\n\nSold ${plan.sold} at ${fmt$(plan.px)} and marked the ` + `option Called Away.\n${plan.short} shares are unaccounted for — check your holdings.`);
          }
        }
      };
    }
    if (action === "Assigned" && t.cp === "P") {
      const shares = (parseInt(t.contracts) || 1) * 100;
      const msg = `Assigned: ${t.contracts || 1} ${t.ticker} put${(parseInt(t.contracts) || 1) > 1 ? "s" : ""} ` + `at ${fmt$(t.strike)}\n\nWill add ${shares} shares to ${t.account} at a cost basis of ` + `${fmt$(t.strike)}  (${fmt$(shares * (parseFloat(t.strike) || 0))} total).\n\nContinue?`;
      if (!window.confirm(msg)) return {
        ok: false,
        apply: null
      };
      return {
        ok: true,
        apply: () => {
          saveStocks([...stocks, {
            id: Date.now() + 1,
            // +1 avoids a same-millisecond id clash with the trade save
            account: t.account,
            ticker: t.ticker,
            company: t.company || tickerName(t.ticker) || "",
            shares: shares.toString(),
            dateAcquired: dateStr,
            costBasis: t.strike,
            currentPrice: t.currentStock || t.strike,
            status: "Assigned",
            soldDate: "",
            soldPrice: ""
          }]);
        }
      };
    }
    return {
      ok: true,
      apply: null
    };
  };
  const handleClose = () => {
    if (!closeForm.closeDate || !closeForm.action) {
      alert("Fill in close date and action.");
      return;
    }
    const t = closeTarget;
    const eff = prepareShareEffect(t, closeForm.action, closeForm.closeDate, t.action || "Open");
    if (!eff.ok) return;

    // Rolling opens the replacement in the same breath as closing the old one.
    // Built before the save so a bad entry stops the whole thing rather than
    // closing the position and leaving you with nothing open.
    let rollTrade = null;
    if (closeForm.action === "Rolled") {
      const {
        rollExp,
        rollStrike,
        rollPrem,
        rollQty
      } = closeForm;
      if (rollExp || rollStrike || rollPrem) {
        const qty = parseInt(rollQty) || 0;
        if (!rollExp || !rollStrike || !rollPrem || !qty) {
          alert("To roll, fill in the new expiry, strike, premium and contracts — or clear all four to just close this position.");
          return;
        }
        if (new Date(rollExp + "T00:00:00") <= new Date(closeForm.closeDate + "T00:00:00")) {
          alert("The new expiry must be after the close date.");
          return;
        }
        const sells = calcSells(t.sb, rollPrem, qty);
        const buys = calcBuys(t.sb, rollPrem, qty);
        const total = sells + buys;
        rollTrade = {
          id: Date.now() + 3,
          // clear of the trade save and any share effect
          rolledFromId: t.id,
          // exact chain link; history is inferred instead
          account: t.account,
          ticker: t.ticker,
          company: t.company || "",
          cp: t.cp,
          sb: t.sb,
          // a roll keeps the same side
          date: closeForm.closeDate,
          // opened the day the old one closed
          strike: rollStrike,
          expDate: rollExp,
          sellPremium: rollPrem,
          contracts: String(qty),
          currentStock: t.currentStock || "",
          sells,
          buys,
          total,
          netPL: total,
          action: "Open",
          closeDate: "",
          closePremium: ""
        };
        rollTrade.moneyOnHold = calcMOH(rollTrade);
      }
    }
    const netPL = calcNetPL(t.total, closeForm.closePremium, closeForm.action);
    const closed = trades.map(tr => tr.id === t.id ? {
      ...tr,
      action: closeForm.action,
      closeDate: closeForm.closeDate,
      closePremium: closeForm.closePremium,
      netPL,
      moneyOnHold: 0,
      ...(rollTrade ? {
        rolledToId: rollTrade.id
      } : {})
    } : tr);
    save(rollTrade ? [...closed, rollTrade] : closed);
    if (eff.apply) eff.apply();
    setCloseTarget(null);
  };
  const fixAllPL = () => {
    if (!window.confirm("Recalculate all Net P&L?")) return;
    save(trades.map(sanitize));
    alert("✅ Done!");
  };

  // ── Stock holdings handlers ──────────────────────────
  const handleStockTicker = v => {
    const t = v.toUpperCase();
    const learned = stocks.find(s => s.ticker === t && s.company)?.company || trades.find(tr => tr.ticker === t && tr.company)?.company;
    setStockForm(f => ({
      ...f,
      ticker: t,
      company: learned || tickerName(t) || f.company
    }));
  };
  const handleStockSubmit = () => {
    if (!stockForm.ticker || !stockForm.shares || !stockForm.costBasis) {
      alert("Ticker, Shares, and Cost Basis are required.");
      return;
    }
    const obj = {
      id: stockEditId || Date.now(),
      ...stockForm
    };
    saveStocks(stockEditId ? stocks.map(s => s.id === stockEditId ? obj : s) : [...stocks, obj]);
    setStockForm(EMPTY_STOCK);
    setStockEditId(null);
    setShowStockForm(false);
  };
  const startStockEdit = s => {
    setStockForm({
      ...s
    });
    setStockEditId(s.id);
    setShowStockForm(true);
  };
  const startStockInlineEdit = s => {
    setStockInlineEditId(s.id);
    setStockInlineForm({
      ...s
    });
  };
  const cancelStockInlineEdit = () => {
    setStockInlineEditId(null);
    setStockInlineForm({});
  };
  const saveStockInlineEdit = () => {
    saveStocks(stocks.map(s => s.id === stockInlineEditId ? {
      ...stockInlineForm
    } : s));
    setStockInlineEditId(null);
    setStockInlineForm({});
  };
  const deleteStock = id => {
    if (window.confirm("Delete this holding?")) saveStocks(stocks.filter(s => s.id !== id));
  };
  const deleteSelectedStocks = () => {
    if (!stockSelected.size) return;
    if (window.confirm(`Delete ${stockSelected.size} holdings?`)) {
      saveStocks(stocks.filter(s => !stockSelected.has(s.id)));
      setStockSelected(new Set());
    }
  };
  const toggleStockSel = id => setStockSelected(s => {
    const n = new Set(s);
    n.has(id) ? n.delete(id) : n.add(id);
    return n;
  });
  const openSellModal = s => {
    setSellTarget(s);
    setSellForm({
      sharesToSell: s.shares,
      soldDate: "",
      soldPrice: ""
    });
  };
  const handleSell = () => {
    const t = sellTarget;
    const sellQty = parseFloat(sellForm.sharesToSell);
    const heldQty = parseFloat(t.shares);
    if (!sellQty || sellQty <= 0) {
      alert("Enter a valid number of shares to sell.");
      return;
    }
    if (sellQty > heldQty) {
      alert(`You only hold ${heldQty} shares — can't sell ${sellQty}.`);
      return;
    }
    if (!sellForm.soldDate || !sellForm.soldPrice) {
      alert("Sold Date and Sold Price are required.");
      return;
    }
    const soldLot = {
      id: Date.now(),
      account: t.account,
      ticker: t.ticker,
      company: t.company,
      shares: sellQty.toString(),
      dateAcquired: t.dateAcquired,
      costBasis: t.costBasis,
      currentPrice: t.currentPrice,
      status: "Sold",
      soldDate: sellForm.soldDate,
      soldPrice: sellForm.soldPrice
    };
    const remaining = heldQty - sellQty;
    let updated;
    if (remaining > 0) {
      updated = stocks.map(s => s.id === t.id ? {
        ...s,
        shares: remaining.toString()
      } : s);
      updated = [...updated, soldLot];
    } else {
      updated = stocks.map(s => s.id === t.id ? soldLot : s);
    }
    saveStocks(updated);
    setSellTarget(null);
  };
  const openBuyModal = s => {
    setBuyTarget(s);
    setBuyForm({
      sharesToBuy: "",
      purchaseDate: "",
      newCostBasis: ""
    });
  };
  const handleBuy = () => {
    const t = buyTarget;
    const newQty = parseFloat(buyForm.sharesToBuy);
    const newPrice = parseFloat(buyForm.newCostBasis);
    const existQty = parseFloat(t.shares) || 0;
    const existCB = parseFloat(t.costBasis) || 0;
    if (!newQty || newQty <= 0) {
      alert("Enter a valid number of shares purchased.");
      return;
    }
    if (!newPrice || newPrice <= 0) {
      alert("Enter a valid cost basis for the new shares.");
      return;
    }
    if (!buyForm.purchaseDate) {
      alert("Purchase Date is required.");
      return;
    }
    const totalQty = existQty + newQty;
    const avgCostBasis = (existQty * existCB + newQty * newPrice) / totalQty;
    const earliestDate = t.dateAcquired && buyForm.purchaseDate ? t.dateAcquired < buyForm.purchaseDate ? t.dateAcquired : buyForm.purchaseDate : t.dateAcquired || buyForm.purchaseDate;
    const updated = stocks.map(s => s.id === t.id ? {
      ...s,
      shares: totalQty.toString(),
      costBasis: avgCostBasis.toFixed(4).replace(/\.?0+$/, "") || avgCostBasis.toFixed(2),
      dateAcquired: earliestDate
    } : s);
    saveStocks(updated);
    setBuyTarget(null);
  };
  const handleExcel = async () => {
    setXlBusy(true);
    try {
      await generateExcel(trades, stocks);
    } catch (e) {
      alert("Excel failed: " + e.message);
    }
    setXlBusy(false);
  };
  const saveToFile = () => {
    if (!trades.length && !stocks.length && !Object.keys(watchlist).length) {
      alert("No data to save.");
      return;
    }
    const data = JSON.stringify({
      version: 4,
      exportedAt: new Date().toISOString(),
      trades,
      stocks,
      watchlist,
      excluded: [...wlExcluded]
    }, null, 2);
    try {
      const r = window.__TRACKER__.saveBackup(data);
      alert(`✅ Backup saved:\n${r.file}`);
    } catch (err) {
      alert("Backup failed: " + err.message);
    }
  };
  const loadFromFile = e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const parsed = JSON.parse(ev.target.result);
        const loadedTrades = Array.isArray(parsed) ? parsed : parsed.trades || [];
        const loadedStocks = Array.isArray(parsed) ? [] : parsed.stocks || [];
        // v3 backups carry the watchlist; older ones don't, and that's fine.
        const loadedWatchlist = !Array.isArray(parsed) && parsed.watchlist && typeof parsed.watchlist === "object" ? parsed.watchlist : null;
        // v4 adds the excluded list. Absent in older backups, which is fine.
        const loadedExcluded = !Array.isArray(parsed) && Array.isArray(parsed.excluded) ? parsed.excluded : null;
        if (!Array.isArray(loadedTrades)) {
          alert("Invalid backup file.");
          return;
        }
        const sanitizedTrades = loadedTrades.map(sanitize);
        const hasStocks = loadedStocks.length > 0;
        const tradeKey = t => `${t.account}|${t.date}|${t.ticker}|${t.strike}|${t.expDate}|${t.cp}|${t.sb}|${t.contracts}|${t.sellPremium}`;
        const stockKey = s => `${s.account}|${s.ticker}|${s.dateAcquired}|${s.shares}|${s.costBasis}|${s.status}|${s.soldDate || ""}|${s.soldPrice || ""}`;
        const existingTradeKeys = new Set(trades.map(tradeKey));
        const existingStockKeys = new Set(stocks.map(stockKey));
        const newTrades = sanitizedTrades.filter(t => !existingTradeKeys.has(tradeKey(t)));
        const dupTrades = sanitizedTrades.length - newTrades.length;
        const newStocks = loadedStocks.filter(s => !existingStockKeys.has(stockKey(s)));
        const dupStocks = loadedStocks.length - newStocks.length;
        const msg = hasStocks ? `Backup has ${sanitizedTrades.length} trades (${dupTrades} already exist) and ${loadedStocks.length} stock holdings (${dupStocks} already exist).\n\nOK = Merge — add only the ${newTrades.length} new trades and ${newStocks.length} new holdings\nCancel = Replace all existing data with this backup` : `Backup has ${sanitizedTrades.length} trades (${dupTrades} already exist). No stock holdings in this backup.\n\nOK = Merge — add only the ${newTrades.length} new trades\nCancel = Replace all existing data with this backup`;
        const newWatch = loadedWatchlist ? Object.keys(loadedWatchlist).filter(k => !watchlist[k]).length : 0;
        if (window.confirm(msg)) {
          save([...trades, ...newTrades]);
          if (hasStocks) saveStocks([...stocks, ...newStocks]);
          // Merge keeps your current names and adds any the backup has.
          if (loadedWatchlist) saveWatchlist({
            ...loadedWatchlist,
            ...watchlist
          });
          alert(`✅ Merged! Added ${newTrades.length} new trades${hasStocks ? ` and ${newStocks.length} new holdings` : ""}${newWatch ? ` and ${newWatch} watchlist tickers` : ""} (skipped ${dupTrades + dupStocks} duplicates).`);
        } else {
          save(sanitizedTrades);
          if (hasStocks) saveStocks(loadedStocks);
          if (loadedWatchlist) saveWatchlist(loadedWatchlist);
          if (loadedExcluded) saveExcluded(new Set(loadedExcluded));
          alert(`✅ Replaced with backup: ${sanitizedTrades.length} trades${hasStocks ? ` and ${loadedStocks.length} holdings` : ""}${loadedWatchlist ? ` and ${Object.keys(loadedWatchlist).length} watchlist tickers` : ""}.`);
        }
      } catch (err) {
        alert("Failed to load file: " + err.message);
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  // Where the US market is in its day, computed in New York time whatever
  // timezone this browser is in. Knows nothing about market holidays, so it
  // will call a Thanksgiving Thursday "open".
  const usMarketState = () => {
    try {
      const ny = new Date(new Date().toLocaleString("en-US", {
        timeZone: "America/New_York"
      }));
      const day = ny.getDay(),
        mins = ny.getHours() * 60 + ny.getMinutes();
      const clock = ny.toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit"
      });
      if (day === 0 || day === 6) return {
        open: false,
        why: `US market shut for the weekend (${clock} in New York)`
      };
      if (mins < 9 * 60 + 30) return {
        open: false,
        why: `US market hasn't opened yet (${clock} in New York)`
      };
      if (mins >= 16 * 60) return {
        open: false,
        why: `US market closed for the day (${clock} in New York)`
      };
      return {
        open: true,
        why: `US market open (${clock} in New York)`
      };
    } catch (e) {
      return {
        open: null,
        why: ""
      };
    }
  };
  const refreshPrices = async () => {
    // No key check up front any more -- the screener service can serve prices
    // without one. The two sources are tried below and only both failing is an
    // error worth stopping for.
    const openTrades = trades.filter(isOpen);
    setRefreshing(true);
    setRefreshStatus("Fetching live prices…");
    const tickers = [...new Set(openTrades.map(t => t.ticker))];
    const stockTickers = [...new Set(stocks.filter(s => s.status !== "Sold").map(s => s.ticker).filter(Boolean))];
    const allTickers = [...new Set([...tickers, ...stockTickers, ...Object.keys(INDEX_TICKERS)])];
    const prices = {};

    // Two sources, in order of trust. The screener service goes through
    // yfinance and works wherever the screener does. Finnhub is fetched
    // straight from this browser, and a free real-time US quote is an
    // exchange-licensed product -- it can be answered with a stale last close
    // and no error at all, which is exactly what happened from India.
    let results = null,
      source = "",
      srcNote = "";
    const viaService = async () => {
      if (!(await checkScrService())) return null;
      try {
        const res = await fetch(`${SCREENER_URL}/prices`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          signal: AbortSignal.timeout(120000),
          body: JSON.stringify({
            tickers: allTickers,
            options: {
              requestsPerSecond: 8,
              workers: 6
            }
          })
        });
        const d = await res.json();
        if (!res.ok || !d.ok) throw new Error(d.error || "HTTP " + res.status);
        const q = d.quotes || {},
          e = d.errors || {};
        if (!Object.keys(q).length) return null; // fall through to Finnhub
        return allTickers.map(tk => {
          // The service normalises symbols to upper case; a trade entered as
          // "aapl " would otherwise silently come back unquoted.
          const v = q[tk] || q[String(tk).trim().toUpperCase()];
          if (!v) return {
            status: "fulfilled",
            value: {
              tk,
              p: null,
              why: e[tk] || "no quote returned"
            }
          };
          return {
            status: "fulfilled",
            value: {
              tk,
              p: v.price,
              pc: v.prev_close,
              h: v.high ?? null,
              // Seconds, to match the Finnhub shape downstream.
              ts: v.asof ? Math.floor(new Date(v.asof).getTime() / 1000) : null,
              asofDate: v.asof_date || "",
              pd: v.prev_date || null,
              ps: v.prev_source || "",
              why: null
            }
          };
        });
      } catch (e) {
        return null;
      }
    };
    const viaFinnhub = async () => {
      if (!fhKey) return null;
      // Catch inside, so a rejected fetch still carries its ticker and reason
      // out. Previously a network failure lost both and the run reported
      // "0 prices updated" with nothing failed -- silence exactly when it mattered.
      return await Promise.allSettled(allTickers.map(async tk => {
        try {
          const res = await fetch(`https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(tk)}&token=${fhKey}&_=${Date.now()}`, {
            signal: AbortSignal.timeout(8000),
            cache: "no-store"
          });
          if (!res.ok) {
            const s = res.status;
            throw new Error(s === 401 || s === 403 ? `key rejected (HTTP ${s})` : s === 429 ? "rate limited by Finnhub (HTTP 429)" : `HTTP ${s}`);
          }
          const d = await res.json();
          return {
            tk,
            p: d?.c || d?.pc || null,
            pc: d?.pc || null,
            h: d?.h || null,
            ts: d?.t || null,
            why: null
          };
        } catch (e) {
          const why = e && (e.name === "TimeoutError" || e.name === "AbortError") ? "timed out after 8s" : e && e.message === "Failed to fetch" ? "could not reach finnhub.io (blocked or offline)" : e && e.message || String(e);
          return {
            tk,
            p: null,
            why
          };
        }
      }));
    };
    setRefreshStatus("Fetching live prices via the screener service…");
    results = await viaService();
    if (results) {
      source = "screener service";
    } else {
      setRefreshStatus("Fetching live prices from Finnhub…");
      results = await viaFinnhub();
      source = "Finnhub";
      srcNote = " (screener service unavailable)";
    }
    if (!results) {
      setRefreshing(false);
      setRefreshStatus("❌ No price source available — start the screener service, or enter a Finnhub key.");
      return;
    }
    let ok = 0,
      err = 0,
      newestTs = 0;
    const newIdx = {};
    const allPrices = {};
    const allChanges = {};
    const athCandidates = {};
    const fails = {};
    results.forEach(r => {
      const v = r.status === "fulfilled" ? r.value : {
        tk: "?",
        p: null,
        why: "unexpected error"
      };
      if (!(v.p > 0)) {
        if (tickers.includes(v.tk)) err++;
        const why = v.why || "no price in the response";
        fails[why] = (fails[why] || 0) + 1;
        return;
      }
      if (v.ts && v.ts > newestTs) newestTs = v.ts;
      const absChg = v.pc ? v.p - v.pc : null;
      const pctChg = v.pc ? (v.p - v.pc) / v.pc * 100 : null;
      if (INDEX_TICKERS[v.tk]) {
        newIdx[v.tk] = {
          name: INDEX_TICKERS[v.tk],
          price: v.p,
          changePct: pctChg
        };
        athCandidates[v.tk] = Math.max(v.p, v.h || 0);
      }
      allPrices[v.tk] = v.p;
      // Carry the date the change is measured against. If a session is missing
      // from the feed this is not yesterday, and the cell should admit that
      // rather than calling a three-day move a day change.
      if (absChg != null && pctChg != null) allChanges[v.tk] = {
        abs: absChg,
        pct: pctChg,
        pd: v.pd || null,
        ps: v.ps || ""
      };
      if (tickers.includes(v.tk)) {
        prices[v.tk] = v.p;
        ok++;
      }
    });
    if (Object.keys(allChanges).length) {
      setTickerChange(allChanges);
      try {
        localStorage.setItem("ticker_change", JSON.stringify(allChanges));
      } catch (e) {}
    }
    // Same trap as the option quotes: the Day Chg cells look this map up by the
    // ticker exactly as typed on the row. "31/31 day changes" can be true while
    // every cell reads "—" if those two strings differ by a space or a case.
    const wantChg = [...new Set([...openTrades.map(t => t.ticker), ...stockTickers])].filter(Boolean);
    const chgHits = wantChg.filter(tk => allChanges[tk]).length;
    let chgNote = "";
    if (wantChg.length && Object.keys(allChanges).length && chgHits === 0) {
      chgNote = ` · ⚠ DAY CHG KEY MISMATCH — stored "${Object.keys(allChanges)[0]}" but the row wants "${wantChg[0]}"`;
    } else if (wantChg.length && chgHits < wantChg.length) {
      chgNote = ` · ${chgHits}/${wantChg.length} rows matched a day change`;
    }
    const updated = trades.map(t => {
      if (!isOpen(t) || !prices[t.ticker]) return t;
      return {
        ...t,
        currentStock: prices[t.ticker].toFixed(2)
      };
    });
    save(updated);
    if (stockTickers.length) {
      const updatedStocks = stocks.map(s => {
        if (s.status === "Sold" || !allPrices[s.ticker]) return s;
        return {
          ...s,
          currentPrice: allPrices[s.ticker].toFixed(2)
        };
      });
      saveStocks(updatedStocks);
    }
    if (Object.keys(newIdx).length) {
      setIndexPrices(newIdx);
      try {
        localStorage.setItem("index_prices", JSON.stringify(newIdx));
      } catch (e) {}
      ratchetATH(athCandidates);
    }
    const changeCount = Object.keys(allChanges).length;
    const gotAny = Object.keys(allPrices).length;
    const failList = Object.entries(fails).sort((a, b) => b[1] - a[1]).map(([w, n]) => `${w} (${n})`).join(" · ");
    const mkt = usMarketState();
    // Compare the newest quote against the New York calendar date, not this
    // machine's. A laptop that is still on US time and one that is on IST
    // otherwise disagree about what "today" means.
    const nyToday = (() => {
      try {
        return new Date().toLocaleDateString("en-CA", {
          timeZone: "America/New_York"
        });
      } catch (e) {
        return "";
      }
    })();
    const newestDay = newestTs ? (() => {
      try {
        return new Date(newestTs * 1000).toLocaleDateString("en-CA", {
          timeZone: "America/New_York"
        });
      } catch (e) {
        return "";
      }
    })() : "";
    const stale = !!(newestDay && nyToday && newestDay < nyToday);
    let msg;
    if (!gotAny) {
      // Nothing arrived at all. That is a connection or key problem, never a
      // quiet market -- say so instead of showing a cheerful tick.
      msg = `❌ No prices came back from ${source} — ${failList || "unknown reason"}`;
    } else {
      msg = `✅ ${ok}/${tickers.length} prices updated · ${changeCount}/${allTickers.length} day changes · via ${source}${srcNote}`;
      if (failList) msg += ` · failed: ${failList}`;
      if (newestDay) msg += ` · newest quote ${newestDay} (New York)`;
      if (stale && mkt.open) {
        // The decisive case: market trading, feed handing back an older
        // session. Not a quiet tape, and not something to shrug at.
        msg += ` · ⚠ STALE — the market is open (${mkt.why}) but ${source} returned ` + `${nyToday > newestDay ? "an earlier session's" : "an old"} close. These are not live prices.`;
      } else if (mkt.open === false) {
        // If the market is shut, the numbers are *supposed* to be identical to
        // the last press. Saying so stops it looking like a broken refresh.
        msg += ` · ${mkt.why}, so these are last-close prices and won't move until it reopens`;
      }
      msg += chgNote;
    }
    setRefreshStatus(msg);

    // Contract prices for open positions. Needs the screener service, since
    // option chains can't be fetched from the browser — so this half is
    // best-effort and never blocks the stock refresh above.
    const optMsg = await refreshOptionQuotes(openTrades);
    setRefreshing(false);
    let finalMsg = msg;
    if (optMsg) finalMsg = msg + " · " + optMsg;
    if (serviceStale) finalMsg += ` · ⚠ SERVICE IS RUNNING OLD CODE (v${scrVersion}, this page needs v${NEEDS_SERVICE}) — ` + `close the service window completely and relaunch. The launcher reuses a service already on port 8765, ` + `so simply running the .bat again does NOT reload the Python.`;
    setRefreshStatus(finalMsg);
    // Only clear a clean run. A warning that erases itself after ten seconds is
    // how the option-quote failures stayed invisible -- leave those up until
    // the next refresh so there is something to read and report.
    if (!/[⚠❌]/.test(finalMsg)) setTimeout(() => setRefreshStatus(""), 10000);
  };

  // ── Live prices for the option contracts you actually hold ──
  const refreshOptionQuotes = async openTrades => {
    const cons = (openTrades || []).filter(t => t.ticker && t.expDate && t.strike).map(t => ({
      id: t.id,
      ticker: (t.ticker || "").trim().toUpperCase(),
      expiry: String(t.expDate).slice(0, 10),
      strike: parseFloat(t.strike),
      cp: (t.cp || "P").toUpperCase()
    }));
    if (!cons.length) return "";
    setRefreshStatus(s => s + ` · pricing ${cons.length} contracts…`);
    const alive = await checkScrService();
    if (!alive) return "⚠ option prices skipped (screener service offline)";
    try {
      const res = await fetch(`${SCREENER_URL}/quotes`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        signal: AbortSignal.timeout(180000),
        body: JSON.stringify({
          contracts: cons,
          criteria: {
            requestsPerSecond: 8
          }
        })
      });
      const d = await res.json();
      if (!res.ok || !d.ok) throw new Error(d.error || "HTTP " + res.status);
      const map = {};
      let got = 0;
      (d.results || []).forEach(r => {
        const key = quoteKey(r.ticker, r.expiry, r.strike, r.cp);
        map[key] = {
          last: r.last,
          bid: r.bid,
          ask: r.ask,
          mid: r.mid,
          iv: r.iv,
          oi: r.openInterest,
          vol: r.volume,
          err: r.error || "",
          lastTrade: r.lastTrade || null,
          lastStale: r.lastStale === true,
          offMarket: r.offMarket === true,
          expired: !!r.expired,
          at: Date.now()
        };
        if (r.last != null || r.mid != null) got++;
      });
      saveOptQuotes({
        ...optQuotes,
        ...map
      });
      // Quotes arriving and quotes displaying are two different things. The
      // rows look them up with a key built from the raw trade fields; if that
      // disagrees with the key they were stored under, everything above
      // succeeds and every cell stays blank. Check it and print both keys.
      const stored = Object.keys(map);
      const rowsWanting = (openTrades || []).filter(t => t.ticker && t.expDate && t.strike);
      const rowHits = rowsWanting.filter(t => map[quoteKey(t.ticker, t.expDate, t.strike, t.cp)]).length;
      let mismatch = "";
      if (stored.length && rowsWanting.length && rowHits === 0) {
        mismatch = ` · ⚠ KEY MISMATCH — nothing displays. Stored "${stored[0]}" but the row wants ` + `"${quoteKey(rowsWanting[0].ticker, rowsWanting[0].expDate, rowsWanting[0].strike, rowsWanting[0].cp)}"`;
      } else if (stored.length && rowHits < rowsWanting.length) {
        mismatch = ` · ${rowHits}/${rowsWanting.length} rows matched a quote`;
      }
      const rl = d.rate && d.rate.hits || 0;
      // Account for every contract that did not price. "26/33" with no
      // explanation of the other 7 is the same silent gap as before, just
      // smaller -- an expired contract and a broken lookup look identical.
      const missing = (d.results || []).filter(r => r.last == null && r.mid == null);
      const expired = missing.filter(r => r.expired);
      const bad = missing.filter(r => r.error && !r.expired);
      const quiet = missing.filter(r => !r.expired && !r.error);
      const notes = [];
      if (expired.length) {
        const tks = [...new Set(expired.map(r => r.ticker))].join(", ");
        notes.push(`${expired.length} expired (${tks}) — past expiry, close them in the log`);
      }
      if (bad.length) {
        const byTicker = {};
        bad.forEach(r => {
          (byTicker[r.ticker] = byTicker[r.ticker] || []).push(r);
        });
        notes.push("⚠ " + Object.entries(byTicker).map(([tk, rs]) => `${tk} ×${rs.length}: ${rs[0].error}`).join(" | "));
      }
      if (quiet.length) {
        const tks = [...new Set(quiet.map(r => r.ticker))].join(", ");
        notes.push(`${quiet.length} with no trade and no bid/ask (${tks}) — the strike is listed but nobody is quoting it`);
      }
      const missCount = cons.length - got;
      // If the arithmetic does not add up, say so rather than quietly losing rows.
      if (missCount > missing.length) notes.push(`⚠ ${missCount - missing.length} unaccounted for`);
      return `⚡ ${got}/${cons.length} contract prices` + (rl ? ` (⚠ throttled ${rl}x)` : "") + (notes.length ? " · " + notes.join(" · ") : "") + mismatch;
    } catch (e) {
      return "⚠ option prices failed: " + (e.message || e);
    }
  };
  const checkATH = async () => {
    if (!fhKey) {
      setShowKeyInput(true);
      setAthStatus("Enter your Finnhub key first.");
      setTimeout(() => setAthStatus(""), 4000);
      return;
    }
    setAthChecking(true);
    setAthStatus("Checking for new highs…");
    try {
      const changes = await fetchIndicesOnly(fhKey);
      if (changes && changes.length) {
        setAthStatus("🎉 New ATH! " + changes.map(c => `${c.sym} ${fmt$(c.to)}`).join(" · "));
      } else {
        setAthStatus(`✓ ATH is current (checked ${new Date().toLocaleTimeString()})`);
      }
    } catch (e) {
      setAthStatus("⚠️ Check failed — try again");
    }
    setAthChecking(false);
    setTimeout(() => setAthStatus(""), 10000);
  };
  const deleteTrade = id => {
    if (window.confirm("Delete?")) save(trades.filter(t => t.id !== id));
  };
  const deleteSelected = () => {
    if (!selected.size) return;
    if (window.confirm(`Delete ${selected.size} trades?`)) {
      save(trades.filter(t => !selected.has(t.id)));
      setSelected(new Set());
    }
  };
  const toggleSel = id => setSelected(s => {
    const n = new Set(s);
    n.has(id) ? n.delete(id) : n.add(id);
    return n;
  });
  const toggleAll = () => {
    if (filtered.length > 0 && filtered.every(t => selected.has(t.id))) setSelected(new Set());else setSelected(new Set(filtered.map(t => t.id)));
  };
  const startEdit = t => {
    setInlineEditId(t.id);
    setInlineForm({
      ...t
    });
  };
  const cancelEdit = () => {
    setInlineEditId(null);
    setInlineForm({});
  };
  const saveEdit = () => {
    const f = inlineForm;
    const sells = calcSells(f.sb, f.sellPremium, f.contracts);
    const buys = calcBuys(f.sb, f.sellPremium, f.contracts);
    const total = sells + buys;
    const netPL = calcNetPL(total, f.closePremium, f.action || "Open");
    const upd = {
      ...f,
      sells,
      buys,
      total,
      netPL,
      moneyOnHold: calcMOH({
        ...f,
        sells,
        buys,
        total,
        netPL
      })
    };

    // Editing the status inline moves shares exactly as the Close dialog does.
    // Previously it did not, so the same change made in two places gave two
    // different results — and the one that silently skipped the holdings was
    // the quicker one to reach.
    const prev = trades.find(t => t.id === inlineEditId);
    const action = f.action || "Open";
    // Assignment is dated by the close date. Fall back to today when the field
    // was left blank, rather than writing an undated lot.
    const when = f.closeDate || new Date().toISOString().slice(0, 10);
    const eff = prepareShareEffect(upd, action, when, prev && prev.action || "Open");
    if (!eff.ok) return; // cancelled — leave the row in edit mode, nothing saved

    save(trades.map(t => t.id === inlineEditId ? upd : t));
    if (eff.apply) eff.apply();
    setInlineEditId(null);
    setInlineForm({});
  };
  const exportCSV = () => setCsvPick(true);
  const doExportCSV = kind => {
    setCsvPick(false);
    const list = kind === "all" ? trades : kind === "open" ? trades.filter(isOpen) : filtered;
    if (!list.length) {
      alert("There are no trades to save for that choice.");
      return;
    }
    const cols = ["Account", "Date", "Company", "Ticker", "Strike", "Current Stock", "Exp Date", "Prem", "Qty", "C/P", "S/B", "Sells", "Total", "Action", "Close Date", "Close Prem", "Net P&L", "Money On Hold"];
    const rows = list.map(t => [t.account, t.date, t.company, t.ticker, t.strike, t.currentStock, t.expDate, t.sellPremium, t.contracts, t.cp, t.sb, t.sells?.toFixed(2), t.total?.toFixed(2), t.action || "", t.closeDate || "", t.closePremium || "", t.netPL != null ? t.netPL.toFixed(2) : "", t.moneyOnHold || ""]);
    const csv = [cols, ...rows].map(r => r.map(v => `"${v ?? ""}"`).join(",")).join("\n");
    const a = document.createElement("a");
    a.href = "data:text/csv;charset=utf-8," + encodeURIComponent(csv);
    a.download = `options_trades_${kind === "all" ? "all" : kind === "open" ? "open" : "filtered"}_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
  };

  // ⬆ Import: read the file into rows, then open the "match your columns"
  // box (impBox below). Excel files: every sheet, dates as YYYY-MM-DD.
  const xlsxSheets = async file => {
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(await file.arrayBuffer());
    const p2 = n => String(n).padStart(2, "0");
    const cell = v => {
      if (v === null || v === undefined) return "";
      if (v instanceof Date) return `${v.getUTCFullYear()}-${p2(v.getUTCMonth() + 1)}-${p2(v.getUTCDate())}`;
      if (typeof v === "object") {
        if ("result" in v) return cell(v.result);
        if (v.richText) return v.richText.map(r => r.text).join("");
        if ("text" in v) return cell(v.text);
        if (v.error) return "";
      }
      return String(v).replace(/[\t\r\n]+/g, " ").trim();
    };
    return wb.worksheets.map(ws => {
      const rows = [];
      ws.eachRow({
        includeEmpty: false
      }, row => {
        const vals = [];
        for (let c = 1; c <= ws.columnCount; c++) vals.push(cell(row.getCell(c).value));
        rows.push(vals);
      });
      return {
        name: ws.name,
        rows: rows.filter(r => r.some(v => v !== ""))
      };
    });
  };
  // Where the headings are, and the first guess at which column is which
  // (or the choices made last time for a file laid out the same way).
  const impSetup = (sheets, si, hr) => {
    const rows = sheets[si].rows;
    if (hr == null) hr = impHeaderRow(rows);
    const heads = rows[hr] || [];
    const saved = impRecall(heads);
    const map = saved ? saved.map : impGuess(heads, rows.slice(hr + 1));
    return {
      si,
      hr,
      map,
      premTotal: saved ? !!saved.premTotal : impPremTotal(rows, hr, map),
      closePerShare: saved ? !!saved.closePerShare : map.closePremium >= 0 && impClosePerShare(heads[map.closePremium]),
      acct: saved && ACCOUNTS.includes(saved.acct) ? saved.acct : ACCOUNTS[0],
      remembered: !!saved
    };
  };
  const importCSV = e => {
    const file = e.target.files[0];
    if (!file) return;
    e.target.value = "";
    if (/\.xls$/i.test(file.name)) {
      alert("This is an older Excel file (.xls).\n\nOpen it in Excel, choose File → Save As → Excel Workbook (.xlsx), then import the new file.");
      return;
    }
    const open = sheets => {
      sheets = sheets.filter(s => s.rows.length > 1);
      if (!sheets.length) {
        alert("That file has no rows of trades in it.");
        return;
      }
      // Start on the sheet whose headings OptionIQ knows best.
      const known = new Set(IMP_FIELDS.flatMap(f => f.exact).map(impNorm));
      const score = s => (s.rows[impHeaderRow(s.rows)] || []).filter(c => known.has(impNorm(c))).length;
      let si = 0;
      sheets.forEach((s, i) => {
        if (score(s) > score(sheets[si])) si = i;
      });
      setImp({
        name: file.name,
        sheets,
        ...impSetup(sheets, si)
      });
    };
    if (/\.xls[xm]$/i.test(file.name)) {
      xlsxSheets(file).then(open).catch(err => alert("Could not read that Excel file: " + err.message));
      return;
    }
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        open([{
          name: file.name,
          rows: impTable(ev.target.result)
        }]);
      } catch (err) {
        alert("Import failed: " + err.message);
      }
    };
    reader.readAsText(file);
  };
  const finishImport = replace => {
    const rows = imp.sheets[imp.si].rows;
    const heads = rows[imp.hr] || [];
    const imported = impBuild(rows, imp.hr, imp.map, imp).list;
    if (!imported.length) return;
    const unknown = {};
    imported.forEach(t => {
      if (!ACCOUNTS.includes(t.account)) unknown[t.account] = (unknown[t.account] || 0) + 1;
    });
    const names = Object.keys(unknown);
    if (names.length && !window.confirm(`This file has ${names.length === 1 ? "an account name" : "account names"} that ${names.length === 1 ? "isn't" : "aren't"} in OptionIQ yet:\n\n` + names.map(n => `   •  ${n}  (${unknown[n]} trade${unknown[n] === 1 ? "" : "s"})`).join("\n") + `\n\nYour accounts now: ${ACCOUNTS.join(", ")}\n\n` + `OK = Create ${names.length === 1 ? "this as a new account" : "these as new accounts"} and continue\n` + `Cancel = Go back. Nothing is imported yet. You can pick a different Account column, or fix the spelling in the file (or rename an account in ⚙ Settings).`)) return;
    if (replace && trades.length && !window.confirm(`Replace all ${trades.length} trades now in OptionIQ with the ${imported.length} from this file?\n\nTip: press 💾 Save Data first if you may want them back.`)) return;
    impRemember(heads, {
      map: imp.map,
      premTotal: imp.premTotal,
      closePerShare: imp.closePerShare,
      acct: imp.acct
    });
    setImp(null);
    save(replace ? imported : [...trades, ...imported]);
    alert(`✅ Imported ${imported.length} trades!`);
  };

  // ── Derived ───────────────────────────────────────────
  const acctTrades = useMemo(() => trades.filter(t => selectedAccounts.has(t.account)), [trades, selectedAccounts]);
  const filtered = useMemo(() => acctTrades.filter(t => {
    if (filters.status === "open" && !isOpen(t)) return false;
    if (filters.status === "closed" && isOpen(t)) return false;
    if (filters.cp !== "all" && t.cp !== filters.cp) return false;
    if (filters.sb !== "all" && t.sb !== filters.sb) return false;
    if (filters.moneyOnHold && !(t.moneyOnHold > 0)) return false;
    if (filters.itmOnly) {
      if (!isOpen(t)) return false;
      const strike = parseFloat(t.strike),
        stock = parseFloat(t.currentStock);
      if (isNaN(strike) || isNaN(stock)) return false;
      const isITM = t.cp === "P" && stock < strike || t.cp === "C" && stock > strike;
      if (!isITM) return false;
    }
    if (!matchesTicker(t.ticker, filters.ticker)) return false;
    if (filters.dateFrom && t.date && t.date < filters.dateFrom) return false;
    if (filters.dateTo && t.date && t.date > filters.dateTo) return false;
    if (filters.closeDateFrom && t.closeDate && t.closeDate < filters.closeDateFrom) return false;
    if (filters.closeDateTo && t.closeDate && t.closeDate > filters.closeDateTo) return false;
    if (filters.minPL !== "" && (t.netPL == null || t.netPL < parseFloat(filters.minPL))) return false;
    if (filters.maxPL !== "" && (t.netPL == null || t.netPL > parseFloat(filters.maxPL))) return false;
    if (filters.maxDTE !== "") {
      if (!isOpen(t) || !t.expDate) return false;
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const exp = new Date(t.expDate + "T00:00:00");
      const dte = Math.ceil((exp - today) / (1000 * 60 * 60 * 24));
      if (dte > parseFloat(filters.maxDTE)) return false;
    }
    // Same rule as the Ticker filter below. This box used to match the company
    // name too, which is why "BE" returned Alphabet — "alpha-BE-t".
    if (!matchesTicker(t.ticker, search)) return false;
    return true;
  }), [acctTrades, filters, search]);
  const LOG_SORT_COLS = {
    "Acct": {
      field: "account",
      type: "string"
    },
    "Date": {
      field: "date",
      type: "date"
    },
    "Ticker": {
      field: "ticker",
      type: "string"
    },
    "Strike": {
      field: "strike",
      type: "number"
    },
    "Stk $": {
      field: "currentStock",
      type: "number"
    },
    "Day Chg": {
      type: "number",
      accessor: t => tickerChange[t.ticker] ? tickerChange[t.ticker].abs : null
    },
    "Diff": {
      type: "number",
      accessor: t => {
        const d = parseFloat(t.currentStock) - parseFloat(t.strike);
        return isNaN(d) ? null : d;
      }
    },
    "Exp": {
      field: "expDate",
      type: "date"
    },
    "Prem": {
      field: "sellPremium",
      type: "number"
    },
    "Now": {
      type: "number",
      accessor: t => {
        const c = currentContractPrice(t);
        return c ? c.price : null;
      }
    },
    "Unreal": {
      type: "number",
      accessor: t => {
        const u = unrealisedPL(t);
        return u ? u.pl : null;
      }
    },
    "Qty": {
      field: "contracts",
      type: "number"
    },
    "C/P": {
      field: "cp",
      type: "string"
    },
    "S/B": {
      field: "sb",
      type: "string"
    },
    "Sells": {
      field: "sells",
      type: "number"
    },
    "Total": {
      field: "total",
      type: "number"
    },
    "Status": {
      type: "string",
      accessor: t => t.action || "Open"
    },
    "Close Date": {
      field: "closeDate",
      type: "date"
    },
    "Close Prem": {
      field: "closePremium",
      type: "number"
    },
    "Net P&L": {
      field: "netPL",
      type: "number"
    },
    "Ann %": {
      type: "number",
      accessor: t => {
        const a = calcAnnualized(t);
        return a ? a.pct : null;
      }
    },
    "$ On Hold": {
      field: "moneyOnHold",
      type: "number"
    }
  };
  const handleSort = h => {
    if (!LOG_SORT_COLS[h]) return;
    setSortConfig(prev => prev.key === h ? {
      key: h,
      direction: prev.direction === "asc" ? "desc" : "asc"
    } : {
      key: h,
      direction: "asc"
    });
  };
  const sortedFiltered = useMemo(() => {
    const col = LOG_SORT_COLS[sortConfig.key];
    if (!col) return filtered;
    const getVal = t => col.accessor ? col.accessor(t) : t[col.field];
    const arr = [...filtered].sort((a, b) => {
      let va = getVal(a),
        vb = getVal(b);
      if (col.type === "number") {
        va = va == null || va === "" ? null : parseFloat(va);
        vb = vb == null || vb === "" ? null : parseFloat(vb);
        if (va == null && vb == null) return 0;
        if (va == null) return 1;
        if (vb == null) return -1;
        return va - vb;
      }
      va = (va || "").toString().toLowerCase();
      vb = (vb || "").toString().toLowerCase();
      if (va < vb) return -1;
      if (va > vb) return 1;
      return 0;
    });
    if (sortConfig.direction === "desc") arr.reverse();
    return arr;
  }, [filtered, sortConfig]);
  const filteredPL = useMemo(() => filtered.filter(t => t.netPL != null).reduce((a, t) => a + t.netPL, 0), [filtered]);
  const filteredMoneyRequired = useMemo(() => filtered.filter(t => {
    if (!isOpen(t) || t.cp !== "P") return false;
    const strike = parseFloat(t.strike),
      stock = parseFloat(t.currentStock);
    if (isNaN(strike) || isNaN(stock)) return false;
    return stock < strike;
  }).reduce((sum, t) => sum + (parseInt(t.contracts) || 0) * (parseFloat(t.strike) || 0) * 100, 0), [filtered]);
  const filteredMoneyOnHold = useMemo(() => filtered.reduce((sum, t) => sum + (t.moneyOnHold || 0), 0), [filtered]);
  const uniqueTickers = useMemo(() => [...new Set(trades.map(t => t.ticker).filter(Boolean))].sort(), [trades]);
  const acctStocks = useMemo(() => stocks.filter(s => selectedAccounts.has(s.account)), [stocks, selectedAccounts]);

  // ── Strategy Scorecard ──────────────────────────────────
  // Reads the same account-filtered trades every other tab uses, so the
  // account checkboxes drive it with no extra wiring.
  const [benchData, setBenchData] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(BENCH_SK) || "null");
    } catch {
      return null;
    }
  });
  const [benchBusy, setBenchBusy] = useState(false);
  const [benchMsg, setBenchMsg] = useState("");

  // Sector comes from the Analysis run if there has been one. No extra
  // requests, and the concentration view simply says "Unclassified" if not.
  const sectorByTicker = useMemo(() => {
    const m = {};
    (anSaved && anSaved.rows || []).forEach(r => {
      if (r.ticker && r.sector) m[r.ticker.toUpperCase()] = r.sector;
    });
    return m;
  }, [anSaved]);
  const sharesByAcctTicker = useMemo(() => {
    const m = {};
    // Inlined rather than calling isStockSold, which is declared further down
    // the component. A const is in its temporal dead zone until then, and a
    // useMemo factory runs during the very first render — calling it here threw
    // a ReferenceError before React could paint anything, blanking the app.
    stocks.filter(s => (s.status || "") !== "Sold").forEach(s => {
      const k = `${(s.account || "").trim()}|${(s.ticker || "").trim().toUpperCase()}`;
      m[k] = (m[k] || 0) + (parseFloat(s.shares) || 0);
    });
    return m;
  }, [stocks]);

  // Share-weighted cost basis per account and ticker, for covered positions.
  // Same inlining reason as above: isStockSold is declared later.
  const costBasisByAcctTicker = useMemo(() => {
    const m = {};
    stocks.filter(s => (s.status || "") !== "Sold").forEach(s => {
      const k = `${(s.account || "").trim()}|${(s.ticker || "").trim().toUpperCase()}`;
      const sh = parseFloat(s.shares) || 0,
        cb = parseFloat(s.costBasis) || 0;
      if (!sh || !cb) return;
      if (!m[k]) m[k] = {
        sh: 0,
        cost: 0
      };
      m[k].sh += sh;
      m[k].cost += sh * cb;
    });
    const out = {};
    Object.entries(m).forEach(([k, v]) => {
      if (v.sh > 0) out[k] = v.cost / v.sh;
    });
    return out;
  }, [stocks]);
  const scorecard = useMemo(() => sc_build(acctTrades, {
    sharesFor: (a, t) => sharesByAcctTicker[`${(a || "").trim()}|${(t || "").trim().toUpperCase()}`] || 0,
    costBasisFor: (a, t) => costBasisByAcctTicker[`${(a || "").trim()}|${(t || "").trim().toUpperCase()}`] || 0,
    sectorFor: t => sectorByTicker[t] || null,
    today: new Date().toISOString().slice(0, 10)
  }), [acctTrades, sharesByAcctTicker, costBasisByAcctTicker, sectorByTicker]);
  const loadBenchmark = async () => {
    const {
      firstDate,
      lastDate
    } = scorecard.totals;
    if (!firstDate) {
      setBenchMsg("No trades to compare against yet.");
      return;
    }
    setBenchBusy(true);
    setBenchMsg("Fetching SPY and QQQ…");
    try {
      if (!(await checkScrService())) throw new Error("screener service is not running");
      const res = await fetch(`${SCREENER_URL}/benchmark`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        signal: AbortSignal.timeout(30000),
        body: JSON.stringify({
          start: firstDate,
          end: lastDate,
          symbols: ["SPY", "QQQ"]
        })
      });
      const d = await res.json();
      if (!res.ok || !d.ok) throw new Error(d.error || "HTTP " + res.status);
      const saved = {
        ...d,
        fetchedAt: new Date().toISOString()
      };
      setBenchData(saved);
      try {
        localStorage.setItem(BENCH_SK, JSON.stringify(saved));
      } catch (e) {}
      setBenchMsg("");
    } catch (e) {
      setBenchMsg("⚠ " + (e.message || e) + " — the rest of the scorecard is unaffected.");
    }
    setBenchBusy(false);
  };
  const setSF = (k, v) => setStockFilters(f => ({
    ...f,
    [k]: v
  }));
  const resetStockFilters = () => setStockFilters({
    ...DEFAULT_STOCK_FILTERS
  });
  const SFC = Object.entries(stockFilters).filter(([k, v]) => v !== DEFAULT_STOCK_FILTERS[k] && v && v !== false).length;
  const accountsWithOpenCalls = useMemo(() => {
    const set = new Set();
    trades.forEach(t => {
      if (t.cp === "C" && isOpen(t)) set.add(`${(t.account || "").trim()}|${(t.ticker || "").trim().toUpperCase()}`);
    });
    return set;
  }, [trades]);
  const filteredStocks = useMemo(() => acctStocks.filter(s => {
    const effStatus = s.status || "Held";
    // "active" = still owned, whether bought outright or assigned to you.
    if (stockFilters.status === "active" && effStatus === "Sold") return false;
    if (stockFilters.status === "held" && effStatus !== "Held") return false;
    if (stockFilters.status === "assigned" && effStatus !== "Assigned") return false;
    if (stockFilters.status === "sold" && effStatus !== "Sold") return false;
    if (!matchesTicker(s.ticker, stockFilters.ticker)) return false;
    if (stockFilters.dateAcqFrom && s.dateAcquired && s.dateAcquired < stockFilters.dateAcqFrom) return false;
    if (stockFilters.dateAcqTo && s.dateAcquired && s.dateAcquired > stockFilters.dateAcqTo) return false;
    if (stockFilters.soldDateFrom && (!s.soldDate || s.soldDate < stockFilters.soldDateFrom)) return false;
    if (stockFilters.soldDateTo && (!s.soldDate || s.soldDate > stockFilters.soldDateTo)) return false;
    if (stockFilters.missingCalls) {
      if (effStatus === "Sold") return false;
      const shares = parseFloat(s.shares) || 0;
      if (shares < 100) return false;
      if (accountsWithOpenCalls.has(`${(s.account || "").trim()}|${(s.ticker || "").trim().toUpperCase()}`)) return false;
    }
    if (!matchesTicker(s.ticker, stockSearch)) return false;
    return true;
  }), [acctStocks, stockFilters, stockSearch, accountsWithOpenCalls]);
  const isStockSold = s => s.status === "Sold";
  const isStockActive = s => s.status !== "Sold";
  const stockGainLoss = s => {
    const shares = parseFloat(s.shares) || 0,
      cb = parseFloat(s.costBasis) || 0;
    const refPrice = isStockSold(s) ? parseFloat(s.soldPrice) || 0 : parseFloat(s.currentPrice) || 0;
    if (!shares || !cb) return null;
    return (refPrice - cb) * shares;
  };
  const stockMarketValue = s => {
    const shares = parseFloat(s.shares) || 0;
    const refPrice = isStockSold(s) ? parseFloat(s.soldPrice) || 0 : parseFloat(s.currentPrice) || 0;
    return shares * refPrice;
  };
  const stockCostValue = s => {
    const shares = parseFloat(s.shares) || 0,
      cb = parseFloat(s.costBasis) || 0;
    return shares * cb;
  };
  // Only "Assigned" stocks get call-premium tracking; "Held" stocks are excluded entirely per user rule.
  // Each Assigned lot only counts calls sold on/after that lot's own assignment date (dateAcquired),
  // windowed against any later assignment of the same account+ticker so calls are never double-counted.
  const assignedLotsByGroup = useMemo(() => {
    const groups = {};
    filteredStocks.forEach(s => {
      if (isStockSold(s) || s.status !== "Assigned") return;
      const key = `${(s.account || "").trim()}|${(s.ticker || "").trim().toUpperCase()}`;
      (groups[key] = groups[key] || []).push(s);
    });
    Object.values(groups).forEach(arr => arr.sort((a, b) => (a.dateAcquired || "").localeCompare(b.dateAcquired || "")));
    return groups;
  }, [filteredStocks]);
  const assignedLotPremium = useMemo(() => {
    const m = {};
    Object.entries(assignedLotsByGroup).forEach(([key, lots]) => {
      const [acct, tk] = key.split("|");
      const dateGroups = {};
      lots.forEach(s => {
        const d = s.dateAcquired || "";
        (dateGroups[d] = dateGroups[d] || []).push(s);
      });
      const uniqueDates = Object.keys(dateGroups).sort();
      uniqueDates.forEach((d, idx) => {
        const windowStart = d;
        const windowEnd = idx + 1 < uniqueDates.length ? uniqueDates[idx + 1] : null;
        const windowPrem = trades.reduce((sum, t) => {
          if (t.cp !== "C" || t.sb !== "S") return sum;
          if ((t.account || "").trim() !== acct) return sum;
          if ((t.ticker || "").trim().toUpperCase() !== tk) return sum;
          if (!t.date || t.date < windowStart) return sum;
          if (windowEnd && t.date >= windowEnd) return sum;
          return sum + (t.netPL != null ? t.netPL : t.total || 0);
        }, 0);
        const lotsInWindow = dateGroups[d];
        const totalShares = lotsInWindow.reduce((a, s) => a + (parseFloat(s.shares) || 0), 0);
        lotsInWindow.forEach(s => {
          const myShares = parseFloat(s.shares) || 0;
          m[s.id] = totalShares ? windowPrem * (myShares / totalShares) : windowPrem;
        });
      });
    });
    return m;
  }, [assignedLotsByGroup, trades]);
  const stockCallPremium = s => {
    if (isStockSold(s)) return null;
    if (s.status !== "Assigned") return null;
    const shares = parseFloat(s.shares) || 0;
    if (shares < 100) return null;
    return assignedLotPremium[s.id] ?? 0;
  };
  const stockEffectiveCostBasis = s => {
    const shares = parseFloat(s.shares) || 0;
    const prem = stockCallPremium(s);
    if (!shares || shares < 100 || prem == null) return null;
    const cb = parseFloat(s.costBasis) || 0;
    const premPerShare = prem / shares;
    return cb - premPerShare;
  };
  const multiLotGroups = useMemo(() => {
    const groups = {};
    filteredStocks.forEach(s => {
      if (isStockSold(s)) return;
      const key = `${(s.account || "").trim()}|${(s.ticker || "").trim().toUpperCase()}`;
      (groups[key] = groups[key] || []).push(s);
    });
    return Object.entries(groups).filter(([, lots]) => lots.length > 1).map(([key, lots]) => {
      const totalShares = lots.reduce((a, s) => a + (parseFloat(s.shares) || 0), 0);
      const weightedCB = totalShares ? lots.reduce((a, s) => a + (parseFloat(s.shares) || 0) * (parseFloat(s.costBasis) || 0), 0) / totalShares : 0;
      const totalPrem = lots.reduce((a, s) => a + (stockCallPremium(s) || 0), 0);
      const effCB = totalShares ? weightedCB - totalPrem / totalShares : null;
      const priced = lots.find(s => s.currentPrice);
      const currentPrice = priced ? parseFloat(priced.currentPrice) || 0 : 0;
      const marketValue = totalShares * currentPrice;
      const costValue = totalShares * weightedCB;
      const gainLoss = marketValue - costValue;
      const gainPct = costValue ? gainLoss / costValue * 100 : null;
      return {
        key,
        account: lots[0].account,
        ticker: lots[0].ticker,
        company: lots[0].company,
        lotsCount: lots.length,
        totalShares,
        weightedCB,
        totalPrem,
        effCB,
        currentPrice,
        marketValue,
        costValue,
        gainLoss,
        gainPct
      };
    });
  }, [filteredStocks, assignedLotPremium]);
  const totalStockGL = acctStocks.filter(s => !isStockSold(s)).reduce((a, s) => a + (stockGainLoss(s) || 0), 0);
  const totalStockValue = acctStocks.filter(s => !isStockSold(s)).reduce((a, s) => a + stockMarketValue(s), 0);
  const totalStockDayChg = acctStocks.filter(s => !isStockSold(s) && tickerChange[s.ticker]).reduce((a, s) => a + (parseFloat(s.shares) || 0) * tickerChange[s.ticker].abs, 0);
  const hasStockDayChg = acctStocks.some(s => !isStockSold(s) && tickerChange[s.ticker]);
  const totalStockPrevValue = acctStocks.filter(s => !isStockSold(s) && tickerChange[s.ticker]).reduce((a, s) => {
    const shares = parseFloat(s.shares) || 0;
    const prevPrice = (parseFloat(s.currentPrice) || 0) - tickerChange[s.ticker].abs;
    return a + shares * prevPrice;
  }, 0);
  const totalStockDayChgPct = totalStockPrevValue > 0 ? totalStockDayChg / totalStockPrevValue * 100 : null;
  const totalSoldGL = acctStocks.filter(isStockSold).reduce((a, s) => a + (stockGainLoss(s) || 0), 0);
  const filteredStockGL = useMemo(() => filteredStocks.reduce((a, s) => a + (stockGainLoss(s) || 0), 0), [filteredStocks]);
  const STOCK_SORT_COLS = {
    "Acct": {
      field: "account",
      type: "string"
    },
    "Ticker": {
      field: "ticker",
      type: "string"
    },
    "Shares": {
      field: "shares",
      type: "number"
    },
    "Date Acquired": {
      field: "dateAcquired",
      type: "date"
    },
    "Cost Basis": {
      field: "costBasis",
      type: "number"
    },
    "Cost Value": {
      type: "number",
      accessor: stockCostValue
    },
    "Call Premium": {
      type: "number",
      accessor: stockCallPremium
    },
    "Eff. Cost Basis": {
      type: "number",
      accessor: stockEffectiveCostBasis
    },
    "Status": {
      type: "string",
      accessor: s => s.status || "Held"
    },
    "Current Price": {
      field: "currentPrice",
      type: "number"
    },
    "Day Chg": {
      type: "number",
      accessor: s => tickerChange[s.ticker] ? tickerChange[s.ticker].abs : null
    },
    "Sold Date": {
      field: "soldDate",
      type: "date"
    },
    "Sold Price": {
      field: "soldPrice",
      type: "number"
    },
    "Market/Sold Value": {
      type: "number",
      accessor: stockMarketValue
    },
    "Net Gain/Loss": {
      type: "number",
      accessor: stockGainLoss
    },
    "%": {
      type: "number",
      accessor: s => {
        const cv = stockCostValue(s),
          gl = stockGainLoss(s);
        return cv > 0 && gl != null ? gl / cv * 100 : null;
      }
    }
  };
  const handleStockSort = h => {
    if (!STOCK_SORT_COLS[h]) return;
    setStockSortConfig(prev => prev.key === h ? {
      key: h,
      direction: prev.direction === "asc" ? "desc" : "asc"
    } : {
      key: h,
      direction: "asc"
    });
  };
  const sortedFilteredStocks = useMemo(() => {
    const col = STOCK_SORT_COLS[stockSortConfig.key];
    if (!col) return filteredStocks;
    const getVal = s => col.accessor ? col.accessor(s) : s[col.field];
    const arr = [...filteredStocks].sort((a, b) => {
      let va = getVal(a),
        vb = getVal(b);
      if (col.type === "number") {
        va = va == null || va === "" ? null : parseFloat(va);
        vb = vb == null || vb === "" ? null : parseFloat(vb);
        if (va == null && vb == null) return 0;
        if (va == null) return 1;
        if (vb == null) return -1;
        return va - vb;
      }
      va = (va || "").toString().toLowerCase();
      vb = (vb || "").toString().toLowerCase();
      if (va < vb) return -1;
      if (va > vb) return 1;
      return 0;
    });
    if (stockSortConfig.direction === "desc") arr.reverse();
    return arr;
  }, [filteredStocks, stockSortConfig]);
  const plByTicker = useMemo(() => {
    const m = {};
    acctTrades.filter(t => t.netPL != null).forEach(t => {
      m[t.ticker] = (m[t.ticker] || 0) + t.netPL;
    });
    return Object.entries(m).map(([ticker, pl]) => ({
      ticker,
      pl
    })).sort((a, b) => b.pl - a.pl);
  }, [acctTrades]);
  const plByMonth = useMemo(() => {
    const m = {};
    acctTrades.filter(t => t.netPL != null && t.closeDate).forEach(t => {
      const d = new Date(t.closeDate);
      if (isNaN(d)) return;
      const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      m[k] = (m[k] || 0) + t.netPL;
    });
    return Object.entries(m).sort().map(([k, pl]) => {
      const [y, mo] = k.split("-");
      return {
        month: `${MONTHS[parseInt(mo) - 1]} ${y}`,
        pl
      };
    });
  }, [acctTrades]);
  const plByWeek = useMemo(() => {
    const m = {};
    acctTrades.filter(t => !isOpen(t) && t.netPL != null).forEach(t => {
      const raw = t.closeDate || t.date;
      const d = raw ? new Date(raw + "T00:00:00") : null;
      if (!d || isNaN(d)) return;
      const day = d.getDay();
      const diffToFri = (5 - day + 7) % 7;
      const friDate = new Date(d);
      friDate.setDate(d.getDate() + diffToFri);
      const key = friDate.toISOString().split("T")[0];
      m[key] = (m[key] || 0) + t.netPL;
    });
    return Object.entries(m).sort().map(([k, pl]) => {
      const d = new Date(k + "T00:00:00");
      return {
        week: `${MONTHS[d.getMonth()]} ${d.getDate()}`,
        fullDate: k,
        pl
      };
    }).map((row, i, arr) => ({
      ...row,
      cumulative: arr.slice(0, i + 1).reduce((s, r) => s + r.pl, 0)
    }));
  }, [acctTrades]);
  const holdByAcct = useMemo(() => ACCOUNTS.map(acct => {
    const op = trades.filter(t => t.account === acct && isOpen(t) && t.cp === "P" && t.sb === "S");
    return {
      acct,
      total: op.reduce((a, t) => a + calcMOH(t), 0),
      count: op.length,
      positions: op
    };
  }), [trades]);
  const totalHold = holdByAcct.filter(h => selectedAccounts.has(h.acct)).reduce((a, b) => a + b.total, 0);
  const totalPL = acctTrades.filter(t => t.netPL != null).reduce((a, t) => a + t.netPL, 0);
  const openPL = acctTrades.filter(t => isOpen(t) && t.netPL != null).reduce((a, t) => a + t.netPL, 0);
  const currentWeekPL = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const day = today.getDay();
    const monOffset = day === 0 ? -6 : 1 - day;
    const monday = new Date(today);
    monday.setDate(today.getDate() + monOffset);
    const friday = new Date(monday);
    friday.setDate(monday.getDate() + 4);
    monday.setHours(0, 0, 0, 0);
    friday.setHours(23, 59, 59, 999);
    return acctTrades.filter(t => {
      if (isOpen(t) || t.netPL == null || !t.closeDate) return false;
      const d = new Date(t.closeDate + "T00:00:00");
      return d >= monday && d <= friday;
    }).reduce((a, t) => a + t.netPL, 0);
  }, [acctTrades]);
  const currentWeekPremium = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const day = today.getDay();
    const monOffset = day === 0 ? -6 : 1 - day;
    const monday = new Date(today);
    monday.setDate(today.getDate() + monOffset);
    const friday = new Date(monday);
    friday.setDate(monday.getDate() + 4);
    monday.setHours(0, 0, 0, 0);
    friday.setHours(23, 59, 59, 999);
    let puts = 0,
      calls = 0;
    acctTrades.forEach(t => {
      if (!t.date) return; // bought contracts count too, as debits
      const d = new Date(t.date + "T00:00:00");
      if (isNaN(d) || d < monday || d > friday) return;
      const amt = netPremium(t);
      if (t.cp === "P") puts += amt;else if (t.cp === "C") calls += amt;
    });
    return {
      puts,
      calls,
      total: puts + calls
    };
  }, [acctTrades]);
  const premiumByWeek = useMemo(() => {
    const m = {};
    acctTrades.filter(t => t.date).forEach(t => {
      const d = new Date(t.date + "T00:00:00");
      if (isNaN(d)) return;
      const day = d.getDay(),
        diffToFri = (5 - day + 7) % 7;
      const fri = new Date(d);
      fri.setDate(d.getDate() + diffToFri);
      const key = fri.toISOString().split("T")[0];
      if (!m[key]) m[key] = {
        puts: 0,
        calls: 0
      };
      const amt = netPremium(t);
      if (t.cp === "P") m[key].puts += amt;else if (t.cp === "C") m[key].calls += amt;
    });
    return Object.entries(m).sort().map(([k, v]) => {
      const d = new Date(k + "T00:00:00");
      return {
        week: `${MONTHS[d.getMonth()]} ${d.getDate()}`,
        fullDate: k,
        puts: v.puts,
        calls: v.calls,
        total: v.puts + v.calls
      };
    });
  }, [acctTrades]);
  const premiumByAcct = useMemo(() => ACCOUNTS.map(acct => {
    const rows = trades.filter(t => t.account === acct);
    const puts = rows.filter(t => t.cp === "P").reduce((a, t) => a + netPremium(t), 0);
    const calls = rows.filter(t => t.cp === "C").reduce((a, t) => a + netPremium(t), 0);
    return {
      acct,
      puts,
      calls,
      total: puts + calls,
      count: rows.length
    };
  }), [trades]);
  const avgWeeklyClosedPL = useMemo(() => {
    const closed = acctTrades.filter(t => !isOpen(t) && t.netPL != null);
    if (!closed.length) return {
      avg: 0,
      weeks: 0,
      totalClosedPL: 0,
      startDate: null
    };
    const totalClosedPL = closed.reduce((a, t) => a + t.netPL, 0);
    // "Start of data" = earliest open date across all trades in current scope (not just closed ones)
    const allDates = acctTrades.map(t => t.date).filter(Boolean).sort();
    if (!allDates.length) return {
      avg: 0,
      weeks: 0,
      totalClosedPL,
      startDate: null
    };
    const start = new Date(allDates[0] + "T00:00:00");
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const daysElapsed = Math.max(1, (today - start) / (1000 * 60 * 60 * 24));
    const weeks = Math.max(daysElapsed / 7, 1 / 7); // never divide by less than 1 day worth
    return {
      avg: totalClosedPL / weeks,
      weeks,
      totalClosedPL,
      startDate: allDates[0]
    };
  }, [acctTrades]);
  const iinp = {
    background: "#1b1e29",
    border: "1px solid #3b82f6",
    borderRadius: 4,
    padding: "4px 6px",
    fontSize: 12,
    color: "#e2e8f0",
    width: "100%"
  };
  const rowBg = t => isOpen(t) ? "rgba(251,191,36,0.07)" : t.netPL > 0 ? "rgba(74,222,128,0.07)" : t.netPL < 0 ? "rgba(248,113,113,0.07)" : "";
  const Tip = ({
    active,
    payload,
    label
  }) => {
    if (!active || !payload?.length) return null;
    const v = payload[0].value;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 6,
        padding: "8px 12px",
        fontSize: 13
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        color: "#94a3b8",
        marginBottom: 4
      }
    }, label), /*#__PURE__*/React.createElement("div", {
      style: {
        color: v >= 0 ? "#4ade80" : "#f87171",
        fontWeight: 700
      }
    }, fmtPL(v)));
  };
  const WeekTip = ({
    active,
    payload,
    label
  }) => {
    if (!active || !payload?.length) return null;
    const weekVal = payload.find(p => p.dataKey === "pl")?.value;
    const cumVal = payload.find(p => p.dataKey === "cumulative")?.value;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 6,
        padding: "8px 12px",
        fontSize: 13
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Week of ", label), /*#__PURE__*/React.createElement("div", {
      style: {
        color: weekVal >= 0 ? "#34d399" : "#f87171",
        fontWeight: 700
      }
    }, "Weekly: ", fmtPL(weekVal)), /*#__PURE__*/React.createElement("div", {
      style: {
        color: "#fbbf24",
        fontWeight: 700,
        marginTop: 2
      }
    }, "Cumulative: ", fmtPL(cumVal)));
  };
  return (
    /*#__PURE__*/
    // PATCH 2: root div is now a flex column filling the full viewport height
    React.createElement("div", {
      style: {
        fontFamily: "system-ui,sans-serif",
        background: "#1b1e29",
        height: "100vh",
        display: "flex",
        flexDirection: "column",
        color: "#e2e8f0"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flexShrink: 0,
        position: "sticky",
        top: 0,
        zIndex: 100,
        background: "#1b1e29"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        borderBottom: "1px solid #2d3748",
        padding: "7px 14px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        flexWrap: "wrap",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8,
        whiteSpace: "nowrap",
        lineHeight: 1.15
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: "brand/optioniq-icon.png",
      alt: "",
      style: {
        width: 34,
        height: 34,
        margin: "-3px 0",
        flex: "none"
      }
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#60a5fa"
      }
    }, window.__TRACKER__.brand.app), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        color: "#94a3b8"
      }
    }, "by ", window.__TRACKER__.brand.owner))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 4,
        flexWrap: "wrap",
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: mainTab === "log" ? "#2563eb" : "#374151",
        color: "white"
      },
      onClick: () => setMainTab("log")
    }, "\uD83D\uDCCB Options"), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: mainTab === "stocks" ? "#0d9488" : "#374151",
        color: "white"
      },
      onClick: () => setMainTab("stocks")
    }, "\uD83C\uDFE6 Stocks"), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: mainTab === "analytics" ? "#7c3aed" : "#374151",
        color: "white"
      },
      onClick: () => setMainTab("analytics")
    }, "\uD83D\uDCC8 Analytics"), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: mainTab === "scorecard" ? "#b45309" : "#374151",
        color: "white"
      },
      onClick: () => setMainTab("scorecard"),
      title: "How each strategy, underlying and account has actually performed"
    }, "\uD83C\uDFC5 Scorecard"), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: mainTab === "screener" ? "#c2410c" : "#374151",
        color: "white"
      },
      onClick: () => setMainTab("screener")
    }, "\uD83C\uDFAF Screener", scrRows.length > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        background: "#f97316",
        color: "white",
        borderRadius: 9,
        padding: "0 6px",
        marginLeft: 6,
        fontSize: 11
      }
    }, scrRows.length)), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: mainTab === "analysis" ? "#7c3aed" : "#374151",
        color: "white"
      },
      onClick: () => setMainTab("analysis"),
      title: "Fundamentals and technicals for everything you hold or watch"
    }, "\uD83D\uDD2C Analysis", anRunning && /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 6
      }
    }, "\u23F3")), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: mainTab === "discover" ? "#0e7490" : "#374151",
        color: "white"
      },
      onClick: () => setMainTab("discover"),
      title: "Scan the S&P 500 for new candidates"
    }, "\uD83D\uDD2D Discover", dsRunning && /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 6
      }
    }, "\u23F3")), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: mainTab === "watchlist" ? "#15803d" : "#374151",
        color: "white"
      },
      onClick: () => setMainTab("watchlist"),
      title: "Fundamentals for the tickers on your watchlist"
    }, "\uD83D\uDC41 Watchlist"), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: mainTab === "calendar" ? "#be185d" : "#374151",
        color: "white"
      },
      onClick: () => setMainTab("calendar"),
      title: "Every open option on its expiry day"
    }, "\uD83D\uDCC5 Calendar"), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: "#374151",
        color: "#a3e635"
      },
      onClick: exportCSV
    }, "\u2B07 CSV"), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: xlBusy ? "#374151" : "#1a5c2e",
        color: "#4ade80",
        opacity: xlBusy ? 0.7 : 1
      },
      onClick: handleExcel,
      disabled: xlBusy
    }, xlBusy ? "⏳ Building…" : "📊 Excel"), /*#__PURE__*/React.createElement("label", {
      className: "btn btn-sm",
      style: {
        background: "#1e3a5f",
        color: "#60a5fa",
        cursor: "pointer"
      }
    }, "\u2B06 Import", /*#__PURE__*/React.createElement("input", {
      type: "file",
      accept: ".csv,.txt,.tsv,.xlsx,.xlsm,.xls",
      style: {
        display: "none"
      },
      onChange: importCSV
    })), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: "#9333ea",
        color: "white"
      },
      onClick: saveToFile
    }, "\uD83D\uDCBE Save Data"), /*#__PURE__*/React.createElement("label", {
      className: "btn btn-sm",
      style: {
        background: "#0891b2",
        color: "white",
        cursor: "pointer"
      }
    }, "\uD83D\uDCC2 Load Data", /*#__PURE__*/React.createElement("input", {
      type: "file",
      accept: ".json",
      style: {
        display: "none"
      },
      onChange: loadFromFile
    })), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: "#7c3aed",
        color: "white"
      },
      onClick: fixAllPL
    }, "\uD83D\uDD27 Fix P&L"), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: refreshing ? "#374151" : "#0e7490",
        color: "white",
        opacity: refreshing ? 0.7 : 1
      },
      onClick: refreshPrices,
      disabled: refreshing
    }, refreshing ? "⏳ Refreshing…" : "🔄 Prices"), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: athChecking ? "#374151" : "#b45309",
        color: "white",
        opacity: athChecking ? 0.7 : 1
      },
      onClick: checkATH,
      disabled: athChecking,
      title: "Check SPY/QQQ for a new all-time high"
    }, athChecking ? "⏳ Checking…" : "🏔 Check ATH"), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: "#374151",
        color: fhKey ? "#4ade80" : "#f87171",
        fontSize: 13
      },
      onClick: () => setShowKeyInput(v => !v)
    }, fhKey ? "🔑 Key ✓" : "🔑 Set Key"), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-sm",
      style: {
        background: "#374151",
        color: "#e2e8f0"
      },
      onClick: () => window.__TRACKER_EXTRAS__ && window.__TRACKER_EXTRAS__.openSettings(),
      title: "Accounts, backups, reminders, price key and where your data is kept"
    }, "\u2699 Settings"), refreshStatus && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        maxWidth: 340
      }
    }, refreshStatus, /*#__PURE__*/React.createElement("button", {
      onClick: () => setRefreshStatus(""),
      title: "Close this message",
      style: {
        marginLeft: 6,
        background: "#374151",
        color: "#e2e8f0",
        border: "none",
        borderRadius: 4,
        padding: "0 6px",
        fontSize: 12,
        cursor: "pointer",
        lineHeight: "18px"
      }
    }, "\u2715")), athStatus && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: "#fbbf24",
        maxWidth: 260
      }
    }, athStatus))), showKeyInput && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        borderBottom: "1px solid #2d3748",
        padding: "10px 16px",
        display: "flex",
        gap: 8,
        alignItems: "center",
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        color: "#94a3b8",
        whiteSpace: "nowrap"
      }
    }, "Finnhub API Key:"), /*#__PURE__*/React.createElement("input", {
      className: "inp",
      style: {
        width: 320,
        fontFamily: "monospace"
      },
      placeholder: "Paste your free Finnhub API key\u2026",
      defaultValue: fhKey,
      id: "fh-key"
    }), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#059669",
        color: "white"
      },
      onClick: () => saveKey(document.getElementById("fh-key").value)
    }, "Save"), /*#__PURE__*/React.createElement("a", {
      href: "https://finnhub.io/register",
      target: "_blank",
      style: {
        fontSize: 13,
        color: "#60a5fa"
      }
    }, "Get free key at finnhub.io \u2192")), /*#__PURE__*/React.createElement("table", {
      style: {
        width: "100%",
        borderCollapse: "collapse",
        background: "#21242f",
        borderBottom: "1px solid #2d3748"
      }
    }, /*#__PURE__*/React.createElement("tbody", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
      style: {
        padding: 0,
        whiteSpace: "nowrap",
        width: "1%"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        overflowX: "auto",
        alignItems: "center",
        gap: 2
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: selectAllAccounts,
      style: {
        padding: "10px 14px",
        fontSize: 14,
        fontWeight: 600,
        border: "none",
        cursor: "pointer",
        whiteSpace: "nowrap",
        background: "transparent",
        borderBottom: allAccountsSelected ? "2px solid #60a5fa" : "2px solid transparent",
        color: allAccountsSelected ? "#60a5fa" : "#6b7280"
      }
    }, "ALL"), ACCOUNTS.map(a => {
      const cnt = mainTab === "stocks" ? stocks.filter(s => s.account === a && !isStockSold(s)).length : trades.filter(t => t.account === a && isOpen(t)).length;
      const col = ACCT_COLOR[a] || "#60a5fa";
      const checked = selectedAccounts.has(a);
      return /*#__PURE__*/React.createElement("label", {
        key: a,
        onClick: e => {
          e.preventDefault();
          toggleAccount(a);
        },
        style: {
          display: "flex",
          alignItems: "center",
          gap: 6,
          padding: "10px 14px",
          fontSize: 14,
          fontWeight: 600,
          cursor: "pointer",
          whiteSpace: "nowrap",
          borderBottom: checked ? `2px solid ${col}` : "2px solid transparent",
          color: checked ? col : "#6b7280"
        }
      }, /*#__PURE__*/React.createElement("input", {
        type: "checkbox",
        checked: checked,
        readOnly: true,
        style: {
          cursor: "pointer",
          width: 14,
          height: 14,
          accentColor: col
        }
      }), a, cnt > 0 && /*#__PURE__*/React.createElement("span", {
        style: {
          background: col + "33",
          color: col,
          borderRadius: 10,
          padding: "1px 6px",
          fontSize: 12
        }
      }, cnt));
    }))), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "0 16px",
        textAlign: "right",
        whiteSpace: "nowrap"
      }
    }, Object.keys(indexPrices).length > 0 && /*#__PURE__*/React.createElement("span", null, Object.entries(indexPrices).map(([sym, d], i) => {
      const ath = athPrices[sym];
      const pctFromATH = ath ? (d.price - ath.price) / ath.price * 100 : null;
      return /*#__PURE__*/React.createElement("span", {
        key: sym,
        style: {
          marginLeft: i > 0 ? 24 : 0
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 12,
          color: "#94a3b8",
          fontWeight: 600
        }
      }, d.name, ": "), /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 13,
          fontWeight: 700,
          color: "#e2e8f0"
        }
      }, d.price.toLocaleString("en-US", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      })), " ", d.changePct != null && /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 12,
          fontWeight: 700,
          color: d.changePct >= 0 ? "#4ade80" : "#f87171"
        }
      }, d.changePct >= 0 ? "▲" : "▼", " ", Math.abs(d.changePct).toFixed(2), "%"), ath && /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 11,
          color: "#fbbf24",
          marginLeft: 8
        },
        title: `ATH as of ${ath.date}`
      }, "ATH ", ath.price.toLocaleString("en-US", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }), pctFromATH != null && /*#__PURE__*/React.createElement("span", {
        style: {
          color: pctFromATH >= 0 ? "#4ade80" : "#f87171",
          fontWeight: 700
        }
      }, " (", pctFromATH >= 0 ? "+" : "", pctFromATH.toFixed(2), "%)")));
    })))))), (mainTab === "log" || mainTab === "analytics") && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "12px 16px 0",
        maxWidth: 1700,
        margin: "0 auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 10,
        marginBottom: 12,
        flexWrap: "wrap"
      }
    }, [{
      label: "Total Net P&L",
      val: fmtPL(totalPL),
      color: totalPL >= 0 ? "#4ade80" : "#f87171"
    }, {
      label: "This Week's Net P&L",
      val: fmtPL(currentWeekPL),
      color: currentWeekPL >= 0 ? "#4ade80" : "#f87171"
    }, {
      label: "This Week's Premium Collected",
      val: fmt$(currentWeekPremium.total),
      color: "#4ade80",
      sub: `Puts: ${fmt$(currentWeekPremium.puts) || "$0.00"} · Calls: ${fmt$(currentWeekPremium.calls) || "$0.00"}`
    }, {
      label: "Avg Weekly Net P&L (Closed)",
      val: fmtPL(avgWeeklyClosedPL.avg),
      color: avgWeeklyClosedPL.avg >= 0 ? "#4ade80" : "#f87171",
      sub: avgWeeklyClosedPL.startDate ? `since ${avgWeeklyClosedPL.startDate} · ${avgWeeklyClosedPL.weeks.toFixed(1)}wk` : null
    }, {
      label: "Open Positions Net P&L",
      val: fmtPL(openPL),
      color: openPL >= 0 ? "#4ade80" : "#f87171"
    }, {
      label: "Open Positions",
      val: acctTrades.filter(isOpen).length,
      color: "#fbbf24"
    }, {
      label: "Closed Trades",
      val: acctTrades.filter(t => !isOpen(t)).length,
      color: "#60a5fa"
    }, {
      label: "Total $ On Hold (Puts)",
      val: fmt$(totalHold),
      color: "#fb923c"
    }].map(s => /*#__PURE__*/React.createElement("div", {
      key: s.label,
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 8,
        padding: "8px 14px",
        minWidth: 150,
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8"
      }
    }, s.label), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 18,
        fontWeight: 700,
        color: s.color,
        marginTop: 2
      }
    }, s.val), s.sub && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        color: "#4b5563",
        marginTop: 2
      }
    }, s.sub))))), mainTab === "stocks" && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "12px 16px 0",
        maxWidth: 1700,
        margin: "0 auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 10,
        marginBottom: 12,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 8,
        padding: "8px 14px",
        minWidth: 150,
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8"
      }
    }, "Holdings (Held)"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 18,
        fontWeight: 700,
        color: "#fbbf24",
        marginTop: 2
      }
    }, acctStocks.filter(s => !isStockSold(s)).length)), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 8,
        padding: "8px 14px",
        minWidth: 150,
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8"
      }
    }, "Total Market Value"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 18,
        fontWeight: 700,
        color: "#60a5fa",
        marginTop: 2
      }
    }, fmt$(totalStockValue))), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 8,
        padding: "8px 14px",
        minWidth: 150,
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8"
      }
    }, "Total Change (Day)"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 18,
        fontWeight: 700,
        marginTop: 2,
        color: hasStockDayChg ? totalStockDayChg >= 0 ? "#4ade80" : "#f87171" : "#4b5563"
      }
    }, hasStockDayChg ? `${totalStockDayChg >= 0 ? "▲" : "▼"}${fmt$(Math.abs(totalStockDayChg))}` : "—", hasStockDayChg && totalStockDayChgPct != null && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        fontWeight: 600,
        marginLeft: 6
      }
    }, "(", totalStockDayChgPct >= 0 ? "+" : "", totalStockDayChgPct.toFixed(2), "%)"))), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 8,
        padding: "8px 14px",
        minWidth: 150,
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8"
      }
    }, "Unrealized Gain/Loss"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 18,
        fontWeight: 700,
        color: totalStockGL >= 0 ? "#4ade80" : "#f87171",
        marginTop: 2
      }
    }, fmtPL(totalStockGL))), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 8,
        padding: "8px 14px",
        minWidth: 150,
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8"
      }
    }, "Realized Gain/Loss (Sold)"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 18,
        fontWeight: 700,
        color: totalSoldGL >= 0 ? "#4ade80" : "#f87171",
        marginTop: 2
      }
    }, fmtPL(totalSoldGL))))), mainTab === "log" && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "0 16px 10px",
        maxWidth: 1700,
        margin: "0 auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        flexWrap: "wrap",
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#059669",
        color: "white"
      },
      onClick: () => {
        setForm({
          ...EMPTY,
          account: defaultAccountForNew
        });
        setEditId(null);
        setShowForm(true);
      }
    }, "\uFF0B New Trade"), /*#__PURE__*/React.createElement("input", {
      className: "inp",
      style: {
        width: 200
      },
      list: "ticker-history-search",
      placeholder: "\uD83D\uDD0D Ticker \u2014 exact, e.g. BE",
      value: search,
      onChange: e => setSearch(e.target.value)
    }), /*#__PURE__*/React.createElement("datalist", {
      id: "ticker-history-search"
    }, uniqueTickers.map(tk => /*#__PURE__*/React.createElement("option", {
      key: tk,
      value: tk
    }))), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: showFilters ? "#7c3aed" : "#2c3346",
        color: "white"
      },
      onClick: () => setShowFilters(f => !f)
    }, "\u2699 Filters", AFC > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        background: "#f87171",
        color: "white",
        borderRadius: 10,
        padding: "0 5px",
        fontSize: 11,
        marginLeft: 4
      }
    }, AFC)), AFC > 0 && /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "#f87171"
      },
      onClick: resetFilters
    }, "\u2715 Clear"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginLeft: "auto"
      }
    }, filtered.length, " rows"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: "#94a3b8"
      }
    }, "\xB7"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        fontWeight: 700
      }
    }, "Filtered Net P&L: ", /*#__PURE__*/React.createElement("span", {
      style: {
        color: filteredPL >= 0 ? "#4ade80" : "#f87171"
      }
    }, fmtPL(filteredPL))), (() => {
      // Live mark-to-market across the open positions currently shown.
      const rows = filtered.filter(isOpen).map(unrealisedPL).filter(Boolean);
      if (!rows.length) return null;
      const tot = rows.reduce((a, x) => a + x.pl, 0);
      return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 13,
          color: "#94a3b8"
        }
      }, "\xB7"), /*#__PURE__*/React.createElement("span", {
        title: `Mark-to-market on ${rows.length} open position(s) with a live quote. Premium collected minus what it would cost to buy back.`,
        style: {
          fontSize: 13,
          fontWeight: 700
        }
      }, "\u26A1 Unrealised: ", /*#__PURE__*/React.createElement("span", {
        style: {
          color: tot >= 0 ? "#4ade80" : "#f87171"
        }
      }, fmtPL(tot)), /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 11,
          fontWeight: 400,
          color: "#4b5563",
          marginLeft: 4
        }
      }, "(", rows.length, " priced)")));
    })(), filteredMoneyRequired > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: "#94a3b8"
      }
    }, "\xB7"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        fontWeight: 700
      }
    }, "\uD83D\uDCB0 Money Required (Puts ITM): ", /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#fb923c"
      }
    }, fmt$(filteredMoneyRequired)))), filteredMoneyOnHold > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: "#94a3b8"
      }
    }, "\xB7"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        fontWeight: 700
      }
    }, "\uD83D\uDD12 Total $ On Hold: ", /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#fb923c"
      }
    }, fmt$(filteredMoneyOnHold)))), selected.size > 0 && /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#7f1d1d",
        color: "#f87171"
      },
      onClick: deleteSelected
    }, "\uD83D\uDDD1 Delete ", selected.size))), mainTab === "stocks" && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "0 16px 10px",
        maxWidth: 1700,
        margin: "0 auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        flexWrap: "wrap",
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#059669",
        color: "white"
      },
      onClick: () => {
        setStockForm({
          ...EMPTY_STOCK,
          account: defaultAccountForNew
        });
        setStockEditId(null);
        setShowStockForm(true);
      }
    }, "\uFF0B New Holding"), /*#__PURE__*/React.createElement("input", {
      className: "inp",
      style: {
        width: 200
      },
      list: "ticker-history",
      placeholder: "\uD83D\uDD0D Ticker \u2014 exact, e.g. BE",
      value: stockSearch,
      onChange: e => setStockSearch(e.target.value)
    }), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: showStockFilters ? "#0d9488" : "#2c3346",
        color: "white"
      },
      onClick: () => setShowStockFilters(f => !f)
    }, "\u2699 Filters", SFC > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        background: "#f87171",
        color: "white",
        borderRadius: 10,
        padding: "0 5px",
        fontSize: 11,
        marginLeft: 4
      }
    }, SFC)), SFC > 0 && /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "#f87171"
      },
      onClick: resetStockFilters
    }, "\u2715 Clear"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginLeft: "auto"
      }
    }, filteredStocks.length, " holdings"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: "#94a3b8"
      }
    }, "\xB7"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        fontWeight: 700
      }
    }, "Filtered Net Gain/Loss: ", /*#__PURE__*/React.createElement("span", {
      style: {
        color: filteredStockGL >= 0 ? "#4ade80" : "#f87171"
      }
    }, fmtPL(filteredStockGL))), stockSelected.size > 0 && /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#7f1d1d",
        color: "#f87171"
      },
      onClick: deleteSelectedStocks
    }, "\uD83D\uDDD1 Delete ", stockSelected.size))), mainTab === "analysis" && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "12px 16px 10px",
        maxWidth: 1700,
        margin: "0 auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        flexWrap: "wrap",
        alignItems: "center"
      }
    }, anRunning ? /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#7f1d1d",
        color: "#fecaca"
      },
      onClick: cancelAnalysis
    }, "\u2715 Cancel") : /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#7c3aed",
        color: "white"
      },
      onClick: runAnalysis
    }, "\uD83D\uDD2C Analyse ", screenUniverse.length, " stocks"), anSaved && anSaved.rows && anSaved.rows.length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("select", {
      className: "inp",
      style: {
        width: 160
      },
      value: anVerdict,
      onChange: e => setAnVerdict(e.target.value)
    }, /*#__PURE__*/React.createElement("option", {
      value: "all"
    }, "All verdicts"), ["BUY", "HOLD+", "HOLD", "MIXED", "HOLD-", "TRIM"].map(v => /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, v, " (", anSaved.rows.filter(r => r.verdict === v).length, ")"))), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginLeft: "auto"
      }
    }, anRows.length, " shown")), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        padding: "3px 9px",
        borderRadius: 11,
        background: scrService === "up" ? "#14532d" : scrService === "down" ? "#7f1d1d" : "#374151",
        color: scrService === "up" ? "#4ade80" : scrService === "down" ? "#fca5a5" : "#94a3b8"
      }
    }, scrService === "up" ? "● Service connected" : scrService === "down" ? "● Service offline" : "● Checking…")), anProgress && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, anProgress.done, "/", anProgress.total, anProgress.ticker ? ` · ${anProgress.ticker}` : ""), /*#__PURE__*/React.createElement("div", {
      style: {
        height: 6,
        background: "#1b1e29",
        borderRadius: 3,
        overflow: "hidden"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        height: "100%",
        width: `${anProgress.total ? Math.round(anProgress.done / anProgress.total * 100) : 0}%`,
        background: "#7c3aed",
        transition: "width .3s"
      }
    }))), anStatus && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: anStatus.startsWith("❌") ? "#fca5a5" : "#94a3b8",
        marginTop: 8
      }
    }, anStatus)), mainTab === "discover" && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "12px 16px 10px",
        maxWidth: 1700,
        margin: "0 auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        flexWrap: "wrap",
        alignItems: "center"
      }
    }, dsRunning ? /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#7f1d1d",
        color: "#fecaca"
      },
      onClick: cancelDiscover
    }, "\u2715 Cancel scan") : /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#0e7490",
        color: "white"
      },
      onClick: runDiscover
    }, "\uD83D\uDD2D Scan S&P 500"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: dsShowCfg ? "#0e7490" : "#2c3346",
        color: "white"
      },
      onClick: () => setDsShowCfg(v => !v)
    }, "\u2699 Criteria", (dsCfg.sectors || []).length > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        background: "#7c3aed",
        color: "white",
        borderRadius: 9,
        padding: "0 6px",
        marginLeft: 6,
        fontSize: 11
      }
    }, (dsCfg.sectors || []).length, " sectors")), (dsAllRows.length > 0 || dsFiltersActive) && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("select", {
      className: "inp",
      style: {
        width: 190,
        borderColor: dsSectorStale ? "#b45309" : undefined
      },
      value: dsSector,
      onChange: e => setDsSector(e.target.value)
    }, /*#__PURE__*/React.createElement("option", {
      value: "all"
    }, "All sectors"), dsSectors.map(s => /*#__PURE__*/React.createElement("option", {
      key: s,
      value: s
    }, s)), dsSectorStale && /*#__PURE__*/React.createElement("option", {
      value: dsSector
    }, dsSector, " \u2014 not in this scan")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "checkbox",
      id: "ds-hide",
      checked: dsHideOwned,
      onChange: e => setDsHideOwned(e.target.checked),
      style: {
        cursor: "pointer",
        width: 15,
        height: 15
      }
    }), /*#__PURE__*/React.createElement("label", {
      htmlFor: "ds-hide",
      style: {
        fontSize: 12.5,
        color: "#e2e8f0",
        cursor: "pointer"
      }
    }, "Hide ones I already track")), dsFiltersActive && dsRows.length < dsAllRows.length && /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "#f87171",
        fontSize: 12,
        padding: "5px 10px"
      },
      onClick: dsClearFilters
    }, "\u2715 Clear filters"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginLeft: "auto"
      }
    }, dsRows.length === dsAllRows.length ? `${dsRows.length} shown` : `${dsRows.length} of ${dsAllRows.length} shown`), dsPicked.size > 0 && /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#059669",
        color: "white"
      },
      onClick: dsAddPicked
    }, "\uFF0B Add ", dsPicked.size, " to watchlist")), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        padding: "3px 9px",
        borderRadius: 11,
        background: scrService === "up" ? "#14532d" : scrService === "down" ? "#7f1d1d" : "#374151",
        color: scrService === "up" ? "#4ade80" : scrService === "down" ? "#fca5a5" : "#94a3b8"
      }
    }, scrService === "up" ? "● Service connected" : scrService === "down" ? "● Service offline" : "● Checking…")), dsProgress && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, dsProgress.stage === "fundamentals" ? "Stage 1 — fundamentals" : dsProgress.stage === "options" ? "Stage 2 — option chains" : "Starting…", dsProgress.total > 0 && ` · ${dsProgress.done}/${dsProgress.total}`, dsProgress.ticker && ` · ${dsProgress.ticker}`), /*#__PURE__*/React.createElement("div", {
      style: {
        height: 6,
        background: "#1b1e29",
        borderRadius: 3,
        overflow: "hidden"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        height: "100%",
        width: `${dsProgress.total ? Math.round(dsProgress.done / dsProgress.total * 100) : 0}%`,
        background: dsProgress.stage === "options" ? "#c2410c" : "#0e7490",
        transition: "width .3s"
      }
    }))), dsStatus && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: dsStatus.startsWith("❌") ? "#fca5a5" : dsStatus.startsWith("⚠") ? "#fbbf24" : "#94a3b8",
        marginTop: 8
      }
    }, dsStatus)), mainTab === "screener" && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "12px 16px 10px",
        maxWidth: 1700,
        margin: "0 auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        flexWrap: "wrap",
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: scrBusy ? "#374151" : "#c2410c",
        color: "white",
        opacity: scrBusy ? 0.7 : 1
      },
      onClick: runScreen,
      disabled: scrBusy
    }, scrBusy ? "⏳ Scanning…" : "🎯 Run Screen"), /*#__PURE__*/React.createElement("select", {
      className: "inp",
      style: {
        width: 190
      },
      value: scrCfg.sides,
      onChange: e => setSC("sides", e.target.value)
    }, /*#__PURE__*/React.createElement("option", {
      value: "both"
    }, "Puts + Covered Calls"), /*#__PURE__*/React.createElement("option", {
      value: "put"
    }, "Cash-Secured Puts only"), /*#__PURE__*/React.createElement("option", {
      value: "call"
    }, "Covered Calls only")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        border: "1px solid #374151",
        borderRadius: 8,
        overflow: "hidden"
      },
      title: "Weekly: 4\u201314 days, delta .10\u2013.25, $40+ a contract. Monthly: 21\u201345 days, delta .15\u2013.30, $75+ a contract."
    }, [["weekly", "Weekly"], ["monthly", "Monthly"]].map(([k, l]) => /*#__PURE__*/React.createElement("button", {
      key: k,
      className: "btn",
      style: {
        borderRadius: 0,
        background: scrCfg.preset === k ? "#c2410c" : "#2c3346",
        color: "white"
      },
      onClick: () => applyPreset(k)
    }, l)), scrCfg.preset === "custom" && /*#__PURE__*/React.createElement("span", {
      style: {
        padding: "6px 10px",
        fontSize: 12,
        color: "#fbbf24",
        background: "#2c3346"
      }
    }, "Custom")), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: scrShowCfg ? "#c2410c" : "#2c3346",
        color: "white"
      },
      onClick: () => setScrShowCfg(v => !v)
    }, "\u2699 Criteria"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: scrShowRolls ? "#7c3aed" : "#2c3346",
        color: "white"
      },
      onClick: () => {
        const v = !scrShowRolls;
        setScrShowRolls(v);
        if (v && !rollRows.length && !rollBusy) runRolls();
      },
      title: "Rolls for open short puts and calls that are under pressure"
    }, "\uD83D\uDD01 Roll candidates"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: wlShow ? "#c2410c" : "#2c3346",
        color: "white"
      },
      onClick: () => setWlShow(v => !v),
      title: wlExcluded.size ? `${wlExcluded.size} ticker(s) excluded from the next scan` : "Manage your watchlist"
    }, "\u2605 Watchlist ", /*#__PURE__*/React.createElement("span", {
      style: {
        opacity: 0.75,
        fontWeight: 400
      }
    }, "(", activeUniverse.length, wlExcluded.size > 0 ? ` of ${screenUniverse.length}` : "", ")")), scrRows.length > 0 && /*#__PURE__*/React.createElement("select", {
      className: "inp",
      style: {
        width: 130
      },
      value: scrSideFilter,
      onChange: e => setScrSideFilter(e.target.value)
    }, /*#__PURE__*/React.createElement("option", {
      value: "all"
    }, "All results"), /*#__PURE__*/React.createElement("option", {
      value: "PUT"
    }, "Puts only"), /*#__PURE__*/React.createElement("option", {
      value: "CALL"
    }, "Calls only")), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        padding: "3px 9px",
        borderRadius: 11,
        background: scrService === "up" ? "#14532d" : scrService === "down" ? "#7f1d1d" : "#374151",
        color: scrService === "up" ? "#4ade80" : scrService === "down" ? "#fca5a5" : "#94a3b8"
      }
    }, scrService === "up" ? "● Service connected" : scrService === "down" ? "● Service offline" : "● Checking…"), scrService === "down" && /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "#60a5fa",
        fontSize: 13
      },
      onClick: checkScrService
    }, "\u21BB Retry"), scrRows.length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginLeft: "auto"
      }
    }, scrSorted.length, " contracts"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "#f87171"
      },
      onClick: () => {
        setScrRows([]);
        setScrMeta(null);
        setScrStatus("");
      }
    }, "\u2715 Clear"))), scrStatus && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: scrStatus.startsWith("❌") ? "#fca5a5" : "#94a3b8",
        marginTop: 8
      }
    }, scrStatus))), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        overflowY: "auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "14px 16px",
        maxWidth: 1700,
        margin: "0 auto"
      }
    }, mainTab === "analysis" && /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 16
      }
    }, anSaved && anSaved.stats && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "baseline",
        flexWrap: "wrap",
        gap: 8,
        marginBottom: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#a78bfa"
      }
    }, "\uD83D\uDD2C Verdict spread"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: anAgeDays != null && anAgeDays >= 5 ? "#fbbf24" : "#94a3b8"
      }
    }, "Last run ", anSaved.ranAt ? new Date(anSaved.ranAt).toLocaleString() : "—", anAgeDays != null && (anAgeDays === 0 ? " · today" : anAgeDays === 1 ? " · yesterday" : ` · ${anAgeDays} days ago`))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        flexWrap: "wrap"
      }
    }, ["BUY", "HOLD+", "HOLD", "MIXED", "HOLD-", "TRIM"].map(v => {
      const n = anSaved.rows.filter(r => r.verdict === v).length;
      return /*#__PURE__*/React.createElement("div", {
        key: v,
        onClick: () => setAnVerdict(anVerdict === v ? "all" : v),
        style: {
          background: anVerdict === v ? "#2c3346" : "#1b1e29",
          border: "1px solid " + (anVerdict === v ? AN_COLOR[v] : "#2d3748"),
          borderRadius: 8,
          padding: "8px 16px",
          minWidth: 96,
          cursor: "pointer"
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11.5,
          color: "#94a3b8"
        }
      }, v), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 20,
          fontWeight: 700,
          color: AN_COLOR[v],
          marginTop: 2
        }
      }, n));
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#4b5563",
        marginTop: 12,
        lineHeight: 1.7
      }
    }, "A verdict is a count of signals that agree, nothing cleverer. ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#94a3b8"
      }
    }, "BUY"), " means both scorecards lean positive,", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#94a3b8"
      }
    }, " TRIM"), " both negative, ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#fbbf24"
      }
    }, " MIXED"), " that they contradict each other \u2014 which is information in itself, not a failure to decide. Click any row to see every signal behind it.")), anRows.length > 0 ? /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        overflow: "auto",
        maxHeight: "72vh"
      }
    }, /*#__PURE__*/React.createElement("table", {
      style: {
        width: "100%",
        borderCollapse: "collapse",
        fontSize: 12.5,
        whiteSpace: "nowrap"
      }
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
      style: {
        color: "#94a3b8"
      }
    }, [["verdict", "Verdict"], ["ticker", "Ticker"], ["name", "Company"], ["price", "Price"], ["fair_gap", "Value"], ["support", "Support"], ["resistance", "Resist"], ["fund_pct", "Fund"], ["tech_pct", "Tech"], ["zone", "Zone"], ["pos52", "52w"], ["pe", "P/E"], ["upside", "Target"], ["rsi", "RSI"], ["vs50", "vs 50d"], ["vs200", "vs 200d"], ["mom1m", "1m"], ["mom3m", "3m"], ["mom6m", "6m"]].map(([k, l]) => /*#__PURE__*/React.createElement("th", {
      key: k,
      onClick: () => anSortBy(k),
      title: "Sort by " + l,
      style: {
        ...AN_TH
      }
    }, l, anSort.key === k ? anSort.dir === "desc" ? " ▾" : " ▴" : "")), /*#__PURE__*/React.createElement("th", {
      style: {
        ...AN_TH,
        cursor: "default"
      }
    }, "Your position"))), /*#__PURE__*/React.createElement("tbody", null, anRows.map((r, i) => {
      const pos = anPosition(r.ticker);
      const open = anOpen === r.ticker;
      const pct = v => v == null ? "—" : `${v.toFixed(0)}%`;
      const sg = v => v == null ? "#4b5563" : v >= 0 ? "#4ade80" : "#f87171";
      return /*#__PURE__*/React.createElement(React.Fragment, {
        key: r.ticker
      }, /*#__PURE__*/React.createElement("tr", {
        onClick: () => setAnOpen(open ? null : r.ticker),
        style: {
          borderBottom: "1px solid #2d3748",
          cursor: "pointer",
          background: open ? "#2c3346" : i % 2 ? "#232739" : "transparent"
        }
      }, /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          background: "#1b1e29",
          color: AN_COLOR[r.verdict],
          border: "1px solid " + AN_COLOR[r.verdict],
          borderRadius: 4,
          padding: "2px 7px",
          fontWeight: 700,
          fontSize: 11
        }
      }, r.verdict)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          fontWeight: 700
        }
      }, /*#__PURE__*/React.createElement("a", {
        className: "ticker-link",
        href: `https://finance.yahoo.com/quote/${r.ticker}`,
        target: "_blank",
        onClick: e => e.stopPropagation(),
        style: {
          color: "#60a5fa"
        }
      }, r.ticker), r.next_earnings && /*#__PURE__*/React.createElement("span", {
        title: "Earnings " + r.next_earnings,
        style: {
          marginLeft: 5,
          color: "#fbbf24",
          fontSize: 10
        }
      }, "\u26A0")), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: "#cbd5e1",
          maxWidth: 190,
          overflow: "hidden",
          textOverflow: "ellipsis"
        }
      }, r.name), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px"
        }
      }, fmt$(r.price)), /*#__PURE__*/React.createElement("td", {
        title: r.fair != null ? `Blended fair value ${fmt$(r.fair)} from ${r.fair_n} method${r.fair_n === 1 ? "" : "s"} ` + `spanning ${fmt$(r.fair_low)}–${fmt$(r.fair_high)}. ` + `${r.fair_conf} agreement between them. Open the row for each method and its assumptions.` : "No valuation — not enough earnings, cash flow or dividend history came back.",
        style: {
          padding: "7px 7px",
          fontWeight: 700,
          cursor: "help",
          color: FV_COLOR[r.fair_label] || "#4b5563"
        }
      }, r.fair_gap != null ? `${r.fair_gap >= 0 ? "+" : ""}${r.fair_gap.toFixed(0)}%` : "—", r.fair_gap != null && r.fair_conf === "low" && /*#__PURE__*/React.createElement("span", {
        title: "The methods disagree widely here \u2014 read the individual anchors, not this number.",
        style: {
          color: "#6b7280",
          fontSize: 10,
          marginLeft: 3,
          fontWeight: 400
        }
      }, "?")), /*#__PURE__*/React.createElement("td", {
        title: r.support ? `${r.support_touches} touches · ${((r.price / r.support - 1) * 100).toFixed(1)}% below price` : "",
        style: {
          padding: "7px 7px",
          color: "#4ade80"
        }
      }, r.support != null ? fmt$(r.support) : "—", r.support != null && /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#4b5563",
          fontSize: 10,
          marginLeft: 3
        }
      }, ((r.price / r.support - 1) * 100).toFixed(0), "%")), /*#__PURE__*/React.createElement("td", {
        title: r.resistance ? `${r.resistance_touches} touches · ${((r.resistance / r.price - 1) * 100).toFixed(1)}% above price` : "",
        style: {
          padding: "7px 7px",
          color: "#f87171"
        }
      }, r.resistance != null ? fmt$(r.resistance) : "—", r.resistance != null && /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#4b5563",
          fontSize: 10,
          marginLeft: 3
        }
      }, ((r.resistance / r.price - 1) * 100).toFixed(0), "%")), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          fontWeight: 700,
          color: r.fund_pct >= 65 ? "#4ade80" : r.fund_pct <= 35 ? "#f87171" : "#94a3b8"
        }
      }, pct(r.fund_pct)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          fontWeight: 700,
          color: r.tech_pct >= 65 ? "#4ade80" : r.tech_pct <= 35 ? "#f87171" : "#94a3b8"
        }
      }, pct(r.tech_pct)), /*#__PURE__*/React.createElement("td", {
        title: r.zone_why || "",
        style: {
          padding: "7px 7px",
          fontSize: 11.5,
          fontWeight: 600,
          color: ZONE_COLOR[r.zone] || "#6b7280"
        }
      }, r.zone && r.zone !== "Neutral" ? r.zone : "—"), /*#__PURE__*/React.createElement("td", {
        title: r.hi52 != null ? `52-week range ${fmt$(r.lo52)} – ${fmt$(r.hi52)}` : "",
        style: {
          padding: "7px 7px",
          color: r.pos52 == null ? "#4b5563" : r.pos52 >= 90 ? "#fbbf24" : r.pos52 <= 10 ? "#60a5fa" : "#94a3b8"
        }
      }, r.pos52 != null ? `${r.pos52.toFixed(0)}%` : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: "#94a3b8"
        }
      }, r.pe != null ? r.pe.toFixed(0) : "—"), /*#__PURE__*/React.createElement("td", {
        title: r.target != null ? `mean analyst target ${fmt$(r.target)}` : "",
        style: {
          padding: "7px 7px",
          color: sg(r.upside)
        }
      }, r.upside != null ? `${r.upside >= 0 ? "+" : ""}${r.upside.toFixed(0)}%` : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: r.rsi == null ? "#4b5563" : r.rsi >= 70 ? "#f87171" : r.rsi <= 30 ? "#4ade80" : "#94a3b8"
        }
      }, r.rsi != null ? r.rsi.toFixed(0) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: sg(r.vs50)
        }
      }, r.vs50 != null ? `${r.vs50 >= 0 ? "+" : ""}${r.vs50.toFixed(0)}%` : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: sg(r.vs200)
        }
      }, r.vs200 != null ? `${r.vs200 >= 0 ? "+" : ""}${r.vs200.toFixed(0)}%` : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: sg(r.mom1m)
        }
      }, r.mom1m != null ? `${r.mom1m >= 0 ? "+" : ""}${r.mom1m.toFixed(0)}%` : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: sg(r.mom3m)
        }
      }, r.mom3m != null ? `${r.mom3m >= 0 ? "+" : ""}${r.mom3m.toFixed(0)}%` : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: sg(r.mom6m)
        }
      }, r.mom6m != null ? `${r.mom6m >= 0 ? "+" : ""}${r.mom6m.toFixed(0)}%` : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          fontSize: 11.5,
          color: pos.any ? "#e2e8f0" : "#4b5563"
        }
      }, pos.any ? [pos.shares > 0 ? `${Math.round(pos.shares)} sh` : null, pos.puts ? `${pos.puts}P` : null, pos.calls ? `${pos.calls}C` : null].filter(Boolean).join(" · ") : "watchlist only")), open && /*#__PURE__*/React.createElement("tr", {
        style: {
          background: "#1b1e29"
        }
      }, /*#__PURE__*/React.createElement("td", {
        colSpan: 20,
        style: {
          padding: "14px 18px",
          borderBottom: "2px solid #7c3aed",
          whiteSpace: "normal"
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 12.5,
          color: "#cbd5e1",
          marginBottom: 14,
          whiteSpace: "normal",
          maxWidth: 920
        }
      }, /*#__PURE__*/React.createElement("b", {
        style: {
          color: AN_COLOR[r.verdict]
        }
      }, r.verdict), " \u2014 ", r.note), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit,minmax(280px,420px))",
          gap: 28,
          justifyContent: "start",
          maxWidth: 920
        }
      }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11.5,
          fontWeight: 700,
          color: "#22d3ee",
          marginBottom: 6
        }
      }, "FUNDAMENTALS \u2014 ", pct(r.fund_pct), " positive"), sigList(r.good, "✓", "#4ade80", "g"), sigList(r.bad, "✕", "#f87171", "b"), sigList(r.fund_neutral, "·", "#6b7280", "n")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11.5,
          fontWeight: 700,
          color: "#c2410c",
          marginBottom: 6
        }
      }, "TECHNICALS \u2014 ", pct(r.tech_pct), " bullish"), sigList(r.bull, "▲", "#4ade80", "bu"), sigList(r.bear, "▼", "#f87171", "be"), sigList(r.tech_neutral, "·", "#6b7280", "tn"))), r.levels && r.levels.length > 0 && /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 16,
          borderTop: "1px solid #2d3748",
          paddingTop: 12,
          maxWidth: 920
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11.5,
          fontWeight: 700,
          color: "#a78bfa",
          marginBottom: 8
        }
      }, "PRICE LEVELS", r.zone && r.zone !== "Neutral" && /*#__PURE__*/React.createElement("span", {
        style: {
          marginLeft: 10,
          color: ZONE_COLOR[r.zone],
          fontWeight: 700
        }
      }, "\xB7 ", r.zone, r.zone_why ? ` (${r.zone_why})` : "")), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          flexDirection: "column",
          gap: 3
        }
      }, [...r.levels].sort((a, b) => b.level - a.level).map((L, j) => {
        const above = L.level > r.price;
        return /*#__PURE__*/React.createElement("div", {
          key: j,
          style: {
            display: "flex",
            alignItems: "center",
            gap: 10,
            fontSize: 11.5
          }
        }, /*#__PURE__*/React.createElement("span", {
          style: {
            width: 70,
            textAlign: "right",
            color: above ? "#f87171" : "#4ade80",
            fontWeight: 600
          }
        }, fmt$(L.level)), /*#__PURE__*/React.createElement("span", {
          style: {
            width: 52,
            color: "#6b7280"
          }
        }, L.dist >= 0 ? "+" : "", L.dist.toFixed(1), "%"), /*#__PURE__*/React.createElement("span", {
          title: `${L.touches} swing points clustered here`,
          style: {
            color: "#94a3b8",
            width: 70
          }
        }, L.touches, " touch", L.touches === 1 ? "" : "es"), /*#__PURE__*/React.createElement("span", {
          style: {
            flex: 1,
            height: 6,
            background: "#1b1e29",
            borderRadius: 3,
            position: "relative",
            maxWidth: 300
          }
        }, /*#__PURE__*/React.createElement("span", {
          style: {
            position: "absolute",
            left: 0,
            top: 0,
            bottom: 0,
            borderRadius: 3,
            width: `${Math.min(L.touches * 14, 100)}%`,
            background: above ? "#7f1d1d" : "#14532d"
          }
        })), /*#__PURE__*/React.createElement("span", {
          style: {
            color: "#4b5563",
            fontSize: 10.5
          }
        }, above ? "resistance" : "support"));
      }), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          alignItems: "center",
          gap: 10,
          fontSize: 11.5,
          marginTop: 2
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          width: 70,
          textAlign: "right",
          color: "#e2e8f0",
          fontWeight: 700
        }
      }, fmt$(r.price)), /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#e2e8f0",
          fontWeight: 600
        }
      }, "\u25C4 price now"), r.pos52 != null && /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#6b7280"
        }
      }, "\xB7 ", r.pos52.toFixed(0), "% of the 52-week range (", fmt$(r.lo52), "\u2013", fmt$(r.hi52), ")"))), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 10.5,
          color: "#4b5563",
          marginTop: 8,
          lineHeight: 1.6
        }
      }, "Levels come from swing highs and lows over the past year, merged where they sit within 2% of each other. More touches means price has turned there more often \u2014 useful for picking covered-call strikes. They are descriptive, not physics: a level holds until it doesn't, and breaks often run.")), r.fair_anchors && r.fair_anchors.length > 0 && /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 16,
          borderTop: "1px solid #2d3748",
          paddingTop: 12,
          maxWidth: 920
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11.5,
          fontWeight: 700,
          color: "#a78bfa",
          marginBottom: 8
        }
      }, "FAIR VALUE", /*#__PURE__*/React.createElement("span", {
        style: {
          marginLeft: 10,
          color: FV_COLOR[r.fair_label] || "#94a3b8"
        }
      }, "\xB7 ", fmt$(r.fair), " blended", r.fair_label ? ` — ${r.fair_label}` : "", r.fair_gap != null ? ` (${r.fair_gap >= 0 ? "+" : ""}${r.fair_gap.toFixed(0)}% vs price)` : ""), /*#__PURE__*/React.createElement("span", {
        style: {
          marginLeft: 10,
          color: "#6b7280",
          fontWeight: 400
        }
      }, r.fair_conf, " agreement")), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          flexDirection: "column",
          gap: 3
        }
      }, [...r.fair_anchors].sort((a, b) => b.value - a.value).map((A, j) => /*#__PURE__*/React.createElement("div", {
        key: j,
        title: A.why || "",
        style: {
          display: "flex",
          alignItems: "center",
          gap: 10,
          fontSize: 11.5,
          cursor: "help"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          width: 70,
          textAlign: "right",
          fontWeight: 600,
          color: A.value >= r.price ? "#4ade80" : "#f87171"
        }
      }, fmt$(A.value)), /*#__PURE__*/React.createElement("span", {
        style: {
          width: 52,
          color: "#6b7280"
        }
      }, A.gap != null ? `${A.gap >= 0 ? "+" : ""}${A.gap.toFixed(0)}%` : ""), /*#__PURE__*/React.createElement("span", {
        style: {
          width: 200,
          color: "#cbd5e1",
          borderBottom: "1px dotted #4b5563"
        }
      }, A.name), /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#6b7280",
          fontSize: 10.5
        }
      }, A.basis || ""))), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          alignItems: "center",
          gap: 10,
          fontSize: 11.5,
          marginTop: 2
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          width: 70,
          textAlign: "right",
          color: "#e2e8f0",
          fontWeight: 700
        }
      }, fmt$(r.price)), /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#e2e8f0",
          fontWeight: 600
        }
      }, "\u25C4 price now"))), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 10.5,
          color: "#4b5563",
          marginTop: 8,
          lineHeight: 1.6
        }
      }, r.fair_note, " Hover any method to see the assumption it rests on. This is the most assumption-heavy figure in the app, which is why it is kept out of the Verdict entirely \u2014 the two scorecards are built from observable facts, this one is not. Read the spread rather than the midpoint.")), r.fair_note && (!r.fair_anchors || r.fair_anchors.length === 0) && /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 16,
          borderTop: "1px solid #2d3748",
          paddingTop: 12,
          maxWidth: 920,
          fontSize: 11,
          color: "#4b5563",
          lineHeight: 1.6
        }
      }, /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#6b7280"
        }
      }, "FAIR VALUE"), " \u2014 ", r.fair_note), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11,
          color: "#4b5563",
          marginTop: 12,
          borderTop: "1px solid #2d3748",
          paddingTop: 8,
          lineHeight: 1.7,
          whiteSpace: "normal",
          maxWidth: 920
        }
      }, r.sma50 != null && /*#__PURE__*/React.createElement(React.Fragment, null, "50-day ", fmt$(r.sma50), " \xB7 "), r.sma200 != null && /*#__PURE__*/React.createElement(React.Fragment, null, "200-day ", fmt$(r.sma200), " \xB7 "), r.macd_hist != null && /*#__PURE__*/React.createElement(React.Fragment, null, "MACD histogram ", r.macd_hist >= 0 ? "+" : "", r.macd_hist, " \xB7 "), r.cross && /*#__PURE__*/React.createElement("span", {
        style: {
          color: r.cross === "golden" ? "#4ade80" : "#f87171"
        }
      }, r.cross, " cross \xB7 "), r.analysts ? /*#__PURE__*/React.createElement(React.Fragment, null, r.analysts, " analysts, consensus ", r.rec.replace(/_/g, " "), " \xB7 ") : null, r.bars, " sessions of history", r.next_earnings && /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#fbbf24"
        }
      }, " \xB7 earnings ", r.next_earnings)))));
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#4b5563",
        marginTop: 12,
        lineHeight: 1.7
      }
    }, "Click a row for the full signal list, then hover any signal to see the threshold that made it green, red or grey.", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#94a3b8"
      }
    }, " Fund"), " and ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#94a3b8"
      }
    }, "Tech"), " are the share of signals pointing positive in each scorecard \u2014 not a price forecast.", /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 6
      }
    }, "These are mechanical readings of public data, computed the same way for every stock. They can't see anything qualitative \u2014 a product cycle, a lawsuit, a change of management \u2014 and indicators are famously good at describing the past. Treat this as a way to notice what's changed in your positions, not as advice. I'm not a financial adviser, and the decision stays yours."))) : !anRunning && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 28,
        textAlign: "center"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 38,
        marginBottom: 8
      }
    }, "\uD83D\uDD2C"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#e2e8f0",
        marginBottom: 6
      }
    }, anSaved && anSaved.rows && anSaved.rows.length ? "Nothing matches that verdict filter" : "No analysis yet"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        lineHeight: 1.7,
        maxWidth: 660,
        margin: "0 auto"
      }
    }, anSaved && anSaved.rows && anSaved.rows.length ? /*#__PURE__*/React.createElement(React.Fragment, null, "Set the verdict filter back to ", /*#__PURE__*/React.createElement("b", null, "All verdicts"), ".") : /*#__PURE__*/React.createElement(React.Fragment, null, "Press ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#a78bfa"
      }
    }, "Analyse"), " to score all ", screenUniverse.length, " stocks you hold, trade or watch \u2014 fundamentals on one side, trend and momentum on the other. Two requests per stock, so a couple of minutes.")))), (mainTab === "watchlist" || mainTab === "calendar") && /*#__PURE__*/React.createElement("iframe", {
      key: mainTab,
      src: mainTab === "watchlist" ? "watchlist.html" : "calendar.html",
      title: mainTab,
      style: {
        width: "100%",
        height: "calc(100vh - 150px)",
        border: "1px solid #2d3748",
        borderRadius: 10,
        background: "#1b1e29"
      }
    }), mainTab === "discover" && /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 16
      }
    }, dsShowCfg && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 4
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#22d3ee"
      }
    }, "\u2699 Discovery Criteria"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "#f87171",
        fontSize: 12
      },
      onClick: resetDsCfg
    }, "Reset to defaults")), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        marginBottom: 12
      }
    }, "Stage 1 filters all 500 on fundamentals. Stage 2 pulls option chains only for the survivors \u2014 that's what keeps the run to minutes."), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: "#a78bfa",
        fontWeight: 700,
        margin: "4px 0 6px"
      }
    }, "SECTORS \u2014 applied before anything is requested"), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#1b1e29",
        border: "1px solid #2d3748",
        borderRadius: 8,
        padding: "10px 12px",
        marginBottom: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        marginBottom: 8
      }
    }, "Tick sectors to scan only those. This is filtered off the S&P 500 constituent list itself, so excluded sectors cost ", /*#__PURE__*/React.createElement("b", null, "no requests at all"), " \u2014 the fastest way to shorten a scan.", (dsCfg.sectors || []).length > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#4ade80"
      }
    }, " Roughly ", Math.round((1 - (dsCfg.sectors || []).length / GICS_SECTORS.length) * 100), "% fewer symbols than a full sweep.")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        flexWrap: "wrap",
        marginBottom: 8
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "#e2e8f0",
        fontSize: 11,
        padding: "3px 9px"
      },
      onClick: () => setDS("sectors", [])
    }, "All sectors"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "#e2e8f0",
        fontSize: 11,
        padding: "3px 9px"
      },
      onClick: () => setDS("sectors", [...GICS_SECTORS])
    }, "Select all")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill,minmax(190px,1fr))",
        gap: 6
      }
    }, GICS_SECTORS.map(sec => {
      const on = (dsCfg.sectors || []).includes(sec);
      return /*#__PURE__*/React.createElement("div", {
        key: sec,
        style: {
          display: "flex",
          alignItems: "center",
          gap: 7
        }
      }, /*#__PURE__*/React.createElement("input", {
        type: "checkbox",
        id: "gics-" + sec,
        checked: on,
        onChange: () => {
          const cur = dsCfg.sectors || [];
          setDS("sectors", on ? cur.filter(x => x !== sec) : [...cur, sec]);
        },
        style: {
          cursor: "pointer",
          width: 15,
          height: 15
        }
      }), /*#__PURE__*/React.createElement("label", {
        htmlFor: "gics-" + sec,
        style: {
          fontSize: 12.5,
          color: on ? "#e2e8f0" : "#94a3b8",
          cursor: "pointer"
        }
      }, sec));
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#4b5563",
        marginTop: 8
      }
    }, "None ticked = every sector. These are GICS names from the index list, not Yahoo's \u2014 the sector shown in the results table comes from Yahoo and is worded differently.")), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: "#22d3ee",
        fontWeight: 700,
        margin: "4px 0 8px"
      }
    }, "STAGE 1 \u2014 the business"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill,minmax(180px,1fr))",
        gap: 12
      }
    }, [{
      k: "priceMin",
      l: "Min share price $",
      step: 5
    }, {
      k: "priceMax",
      l: "Max share price $",
      step: 25,
      hint: "caps collateral per contract"
    }, {
      k: "marketCapMin",
      l: "Min market cap $B",
      step: 1
    }, {
      k: "peMin",
      l: "Min P/E",
      step: 1
    }, {
      k: "peMax",
      l: "Max P/E",
      step: 5
    }, {
      k: "marginMin",
      l: "Min profit margin %",
      step: 1
    }, {
      k: "roeMin",
      l: "Min return on equity %",
      step: 1
    }, {
      k: "revGrowthMin",
      l: "Min revenue growth %",
      step: 1,
      hint: "0 = not shrinking"
    }, {
      k: "avgVolumeMin",
      l: "Min avg volume (M shares)",
      step: 0.5
    }].map(f => /*#__PURE__*/React.createElement("div", {
      key: f.k
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, f.l), /*#__PURE__*/React.createElement("input", {
      className: "inp",
      type: "number",
      step: f.step,
      value: dsCfg[f.k],
      onChange: e => setDS(f.k, e.target.value)
    }), f.hint && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        color: "#4b5563",
        marginTop: 3
      }
    }, f.hint)))), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: "#c2410c",
        fontWeight: 700,
        margin: "16px 0 6px"
      }
    }, "STAGE 2 \u2014 the contracts"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        marginBottom: 8
      }
    }, "The same screen the ", /*#__PURE__*/React.createElement("b", null, "\uD83C\uDFAF Screener"), " tab runs, applied to whatever survived stage 1. A name that appears here will behave the same way when you screen it properly later.", /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8,
        marginTop: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: "#94a3b8"
      }
    }, "Contract type"), /*#__PURE__*/React.createElement("select", {
      className: "inp",
      style: {
        width: 190
      },
      value: dsCfg.side || "put",
      onChange: e => setDS("side", e.target.value)
    }, /*#__PURE__*/React.createElement("option", {
      value: "put"
    }, "Cash-secured puts"), /*#__PURE__*/React.createElement("option", {
      value: "call"
    }, "Calls")))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill,minmax(180px,1fr))",
        gap: 12
      }
    }, [{
      k: "dteMin",
      l: "Min days to expiry",
      step: 1
    }, {
      k: "dteMax",
      l: "Max days to expiry",
      step: 1
    }, {
      k: "deltaMin",
      l: "Min |Delta|",
      step: 0.01,
      hint: "≈ chance of assignment"
    }, {
      k: "deltaMax",
      l: "Max |Delta|",
      step: 0.01
    }, {
      k: "ivMin",
      l: "Min IV %",
      step: 5,
      hint: "the premium you're hunting"
    }, {
      k: "ivMax",
      l: "Max IV %",
      step: 5,
      hint: "above this is usually trouble"
    }, {
      k: "minAnnualized",
      l: "Min annualized %",
      step: 5,
      hint: "after the $0.67 fee"
    }, {
      k: "minNetPremium",
      l: "Min premium $/contract",
      step: 5,
      hint: "after the $0.67 fee"
    }, {
      k: "minIVHV",
      l: "Min IV ÷ HV",
      step: 0.05,
      hint: "0 = rank by Score only"
    }, {
      k: "minPremium",
      l: "Min premium $/share",
      step: 0.05
    }, {
      k: "minOI",
      l: "Min open interest",
      step: 50
    }, {
      k: "minVolume",
      l: "Min volume today",
      step: 10
    }, {
      k: "maxSpreadPct",
      l: "Max bid/ask spread %",
      step: 1
    }, {
      k: "minBid",
      l: "Min bid $",
      step: 0.05
    }, {
      k: "maxPerTicker",
      l: "Max contracts / stock",
      step: 1,
      hint: "1 keeps the list one row per name"
    }, {
      k: "maxExpiries",
      l: "Expiries checked / stock",
      step: 1,
      hint: "each one is a request — 2 is a good balance"
    }, {
      k: "workers",
      l: "Parallel requests",
      step: 1,
      hint: "hides network latency; the rate cap still applies"
    }, {
      k: "requestsPerSecond",
      l: "Requests per second",
      step: 1,
      hint: "target — backs off on its own if throttled"
    }].map(f => /*#__PURE__*/React.createElement("div", {
      key: f.k
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, f.l), /*#__PURE__*/React.createElement("input", {
      className: "inp",
      type: "number",
      step: f.step,
      value: dsCfg[f.k],
      onChange: e => setDS(f.k, e.target.value)
    }), f.hint && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        color: "#4b5563",
        marginTop: 3
      }
    }, f.hint)))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 20,
        flexWrap: "wrap",
        marginTop: 14,
        paddingTop: 12,
        borderTop: "1px solid #2d3748"
      }
    }, [{
      k: "positiveEPS",
      l: "Require positive earnings per share"
    }, {
      k: "allowMissingMetrics",
      l: "Keep stocks where Yahoo has no figure for a metric"
    }, {
      k: "skipEarnings",
      l: "Skip expirations that span an earnings date"
    }].map(c => /*#__PURE__*/React.createElement("div", {
      key: c.k,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "checkbox",
      id: "ds-" + c.k,
      checked: !!dsCfg[c.k],
      onChange: e => setDS(c.k, e.target.checked),
      style: {
        cursor: "pointer",
        width: 16,
        height: 16
      }
    }), /*#__PURE__*/React.createElement("label", {
      htmlFor: "ds-" + c.k,
      style: {
        fontSize: 13,
        color: "#e2e8f0",
        cursor: "pointer"
      }
    }, c.l))))), dsSaved && dsSaved.stats && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "baseline",
        flexWrap: "wrap",
        gap: 8,
        marginBottom: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#22d3ee"
      }
    }, "\uD83D\uDCCA Scan Funnel"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: dsAgeDays != null && dsAgeDays >= 7 ? "#fbbf24" : "#94a3b8"
      }
    }, "Last run ", dsSaved.ranAt ? new Date(dsSaved.ranAt).toLocaleString() : "—", dsAgeDays != null && (dsAgeDays === 0 ? " · today" : dsAgeDays === 1 ? " · yesterday" : ` · ${dsAgeDays} days ago`), dsAgeDays != null && dsAgeDays >= 7 && " — worth re-running")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 10,
        flexWrap: "wrap"
      }
    }, [["Scanned", dsSaved.stats.universe, "#94a3b8"], ["Passed fundamentals", dsSaved.stats.stage1_pass, "#22d3ee"], ["Candidates", dsSaved.stats.stage2_pass, "#4ade80"], ["New to you", (dsSaved.rows || []).filter(r => !dsOwned(r.Ticker)).length, "#fbbf24"]].map(([l, v, c]) => /*#__PURE__*/React.createElement("div", {
      key: l,
      style: {
        background: "#1b1e29",
        border: "1px solid #2d3748",
        borderRadius: 8,
        padding: "8px 14px",
        minWidth: 130,
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: "#94a3b8"
      }
    }, l), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 20,
        fontWeight: 700,
        color: c,
        marginTop: 2
      }
    }, v)))), dsStats && dsStats.rate_limited > 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#2a1f1f",
        border: "1px solid #b45309",
        borderRadius: 8,
        padding: "12px 14px",
        marginTop: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: 700,
        color: "#fbbf24",
        marginBottom: 6
      }
    }, "\u26A0 Yahoo rate-limited this scan \u2014 ", dsStats.rate_limited, " symbol", dsStats.rate_limited === 1 ? "" : "s", " came back empty"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#cbd5e1",
        lineHeight: 1.8
      }
    }, "Those symbols were never assessed against your criteria; the request was refused before any data came back.", dsStats.rate_limit_severe && /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#fca5a5"
      }
    }, " Enough were affected that the numbers below aren't a fair verdict on your settings \u2014 don't loosen anything based on this run."), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 8
      }
    }, /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#e2e8f0"
      }
    }, "What to do:"), " open \u2699 Criteria and lower ", /*#__PURE__*/React.createElement("b", null, "Requests per second"), " (try 3) and ", /*#__PURE__*/React.createElement("b", null, "Parallel requests"), " (try 2), then scan again. It'll take longer but finish properly. Yahoo's limits are per-IP and recover after a few minutes, so waiting a little before retrying helps too."), dsStats.rate && (dsStats.rate.retries > 0 || dsStats.rate.gave_up > 0) && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#94a3b8",
        marginTop: 8
      }
    }, dsStats.rate.hits, " throttled response", dsStats.rate.hits === 1 ? "" : "s", " \xB7 ", dsStats.rate.retries, " recovered on retry \xB7 ", dsStats.rate.gave_up, " gave up after backing off"))), dsSaved.stats.universeSource && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 12,
        fontSize: 12,
        background: dsSaved.stats.universeSource.includes("fallback") ? "#2a1f1f" : "#1b1e29",
        border: "1px solid " + (dsSaved.stats.universeSource.includes("fallback") ? "#7f1d1d" : "#2d3748"),
        borderRadius: 7,
        padding: "8px 12px",
        color: dsSaved.stats.universeSource.includes("fallback") ? "#fca5a5" : "#94a3b8"
      }
    }, dsSaved.stats.universeSource.includes("fallback") ? "⚠ " : "Universe: ", dsSaved.stats.universeSource, dsSaved.stats.universeSource.includes("fallback") && /*#__PURE__*/React.createElement("span", null, " Run ", /*#__PURE__*/React.createElement("b", null, "Diagnose_Screener.bat"), " to see which step failed."), dsStats.skippedBySector > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#a78bfa"
      }
    }, " \xB7 ", dsStats.skippedBySector, " symbols skipped by the sector filter before any request was made.")), dsSaved.stats.rejects && Object.keys(dsSaved.stats.rejects).length > 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#4b5563",
        marginTop: 12,
        lineHeight: 1.8
      }
    }, /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#94a3b8"
      }
    }, "Why the rest dropped out:"), " ", Object.entries(dsSaved.stats.rejects).map(([k, v]) => `${k} (${v})`).join(" · "))), dsRows.length > 0 ? /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#4ade80",
        marginBottom: 12
      }
    }, "\uD83D\uDD2D Candidates"), /*#__PURE__*/React.createElement("div", {
      style: {
        overflowX: "auto"
      }
    }, /*#__PURE__*/React.createElement("table", {
      style: {
        width: "100%",
        borderCollapse: "collapse",
        fontSize: 12.5,
        whiteSpace: "nowrap"
      }
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
      style: {
        background: "#1b1e29",
        color: "#94a3b8"
      }
    }, /*#__PURE__*/React.createElement("th", {
      style: {
        padding: "8px 7px",
        borderBottom: "1px solid #2d3748"
      }
    }), [["Score", "Score"], ["Ticker", "Ticker"], ["Name", "Company"], ["Sector", "Sector"], ["Price", "Price"], ["Side", "Side"], ["Expiry", "Expiry"], ["DTE", "DTE"], ["Strike", "Strike"], ["OTM %", "OTM%"], ["Mid", "Prem"], ["Net Premium $", "Net $"], ["Annualized %", "Ann %"], ["IV", "IV"], ["IV/HV", "IV/HV"], ["IV Rank", "IVR"], ["Delta", "Δ"], ["PoP (est)", "PoP"], ["Breakeven", "B/E"], ["OI", "OI"], ["Spread %", "Spr%"], ["Collateral $", "Collateral"], ["PE", "P/E"], ["Margin %", "Margin"], ["ROE %", "ROE"], ["Rev Growth %", "Rev↑"], ["EPS Growth %", "EPS↑"], ["Mkt Cap $B", "Cap $B"], ["Avg Vol M", "Vol M"], ["Beta", "Beta"], ["Div %", "Div"]].map(([k, l]) => /*#__PURE__*/React.createElement("th", {
      key: k,
      onClick: () => dsSortBy(k),
      title: "Sort by " + k,
      style: {
        padding: "8px 7px",
        textAlign: "left",
        cursor: "pointer",
        userSelect: "none",
        borderBottom: "1px solid #2d3748",
        fontWeight: 600
      }
    }, l, dsSort.key === k ? dsSort.dir === "desc" ? " ▾" : " ▴" : "")))), /*#__PURE__*/React.createElement("tbody", null, dsRows.map((r, i) => {
      const owned = dsOwned(r.Ticker);
      return /*#__PURE__*/React.createElement("tr", {
        key: r.Ticker,
        style: {
          borderBottom: "1px solid #2d3748",
          background: dsPicked.has(r.Ticker) ? "#14532d" : i % 2 ? "#232739" : "transparent"
        }
      }, /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px"
        }
      }, owned ? /*#__PURE__*/React.createElement("span", {
        title: "Already on your watchlist",
        style: {
          color: "#4ade80",
          fontSize: 13
        }
      }, "\u2713") : /*#__PURE__*/React.createElement("input", {
        type: "checkbox",
        checked: dsPicked.has(r.Ticker),
        onChange: () => dsTogglePick(r.Ticker),
        style: {
          cursor: "pointer",
          width: 15,
          height: 15
        }
      })), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px"
        }
      }, /*#__PURE__*/React.createElement(ScoreBadge, {
        row: r
      })), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          fontWeight: 700
        }
      }, /*#__PURE__*/React.createElement("a", {
        className: "ticker-link",
        href: `https://finance.yahoo.com/quote/${r.Ticker}`,
        target: "_blank",
        style: {
          color: "#60a5fa"
        }
      }, r.Ticker), /*#__PURE__*/React.createElement(ScreenFlags, {
        r: r
      })), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#cbd5e1",
          maxWidth: 210,
          overflow: "hidden",
          textOverflow: "ellipsis"
        }
      }, r.Name), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#94a3b8",
          fontSize: 11.5
        }
      }, r.Sector), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px"
        }
      }, fmt$(r.Price)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          background: r.Side === "PUT" ? "#1e3a5f" : "#3f2d14",
          color: r.Side === "PUT" ? "#60a5fa" : "#fbbf24",
          borderRadius: 4,
          padding: "2px 6px",
          fontWeight: 700,
          fontSize: 11
        }
      }, r.Side)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#cbd5e1"
        }
      }, r.Expiry, r["Earnings Before Exp"] && /*#__PURE__*/React.createElement("span", {
        title: "Earnings " + (r["Next Earnings"] || "") + " falls before expiry",
        style: {
          marginLeft: 5,
          color: "#fbbf24"
        }
      }, "\u26A0")), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#94a3b8"
        }
      }, r.DTE), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          fontWeight: 600
        }
      }, fmt$(r.Strike)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: r["OTM %"] >= 0 ? "#4ade80" : "#f87171"
        }
      }, r["OTM %"] != null ? r["OTM %"].toFixed(1) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#4ade80"
        }
      }, fmt$(r.Mid)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#4ade80",
          fontWeight: 600
        }
      }, r["Net Premium $"] != null ? "$" + Math.round(r["Net Premium $"]) : r["Premium $"] != null ? "$" + Math.round(r["Premium $"]) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          fontWeight: 700,
          color: "#fbbf24"
        }
      }, r["Annualized %"] != null ? r["Annualized %"].toFixed(1) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#a78bfa",
          fontWeight: 600
        }
      }, r.IV != null ? (r.IV * 100).toFixed(0) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: r["IV/HV"] == null ? "#4b5563" : r["IV/HV"] >= 1.1 ? "#4ade80" : "#94a3b8"
        }
      }, r["IV/HV"] != null ? r["IV/HV"].toFixed(2) : "—"), (() => {
        const v = ivrText(r);
        return /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 7px",
            color: v.c
          },
          title: v.tip
        }, v.t);
      })(), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#94a3b8"
        }
      }, r.Delta != null ? r.Delta.toFixed(2) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#2dd4bf"
        }
      }, r["PoP (est)"] != null ? (r["PoP (est)"] * 100).toFixed(0) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#cbd5e1"
        }
      }, fmt$(r.Breakeven)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#94a3b8"
        }
      }, r.OI != null ? r.OI.toLocaleString() : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: r["Spread %"] > 12 ? "#f87171" : "#94a3b8"
        }
      }, r["Spread %"] != null ? r["Spread %"].toFixed(0) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#94a3b8"
        }
      }, r["Collateral $"] ? "$" + Math.round(r["Collateral $"]).toLocaleString() : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#94a3b8"
        }
      }, r.PE != null ? r.PE.toFixed(0) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: r["Margin %"] >= 0 ? "#4ade80" : "#f87171"
        }
      }, r["Margin %"] != null ? r["Margin %"].toFixed(0) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: r["ROE %"] >= 0 ? "#4ade80" : "#f87171"
        }
      }, r["ROE %"] != null ? r["ROE %"].toFixed(0) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: r["Rev Growth %"] >= 0 ? "#4ade80" : "#f87171"
        }
      }, r["Rev Growth %"] != null ? r["Rev Growth %"].toFixed(0) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: r["EPS Growth %"] >= 0 ? "#4ade80" : "#f87171"
        }
      }, r["EPS Growth %"] != null ? r["EPS Growth %"].toFixed(0) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#94a3b8"
        }
      }, r["Mkt Cap $B"] ?? "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#94a3b8"
        }
      }, r["Avg Vol M"] ?? "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#94a3b8"
        }
      }, r.Beta ?? "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: r["Div %"] > 0 ? "#94a3b8" : "#4b5563"
        }
      }, r["Div %"] != null ? r["Div %"] > 0 ? r["Div %"].toFixed(2) + "%" : "—" : "—"));
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#4b5563",
        marginTop: 12,
        lineHeight: 1.7
      }
    }, "Tick the ones you want and press ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#4ade80"
      }
    }, "\uFF0B Add to watchlist"), ". A ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#4ade80"
      }
    }, "\u2713"), " means it's already there.", /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 4
      }
    }, "These are real contracts, screened on the same rules as the ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#fb923c"
      }
    }, "\uD83C\uDFAF Screener"), " tab \u2014 the best ", dsCfg.maxPerTicker, " per stock, from the ", dsCfg.maxExpiries, " expiries nearest the middle of your DTE window. Add a name to your watchlist and screen it properly to see its whole chain. High IV is the market pricing a large move; the fundamentals columns are there to tell you whether you'd be content owning the shares if it goes against you."))) : !dsRunning && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 28,
        textAlign: "center"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 38,
        marginBottom: 8
      }
    }, "\uD83D\uDD2D"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#e2e8f0",
        marginBottom: 6
      }
    }, dsAllRows.length ? "Your filters are hiding everything" : dsHasRun ? "The scan ran, but no stock met every criterion" : "No scan yet"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        lineHeight: 1.8,
        maxWidth: 700,
        margin: "0 auto"
      }
    }, !dsAllRows.length && dsHasRun && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        justifyContent: "center",
        flexWrap: "wrap",
        margin: "6px 0 14px"
      }
    }, [["Scanned", dsStats.universe, "#94a3b8"], ["Passed fundamentals", dsStats.stage1_pass, dsStats.stage1_pass ? "#22d3ee" : "#f87171"], ["Passed options", dsStats.stage2_pass, "#f87171"]].map(([l, v, c]) => /*#__PURE__*/React.createElement("div", {
      key: l,
      style: {
        background: "#1b1e29",
        border: "1px solid #2d3748",
        borderRadius: 8,
        padding: "8px 14px",
        minWidth: 120
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#94a3b8"
      }
    }, l), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 19,
        fontWeight: 700,
        color: c,
        marginTop: 2
      }
    }, v)))), dsStats.rate_limit_severe ? /*#__PURE__*/React.createElement("div", {
      style: {
        color: "#fbbf24"
      }
    }, /*#__PURE__*/React.createElement("b", null, "This was a network problem, not a screening one."), " Yahoo throttled ", dsStats.rate_limited, " of the requests, so most symbols were never actually assessed. Lower ", /*#__PURE__*/React.createElement("b", null, "Requests per second"), " and ", /*#__PURE__*/React.createElement("b", null, "Parallel requests"), " in \u2699 Criteria and scan again before changing any of your screening thresholds.") : dsBlame === "stage1" ? /*#__PURE__*/React.createElement("div", null, "Every stock failed on ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#22d3ee"
      }
    }, "fundamentals"), ", so no option chains were even fetched. The quality floors are too strict for this universe.") : /*#__PURE__*/React.createElement("div", null, dsStats.stage1_pass, " stock", dsStats.stage1_pass === 1 ? "" : "s", " passed the fundamentals, then all of them failed on the ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#c2410c"
      }
    }, "option filters"), ".", dsObsIV && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#1b1e29",
        border: "1px solid #2d3748",
        borderRadius: 8,
        padding: "10px 14px",
        margin: "12px auto 0",
        maxWidth: 520
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: "#94a3b8",
        marginBottom: 6
      }
    }, "Implied volatility on the contracts actually examined (", dsObsIV.n, ")"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#e2e8f0"
      }
    }, "lowest ", /*#__PURE__*/React.createElement("b", null, (dsObsIV.min * 100).toFixed(0), "%"), " \xB7 median ", /*#__PURE__*/React.createElement("b", null, (dsObsIV.p50 * 100).toFixed(0), "%"), " \xB7 top decile ", /*#__PURE__*/React.createElement("b", null, (dsObsIV.p90 * 100).toFixed(0), "%"), " \xB7 highest ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#a78bfa"
      }
    }, (dsObsIV.max * 100).toFixed(0), "%")), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: dsObsIV.max < dsStats.observed.ivFloor ? "#fca5a5" : "#94a3b8",
        marginTop: 6
      }
    }, "Your floor is ", /*#__PURE__*/React.createElement("b", null, (dsStats.observed.ivFloor * 100).toFixed(0), "%"), dsObsIV.max < dsStats.observed.ivFloor ? " — above even the most volatile of them, so nothing could pass." : " — something else in the option filters is catching them.")), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        marginTop: 10,
        maxWidth: 560,
        margin: "10px auto 0"
      }
    }, "This is the tension in the scan: stage 1 selects for stable, profitable businesses, and those are exactly the names with ", /*#__PURE__*/React.createElement("i", null, "low"), " volatility. Asking for high quality and high IV at once narrows fast."))), dsTopRejects.length > 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: "left",
        display: "inline-block",
        marginTop: 12,
        fontSize: 12,
        lineHeight: 1.9
      }
    }, /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#e2e8f0"
      }
    }, "What caught them:"), dsTopRejects.map(([k, v]) => /*#__PURE__*/React.createElement("div", {
      key: k
    }, "\xB7 ", k, " \u2014 ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#fbbf24"
      }
    }, v)))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 16,
        display: "flex",
        gap: 8,
        justifyContent: "center",
        flexWrap: "wrap"
      }
    }, dsStats.rate_limit_severe && /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#b45309",
        color: "white"
      },
      onClick: dsSlowDown
    }, "\uD83D\uDC22 Slow down and re-scan"), dsObsIV && dsBlame !== "stage1" && !dsStats.rate_limit_severe && /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#7c3aed",
        color: "white"
      },
      onClick: () => dsUseObservedIV(dsObsIV.p90),
      title: `Keeps only the most volatile tenth of what the scan found (${(dsObsIV.p90 * 100).toFixed(0)}% and above)`
    }, "\u21E2 Set IV floor to ", (dsObsIV.p90 * 100).toFixed(0), "% (top decile)"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#059669",
        color: "white"
      },
      onClick: dsLoosen
    }, "\u27F2 Loosen ", dsBlame === "stage1" ? "quality floors" : "option filters"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#2c3346",
        color: "white"
      },
      onClick: () => setDsShowCfg(true)
    }, "\u2699 Open criteria"))), dsAllRows.length ? /*#__PURE__*/React.createElement(React.Fragment, null, "The scan found ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#4ade80"
      }
    }, dsAllRows.length), " candidate", dsAllRows.length === 1 ? "" : "s", ", but none survive the current filters:", /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: "left",
        display: "inline-block",
        marginTop: 10
      }
    }, dsHiddenByOwned > 0 && /*#__PURE__*/React.createElement("div", null, "\xB7 ", /*#__PURE__*/React.createElement("b", null, "Hide ones I already track"), " is hiding ", dsHiddenByOwned), dsSector !== "all" && /*#__PURE__*/React.createElement("div", null, "\xB7 Sector ", /*#__PURE__*/React.createElement("b", null, dsSector), " is hiding ", dsHiddenBySector, dsSectorStale && /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#fbbf24"
      }
    }, " \u2014 that sector isn't in this scan at all, it's left over from a previous run"))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 14
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#059669",
        color: "white"
      },
      onClick: dsClearFilters
    }, "\u2715 Clear filters and show all ", dsAllRows.length))) : !dsHasRun && /*#__PURE__*/React.createElement(React.Fragment, null, "Press ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#22d3ee"
      }
    }, "Scan S&P 500"), " to look for stocks with high implied volatility that are also profitable and growing. Takes a few minutes \u2014 you can switch tabs while it runs. Once or twice a week is plenty; the results are saved here between sessions.")))), mainTab === "screener" && /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 16
      }
    }, scrService === "down" && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#2a1f1f",
        border: "1px solid #7f1d1d",
        borderRadius: 10,
        padding: 18
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#fca5a5",
        marginBottom: 10
      }
    }, "\u26A0 Can't reach the screener service"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#cbd5e1",
        lineHeight: 1.7
      }
    }, "Work through these in order \u2014 it's almost always the first one.", /*#__PURE__*/React.createElement("ol", {
      style: {
        margin: "12px 0 0 20px",
        padding: 0,
        lineHeight: 2
      }
    }, /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#e2e8f0"
      }
    }, "Start it with a visible console."), " Double-click ", /*#__PURE__*/React.createElement("code", {
      style: {
        color: "#fbbf24"
      }
    }, "Start_Screener_Service.bat"), " (not the .pyw). A ", /*#__PURE__*/React.createElement("code", null, ".pyw"), " file runs with no console, so if Python is missing or the install fails it closes instantly with nothing shown. The .bat keeps the window open and prints the reason."), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#e2e8f0"
      }
    }, "Check the connection directly."), " Open ", /*#__PURE__*/React.createElement("a", {
      href: `${SCREENER_URL}/health`,
      target: "_blank",
      style: {
        color: "#60a5fa"
      }
    }, SCREENER_URL, "/health"), " in a tab. If you see ", /*#__PURE__*/React.createElement("code", {
      style: {
        color: "#4ade80"
      }
    }, `{"ok":true...}`), " the service is fine and the problem is the browser \u2014 see step 4. If the page won't load, the service isn't running."), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#e2e8f0"
      }
    }, "Run the diagnostics."), " Double-click ", /*#__PURE__*/React.createElement("code", {
      style: {
        color: "#fbbf24"
      }
    }, "Diagnose_Screener.bat"), ". It checks Python, the packages, the port, and whether Yahoo is reachable, then tells you exactly which link is broken."), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#e2e8f0"
      }
    }, "If /health works but this page still says offline"), ", Chrome is blocking a local-network request from a ", /*#__PURE__*/React.createElement("code", null, "file://"), " page. Open ", /*#__PURE__*/React.createElement("code", {
      style: {
        color: "#fbbf24"
      }
    }, "chrome://flags"), ", set ", /*#__PURE__*/React.createElement("i", null, "Block insecure private network requests"), " to ", /*#__PURE__*/React.createElement("b", null, "Disabled"), ", and restart Chrome. Edge and Firefox don't have this restriction.")), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 12,
        color: "#94a3b8",
        fontSize: 12,
        borderTop: "1px solid #4b1d1d",
        paddingTop: 10
      }
    }, "Why a separate service at all: browsers can't fetch option chains. Yahoo blocks cross-origin requests and Finnhub's chain endpoint is paid-tier \u2014 your key works for ", /*#__PURE__*/React.createElement("code", null, "/quote"), " because that one is free. So the fetching happens in Python, the same way ", /*#__PURE__*/React.createElement("code", null, "Options_Updater.pyw"), " does its work. It listens only on 127.0.0.1; nothing outside this machine can reach it."))), wlShow && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "baseline",
        flexWrap: "wrap",
        gap: 8,
        marginBottom: 4
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#fb923c"
      }
    }, "\u2605 Watchlist"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: wlExcluded.size ? "#fbbf24" : "#94a3b8"
      }
    }, /*#__PURE__*/React.createElement("b", null, activeUniverse.length), " of ", screenUniverse.length, " will be scanned", wlExcluded.size > 0 && ` · ${wlExcluded.size} sitting out`), wlExcluded.size > 0 && /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "#4ade80",
        fontSize: 12,
        padding: "4px 10px"
      },
      onClick: includeAll
    }, "Include all"), wlExcluded.size < screenUniverse.length && /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "#f87171",
        fontSize: 12,
        padding: "4px 10px"
      },
      onClick: excludeAll
    }, "Exclude all"))), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        marginBottom: 12
      }
    }, "Untick a symbol to skip it on the next scan without removing it from your list. Click a company name to edit it \u2014 that name is what the trade and holding forms autofill."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        flexWrap: "wrap",
        alignItems: "center",
        marginBottom: 10
      }
    }, /*#__PURE__*/React.createElement("input", {
      className: "inp",
      style: {
        width: 290
      },
      placeholder: "Add tickers \u2014 e.g. PLTR, SOFI HOOD",
      value: wlInput,
      onChange: e => setWlInput(e.target.value),
      onKeyDown: e => {
        if (e.key === "Enter" && !wlBusy) addWatchlistTickers(wlInput);
      }
    }), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: wlBusy ? "#374151" : "#059669",
        color: "white",
        opacity: wlBusy ? 0.7 : 1
      },
      disabled: wlBusy,
      onClick: () => addWatchlistTickers(wlInput)
    }, wlBusy ? "⏳ Verifying…" : "＋ Add"), unnamedTickers.length > 0 && /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: wlBusy ? "#374151" : "#1e3a5f",
        color: "#60a5fa",
        opacity: wlBusy ? 0.7 : 1
      },
      disabled: wlBusy,
      onClick: fillMissingNames,
      title: "Look up: " + unnamedTickers.join(", ")
    }, "\u2B07 Fill ", unnamedTickers.length, " missing name", unnamedTickers.length > 1 ? "s" : ""), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        color: "#4b5563"
      }
    }, "Separate with commas or spaces. Each is checked for listed options before it's added.")), wlStatus && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: wlStatus.startsWith("❌") ? "#fca5a5" : wlStatus.startsWith("⚠") ? "#fbbf24" : "#94a3b8",
        marginBottom: 12,
        lineHeight: 1.6
      }
    }, wlStatus), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill,minmax(330px,1fr))",
        gap: 4,
        maxHeight: 420,
        overflowY: "auto"
      }
    }, screenUniverse.map(tk => {
      const src = tickerSource(tk);
      const off = wlExcluded.has(tk);
      const nm = tickerName(tk);
      return /*#__PURE__*/React.createElement("div", {
        key: tk,
        style: {
          display: "flex",
          alignItems: "center",
          gap: 8,
          background: off ? "#232739" : "#2c3346",
          border: "1px solid " + (off ? "#374151" : src.color),
          borderRadius: 7,
          padding: "5px 8px",
          opacity: off ? 0.55 : 1
        }
      }, /*#__PURE__*/React.createElement("input", {
        type: "checkbox",
        checked: !off,
        onChange: () => toggleExcluded(tk),
        title: off ? `Include ${tk} in the next scan` : `Skip ${tk} on the next scan`,
        style: {
          cursor: "pointer",
          width: 15,
          height: 15,
          flexShrink: 0
        }
      }), /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 12.5,
          fontWeight: 700,
          width: 58,
          flexShrink: 0,
          textDecoration: off ? "line-through" : "none"
        }
      }, tk), wlEditing === tk ? /*#__PURE__*/React.createElement("input", {
        className: "inp",
        autoFocus: true,
        style: {
          flex: 1,
          fontSize: 11.5,
          padding: "3px 6px"
        },
        value: wlEditVal,
        placeholder: "Company name\u2026",
        onChange: e => setWlEditVal(e.target.value),
        onBlur: commitEditName,
        onKeyDown: e => {
          if (e.key === "Enter") commitEditName();
          if (e.key === "Escape") {
            setWlEditing(null);
            setWlEditVal("");
          }
        }
      }) : /*#__PURE__*/React.createElement("span", {
        onClick: () => startEditName(tk),
        title: nm ? `${nm}\n(${nameSource(tk)}) — click to edit` : "Click to add a company name",
        style: {
          flex: 1,
          fontSize: 11.5,
          color: nm ? "#cbd5e1" : "#4b5563",
          cursor: "text",
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
          fontStyle: nm ? "normal" : "italic"
        }
      }, nm || "add company name…"), /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 9,
          color: src.color === "#4b5563" ? "#94a3b8" : src.color,
          textTransform: "uppercase",
          letterSpacing: 0.4,
          fontWeight: 700,
          flexShrink: 0
        }
      }, src.label), src.removable ? /*#__PURE__*/React.createElement("button", {
        title: "Remove " + tk + " from your list",
        onClick: () => removeWatchlist(tk),
        style: {
          background: "none",
          border: "none",
          color: "#f87171",
          cursor: "pointer",
          fontSize: 15,
          lineHeight: 1,
          padding: "0 2px",
          flexShrink: 0
        }
      }, "\xD7") : /*#__PURE__*/React.createElement("span", {
        style: {
          width: 13,
          flexShrink: 0
        }
      }));
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#4b5563",
        marginTop: 12,
        lineHeight: 1.7,
        borderTop: "1px solid #2d3748",
        paddingTop: 10
      }
    }, "Unticking is temporary \u2014 the symbol stays on your list and the setting sticks until you tick it back.", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#f87171"
      }
    }, " \xD7"), " is the permanent one, and only appears on names you added yourself.", /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 6
      }
    }, /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#c2410c"
      }
    }, "YOURS"), " you added \u2014 removable \xB7", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#0d9488"
      }
    }, " HELD"), " you own shares \xB7", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#4338ca"
      }
    }, " TRADED"), " appears in your trade log \xB7", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#94a3b8"
      }
    }, " BUILT-IN"), " shipped with the app."), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 4
      }
    }, "Held and traded names come from your own data and drop off on their own when you close the position. Names and exclusions are saved with ", /*#__PURE__*/React.createElement("b", null, "\uD83D\uDCBE Save Data"), "."))), scrShowRolls && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #7c3aed",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        flexWrap: "wrap",
        gap: 8,
        marginBottom: 6
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#a78bfa"
      }
    }, "\uD83D\uDD01 Roll Candidates"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 12,
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement("label", {
      style: {
        fontSize: 12.5,
        color: "#cbd5e1",
        display: "flex",
        gap: 6,
        alignItems: "center",
        cursor: "pointer"
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "checkbox",
      checked: rollDebits,
      onChange: e => setRollDebits(e.target.checked),
      style: {
        width: 15,
        height: 15
      }
    }), "Include rolls that cost money (debits)"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: rollBusy ? "#374151" : "#7c3aed",
        color: "white",
        opacity: rollBusy ? 0.7 : 1
      },
      disabled: rollBusy,
      onClick: runRolls
    }, rollBusy ? "⏳ Checking…" : "↻ Check my positions"))), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        marginBottom: 10,
        lineHeight: 1.6
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 14,
        flexWrap: "wrap",
        alignItems: "center",
        marginBottom: 8,
        color: "#cbd5e1",
        fontSize: 12.5
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 700,
        color: "#a78bfa",
        display: "flex",
        gap: 6,
        alignItems: "center"
      }
    }, "Show", /*#__PURE__*/React.createElement("select", {
      className: "inp",
      style: {
        padding: "3px 6px",
        width: "auto"
      },
      value: rollRules.type || "All",
      onChange: e => setRR("type", e.target.value)
    }, /*#__PURE__*/React.createElement("option", {
      value: "All"
    }, "puts and calls"), /*#__PURE__*/React.createElement("option", {
      value: "P"
    }, "puts only"), /*#__PURE__*/React.createElement("option", {
      value: "C"
    }, "calls only")), " that:"), /*#__PURE__*/React.createElement("label", {
      style: {
        display: "flex",
        gap: 6,
        alignItems: "center"
      }
    }, "expire within", /*#__PURE__*/React.createElement("input", {
      className: "inp",
      type: "number",
      min: "0",
      step: "1",
      style: {
        width: 64,
        padding: "3px 6px"
      },
      value: rollRules.maxDays,
      placeholder: "off",
      onChange: e => setRR("maxDays", e.target.value)
    }), " days"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#6b7280"
      }
    }, "or"), /*#__PURE__*/React.createElement("label", {
      style: {
        display: "flex",
        gap: 6,
        alignItems: "center"
      }
    }, "have delta of", /*#__PURE__*/React.createElement("input", {
      className: "inp",
      type: "number",
      min: "0",
      max: "1",
      step: "0.05",
      style: {
        width: 70,
        padding: "3px 6px"
      },
      value: rollRules.minDelta,
      placeholder: "off",
      onChange: e => setRR("minDelta", e.target.value)
    }), " or more"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#6b7280"
      }
    }, "or"), /*#__PURE__*/React.createElement("label", {
      style: {
        display: "flex",
        gap: 6,
        alignItems: "center",
        cursor: "pointer"
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "checkbox",
      checked: !!rollRules.itm,
      onChange: e => setRR("itm", e.target.checked),
      style: {
        width: 15,
        height: 15
      }
    }), "are in the money"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#6b7280",
        fontSize: 11.5
      }
    }, "Leave a box empty to turn that rule off. Press \u21BB Check my positions after changing.")), "Your open short ", (rollRules.type || "All") === "P" ? "puts" : (rollRules.type || "All") === "C" ? "calls" : "puts and calls", " that match any of the settings above. Each one lists rolls to the same stock 1\u20134 weeks later, best credit per extra day first. Puts roll to the same or a lower strike, calls to the same or a higher one (never below your cost basis). Net credit is after the $0.67 fee on both legs. Pick one to open the Close / Roll form filled in; nothing is saved until you confirm."), rollStatus && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: rollStatus.startsWith("❌") ? "#fca5a5" : "#94a3b8",
        marginBottom: 10
      }
    }, rollStatus), rollRows.map(p => {
      const t = trades.find(x => String(x.id) === String(p.id));
      const offers = (p.offers || []).filter(o => rollDebits || o.credit);
      return /*#__PURE__*/React.createElement("div", {
        key: p.id,
        style: {
          border: "1px solid #2d3748",
          borderRadius: 8,
          padding: 12,
          marginBottom: 12,
          background: "#232739"
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          gap: 10,
          flexWrap: "wrap",
          alignItems: "baseline",
          marginBottom: 8
        }
      }, /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#60a5fa",
          fontSize: 14
        }
      }, p.ticker), /*#__PURE__*/React.createElement("span", {
        style: {
          background: p.cp === "P" ? "#1e3a5f" : "#3f2d14",
          color: p.cp === "P" ? "#60a5fa" : "#fbbf24",
          borderRadius: 4,
          padding: "1px 6px",
          fontWeight: 700,
          fontSize: 11
        }
      }, p.cp === "P" ? "PUT" : "CALL"), /*#__PURE__*/React.createElement("span", {
        style: {
          fontWeight: 600
        }
      }, fmt$(p.strike)), /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#94a3b8"
        }
      }, "exp ", p.expDate, " \xB7 ", p.contracts, " contract", p.contracts > 1 ? "s" : "", t ? ` · ${t.account}` : ""), p.spot != null && /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#94a3b8"
        }
      }, "stock ", fmt$(p.spot)), (p.why || []).map(w => /*#__PURE__*/React.createElement("span", {
        key: w,
        style: {
          background: "#7f1d1d55",
          color: "#fca5a5",
          borderRadius: 9,
          padding: "1px 8px",
          fontSize: 11.5
        }
      }, w))), p.error ? /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 12,
          color: "#fca5a5"
        }
      }, "\u274C ", p.error) : /*#__PURE__*/React.createElement(React.Fragment, null, p.buyBack != null && /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          gap: 10,
          alignItems: "center",
          flexWrap: "wrap",
          fontSize: 12.5,
          color: "#cbd5e1",
          background: "#1b1e29",
          borderRadius: 6,
          padding: "7px 10px",
          marginBottom: 8
        }
      }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", null, "Close instead:"), " buy back at ", fmt$(p.buyBack), " \u2014 costs ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#f87171"
        }
      }, fmt$(p.closeCost)), p.captured != null && (p.captured >= 0 ? /*#__PURE__*/React.createElement(React.Fragment, null, " and keeps ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#4ade80"
        }
      }, p.captured.toFixed(0), "%"), " of the premium you collected") : /*#__PURE__*/React.createElement(React.Fragment, null, ", ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#f87171"
        }
      }, (-p.captured).toFixed(0), "%"), " more than the premium you collected"))), t && /*#__PURE__*/React.createElement("button", {
        className: "btn",
        style: {
          background: "#374151",
          color: "#e2e8f0",
          fontSize: 11,
          padding: "3px 9px",
          marginLeft: "auto"
        },
        onClick: () => closeFromRoll(t, p, null)
      }, "Close it \u25B8")), offers.length ? /*#__PURE__*/React.createElement("div", {
        style: {
          overflowX: "auto"
        }
      }, /*#__PURE__*/React.createElement("table", {
        style: {
          width: "100%",
          borderCollapse: "collapse",
          fontSize: 12.5,
          whiteSpace: "nowrap"
        }
      }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
        style: {
          background: "#1b1e29",
          color: "#94a3b8"
        }
      }, ["New expiry", "New strike", "Strike change", "Extra days", "Buy back", "Sell new", "Net credit", "Credit / extra day", "New breakeven", "Δ", "OI", ""].map(h => /*#__PURE__*/React.createElement("th", {
        key: h,
        style: {
          padding: "6px 7px",
          textAlign: "left",
          fontWeight: 600,
          borderBottom: "1px solid #2d3748"
        }
      }, h)))), /*#__PURE__*/React.createElement("tbody", null, offers.map((o, i) => /*#__PURE__*/React.createElement("tr", {
        key: o.expiry + o.strike,
        style: {
          borderBottom: "1px solid #2d3748",
          background: i === 0 && o.credit ? "#14532d55" : "transparent"
        }
      }, /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#cbd5e1"
        }
      }, o.expiry), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          fontWeight: 600
        }
      }, fmt$(o.strike)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: o.strikeChange === 0 ? "#94a3b8" : (p.cp === "P" ? o.strikeChange < 0 : o.strikeChange > 0) ? "#4ade80" : "#f87171"
        }
      }, o.strikeChange === 0 ? "same" : (o.strikeChange > 0 ? "+" : "−") + fmt$(Math.abs(o.strikeChange))), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#94a3b8"
        }
      }, "+", o.extraDays), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px"
        }
      }, fmt$(p.buyBack)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px"
        }
      }, fmt$(o.mid)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          fontWeight: 700,
          color: o.netCredit >= 0 ? "#4ade80" : "#f87171"
        }
      }, fmtPL(o.netCredit)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          fontWeight: 700,
          color: "#fbbf24"
        }
      }, fmtPL(o.creditPerDay)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#cbd5e1"
        }
      }, o.newBreakeven != null ? fmt$(o.newBreakeven) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#94a3b8"
        }
      }, o.delta != null ? o.delta.toFixed(2) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px",
          color: "#94a3b8"
        }
      }, o.oi != null ? o.oi.toLocaleString() : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 7px"
        }
      }, t && /*#__PURE__*/React.createElement("button", {
        className: "btn",
        style: {
          background: "#7c3aed",
          color: "white",
          fontSize: 11,
          padding: "3px 9px"
        },
        title: "Open the Close / Roll form filled in with this roll",
        onClick: () => closeFromRoll(t, p, o)
      }, "Roll \u25B8")))))), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11,
          color: "#4b5563",
          marginTop: 6
        }
      }, "Net credit and credit per day are per contract. New breakeven counts every premium collected on this position, including earlier rolls.")) : /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 12,
          color: "#94a3b8"
        }
      }, "No ", rollDebits ? "" : "net-credit ", "rolls found 1\u20134 weeks out", rollDebits ? "" : " — tick “Include rolls that cost money” to see debit rolls", ".")));
    })), scrShowCfg && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#fb923c"
      }
    }, "\u2699 Screening Criteria"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "#f87171",
        fontSize: 12
      },
      onClick: resetScrCfg
    }, "Reset to defaults")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill,minmax(190px,1fr))",
        gap: 12
      }
    }, [{
      k: "dteMin",
      l: "Min days to expiry",
      t: "number",
      step: 1
    }, {
      k: "dteMax",
      l: "Max days to expiry",
      t: "number",
      step: 1
    }, {
      k: "deltaMin",
      l: "Min |Delta|",
      t: "number",
      step: 0.01,
      hint: "≈ chance of assignment"
    }, {
      k: "deltaMax",
      l: "Max |Delta|",
      t: "number",
      step: 0.01
    }, {
      k: "ivMin",
      l: "Min IV %",
      t: "number",
      step: 5
    }, {
      k: "ivMax",
      l: "Max IV %",
      t: "number",
      step: 5
    }, {
      k: "minAnnualized",
      l: "Min annualized %",
      t: "number",
      step: 5,
      hint: "after the $0.67 fee"
    }, {
      k: "minNetPremium",
      l: "Min premium $/contract",
      t: "number",
      step: 5,
      hint: "after the $0.67 fee"
    }, {
      k: "minIVHV",
      l: "Min IV ÷ HV",
      t: "number",
      step: 0.05,
      hint: "option price vs the stock's own moves"
    }, {
      k: "minIVRank",
      l: "Min IV Rank",
      t: "number",
      step: 5,
      hint: "switches on after 60 days of history"
    }, {
      k: "minAvgVolumeM",
      l: "Min stock volume (M/day)",
      t: "number",
      step: 0.5
    }, {
      k: "minPremium",
      l: "Min premium $/share",
      t: "number",
      step: 0.05
    }, {
      k: "peMin",
      l: "Min P/E",
      t: "number",
      step: 1
    }, {
      k: "peMax",
      l: "Max P/E",
      t: "number",
      step: 5
    }, {
      k: "minOI",
      l: "Min open interest",
      t: "number",
      step: 25
    }, {
      k: "minVolume",
      l: "Min volume today",
      t: "number",
      step: 10
    }, {
      k: "maxSpreadPct",
      l: "Max bid/ask spread %",
      t: "number",
      step: 1
    }, {
      k: "minBid",
      l: "Min bid $",
      t: "number",
      step: 0.05
    }, {
      k: "maxPerTicker",
      l: "Max contracts / ticker",
      t: "number",
      step: 1
    }, {
      k: "costBasisMargin",
      l: "Strike above basis %",
      t: "number",
      step: 1,
      hint: "0 = at basis is fine"
    }, {
      k: "workers",
      l: "Parallel requests",
      t: "number",
      step: 1,
      hint: "lower if rate-limited"
    }].map(f => /*#__PURE__*/React.createElement("div", {
      key: f.k
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, f.l), /*#__PURE__*/React.createElement("input", {
      className: "inp",
      type: f.t,
      step: f.step,
      value: scrCfg[f.k],
      onChange: e => setSC(f.k, e.target.value)
    }), f.hint && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        color: "#4b5563",
        marginTop: 3
      }
    }, f.hint)))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 20,
        flexWrap: "wrap",
        marginTop: 14,
        paddingTop: 12,
        borderTop: "1px solid #2d3748"
      }
    }, [{
      k: "costBasisFloor",
      l: "Never suggest a call strike below my cost basis"
    }, {
      k: "flagEarnings",
      l: "Flag contracts spanning earnings with ⚠ (one extra request per symbol)"
    }, {
      k: "skipEarnings",
      l: "Skip expirations that span an earnings date entirely"
    }, {
      k: "allowMissingPE",
      l: "Include names with no P/E (unprofitable)"
    }].map(c => /*#__PURE__*/React.createElement("div", {
      key: c.k,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "checkbox",
      id: "scr-" + c.k,
      checked: !!scrCfg[c.k],
      onChange: e => setSC(c.k, e.target.checked),
      style: {
        cursor: "pointer",
        width: 16,
        height: 16
      }
    }), /*#__PURE__*/React.createElement("label", {
      htmlFor: "scr-" + c.k,
      style: {
        fontSize: 13,
        color: "#e2e8f0",
        cursor: "pointer"
      }
    }, c.l))))), scrMeta && scrMeta.positions && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#2dd4bf",
        marginBottom: 4
      }
    }, "\uD83C\uDFE6 Covered Call Capacity"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        marginBottom: 12
      }
    }, "Shares you hold, less 100 per open short call. Only tickers with at least one free lot were screened for calls."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        flexWrap: "wrap"
      }
    }, Object.entries(scrMeta.positions).sort((a, b) => b[1].available - a[1].available).map(([tk, p]) => /*#__PURE__*/React.createElement("div", {
      key: tk,
      style: {
        background: p.available > 0 ? "#14532d" : "#2c3346",
        border: "1px solid " + (p.available > 0 ? "#166534" : "#374151"),
        borderRadius: 8,
        padding: "7px 11px",
        minWidth: 118
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: 700,
        color: p.available > 0 ? "#4ade80" : "#94a3b8"
      }
    }, tk), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#94a3b8",
        marginTop: 2
      }
    }, Math.round(p.shares), " sh \xB7 basis ", fmt$(p.costBasis)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        marginTop: 2,
        color: p.available > 0 ? "#4ade80" : "#6b7280"
      }
    }, p.available > 0 ? `${p.available} lot${p.available > 1 ? "s" : ""} free` : p.committed > 0 ? `all ${p.committed} written` : "under 100 sh")))), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#4b5563",
        marginTop: 10
      }
    }, "Risk-free rate ", scrMeta.riskFreeRate != null ? (scrMeta.riskFreeRate * 100).toFixed(2) + "%" : "—", " \xB7 put universe ", scrMeta.putUniverse, " \xB7 call universe ", scrMeta.callUniverse, " \xB7 run ", scrMeta.ranAt || "")), scrSorted.length > 0 ? /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "baseline",
        marginBottom: 12,
        flexWrap: "wrap",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#fbbf24"
      }
    }, "\uD83C\uDFAF Screened Contracts"), (() => {
      const mv = scrSorted.filter(r => r["Day %"] != null);
      if (!mv.length) return null;
      const up = mv.filter(r => r["Day %"] > 0).length,
        dn = mv.filter(r => r["Day %"] < 0).length;
      return /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11.5,
          color: "#94a3b8"
        }
      }, "underlyings today: ", /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#4ade80"
        }
      }, "\u25B2", up), " \xB7 ", /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#f87171"
        }
      }, "\u25BC", dn));
    })()), /*#__PURE__*/React.createElement("div", {
      style: {
        overflowX: "auto"
      }
    }, /*#__PURE__*/React.createElement("table", {
      style: {
        width: "100%",
        borderCollapse: "collapse",
        fontSize: 12.5,
        whiteSpace: "nowrap"
      }
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
      style: {
        background: "#1b1e29",
        color: "#94a3b8"
      }
    }, [["Score", "Score"], ["Ticker", "Ticker"], ["Side", "Side"], ["Expiry", "Expiry"], ["DTE", "DTE"], ["Strike", "Strike"], ["Spot", "Spot"], ["Day $", "Day $"], ["Day %", "Day %"], ["OTM %", "OTM%"], ["Mid", "Prem"], ["Net Premium $", "Net $"], ["Annualized %", "Ann %"], ["IV", "IV"], ["IV/HV", "IV/HV"], ["IV Rank", "IVR"], ["Delta", "Δ"], ["PoP (est)", "PoP"], ["OI", "OI"], ["Spread %", "Spr%"], ["PE", "P/E"], ["Contracts Avail", "Free"], ["Cost Basis", "Basis"], ["Gain vs Basis %", "vs Basis"], ["Breakeven", "B/E"]].map(([k, label]) => /*#__PURE__*/React.createElement("th", {
      key: k,
      onClick: () => scrSortBy(k),
      title: "Sort by " + k,
      style: {
        padding: "8px 7px",
        textAlign: "left",
        cursor: "pointer",
        userSelect: "none",
        borderBottom: "1px solid #2d3748",
        fontWeight: 600
      }
    }, label, scrSort.key === k ? scrSort.dir === "desc" ? " ▾" : " ▴" : "")), /*#__PURE__*/React.createElement("th", {
      style: {
        padding: "8px 7px",
        borderBottom: "1px solid #2d3748"
      }
    }))), /*#__PURE__*/React.createElement("tbody", null, scrSorted.map((r, i) => {
      const isPut = r.Side === "PUT";
      return /*#__PURE__*/React.createElement("tr", {
        key: i,
        style: {
          borderBottom: "1px solid #2d3748",
          background: i % 2 ? "#232739" : "transparent"
        }
      }, /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px"
        }
      }, /*#__PURE__*/React.createElement(ScoreBadge, {
        row: r
      })), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          fontWeight: 700
        }
      }, /*#__PURE__*/React.createElement("a", {
        className: "ticker-link",
        href: `https://finance.yahoo.com/quote/${r.Ticker}`,
        target: "_blank",
        style: {
          color: "#60a5fa"
        }
      }, r.Ticker), r["Earnings Before Exp"] && /*#__PURE__*/React.createElement("span", {
        title: "Earnings " + (r["Next Earnings"] || "") + " falls before expiry",
        style: {
          marginLeft: 5,
          color: "#fbbf24"
        }
      }, "\u26A0"), /*#__PURE__*/React.createElement(ScreenFlags, {
        r: r
      })), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          background: isPut ? "#1e3a5f" : "#3f2d14",
          color: isPut ? "#60a5fa" : "#fbbf24",
          borderRadius: 4,
          padding: "2px 6px",
          fontWeight: 700,
          fontSize: 11
        }
      }, r.Side)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: "#cbd5e1"
        }
      }, r.Expiry), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: "#94a3b8"
        }
      }, r.DTE), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          fontWeight: 600
        }
      }, fmt$(r.Strike)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: "#94a3b8"
        }
      }, fmt$(r.Spot)), /*#__PURE__*/React.createElement("td", {
        title: r["Prev Close"] != null ? `Prev close ${fmt$(r["Prev Close"])}` : "",
        style: {
          padding: "7px 7px",
          fontWeight: 600,
          color: r["Day $"] == null ? "#4b5563" : r["Day $"] >= 0 ? "#4ade80" : "#f87171"
        }
      }, r["Day $"] != null ? `${r["Day $"] >= 0 ? "▲" : "▼"}${fmt$(Math.abs(r["Day $"]))}` : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          fontWeight: 600,
          color: r["Day %"] == null ? "#4b5563" : r["Day %"] >= 0 ? "#4ade80" : "#f87171"
        }
      }, r["Day %"] != null ? `${r["Day %"] >= 0 ? "+" : ""}${r["Day %"].toFixed(2)}%` : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: r["OTM %"] >= 0 ? "#4ade80" : "#f87171"
        }
      }, r["OTM %"] != null ? r["OTM %"].toFixed(1) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px"
        }
      }, fmt$(r.Mid)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: "#4ade80",
          fontWeight: 600
        },
        title: "Premium for one contract after the $0.67 fee"
      }, r["Net Premium $"] != null ? "$" + Math.round(r["Net Premium $"]) : r["Premium $"] != null ? "$" + Math.round(r["Premium $"]) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          fontWeight: 700,
          color: "#fbbf24"
        }
      }, r["Annualized %"] != null ? r["Annualized %"].toFixed(1) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: "#a78bfa"
        }
      }, r.IV != null ? (r.IV * 100).toFixed(0) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: r["IV/HV"] == null ? "#4b5563" : r["IV/HV"] >= 1.1 ? "#4ade80" : "#94a3b8"
        },
        title: r["HV20 %"] != null ? `30-day IV ${r["IV30 %"]}% vs the stock's 20-day moves ${r["HV20 %"]}%` : ""
      }, r["IV/HV"] != null ? r["IV/HV"].toFixed(2) : "—"), (() => {
        const v = ivrText(r);
        return /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "7px 7px",
            color: v.c
          },
          title: v.tip
        }, v.t);
      })(), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: "#94a3b8"
        }
      }, r.Delta != null ? r.Delta.toFixed(2) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: "#2dd4bf"
        }
      }, r["PoP (est)"] != null ? (r["PoP (est)"] * 100).toFixed(0) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: "#94a3b8"
        }
      }, r.OI != null ? r.OI.toLocaleString() : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: r["Spread %"] > 12 ? "#f87171" : "#94a3b8"
        }
      }, r["Spread %"] != null ? r["Spread %"].toFixed(0) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: "#94a3b8"
        }
      }, r.PE != null ? r.PE.toFixed(0) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: "#4ade80"
        }
      }, r["Contracts Avail"] != null ? r["Contracts Avail"] : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: "#94a3b8"
        }
      }, r["Cost Basis"] != null ? fmt$(r["Cost Basis"]) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          fontWeight: 600,
          color: r["Gain vs Basis %"] >= 0 ? "#4ade80" : "#f87171"
        }
      }, r["Gain vs Basis %"] != null ? (r["Gain vs Basis %"] >= 0 ? "+" : "") + r["Gain vs Basis %"].toFixed(1) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px",
          color: "#cbd5e1"
        }
      }, fmt$(r.Breakeven)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "7px 7px"
        }
      }, /*#__PURE__*/React.createElement("button", {
        className: "btn",
        style: {
          background: "#059669",
          color: "white",
          fontSize: 11,
          padding: "4px 9px"
        },
        title: "Prefill a new trade from this contract",
        onClick: () => logFromScreener(r)
      }, "\uFF0B Log")));
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#4b5563",
        marginTop: 12,
        lineHeight: 1.6
      }
    }, /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#94a3b8"
      }
    }, "Day $ / Day %"), " is the underlying stock's move today versus its previous close \u2014 not the option's. Quotes are delayed and free \u2014 confirm the live bid in your broker before entering. Greeks are Black-Scholes, computed locally.", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#94a3b8"
      }
    }, "Score"), " (0\u2013100) ranks each contract on Edge, Cushion, Return and Liquidity \u2014 hover it to see how it was worked out. Net $ and Ann % are after the $0.67 fee. ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#94a3b8"
      }
    }, "IVR"), " needs 60 days of history (OptionIQ records one reading a day); until then it shows how many days it has. Flags: \u26A0 earnings before expiry \xB7 \uD83D\uDCB2 ex-dividend before expiry (calls) \xB7 \u2696 over half your short-put money in one sector \xB7 \u26F0\uFE0F strike beyond a support or resistance level. Sorting by annualized yield alone sorts by risk: a high number means the market is pricing a large move, not that the trade is good.", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#94a3b8"
      }
    }, " \uFF0B Log"), " only prefills the entry form; nothing is saved until you submit it.")) : scrService !== "down" && !scrBusy && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 28,
        textAlign: "center"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 38,
        marginBottom: 8
      }
    }, "\uD83C\uDFAF"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#e2e8f0",
        marginBottom: 6
      }
    }, scrMeta ? "Nothing came back from that scan" : "No results yet"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        lineHeight: 1.8,
        maxWidth: 660,
        margin: "0 auto"
      }
    }, scrMeta ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        justifyContent: "center",
        flexWrap: "wrap",
        margin: "6px 0 12px"
      }
    }, [["Symbol scans", scrMeta.scanned, "#94a3b8"], ["Put universe", scrMeta.putUniverse, "#60a5fa"], ["Call universe", scrMeta.callUniverse, "#fbbf24"]].map(([l, v, c]) => /*#__PURE__*/React.createElement("div", {
      key: l,
      style: {
        background: "#1b1e29",
        border: "1px solid #2d3748",
        borderRadius: 8,
        padding: "8px 14px",
        minWidth: 112
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#94a3b8"
      }
    }, l), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 19,
        fontWeight: 700,
        color: c,
        marginTop: 2
      }
    }, v)))), scrMeta.rate && scrMeta.rate.hits > 0 ? /*#__PURE__*/React.createElement("div", {
      style: {
        color: "#fbbf24"
      }
    }, /*#__PURE__*/React.createElement("b", null, "Yahoo throttled ", scrMeta.rate.hits, " request", scrMeta.rate.hits === 1 ? "" : "s"), " during this scan (", scrMeta.rate.gave_up || 0, " gave up entirely). That's a rate limit, not your criteria \u2014 wait a few minutes before trying again, and don't loosen anything based on this run.") : scrMeta.scanned === 0 ? /*#__PURE__*/React.createElement("div", {
      style: {
        color: "#fca5a5"
      }
    }, "Nothing was scanned at all. Check that tickers are ticked in ", /*#__PURE__*/React.createElement("b", null, "\u2605 Watchlist"), ".") : /*#__PURE__*/React.createElement(React.Fragment, null, "Every contract was filtered out. The usual culprits, in order: the ", /*#__PURE__*/React.createElement("b", null, "annualized yield floor"), ", a narrow ", /*#__PURE__*/React.createElement("b", null, "|delta|"), " band, and the ", /*#__PURE__*/React.createElement("b", null, "open interest"), " minimum.", wlExcluded.size > 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 6,
        color: "#fbbf24"
      }
    }, "Note: ", wlExcluded.size, " of your ", screenUniverse.length, " tickers are unticked in \u2605 Watchlist and weren't scanned."))) : /*#__PURE__*/React.createElement(React.Fragment, null, "Press ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#fb923c"
      }
    }, "Run Screen"), " to scan your ", activeUniverse.length, " watchlist tickers for cash-secured puts, and your holdings with free share lots for covered calls. Use ", /*#__PURE__*/React.createElement("b", null, "\u2699 Criteria"), " to adjust delta, IV, days to expiry and the yield floor.")))), mainTab === "scorecard" && (() => {
      const S = scorecard,
        T = S.totals;
      const pct = v => v == null ? "—" : `${v >= 0 ? "" : "−"}${Math.abs(v).toFixed(1)}%`;
      const pcol = v => v == null ? "#4b5563" : v >= 0 ? "#4ade80" : "#f87171";
      const card = {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      };
      const th = {
        padding: "7px 9px",
        textAlign: "left",
        fontWeight: 600,
        color: "#94a3b8",
        borderBottom: "1px solid #2d3748",
        whiteSpace: "nowrap"
      };
      const td = {
        padding: "6px 9px",
        whiteSpace: "nowrap"
      };
      const Table = ({
        cols,
        rows,
        empty
      }) => /*#__PURE__*/React.createElement("div", {
        style: {
          overflowX: "auto"
        }
      }, /*#__PURE__*/React.createElement("table", {
        style: {
          width: "100%",
          borderCollapse: "collapse",
          fontSize: 12.5
        }
      }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
        style: {
          background: "#1b1e29"
        }
      }, cols.map((c, i) => /*#__PURE__*/React.createElement("th", {
        key: i,
        style: th
      }, c)))), /*#__PURE__*/React.createElement("tbody", null, rows.length ? rows : /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
        colSpan: cols.length,
        style: {
          ...td,
          color: "#4b5563",
          padding: "14px 9px"
        }
      }, empty)))));
      // Gross, paid and net side by side in every breakdown. Net leads —
      // it is the only one of the three you actually kept.
      const Bucket = ({
        title,
        rows,
        label
      }) => /*#__PURE__*/React.createElement("div", {
        style: card
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 14,
          fontWeight: 700,
          color: "#fbbf24",
          marginBottom: 10
        }
      }, title), /*#__PURE__*/React.createElement(Table, {
        cols: [label, "n", "Gross", "Paid to close", "Net", "Capital", "Ann. (net)"],
        empty: "Nothing yet.",
        rows: rows.map(b => /*#__PURE__*/React.createElement("tr", {
          key: b.key,
          style: {
            borderBottom: "1px solid #2d3748"
          }
        }, /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            fontWeight: 600,
            color: "#e2e8f0"
          }
        }, b.key, b.losers > 0 && /*#__PURE__*/React.createElement("span", {
          title: `${b.losers} closed for a net debit`,
          style: {
            marginLeft: 5,
            color: "#f87171",
            fontSize: 10,
            cursor: "help"
          }
        }, "\u25BC", b.losers)), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            color: "#6b7280"
          }
        }, b.n), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            color: "#6b7280"
          }
        }, fmt$(b.gross)), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            color: b.paid ? "#f87171" : "#4b5563"
          }
        }, b.paid ? fmt$(Math.abs(b.paid)) : "—"), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            fontWeight: 700,
            color: b.net >= 0 ? "#4ade80" : "#f87171"
          }
        }, fmtPL(b.net)), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            color: "#94a3b8"
          }
        }, fmt$(b.capital)), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            fontWeight: 700,
            color: pcol(b.wAnn)
          }
        }, pct(b.wAnn))))
      }));
      const R = S.rollCompare;
      return /*#__PURE__*/React.createElement("div", {
        style: {
          display: "grid",
          gap: 16
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit,minmax(185px,1fr))",
          gap: 12
        }
      }, [{
        label: "Annualized on capital at risk",
        val: pct(T.weightedAnn),
        color: pcol(T.weightedAnn),
        sub: "net premium · weighted by capital × days"
      }, {
        label: "Net premium kept",
        val: fmtPL(T.net),
        color: T.net >= 0 ? "#4ade80" : "#f87171",
        sub: `after ${fmt$(Math.abs(T.paid))} paid to close`
      }, {
        label: "Gross premium",
        val: fmt$(T.gross),
        color: "#6b7280",
        sub: `${T.positions} position${T.positions === 1 ? "" : "s"} · ${T.losers} at a net loss`
      }, {
        label: "Period",
        val: T.firstDate ? `${T.firstDate} →` : "—",
        color: "#60a5fa",
        sub: T.lastDate
      }].map(s => /*#__PURE__*/React.createElement("div", {
        key: s.label,
        style: card
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 12,
          color: "#94a3b8",
          marginBottom: 4
        }
      }, s.label), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 20,
          fontWeight: 700,
          color: s.color
        }
      }, s.val), s.sub && /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11,
          color: "#4b5563",
          marginTop: 3
        }
      }, s.sub)))), /*#__PURE__*/React.createElement("div", {
        style: {
          ...card,
          padding: "12px 16px"
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 12,
          fontWeight: 700,
          color: "#94a3b8",
          marginBottom: 8
        }
      }, "How this reconciles with the Options tab"), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          flexWrap: "wrap",
          alignItems: "center",
          gap: "4px 10px",
          fontSize: 13
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#94a3b8"
        }
      }, "Gross premium"), /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#6b7280"
        }
      }, fmt$(T.gross)), /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#4b5563"
        }
      }, "\u2212"), /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#94a3b8"
        }
      }, "paid to close"), /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#f87171"
        }
      }, fmt$(Math.abs(T.paid))), /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#4b5563"
        }
      }, "="), /*#__PURE__*/React.createElement("b", {
        style: {
          color: T.net >= 0 ? "#4ade80" : "#f87171",
          fontSize: 15
        }
      }, fmtPL(T.net)), /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#4b5563",
          fontSize: 11.5
        }
      }, "net \xB7 the Options tab\u2019s \u201CTotal Net P&L\u201D reads ", fmtPL(T.netPL))), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11,
          color: "#4b5563",
          marginTop: 8,
          lineHeight: 1.6
        }
      }, "Every figure below is net. Per-contract fees are already inside these numbers \u2014 $0.67 a contract comes off when the trade is logged, so net = gross \u2212 paid to close is already after fees.")), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11.5,
          color: "#4b5563",
          lineHeight: 1.6,
          marginTop: -6
        }
      }, "Capital at risk: strike \xD7 100 on a cash-secured put, your share cost basis on a covered position, the width between strikes on a spread, premium paid on a long option. A rolled position counts its capital once, not once per leg \u2014 rolling replaces the collateral, it does not add to it. Annualized is net \xF7 capital \xD7 365 \xF7 days held, and averages are weighted by capital \xD7 days so one small fast trade cannot outvote a large slow one."), /*#__PURE__*/React.createElement("div", {
        style: card
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 14,
          fontWeight: 700,
          color: "#fbbf24",
          marginBottom: 4
        }
      }, "Rolled vs. left alone"), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11.5,
          color: "#6b7280",
          marginBottom: 12
        }
      }, "A roll chain is one campaign: every credit and every buy-back across all its legs, from the first open to the final close.", R.rolled.inferred > 0 && /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#fbbf24"
        }
      }, " ", R.rolled.inferred, " chain", R.rolled.inferred === 1 ? "" : "s", " reconstructed from dates rather than an explicit link \u2014 marked \u2248 below.")), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit,minmax(250px,1fr))",
          gap: 12,
          marginBottom: 14
        }
      }, [["Rolled", R.rolled, "#a78bfa"], ["Not rolled", R.unrolled, "#60a5fa"]].map(([name, g, col]) => /*#__PURE__*/React.createElement("div", {
        key: name,
        style: {
          background: "#1b1e29",
          borderRadius: 8,
          padding: 12,
          borderLeft: `3px solid ${col}`
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 12.5,
          fontWeight: 700,
          color: col,
          marginBottom: 6
        }
      }, name, " \xB7 ", g.n, /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#4b5563",
          fontWeight: 400
        }
      }, " (", g.open, " open, ", g.losers, " at a loss)")), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 12.5,
          color: "#94a3b8",
          lineHeight: 1.9
        }
      }, "Gross ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#6b7280"
        }
      }, fmt$(g.gross)), " \u2212 paid ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#f87171"
        }
      }, fmt$(Math.abs(g.paid))), /*#__PURE__*/React.createElement("br", null), "Net: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: g.net >= 0 ? "#4ade80" : "#f87171",
          fontSize: 14
        }
      }, fmtPL(g.net)), /*#__PURE__*/React.createElement("br", null), "Avg days held: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#e2e8f0"
        }
      }, g.avgDays == null ? "—" : g.avgDays.toFixed(0)), /*#__PURE__*/React.createElement("br", null), "Annualized: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: pcol(g.wAnn)
        }
      }, pct(g.wAnn)))))), /*#__PURE__*/React.createElement(Table, {
        cols: ["Ticker", "Acct", "Legs", "Gross", "Paid", "Net", "Days", "Ann. (net)", "State"],
        empty: "No roll chains found. Rolls made through the Close dialog are linked automatically from now on.",
        rows: S.chainRows.map((c, i) => /*#__PURE__*/React.createElement("tr", {
          key: i,
          style: {
            borderBottom: "1px solid #2d3748"
          }
        }, /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            fontWeight: 700
          }
        }, c.ticker, c.inferred && /*#__PURE__*/React.createElement("span", {
          title: "Matched by date, not an explicit link",
          style: {
            marginLeft: 5,
            color: "#fbbf24",
            fontSize: 10,
            cursor: "help"
          }
        }, "\u2248")), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            color: ACCT_COLOR[c.account] || "#60a5fa",
            fontSize: 11
          }
        }, c.account), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            color: "#6b7280"
          }
        }, c.legs.length), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            color: "#6b7280"
          }
        }, fmt$(c.gross)), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            color: c.paid ? "#f87171" : "#4b5563"
          }
        }, c.paid ? fmt$(Math.abs(c.paid)) : "—"), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            fontWeight: 700,
            color: c.net >= 0 ? "#4ade80" : "#f87171"
          }
        }, fmtPL(c.net)), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            color: "#94a3b8"
          }
        }, c.days == null ? "—" : c.days), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            fontWeight: 600,
            color: pcol(c.ann)
          }
        }, pct(c.ann)), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            fontSize: 11,
            color: c.open ? "#fbbf24" : "#6b7280"
          }
        }, c.open ? "open" : "closed")))
      })), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit,minmax(420px,1fr))",
          gap: 16
        }
      }, /*#__PURE__*/React.createElement(Bucket, {
        title: "By strategy",
        rows: S.byStrategy,
        label: "Strategy"
      }), /*#__PURE__*/React.createElement(Bucket, {
        title: "By underlying",
        rows: S.byTicker,
        label: "Ticker"
      }), /*#__PURE__*/React.createElement(Bucket, {
        title: "By account",
        rows: S.byAccount,
        label: "Account"
      })), /*#__PURE__*/React.createElement("div", {
        style: card
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 14,
          fontWeight: 700,
          color: "#fbbf24",
          marginBottom: 4
        }
      }, "Concentration \u2014 open short-put notional ", acctLabel), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11.5,
          color: "#6b7280",
          marginBottom: 12
        }
      }, "What you would owe if every open short put were assigned at once, grouped by sector. Counted at full notional, so a short put that is part of a spread is included here even though its net risk is only the width between the strikes.", Object.keys(sectorByTicker).length === 0 ? /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#fbbf24"
        }
      }, " Sectors come from the Analysis tab \u2014 run it once and these will fill in.") : null), S.concentration.length === 0 ? /*#__PURE__*/React.createElement("div", {
        style: {
          color: "#4b5563",
          fontSize: 12.5
        }
      }, "No open short puts.") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 12.5,
          color: "#94a3b8",
          marginBottom: 10
        }
      }, "Total at risk if all assigned: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#fb923c"
        }
      }, fmt$(S.concTotal))), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          flexDirection: "column",
          gap: 8
        }
      }, S.concentration.map(c => /*#__PURE__*/React.createElement("div", {
        key: c.sector
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          justifyContent: "space-between",
          fontSize: 12.5,
          marginBottom: 3
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#e2e8f0",
          fontWeight: 600
        }
      }, c.sector, /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#4b5563",
          fontWeight: 400,
          marginLeft: 8,
          fontSize: 11
        }
      }, c.tickers.join(" · "))), /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#94a3b8",
          whiteSpace: "nowrap"
        }
      }, fmt$(c.notional), " \xB7 ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: c.pct >= 50 ? "#f87171" : c.pct >= 30 ? "#fbbf24" : "#94a3b8"
        }
      }, c.pct.toFixed(1), "%"))), /*#__PURE__*/React.createElement("div", {
        style: {
          height: 8,
          background: "#1b1e29",
          borderRadius: 4,
          overflow: "hidden"
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          height: "100%",
          width: `${Math.min(c.pct, 100)}%`,
          background: c.pct >= 50 ? "#991b1b" : c.pct >= 30 ? "#92400e" : "#1e40af"
        }
      })), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 10.5,
          color: "#4b5563",
          marginTop: 2
        }
      }, "across ", c.accounts.length, " account", c.accounts.length === 1 ? "" : "s", ": ", c.accounts.join(", "))))), S.concentration[0] && S.concentration[0].pct >= 50 && /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 12,
          padding: 10,
          background: "#7f1d1d33",
          border: "1px solid #7f1d1d",
          borderRadius: 8,
          fontSize: 12,
          color: "#fca5a5"
        }
      }, S.concentration[0].pct.toFixed(0), "% of your short-put exposure is in ", S.concentration[0].sector, ". Spreading it across four IRAs does not diversify it \u2014 those names fall together."))), /*#__PURE__*/React.createElement("div", {
        style: card
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          alignItems: "center",
          gap: 10,
          flexWrap: "wrap",
          marginBottom: 4
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 14,
          fontWeight: 700,
          color: "#fbbf24"
        }
      }, "Against simply holding the index"), /*#__PURE__*/React.createElement("button", {
        className: "btn btn-sm",
        style: {
          background: benchBusy ? "#374151" : "#0e7490",
          color: "white"
        },
        onClick: loadBenchmark,
        disabled: benchBusy
      }, benchBusy ? "⏳ Fetching…" : benchData ? "🔄 Refresh" : "📊 Fetch SPY / QQQ")), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11.5,
          color: "#6b7280",
          marginBottom: 12
        }
      }, "SPY and QQQ total return (dividends included) over the same window as your trades,", T.firstDate ? ` ${T.firstDate} to ${T.lastDate}` : " once you have trades", ". Needs the screener service."), benchMsg && /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 12,
          color: "#fbbf24",
          marginBottom: 10
        }
      }, benchMsg), benchData && benchData.results ? /*#__PURE__*/React.createElement(Table, {
        cols: ["", "Total return", "Annualized", "Window"],
        empty: "",
        rows: [/*#__PURE__*/React.createElement("tr", {
          key: "you",
          style: {
            borderBottom: "1px solid #2d3748",
            background: "#1b1e29"
          }
        }, /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            fontWeight: 700,
            color: "#fbbf24"
          }
        }, "Your options book"), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            color: "#6b7280"
          }
        }, "\u2014"), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            fontWeight: 700,
            color: pcol(T.weightedAnn)
          }
        }, pct(T.weightedAnn)), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            fontSize: 11,
            color: "#4b5563"
          }
        }, "net premium on capital at risk")), ...Object.entries(benchData.results).map(([sym, v]) => /*#__PURE__*/React.createElement("tr", {
          key: sym,
          style: {
            borderBottom: "1px solid #2d3748"
          }
        }, /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            fontWeight: 700,
            color: "#60a5fa"
          }
        }, sym), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            color: v.error ? "#f87171" : v.totalPct >= 0 ? "#4ade80" : "#f87171"
          }
        }, v.error ? v.error : pct(v.totalPct)), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            fontWeight: 700,
            color: v.error ? "#4b5563" : pcol(v.annualizedPct)
          }
        }, v.error ? "—" : pct(v.annualizedPct)), /*#__PURE__*/React.createElement("td", {
          style: {
            ...td,
            fontSize: 11,
            color: "#4b5563"
          }
        }, v.error ? "" : `${v.start} → ${v.end} · ${v.days}d`)))]
      }) : /*#__PURE__*/React.createElement("div", {
        style: {
          color: "#4b5563",
          fontSize: 12.5
        }
      }, "Not fetched yet."), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 10.5,
          color: "#4b5563",
          marginTop: 10,
          lineHeight: 1.6
        }
      }, "Your figure is net premium on capital at risk. Not like-for-like: the index return is on money actually invested, yours on collateral mostly never spent. Selling puts into a rising market will usually trail the index \u2014 the question this answers is by how much, and whether the income justified the capital.")));
    })(), mainTab === "analytics" && /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 12,
        flexWrap: "wrap",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#fbbf24"
      }
    }, "\uD83D\uDCC2 Open Positions ", acctLabel), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("select", {
      className: "inp",
      style: {
        width: 140
      },
      onChange: e => {
        const v = e.target.value;
        document.querySelectorAll(".op-row,.op-grp").forEach(r => r.style.display = v === "all" || r.dataset.acct === v ? "" : "none");
      }
    }, /*#__PURE__*/React.createElement("option", {
      value: "all"
    }, "All Accounts"), ACCOUNTS.map(a => /*#__PURE__*/React.createElement("option", {
      key: a,
      value: a
    }, a))), /*#__PURE__*/React.createElement("select", {
      className: "inp",
      style: {
        width: 110
      },
      onChange: e => {
        const v = e.target.value;
        document.querySelectorAll(".op-row").forEach(r => r.style.display = v === "all" || r.dataset.cp === v ? "" : "none");
      }
    }, /*#__PURE__*/React.createElement("option", {
      value: "all"
    }, "All C/P"), /*#__PURE__*/React.createElement("option", {
      value: "P"
    }, "Puts"), /*#__PURE__*/React.createElement("option", {
      value: "C"
    }, "Calls")), /*#__PURE__*/React.createElement("select", {
      className: "inp",
      style: {
        width: 140
      },
      onChange: e => {
        const v = e.target.value;
        document.querySelectorAll(".op-row").forEach(r => {
          const dte = parseFloat(r.dataset.dte);
          r.style.display = v === "all" || !isNaN(dte) && dte <= parseFloat(v) ? "" : "none";
        });
      }
    }, /*#__PURE__*/React.createElement("option", {
      value: "all"
    }, "All DTE"), /*#__PURE__*/React.createElement("option", {
      value: "7"
    }, "\u2264 7 days"), /*#__PURE__*/React.createElement("option", {
      value: "14"
    }, "\u2264 14 days"), /*#__PURE__*/React.createElement("option", {
      value: "30"
    }, "\u2264 30 days")))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 10,
        marginBottom: 14,
        flexWrap: "wrap"
      }
    }, ACCOUNTS.map(acct => {
      const op = trades.filter(t => t.account === acct && isOpen(t));
      if (!op.length) return null;
      const pl = op.reduce((a, t) => a + (t.netPL || 0), 0),
        moh = op.reduce((a, t) => a + (t.moneyOnHold || 0), 0);
      return /*#__PURE__*/React.createElement("div", {
        key: acct,
        style: {
          background: "#1b1e29",
          border: `1px solid ${ACCT_COLOR[acct]}44`,
          borderRadius: 8,
          padding: "10px 14px",
          minWidth: 180,
          flex: 1
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontWeight: 700,
          color: ACCT_COLOR[acct],
          marginBottom: 6
        }
      }, acct), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 13,
          color: "#94a3b8"
        }
      }, "Open: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#fbbf24"
        }
      }, op.length)), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 13,
          color: "#94a3b8"
        }
      }, "Net P&L: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: pl >= 0 ? "#4ade80" : "#f87171"
        }
      }, fmtPL(pl))), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 13,
          color: "#94a3b8"
        }
      }, "$ On Hold: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#fb923c"
        }
      }, fmt$(moh))));
    })), (() => {
      const ot = acctTrades.filter(isOpen).sort((a, b) => a.account !== b.account ? a.account.localeCompare(b.account) : (a.expDate || "").localeCompare(b.expDate || ""));
      if (!ot.length) return /*#__PURE__*/React.createElement("div", {
        style: {
          color: "#4b5563",
          textAlign: "center",
          padding: 24
        }
      }, "No open positions.");
      return /*#__PURE__*/React.createElement("div", {
        style: {
          overflowX: "auto",
          overflowY: "auto",
          maxHeight: "60vh",
          borderRadius: 8,
          border: "1px solid #2d3748"
        }
      }, /*#__PURE__*/React.createElement("table", {
        style: {
          width: "100%",
          borderCollapse: "separate",
          borderSpacing: 0,
          fontSize: 13,
          minWidth: 900
        }
      }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
        style: {
          background: "#21242f",
          color: "#94a3b8"
        }
      }, ["Account", "Ticker", "Strike", "C/P", "Qty", "Open Date", "Exp Date", "Sell Prem", "Net P&L", "$ On Hold", "DTE"].map(h => /*#__PURE__*/React.createElement("th", {
        key: h,
        style: {
          padding: "8px 10px",
          fontWeight: 600,
          whiteSpace: "nowrap",
          borderBottom: "1px solid #2d3748",
          textAlign: "left",
          position: "sticky",
          top: 0,
          background: "#21242f",
          zIndex: 5
        }
      }, h)))), /*#__PURE__*/React.createElement("tbody", null, ot.map((t, i) => {
        const today = new Date(),
          exp = t.expDate ? new Date(t.expDate) : null,
          dte = exp ? Math.ceil((exp - today) / (1000 * 60 * 60 * 24)) : null,
          dteC = dte == null ? "#94a3b8" : dte <= 7 ? "#f87171" : dte <= 14 ? "#fbbf24" : "#4ade80",
          prev = i > 0 ? ot[i - 1].account : null;
        return /*#__PURE__*/React.createElement(React.Fragment, {
          key: t.id
        }, prev !== t.account && /*#__PURE__*/React.createElement("tr", {
          className: "op-grp",
          "data-acct": t.account
        }, /*#__PURE__*/React.createElement("td", {
          colSpan: 11,
          style: {
            padding: "6px 10px",
            background: "#262a3d",
            color: ACCT_COLOR[t.account],
            fontWeight: 700,
            fontSize: 13
          }
        }, t.account, " \u2014 ", ot.filter(x => x.account === t.account).length, " open")), /*#__PURE__*/React.createElement("tr", {
          className: "op-row",
          "data-acct": t.account,
          "data-cp": t.cp,
          "data-dte": dte != null ? dte : "",
          style: {
            borderBottom: "1px solid #262a3d",
            background: "rgba(251,191,36,0.05)"
          }
        }, /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px"
          }
        }, /*#__PURE__*/React.createElement("span", {
          style: {
            color: ACCT_COLOR[t.account],
            fontWeight: 600,
            fontSize: 12
          }
        }, t.account)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px"
          }
        }, /*#__PURE__*/React.createElement("div", {
          style: {
            fontWeight: 700,
            color: "#60a5fa"
          }
        }, t.ticker), /*#__PURE__*/React.createElement("div", {
          style: {
            fontSize: 11,
            color: "#4b5563",
            maxWidth: 90,
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap"
          }
        }, t.company)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            fontWeight: 600
          }
        }, fmt$(t.strike)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px"
          }
        }, /*#__PURE__*/React.createElement("span", {
          style: {
            background: t.cp === "P" ? "#7c3aed22" : "#0369a122",
            color: t.cp === "P" ? "#a78bfa" : "#38bdf8",
            padding: "2px 6px",
            borderRadius: 4,
            fontWeight: 700
          }
        }, t.cp)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            textAlign: "center"
          }
        }, t.contracts), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            color: "#94a3b8",
            whiteSpace: "nowrap"
          }
        }, t.date), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            whiteSpace: "nowrap",
            color: "#94a3b8"
          }
        }, t.expDate), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            color: "#4ade80"
          }
        }, fmt$(t.sellPremium)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            fontWeight: 700,
            color: (t.netPL || 0) >= 0 ? "#4ade80" : "#f87171"
          }
        }, fmtPL(t.netPL)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            color: "#fb923c"
          }
        }, t.moneyOnHold ? fmt$(t.moneyOnHold) : ""), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            fontWeight: 700,
            color: dteC
          }
        }, dte != null ? `${dte}d` : "—")));
      })), /*#__PURE__*/React.createElement("tfoot", null, /*#__PURE__*/React.createElement("tr", {
        style: {
          background: "#21242f",
          borderTop: "2px solid #2d3748"
        }
      }, /*#__PURE__*/React.createElement("td", {
        colSpan: 8,
        style: {
          padding: "8px 10px",
          color: "#94a3b8",
          fontSize: 13,
          fontWeight: 600
        }
      }, "Total (", ot.length, ")"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "8px 10px",
          fontWeight: 700,
          color: ot.reduce((a, t) => a + (t.netPL || 0), 0) >= 0 ? "#4ade80" : "#f87171"
        }
      }, fmtPL(ot.reduce((a, t) => a + (t.netPL || 0), 0))), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "8px 10px",
          fontWeight: 700,
          color: "#fb923c"
        }
      }, fmt$(ot.reduce((a, t) => a + (t.moneyOnHold || 0), 0))), /*#__PURE__*/React.createElement("td", null)))));
    })()), (() => {
      const isAssignable = t => {
        const strike = parseFloat(t.strike),
          stock = parseFloat(t.currentStock);
        if (isNaN(strike) || isNaN(stock)) return false;
        return t.cp === "P" && stock < strike || t.cp === "C" && stock > strike;
      };
      const openT = acctTrades.filter(isOpen);
      const assignPuts = openT.filter(t => t.cp === "P" && isAssignable(t)).sort((a, b) => (a.expDate || "").localeCompare(b.expDate || ""));
      const assignCalls = openT.filter(t => t.cp === "C" && isAssignable(t)).sort((a, b) => (a.expDate || "").localeCompare(b.expDate || ""));
      const putsMoneyRequired = assignPuts.reduce((sum, t) => sum + (parseInt(t.contracts) || 0) * (parseFloat(t.strike) || 0) * 100, 0);
      const AssignTable = ({
        title,
        rows,
        accent,
        moneyRequired
      }) => /*#__PURE__*/React.createElement("div", {
        style: {
          flex: 1,
          minWidth: 340
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
          marginBottom: 8,
          flexWrap: "wrap",
          gap: 6
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 14,
          fontWeight: 700,
          color: accent
        }
      }, title, " (", rows.length, ")"), moneyRequired != null && rows.length > 0 && /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 13,
          fontWeight: 700,
          color: "#fb923c"
        }
      }, "\uD83D\uDCB0 Money Required: ", fmt$(moneyRequired))), rows.length === 0 ? /*#__PURE__*/React.createElement("div", {
        style: {
          color: "#4b5563",
          fontSize: 13,
          padding: "10px 0"
        }
      }, "None currently ITM.") : /*#__PURE__*/React.createElement("div", {
        style: {
          overflowX: "auto",
          overflowY: "auto",
          maxHeight: 280,
          borderRadius: 8,
          border: "1px solid #2d3748"
        }
      }, /*#__PURE__*/React.createElement("table", {
        style: {
          width: "100%",
          borderCollapse: "separate",
          borderSpacing: 0,
          fontSize: 12,
          minWidth: 480
        }
      }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
        style: {
          background: "#21242f",
          color: "#94a3b8"
        }
      }, ["Acct", "Ticker", "Strike", "Stock", "Diff", "Exp", "DTE"].map(h => /*#__PURE__*/React.createElement("th", {
        key: h,
        style: {
          padding: "6px 8px",
          fontWeight: 600,
          whiteSpace: "nowrap",
          borderBottom: "1px solid #2d3748",
          textAlign: "left",
          position: "sticky",
          top: 0,
          background: "#21242f",
          zIndex: 5
        }
      }, h)))), /*#__PURE__*/React.createElement("tbody", null, rows.map(t => {
        const strike = parseFloat(t.strike),
          stock = parseFloat(t.currentStock);
        const diff = strike - stock;
        const today = new Date(),
          exp = t.expDate ? new Date(t.expDate) : null,
          dte = exp ? Math.ceil((exp - today) / (1000 * 60 * 60 * 24)) : null;
        return /*#__PURE__*/React.createElement("tr", {
          key: t.id,
          style: {
            borderBottom: "1px solid #262a3d",
            background: "rgba(248,113,113,0.08)"
          }
        }, /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 8px",
            color: ACCT_COLOR[t.account],
            fontWeight: 600,
            fontSize: 11
          }
        }, t.account), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 8px",
            fontWeight: 700,
            color: "#60a5fa"
          }
        }, t.ticker), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 8px",
            fontWeight: 600
          }
        }, fmt$(t.strike)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 8px",
            color: "#94a3b8"
          }
        }, fmt$(t.currentStock)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 8px",
            fontWeight: 700,
            color: "#f87171"
          }
        }, diff >= 0 ? "+" : "", diff.toFixed(2)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 8px",
            color: "#94a3b8",
            whiteSpace: "nowrap"
          }
        }, t.expDate), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 8px",
            fontWeight: 600,
            color: dte != null && dte <= 7 ? "#f87171" : "#fbbf24"
          }
        }, dte != null ? `${dte}d` : "—"));
      })))));
      return /*#__PURE__*/React.createElement("div", {
        style: {
          background: "#262a3d",
          border: "1px solid #7f1d1d",
          borderRadius: 10,
          padding: 16
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 15,
          fontWeight: 700,
          color: "#f87171",
          marginBottom: 4
        }
      }, "\u26A0\uFE0F Potentially Assignable (ITM) ", acctLabel), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 12,
          color: "#6b7280",
          marginBottom: 14
        }
      }, "Puts: Strike > Current Stock Price \xA0\xB7\xA0 Calls: Strike < Current Stock Price"), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          gap: 20,
          flexWrap: "wrap"
        }
      }, /*#__PURE__*/React.createElement(AssignTable, {
        title: "\uD83D\uDD34 PUTS",
        rows: assignPuts,
        accent: "#a78bfa",
        moneyRequired: putsMoneyRequired
      }), /*#__PURE__*/React.createElement(AssignTable, {
        title: "\uD83D\uDD35 CALLS",
        rows: assignCalls,
        accent: "#38bdf8"
      })));
    })(), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 12,
        flexWrap: "wrap",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#60a5fa"
      }
    }, "\u2705 Closed Trades ", acctLabel), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("select", {
      className: "inp",
      style: {
        width: 140
      },
      onChange: e => {
        const v = e.target.value;
        document.querySelectorAll(".cl-row,.cl-grp").forEach(r => r.style.display = v === "all" || r.dataset.acct === v ? "" : "none");
      }
    }, /*#__PURE__*/React.createElement("option", {
      value: "all"
    }, "All Accounts"), ACCOUNTS.map(a => /*#__PURE__*/React.createElement("option", {
      key: a,
      value: a
    }, a))), /*#__PURE__*/React.createElement("select", {
      className: "inp",
      style: {
        width: 110
      },
      onChange: e => {
        const v = e.target.value;
        document.querySelectorAll(".cl-row").forEach(r => r.style.display = v === "all" || r.dataset.cp === v ? "" : "none");
      }
    }, /*#__PURE__*/React.createElement("option", {
      value: "all"
    }, "All C/P"), /*#__PURE__*/React.createElement("option", {
      value: "P"
    }, "Puts"), /*#__PURE__*/React.createElement("option", {
      value: "C"
    }, "Calls")), /*#__PURE__*/React.createElement("select", {
      className: "inp",
      style: {
        width: 150
      },
      onChange: e => {
        const v = e.target.value;
        document.querySelectorAll(".cl-row").forEach(r => r.style.display = v === "all" || r.dataset.action === v ? "" : "none");
      }
    }, /*#__PURE__*/React.createElement("option", {
      value: "all"
    }, "All Actions"), ACTIONS.filter(a => a !== "Open").map(a => /*#__PURE__*/React.createElement("option", {
      key: a,
      value: a
    }, a))))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 10,
        marginBottom: 14,
        flexWrap: "wrap"
      }
    }, ACCOUNTS.map(acct => {
      const cl = trades.filter(t => t.account === acct && !isOpen(t));
      if (!cl.length) return null;
      const pl = cl.reduce((a, t) => a + (t.netPL || 0), 0),
        wins = cl.filter(t => (t.netPL || 0) > 0).length;
      return /*#__PURE__*/React.createElement("div", {
        key: acct,
        style: {
          background: "#1b1e29",
          border: `1px solid ${ACCT_COLOR[acct]}44`,
          borderRadius: 8,
          padding: "10px 14px",
          minWidth: 180,
          flex: 1
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontWeight: 700,
          color: ACCT_COLOR[acct],
          marginBottom: 6
        }
      }, acct), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 13,
          color: "#94a3b8"
        }
      }, "Closed: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#60a5fa"
        }
      }, cl.length)), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 13,
          color: "#94a3b8"
        }
      }, "Net P&L: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: pl >= 0 ? "#4ade80" : "#f87171"
        }
      }, fmtPL(pl))), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 13,
          color: "#94a3b8"
        }
      }, "Win Rate: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#a78bfa"
        }
      }, cl.length ? Math.round(wins / cl.length * 100) : 0, "%")));
    })), (() => {
      const ct = acctTrades.filter(t => !isOpen(t)).sort((a, b) => a.account !== b.account ? a.account.localeCompare(b.account) : (b.closeDate || "").localeCompare(a.closeDate || ""));
      if (!ct.length) return /*#__PURE__*/React.createElement("div", {
        style: {
          color: "#4b5563",
          textAlign: "center",
          padding: 24
        }
      }, "No closed trades yet.");
      return /*#__PURE__*/React.createElement("div", {
        style: {
          overflowX: "auto",
          overflowY: "auto",
          maxHeight: "60vh",
          borderRadius: 8,
          border: "1px solid #2d3748"
        }
      }, /*#__PURE__*/React.createElement("table", {
        style: {
          width: "100%",
          borderCollapse: "separate",
          borderSpacing: 0,
          fontSize: 13,
          minWidth: 950
        }
      }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
        style: {
          background: "#21242f",
          color: "#94a3b8"
        }
      }, ["Account", "Ticker", "Strike", "C/P", "Qty", "Open Date", "Exp Date", "Close Date", "Action", "Sell Prem", "Close Prem", "Net P&L"].map(h => /*#__PURE__*/React.createElement("th", {
        key: h,
        style: {
          padding: "8px 10px",
          fontWeight: 600,
          whiteSpace: "nowrap",
          borderBottom: "1px solid #2d3748",
          textAlign: "left",
          position: "sticky",
          top: 0,
          background: "#21242f",
          zIndex: 5
        }
      }, h)))), /*#__PURE__*/React.createElement("tbody", null, ct.map((t, i) => {
        const prev = i > 0 ? ct[i - 1].account : null,
          pl = t.netPL || 0,
          acPL = ct.filter(x => x.account === t.account).reduce((a, x) => a + (x.netPL || 0), 0);
        return /*#__PURE__*/React.createElement(React.Fragment, {
          key: t.id
        }, prev !== t.account && /*#__PURE__*/React.createElement("tr", {
          className: "cl-grp",
          "data-acct": t.account
        }, /*#__PURE__*/React.createElement("td", {
          colSpan: 12,
          style: {
            padding: "6px 10px",
            background: "#262a3d",
            color: ACCT_COLOR[t.account],
            fontWeight: 700,
            fontSize: 13
          }
        }, t.account, " \u2014 ", ct.filter(x => x.account === t.account).length, " closed \xA0|\xA0 P&L: ", /*#__PURE__*/React.createElement("span", {
          style: {
            color: acPL >= 0 ? "#4ade80" : "#f87171"
          }
        }, fmtPL(acPL)))), /*#__PURE__*/React.createElement("tr", {
          className: "cl-row",
          "data-acct": t.account,
          "data-cp": t.cp,
          "data-action": t.action,
          style: {
            borderBottom: "1px solid #262a3d",
            background: pl > 0 ? "rgba(74,222,128,0.05)" : pl < 0 ? "rgba(248,113,113,0.05)" : ""
          }
        }, /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px"
          }
        }, /*#__PURE__*/React.createElement("span", {
          style: {
            color: ACCT_COLOR[t.account],
            fontWeight: 600,
            fontSize: 12
          }
        }, t.account)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px"
          }
        }, /*#__PURE__*/React.createElement("div", {
          style: {
            fontWeight: 700,
            color: "#60a5fa"
          }
        }, t.ticker), /*#__PURE__*/React.createElement("div", {
          style: {
            fontSize: 11,
            color: "#4b5563",
            maxWidth: 90,
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap"
          }
        }, t.company)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            fontWeight: 600
          }
        }, fmt$(t.strike)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px"
          }
        }, /*#__PURE__*/React.createElement("span", {
          style: {
            background: t.cp === "P" ? "#7c3aed22" : "#0369a122",
            color: t.cp === "P" ? "#a78bfa" : "#38bdf8",
            padding: "2px 6px",
            borderRadius: 4,
            fontWeight: 700
          }
        }, t.cp)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            textAlign: "center"
          }
        }, t.contracts), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            color: "#94a3b8",
            whiteSpace: "nowrap"
          }
        }, t.date), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            color: "#94a3b8",
            whiteSpace: "nowrap"
          }
        }, t.expDate), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            color: "#94a3b8",
            whiteSpace: "nowrap"
          }
        }, t.closeDate), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px"
          }
        }, /*#__PURE__*/React.createElement("span", {
          style: {
            padding: "2px 7px",
            borderRadius: 4,
            fontSize: 11,
            fontWeight: 600,
            whiteSpace: "nowrap",
            background: t.action === "Expired" ? "#14532d33" : t.action === "Assigned" ? "#1e3a5f33" : t.action === "Rolled" ? "#78350f33" : "#1e293b",
            color: t.action === "Expired" ? "#4ade80" : t.action === "Assigned" ? "#60a5fa" : t.action === "Rolled" ? "#fbbf24" : "#94a3b8"
          }
        }, t.action)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            color: "#4ade80"
          }
        }, fmt$(t.sellPremium)), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            color: t.closePremium && parseFloat(t.closePremium) < 0 ? "#f87171" : "#94a3b8"
          }
        }, t.closePremium ? fmt$(t.closePremium) : ""), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 10px",
            fontWeight: 700,
            color: pl >= 0 ? "#4ade80" : "#f87171"
          }
        }, fmtPL(pl))));
      })), /*#__PURE__*/React.createElement("tfoot", null, /*#__PURE__*/React.createElement("tr", {
        style: {
          background: "#21242f",
          borderTop: "2px solid #2d3748"
        }
      }, /*#__PURE__*/React.createElement("td", {
        colSpan: 11,
        style: {
          padding: "8px 10px",
          color: "#94a3b8",
          fontSize: 13,
          fontWeight: 600
        }
      }, "Total (", ct.length, ") \xA0|\xA0 Win Rate: ", /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#a78bfa"
        }
      }, ct.length ? Math.round(ct.filter(t => (t.netPL || 0) > 0).length / ct.length * 100) : 0, "%")), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "8px 10px",
          fontWeight: 700,
          color: ct.reduce((a, t) => a + (t.netPL || 0), 0) >= 0 ? "#4ade80" : "#f87171"
        }
      }, fmtPL(ct.reduce((a, t) => a + (t.netPL || 0), 0)))))));
    })()), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        marginBottom: 12,
        color: "#a78bfa"
      }
    }, "P&L by Ticker ", acctLabel), plByTicker.length === 0 ? /*#__PURE__*/React.createElement("div", {
      style: {
        color: "#4b5563",
        textAlign: "center",
        padding: 24
      }
    }, "No trades yet.") : /*#__PURE__*/React.createElement(ResponsiveContainer, {
      width: "100%",
      height: 260
    }, /*#__PURE__*/React.createElement(BarChart, {
      data: plByTicker,
      margin: {
        top: 4,
        right: 16,
        bottom: 4,
        left: 10
      }
    }, /*#__PURE__*/React.createElement(XAxis, {
      dataKey: "ticker",
      tick: {
        fill: "#94a3b8",
        fontSize: 12
      },
      axisLine: false,
      tickLine: false
    }), /*#__PURE__*/React.createElement(YAxis, {
      tickFormatter: v => fmtK(v),
      tick: {
        fill: "#94a3b8",
        fontSize: 11
      },
      axisLine: false,
      tickLine: false
    }), /*#__PURE__*/React.createElement(Tooltip, {
      content: /*#__PURE__*/React.createElement(Tip, null)
    }), /*#__PURE__*/React.createElement(Bar, {
      dataKey: "pl",
      radius: [4, 4, 0, 0]
    }, plByTicker.map((e, i) => /*#__PURE__*/React.createElement(Cell, {
      key: i,
      fill: e.pl >= 0 ? "#4ade80" : "#f87171"
    })))))), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        marginBottom: 12,
        color: "#38bdf8"
      }
    }, "P&L by Month ", acctLabel), plByMonth.length === 0 ? /*#__PURE__*/React.createElement("div", {
      style: {
        color: "#4b5563",
        textAlign: "center",
        padding: 24
      }
    }, "No closed trades yet.") : /*#__PURE__*/React.createElement(ResponsiveContainer, {
      width: "100%",
      height: 240
    }, /*#__PURE__*/React.createElement(BarChart, {
      data: plByMonth,
      margin: {
        top: 4,
        right: 16,
        bottom: 4,
        left: 10
      }
    }, /*#__PURE__*/React.createElement(XAxis, {
      dataKey: "month",
      tick: {
        fill: "#94a3b8",
        fontSize: 11
      },
      axisLine: false,
      tickLine: false
    }), /*#__PURE__*/React.createElement(YAxis, {
      tickFormatter: v => fmtK(v),
      tick: {
        fill: "#94a3b8",
        fontSize: 11
      },
      axisLine: false,
      tickLine: false
    }), /*#__PURE__*/React.createElement(Tooltip, {
      content: /*#__PURE__*/React.createElement(Tip, null)
    }), /*#__PURE__*/React.createElement(Bar, {
      dataKey: "pl",
      radius: [4, 4, 0, 0]
    }, plByMonth.map((e, i) => /*#__PURE__*/React.createElement(Cell, {
      key: i,
      fill: e.pl >= 0 ? "#60a5fa" : "#f87171"
    })))))), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        marginBottom: 4,
        color: "#34d399"
      }
    }, "P&L by Week \u2014 Weekly & Cumulative ", acctLabel), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#6b7280",
        marginBottom: 12
      }
    }, "Bars = weekly P&L (rolled to that week's Friday) \xB7 Line = running cumulative total"), plByWeek.length === 0 ? /*#__PURE__*/React.createElement("div", {
      style: {
        color: "#4b5563",
        textAlign: "center",
        padding: 24
      }
    }, "No closed trades yet.") : /*#__PURE__*/React.createElement(ResponsiveContainer, {
      width: "100%",
      height: 280
    }, /*#__PURE__*/React.createElement(ComposedChart, {
      data: plByWeek,
      margin: {
        top: 4,
        right: 16,
        bottom: 4,
        left: 10
      }
    }, /*#__PURE__*/React.createElement(XAxis, {
      dataKey: "week",
      tick: {
        fill: "#94a3b8",
        fontSize: 11
      },
      axisLine: false,
      tickLine: false
    }), /*#__PURE__*/React.createElement(YAxis, {
      tickFormatter: v => fmtK(v),
      tick: {
        fill: "#94a3b8",
        fontSize: 11
      },
      axisLine: false,
      tickLine: false
    }), /*#__PURE__*/React.createElement(Tooltip, {
      content: /*#__PURE__*/React.createElement(WeekTip, null)
    }), /*#__PURE__*/React.createElement(Legend, {
      wrapperStyle: {
        fontSize: 12,
        color: "#94a3b8"
      }
    }), /*#__PURE__*/React.createElement(Bar, {
      dataKey: "pl",
      name: "Weekly P&L",
      radius: [4, 4, 0, 0]
    }, plByWeek.map((e, i) => /*#__PURE__*/React.createElement(Cell, {
      key: i,
      fill: e.pl >= 0 ? "#34d399" : "#f87171"
    }))), /*#__PURE__*/React.createElement(Line, {
      type: "monotone",
      dataKey: "cumulative",
      name: "Cumulative P&L",
      stroke: "#fbbf24",
      strokeWidth: 2.5,
      dot: {
        r: 3,
        fill: "#fbbf24"
      }
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        marginBottom: 12,
        color: "#fb923c"
      }
    }, "\uD83D\uDCB0 Money On Hold \u2014 Open Puts by Account"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill,minmax(280px,1fr))",
        gap: 12
      }
    }, holdByAcct.map(({
      acct,
      total,
      count,
      positions
    }) => /*#__PURE__*/React.createElement("div", {
      key: acct,
      style: {
        background: "#1b1e29",
        border: `1px solid ${ACCT_COLOR[acct]}44`,
        borderRadius: 8,
        padding: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        marginBottom: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 700,
        color: ACCT_COLOR[acct]
      }
    }, acct), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: "#94a3b8"
      }
    }, count, " pos")), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 20,
        fontWeight: 700,
        color: "#fb923c",
        marginBottom: 8
      }
    }, fmt$(total) || "$0.00"), positions.slice(0, 5).map(p => /*#__PURE__*/React.createElement("div", {
      key: p.id,
      style: {
        display: "flex",
        justifyContent: "space-between",
        fontSize: 12,
        color: "#94a3b8",
        padding: "3px 0",
        borderTop: "1px solid #2c3346"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#60a5fa",
        fontWeight: 600
      }
    }, p.ticker), /*#__PURE__*/React.createElement("span", null, "$", p.strike, " ", p.cp, " exp ", p.expDate), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#fb923c"
      }
    }, fmt$(calcMOH(p))))), positions.length > 5 && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#4b5563",
        marginTop: 4
      }
    }, "+", positions.length - 5, " more")))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 12,
        paddingTop: 10,
        borderTop: "1px solid #2d3748",
        display: "flex",
        justifyContent: "space-between"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#94a3b8",
        fontSize: 14
      }
    }, "Total All Accounts"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 18,
        fontWeight: 700,
        color: "#fb923c"
      }
    }, fmt$(holdByAcct.reduce((a, b) => a + b.total, 0))))), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        marginBottom: 4,
        color: "#4ade80"
      }
    }, "\uD83D\uDCB5 Weekly Premium Collected \u2014 Puts vs Calls ", acctLabel), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#6b7280",
        marginBottom: 12
      }
    }, "Premium received when selling to open, rolled to that week's Friday, based on Open Date"), premiumByWeek.length === 0 ? /*#__PURE__*/React.createElement("div", {
      style: {
        color: "#4b5563",
        textAlign: "center",
        padding: 24
      }
    }, "No premium collected yet.") : /*#__PURE__*/React.createElement(ResponsiveContainer, {
      width: "100%",
      height: 260
    }, /*#__PURE__*/React.createElement(BarChart, {
      data: premiumByWeek,
      margin: {
        top: 4,
        right: 16,
        bottom: 4,
        left: 10
      }
    }, /*#__PURE__*/React.createElement(XAxis, {
      dataKey: "week",
      tick: {
        fill: "#94a3b8",
        fontSize: 11
      },
      axisLine: false,
      tickLine: false
    }), /*#__PURE__*/React.createElement(YAxis, {
      tickFormatter: v => fmtK(v),
      tick: {
        fill: "#94a3b8",
        fontSize: 11
      },
      axisLine: false,
      tickLine: false
    }), /*#__PURE__*/React.createElement(Tooltip, {
      content: ({
        active,
        payload,
        label
      }) => {
        if (!active || !payload?.length) return null;
        const puts = payload.find(p => p.dataKey === "puts")?.value || 0;
        const calls = payload.find(p => p.dataKey === "calls")?.value || 0;
        return /*#__PURE__*/React.createElement("div", {
          style: {
            background: "#262a3d",
            border: "1px solid #2d3748",
            borderRadius: 6,
            padding: "8px 12px",
            fontSize: 13
          }
        }, /*#__PURE__*/React.createElement("div", {
          style: {
            color: "#94a3b8",
            marginBottom: 4
          }
        }, "Week of ", label), /*#__PURE__*/React.createElement("div", {
          style: {
            color: "#a78bfa",
            fontWeight: 700
          }
        }, "Puts: ", fmt$(puts)), /*#__PURE__*/React.createElement("div", {
          style: {
            color: "#38bdf8",
            fontWeight: 700
          }
        }, "Calls: ", fmt$(calls)), /*#__PURE__*/React.createElement("div", {
          style: {
            color: "#4ade80",
            fontWeight: 700,
            marginTop: 2
          }
        }, "Total: ", fmt$(puts + calls)));
      }
    }), /*#__PURE__*/React.createElement(Legend, {
      wrapperStyle: {
        fontSize: 12,
        color: "#94a3b8"
      }
    }), /*#__PURE__*/React.createElement(Bar, {
      dataKey: "puts",
      name: "Puts Premium",
      stackId: "prem",
      fill: "#a78bfa",
      radius: [0, 0, 0, 0]
    }), /*#__PURE__*/React.createElement(Bar, {
      dataKey: "calls",
      name: "Calls Premium",
      stackId: "prem",
      fill: "#38bdf8",
      radius: [4, 4, 0, 0]
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 16,
        paddingTop: 14,
        borderTop: "1px solid #2d3748"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: 700,
        color: "#94a3b8",
        marginBottom: 10
      }
    }, "Premium Collected by Account (All-Time)"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill,minmax(230px,1fr))",
        gap: 12
      }
    }, premiumByAcct.map(({
      acct,
      puts,
      calls,
      total,
      count
    }) => /*#__PURE__*/React.createElement("div", {
      key: acct,
      style: {
        background: "#1b1e29",
        border: `1px solid ${ACCT_COLOR[acct]}44`,
        borderRadius: 8,
        padding: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        marginBottom: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 700,
        color: ACCT_COLOR[acct]
      }
    }, acct), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: "#94a3b8"
      }
    }, count, " sold")), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 18,
        fontWeight: 700,
        color: "#4ade80",
        marginBottom: 6
      }
    }, fmt$(total) || "$0.00"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        display: "flex",
        justifyContent: "space-between"
      }
    }, /*#__PURE__*/React.createElement("span", null, "Puts"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#a78bfa",
        fontWeight: 600
      }
    }, fmt$(puts) || "$0.00")), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#94a3b8",
        display: "flex",
        justifyContent: "space-between"
      }
    }, /*#__PURE__*/React.createElement("span", null, "Calls"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#38bdf8",
        fontWeight: 600
      }
    }, fmt$(calls) || "$0.00"))))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 12,
        paddingTop: 10,
        borderTop: "1px solid #2d3748",
        display: "flex",
        justifyContent: "space-between"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#94a3b8",
        fontSize: 14
      }
    }, "Total All Accounts"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 18,
        fontWeight: 700,
        color: "#4ade80"
      }
    }, fmt$(premiumByAcct.reduce((a, b) => a + b.total, 0))))))), mainTab === "stocks" && /*#__PURE__*/React.createElement(React.Fragment, null, showStockForm && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16,
        marginBottom: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 16,
        fontWeight: 700,
        marginBottom: 14,
        color: "#14b8a6"
      }
    }, stockEditId ? "✏️ Edit Holding" : "➕ New Stock Holding"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill,minmax(160px,1fr))",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Account"), /*#__PURE__*/React.createElement("select", {
      className: "inp",
      value: stockForm.account,
      onChange: e => setStockForm(f => ({
        ...f,
        account: e.target.value
      }))
    }, ACCOUNTS.map(a => /*#__PURE__*/React.createElement("option", {
      key: a
    }, a)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Ticker"), /*#__PURE__*/React.createElement("input", {
      className: "inp",
      list: "ticker-history",
      placeholder: "e.g. AAPL",
      value: stockForm.ticker,
      onChange: e => handleStockTicker(e.target.value)
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Company"), /*#__PURE__*/React.createElement("input", {
      className: "inp",
      placeholder: "Auto-fills",
      value: stockForm.company,
      onChange: e => setStockForm(f => ({
        ...f,
        company: e.target.value
      }))
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "# of Shares"), /*#__PURE__*/React.createElement("input", {
      type: "number",
      className: "inp",
      placeholder: "0",
      value: stockForm.shares,
      onChange: e => setStockForm(f => ({
        ...f,
        shares: e.target.value
      }))
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Date Acquired"), /*#__PURE__*/React.createElement("input", {
      type: "date",
      className: "inp",
      value: stockForm.dateAcquired,
      onChange: e => setStockForm(f => ({
        ...f,
        dateAcquired: e.target.value
      }))
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, stockForm.status === "Assigned" ? "Assigned Price (Strike, $/share)" : "Cost Basis ($/share)"), /*#__PURE__*/React.createElement("input", {
      type: "number",
      step: "0.01",
      className: "inp",
      placeholder: "0.00",
      value: stockForm.costBasis,
      onChange: e => setStockForm(f => ({
        ...f,
        costBasis: e.target.value
      }))
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Current Price ($/share)"), /*#__PURE__*/React.createElement("input", {
      type: "number",
      step: "0.01",
      className: "inp",
      placeholder: "0.00",
      value: stockForm.currentPrice,
      onChange: e => setStockForm(f => ({
        ...f,
        currentPrice: e.target.value
      }))
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Status"), /*#__PURE__*/React.createElement("select", {
      className: "inp",
      value: stockForm.status,
      onChange: e => setStockForm(f => ({
        ...f,
        status: e.target.value
      }))
    }, /*#__PURE__*/React.createElement("option", {
      value: "Held"
    }, "Held"), /*#__PURE__*/React.createElement("option", {
      value: "Assigned"
    }, "Assigned (from Put)"), /*#__PURE__*/React.createElement("option", {
      value: "Sold"
    }, "Sold"))), stockForm.status === "Sold" && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Sold Date"), /*#__PURE__*/React.createElement("input", {
      type: "date",
      className: "inp",
      value: stockForm.soldDate,
      onChange: e => setStockForm(f => ({
        ...f,
        soldDate: e.target.value
      }))
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Sold Price ($/share)"), /*#__PURE__*/React.createElement("input", {
      type: "number",
      step: "0.01",
      className: "inp",
      placeholder: "0.00",
      value: stockForm.soldPrice,
      onChange: e => setStockForm(f => ({
        ...f,
        soldPrice: e.target.value
      }))
    })))), stockForm.shares && stockForm.costBasis && (stockForm.status === "Sold" ? stockForm.soldPrice : stockForm.currentPrice) && (() => {
      const refP = stockForm.status === "Sold" ? parseFloat(stockForm.soldPrice) : parseFloat(stockForm.currentPrice);
      const sh = parseFloat(stockForm.shares),
        cb = parseFloat(stockForm.costBasis);
      return /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 12,
          padding: 10,
          background: "#1b1e29",
          borderRadius: 8,
          display: "flex",
          gap: 20,
          flexWrap: "wrap",
          fontSize: 13
        }
      }, /*#__PURE__*/React.createElement("span", null, "Cost Value: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#94a3b8"
        }
      }, fmt$(sh * cb))), /*#__PURE__*/React.createElement("span", null, stockForm.status === "Sold" ? "Sold" : "Market", " Value: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#60a5fa"
        }
      }, fmt$(sh * refP))), /*#__PURE__*/React.createElement("span", null, "Net Gain/Loss: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: refP - cb >= 0 ? "#4ade80" : "#f87171"
        }
      }, fmtPL((refP - cb) * sh))));
    })(), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        marginTop: 12
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#059669",
        color: "white"
      },
      onClick: handleStockSubmit
    }, stockEditId ? "Save Changes" : "Add Holding"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "white"
      },
      onClick: () => {
        setShowStockForm(false);
        setStockEditId(null);
        setStockForm(EMPTY_STOCK);
      }
    }, "Cancel"))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 10
      }
    }, showStockFilters && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 14,
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill,minmax(170px,1fr))",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Status"), /*#__PURE__*/React.createElement("select", {
      className: "inp",
      value: stockFilters.status,
      onChange: e => setSF("status", e.target.value)
    }, /*#__PURE__*/React.createElement("option", {
      value: "all"
    }, "All"), /*#__PURE__*/React.createElement("option", {
      value: "active"
    }, "Open positions (not sold)"), /*#__PURE__*/React.createElement("option", {
      value: "held"
    }, "Held only"), /*#__PURE__*/React.createElement("option", {
      value: "assigned"
    }, "Assigned only"), /*#__PURE__*/React.createElement("option", {
      value: "sold"
    }, "Sold only"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Ticker"), /*#__PURE__*/React.createElement("input", {
      className: "inp",
      list: "ticker-history",
      placeholder: "e.g. AAPL",
      value: stockFilters.ticker,
      onChange: e => setSF("ticker", e.target.value)
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Date Acquired From"), /*#__PURE__*/React.createElement("input", {
      type: "date",
      className: "inp",
      value: stockFilters.dateAcqFrom,
      onChange: e => setSF("dateAcqFrom", e.target.value)
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Date Acquired To"), /*#__PURE__*/React.createElement("input", {
      type: "date",
      className: "inp",
      value: stockFilters.dateAcqTo,
      onChange: e => setSF("dateAcqTo", e.target.value)
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Sold Date From"), /*#__PURE__*/React.createElement("input", {
      type: "date",
      className: "inp",
      value: stockFilters.soldDateFrom,
      onChange: e => setSF("soldDateFrom", e.target.value)
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Sold Date To"), /*#__PURE__*/React.createElement("input", {
      type: "date",
      className: "inp",
      value: stockFilters.soldDateTo,
      onChange: e => setSF("soldDateTo", e.target.value)
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8,
        paddingTop: 20
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "checkbox",
      id: "missingCalls",
      checked: stockFilters.missingCalls,
      onChange: e => setSF("missingCalls", e.target.checked),
      style: {
        cursor: "pointer",
        width: 16,
        height: 16
      }
    }), /*#__PURE__*/React.createElement("label", {
      htmlFor: "missingCalls",
      style: {
        fontSize: 13,
        color: "#e2e8f0",
        cursor: "pointer"
      }
    }, "Covered Call Opportunity")), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#6b7280",
        marginTop: 2
      }
    }, "Shares \u2265 100, no open Call in that account/ticker")))), filteredStocks.length === 0 ? /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: "center",
        padding: 48,
        color: "#4b5563"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 40,
        marginBottom: 8
      }
    }, "\uD83D\uDCE6"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15
      }
    }, "No holdings match your filters.")) : /*#__PURE__*/React.createElement("div", {
      style: {
        overflowX: "auto",
        overflowY: "auto",
        maxHeight: "65vh",
        borderRadius: 10,
        border: "1px solid #2d3748"
      }
    }, /*#__PURE__*/React.createElement("table", {
      style: {
        width: "100%",
        borderCollapse: "separate",
        borderSpacing: 0,
        fontSize: 13,
        minWidth: 1100
      }
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
      style: {
        background: "#2c3346",
        color: "#94a3b8"
      }
    }, ["", "Acct", "Ticker", "Shares", "Date Acquired", "Cost Basis", "Eff. Cost Basis", "Current Price", "Day Chg", "Cost Value", "Call Premium", "Status", "Sold Date", "Sold Price", "Market/Sold Value", "Net Gain/Loss", "%", ""].map((h, i) => {
      const sortable = STOCK_SORT_COLS[h];
      const active = stockSortConfig.key === h;
      return /*#__PURE__*/React.createElement("th", {
        key: i,
        onClick: sortable ? () => handleStockSort(h) : undefined,
        title: h === "Call Premium" ? "Assigned stocks only — net P&L of calls sold since the assignment date. Held stocks show none." : undefined,
        style: {
          padding: "8px 9px",
          fontWeight: 600,
          whiteSpace: "nowrap",
          borderBottom: "1px solid #2d3748",
          textAlign: "left",
          position: "sticky",
          top: 0,
          background: active ? "#3a3f56" : "#2c3346",
          zIndex: 10,
          cursor: sortable ? "pointer" : "default",
          userSelect: "none",
          color: active ? "#fbbf24" : "#94a3b8"
        }
      }, h, active && (stockSortConfig.direction === "asc" ? " ▲" : " ▼"));
    }))), /*#__PURE__*/React.createElement("tbody", null, sortedFilteredStocks.map(s => {
      const gl = stockGainLoss(s),
        mv = stockMarketValue(s),
        cv = stockCostValue(s);
      const glPct = cv > 0 && gl != null ? gl / cv * 100 : null;
      const ac = ACCT_COLOR[s.account] || "#60a5fa";
      const sold = isStockSold(s);
      const callPrem = stockCallPremium(s);
      const effCB = stockEffectiveCostBasis(s);
      if (stockInlineEditId === s.id) {
        const f = stockInlineForm;
        return /*#__PURE__*/React.createElement("tr", {
          key: s.id,
          style: {
            borderBottom: "2px solid #0d9488",
            background: "rgba(13,148,136,0.1)"
          }
        }, /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("select", {
          style: iinp,
          value: f.account,
          onChange: e => setStockInlineForm(p => ({
            ...p,
            account: e.target.value
          }))
        }, ACCOUNTS.map(a => /*#__PURE__*/React.createElement("option", {
          key: a
        }, a)))), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("input", {
          style: iinp,
          list: "ticker-history",
          value: f.ticker,
          onChange: e => {
            const v = e.target.value.toUpperCase();
            const learned = stocks.find(st => st.ticker === v && st.company)?.company;
            setStockInlineForm(p => ({
              ...p,
              ticker: v,
              company: learned || tickerName(v) || p.company
            }));
          }
        }), /*#__PURE__*/React.createElement("input", {
          style: {
            ...iinp,
            marginTop: 2
          },
          value: f.company,
          onChange: e => setStockInlineForm(p => ({
            ...p,
            company: e.target.value
          }))
        })), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("input", {
          type: "number",
          style: iinp,
          value: f.shares,
          onChange: e => setStockInlineForm(p => ({
            ...p,
            shares: e.target.value
          }))
        })), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("input", {
          type: "date",
          style: iinp,
          value: f.dateAcquired,
          onChange: e => setStockInlineForm(p => ({
            ...p,
            dateAcquired: e.target.value
          }))
        })), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("input", {
          type: "number",
          step: "0.01",
          style: iinp,
          value: f.costBasis,
          onChange: e => setStockInlineForm(p => ({
            ...p,
            costBasis: e.target.value
          }))
        })), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("input", {
          type: "number",
          step: "0.01",
          style: iinp,
          value: f.currentPrice,
          onChange: e => setStockInlineForm(p => ({
            ...p,
            currentPrice: e.target.value
          }))
        })), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("select", {
          style: iinp,
          value: f.status,
          onChange: e => setStockInlineForm(p => ({
            ...p,
            status: e.target.value
          }))
        }, /*#__PURE__*/React.createElement("option", {
          value: "Held"
        }, "Held"), /*#__PURE__*/React.createElement("option", {
          value: "Assigned"
        }, "Assigned"), /*#__PURE__*/React.createElement("option", {
          value: "Sold"
        }, "Sold"))), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, f.status === "Sold" ? /*#__PURE__*/React.createElement("input", {
          type: "date",
          style: iinp,
          value: f.soldDate,
          onChange: e => setStockInlineForm(p => ({
            ...p,
            soldDate: e.target.value
          }))
        }) : null), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, f.status === "Sold" ? /*#__PURE__*/React.createElement("input", {
          type: "number",
          step: "0.01",
          style: iinp,
          value: f.soldPrice,
          onChange: e => setStockInlineForm(p => ({
            ...p,
            soldPrice: e.target.value
          }))
        }) : null), /*#__PURE__*/React.createElement("td", {
          colSpan: 3
        }), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px",
            whiteSpace: "nowrap"
          }
        }, /*#__PURE__*/React.createElement("div", {
          style: {
            display: "flex",
            gap: 3
          }
        }, /*#__PURE__*/React.createElement("button", {
          className: "btn",
          style: {
            background: "#059669",
            color: "white",
            padding: "3px 8px",
            fontSize: 12
          },
          onClick: saveStockInlineEdit
        }, "\u2713"), /*#__PURE__*/React.createElement("button", {
          className: "btn",
          style: {
            background: "#374151",
            color: "white",
            padding: "3px 8px",
            fontSize: 12
          },
          onClick: cancelStockInlineEdit
        }, "\u2715"))));
      }
      return /*#__PURE__*/React.createElement("tr", {
        key: s.id,
        style: {
          borderBottom: "1px solid #262a3d",
          background: gl > 0 ? "rgba(74,222,128,0.05)" : gl < 0 ? "rgba(248,113,113,0.05)" : ""
        }
      }, /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, /*#__PURE__*/React.createElement("input", {
        type: "checkbox",
        checked: stockSelected.has(s.id),
        onChange: () => toggleStockSel(s.id),
        style: {
          cursor: "pointer"
        }
      })), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          color: ac,
          fontWeight: 600,
          fontSize: 11
        }
      }, s.account)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontWeight: 700
        }
      }, /*#__PURE__*/React.createElement("button", {
        onClick: () => setQuoteModalTicker(s.ticker),
        className: "ticker-link",
        style: {
          color: "#60a5fa",
          background: "none",
          border: "none",
          padding: 0,
          font: "inherit",
          fontWeight: 700,
          cursor: "pointer"
        }
      }, s.ticker)), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11,
          color: "#4b5563",
          maxWidth: 140,
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap"
        }
      }, s.company)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          textAlign: "center"
        }
      }, s.shares), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          color: "#94a3b8",
          whiteSpace: "nowrap"
        }
      }, s.dateAcquired), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, fmt$(s.costBasis)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          color: effCB != null ? "#a78bfa" : "#4b5563",
          fontWeight: 600
        }
      }, effCB != null ? fmt$(effCB) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          color: sold ? "#4b5563" : "#fbbf24"
        }
      }, sold ? "—" : fmt$(s.currentPrice)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          whiteSpace: "nowrap"
        }
      }, !sold && tickerChange[s.ticker] ? (() => {
        const ch = tickerChange[s.ticker];
        const up = ch.abs >= 0;
        return /*#__PURE__*/React.createElement("span", {
          title: ch.pd ? `vs the close of ${ch.pd}${ch.ps && ch.ps !== "daily bar" ? ` — ${ch.ps}` : ""}` : "",
          style: {
            color: up ? "#4ade80" : "#f87171",
            fontWeight: 600,
            cursor: ch.pd ? "help" : "default"
          }
        }, up ? "▲" : "▼", fmt$(Math.abs(ch.abs)), " (", Math.abs(ch.pct).toFixed(2), "%)");
      })() : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          color: "#94a3b8"
        }
      }, fmt$(cv)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          fontWeight: 600,
          color: callPrem > 0 ? "#4ade80" : "#4b5563"
        }
      }, callPrem > 0 ? fmt$(callPrem) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          padding: "2px 7px",
          borderRadius: 4,
          fontSize: 11,
          fontWeight: 600,
          whiteSpace: "nowrap",
          background: sold ? "#78350f33" : s.status === "Assigned" ? "#5b21b633" : "#14532d33",
          color: sold ? "#fbbf24" : s.status === "Assigned" ? "#c084fc" : "#4ade80"
        }
      }, s.status || "Held")), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          color: "#94a3b8",
          whiteSpace: "nowrap"
        }
      }, sold ? s.soldDate || "—" : ""), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          color: sold ? "#fbbf24" : "#4b5563"
        }
      }, sold ? fmt$(s.soldPrice) : ""), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          fontWeight: 600,
          color: "#60a5fa"
        }
      }, fmt$(mv)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          fontWeight: 700,
          color: gl == null ? "#4b5563" : gl >= 0 ? "#4ade80" : "#f87171"
        }
      }, gl != null ? fmtPL(gl) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          fontWeight: 600,
          color: glPct == null ? "#4b5563" : glPct >= 0 ? "#4ade80" : "#f87171"
        }
      }, glPct != null ? (glPct >= 0 ? "+" : "") + glPct.toFixed(1) + "%" : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          whiteSpace: "nowrap"
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          gap: 3
        }
      }, !sold && /*#__PURE__*/React.createElement("button", {
        className: "btn",
        style: {
          background: "#0d9488",
          color: "white",
          padding: "3px 8px",
          fontSize: 12
        },
        onClick: () => openBuyModal(s)
      }, "Buy More"), !sold && /*#__PURE__*/React.createElement("button", {
        className: "btn",
        style: {
          background: "#dc2626",
          color: "white",
          padding: "3px 8px",
          fontSize: 12
        },
        onClick: () => openSellModal(s)
      }, "Sell"), /*#__PURE__*/React.createElement("button", {
        className: "btn",
        style: {
          background: "#374151",
          color: "#94a3b8",
          padding: "3px 8px",
          fontSize: 12
        },
        onClick: () => startStockInlineEdit(s)
      }, "\u270F\uFE0F"), /*#__PURE__*/React.createElement("button", {
        className: "btn",
        style: {
          background: "#7f1d1d33",
          color: "#f87171",
          padding: "3px 8px",
          fontSize: 12
        },
        onClick: () => deleteStock(s.id)
      }, "\uD83D\uDDD1"))));
    })), /*#__PURE__*/React.createElement("tfoot", null, /*#__PURE__*/React.createElement("tr", {
      style: {
        background: "#21242f",
        borderTop: "2px solid #2d3748"
      }
    }, /*#__PURE__*/React.createElement("td", {
      colSpan: 6,
      style: {
        padding: "8px 9px",
        color: "#94a3b8",
        fontSize: 13,
        fontWeight: 600
      }
    }, "Total (", filteredStocks.length, " holdings)"), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", {
      title: "Shares \xD7 per-share day change, held/assigned positions only",
      style: {
        padding: "8px 9px",
        fontWeight: 700,
        whiteSpace: "nowrap"
      }
    }, (() => {
      const totalDayChg = filteredStocks.filter(s => !isStockSold(s) && tickerChange[s.ticker]).reduce((a, s) => a + (parseFloat(s.shares) || 0) * tickerChange[s.ticker].abs, 0);
      const hasAny = filteredStocks.some(s => !isStockSold(s) && tickerChange[s.ticker]);
      if (!hasAny) return "—";
      return /*#__PURE__*/React.createElement("span", {
        style: {
          color: totalDayChg >= 0 ? "#4ade80" : "#f87171"
        }
      }, totalDayChg >= 0 ? "▲" : "▼", fmt$(Math.abs(totalDayChg)));
    })()), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "8px 9px",
        color: "#94a3b8",
        fontWeight: 700
      }
    }, fmt$(filteredStocks.reduce((a, s) => a + stockCostValue(s), 0))), /*#__PURE__*/React.createElement("td", {
      title: "Assigned positions only, \u2265100 shares \u2014 calls sold since each lot's assignment date",
      style: {
        padding: "8px 9px",
        fontWeight: 700,
        color: "#4ade80"
      }
    }, fmt$(filteredStocks.filter(s => !isStockSold(s) && (parseFloat(s.shares) || 0) >= 100).reduce((a, s) => a + (stockCallPremium(s) || 0), 0))), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "8px 9px",
        fontWeight: 700,
        color: "#60a5fa"
      }
    }, fmt$(filteredStocks.reduce((a, s) => a + stockMarketValue(s), 0))), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "8px 9px",
        fontWeight: 700,
        color: filteredStocks.reduce((a, s) => a + (stockGainLoss(s) || 0), 0) >= 0 ? "#4ade80" : "#f87171"
      }
    }, fmtPL(filteredStocks.reduce((a, s) => a + (stockGainLoss(s) || 0), 0))), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", null))))), multiLotGroups.length > 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #8b5cf6",
        borderRadius: 10,
        padding: 16,
        marginTop: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: "#a78bfa",
        marginBottom: 4
      }
    }, "\uD83D\uDD17 Combined Positions (Multiple Lots)"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "#6b7280",
        marginBottom: 12
      }
    }, "Blended view for tickers with more than one active lot in the same account \u2014 weighted-average cost basis across all lots, but net call premium only comes from Assigned lots (calls sold since each one's assignment date). Held lots contribute shares/cost basis but no premium. Individual lots above remain separate for tax/date tracking."), /*#__PURE__*/React.createElement("div", {
      style: {
        overflowX: "auto",
        borderRadius: 8,
        border: "1px solid #2d3748"
      }
    }, /*#__PURE__*/React.createElement("table", {
      style: {
        width: "100%",
        borderCollapse: "separate",
        borderSpacing: 0,
        fontSize: 13,
        minWidth: 950
      }
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
      style: {
        background: "#2c3346",
        color: "#94a3b8"
      }
    }, ["Acct", "Ticker", "# Lots", "Total Shares", "Wtd Avg Cost Basis", "Net Call Premium", "Eff. Avg Cost Basis", "Current Price", "Market Value", "Net Gain/Loss", "%"].map(h => /*#__PURE__*/React.createElement("th", {
      key: h,
      style: {
        padding: "8px 9px",
        fontWeight: 600,
        whiteSpace: "nowrap",
        borderBottom: "1px solid #2d3748",
        textAlign: "left"
      }
    }, h)))), /*#__PURE__*/React.createElement("tbody", null, multiLotGroups.map(g => {
      const ac = ACCT_COLOR[g.account] || "#60a5fa";
      return /*#__PURE__*/React.createElement("tr", {
        key: g.key,
        style: {
          borderBottom: "1px solid #262a3d",
          background: g.gainLoss > 0 ? "rgba(74,222,128,0.05)" : g.gainLoss < 0 ? "rgba(248,113,113,0.05)" : ""
        }
      }, /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          color: ac,
          fontWeight: 600,
          fontSize: 11
        }
      }, g.account)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontWeight: 700,
          color: "#60a5fa"
        }
      }, g.ticker), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11,
          color: "#4b5563",
          maxWidth: 140,
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap"
        }
      }, g.company)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          textAlign: "center"
        }
      }, g.lotsCount), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          textAlign: "center"
        }
      }, g.totalShares), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, fmt$(g.weightedCB)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          fontWeight: 600,
          color: g.totalPrem > 0 ? "#4ade80" : "#4b5563"
        }
      }, g.totalPrem > 0 ? fmt$(g.totalPrem) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          fontWeight: 700,
          color: "#a78bfa"
        }
      }, g.effCB != null ? fmt$(g.effCB) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          color: "#fbbf24"
        }
      }, fmt$(g.currentPrice)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          fontWeight: 600,
          color: "#60a5fa"
        }
      }, fmt$(g.marketValue)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          fontWeight: 700,
          color: g.gainLoss >= 0 ? "#4ade80" : "#f87171"
        }
      }, fmtPL(g.gainLoss)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          fontWeight: 600,
          color: g.gainPct == null ? "#4b5563" : g.gainPct >= 0 ? "#4ade80" : "#f87171"
        }
      }, g.gainPct != null ? (g.gainPct >= 0 ? "+" : "") + g.gainPct.toFixed(1) + "%" : "—"));
    })))))), mainTab === "log" && /*#__PURE__*/React.createElement(React.Fragment, null, showForm && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 16,
        marginBottom: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 16,
        fontWeight: 700,
        marginBottom: 14,
        color: "#60a5fa"
      }
    }, editId ? "✏️ Edit Trade" : "➕ New Trade"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill,minmax(160px,1fr))",
        gap: 12
      }
    }, [{
      label: "Account",
      el: /*#__PURE__*/React.createElement("select", {
        className: "inp",
        value: form.account,
        onChange: e => setForm(f => ({
          ...f,
          account: e.target.value
        }))
      }, ACCOUNTS.map(a => /*#__PURE__*/React.createElement("option", {
        key: a
      }, a)))
    }, {
      label: "Open Date",
      el: /*#__PURE__*/React.createElement("input", {
        type: "date",
        className: "inp",
        value: form.date,
        onChange: e => setForm(f => ({
          ...f,
          date: e.target.value
        }))
      })
    }, {
      label: "Ticker",
      el: /*#__PURE__*/React.createElement("input", {
        className: "inp",
        placeholder: "e.g. MU",
        value: form.ticker,
        onChange: e => handleTicker(e.target.value)
      })
    }, {
      label: "Company",
      el: /*#__PURE__*/React.createElement("input", {
        className: "inp",
        placeholder: "Auto-fills",
        value: form.company,
        onChange: e => setForm(f => ({
          ...f,
          company: e.target.value
        }))
      })
    }, {
      label: "Strike Price",
      el: /*#__PURE__*/React.createElement("input", {
        type: "number",
        className: "inp",
        placeholder: "0.00",
        value: form.strike,
        onChange: e => setForm(f => ({
          ...f,
          strike: e.target.value
        }))
      })
    }, {
      label: "Current Stock $",
      el: /*#__PURE__*/React.createElement("input", {
        type: "number",
        className: "inp",
        placeholder: "0.00",
        value: form.currentStock,
        onChange: e => setForm(f => ({
          ...f,
          currentStock: e.target.value
        }))
      })
    }, {
      label: "Exp Date",
      el: /*#__PURE__*/React.createElement("input", {
        type: "date",
        className: "inp",
        value: form.expDate,
        onChange: e => setForm(f => ({
          ...f,
          expDate: e.target.value
        }))
      })
    }, {
      label: "Sell Premium",
      el: /*#__PURE__*/React.createElement("input", {
        type: "number",
        className: "inp",
        step: "0.01",
        placeholder: "0.00",
        value: form.sellPremium,
        onChange: e => setForm(f => ({
          ...f,
          sellPremium: e.target.value
        }))
      })
    }, {
      label: "Contracts",
      el: /*#__PURE__*/React.createElement("input", {
        type: "number",
        className: "inp",
        min: "1",
        value: form.contracts,
        onChange: e => setForm(f => ({
          ...f,
          contracts: e.target.value
        }))
      })
    }, {
      label: "C/P",
      el: /*#__PURE__*/React.createElement("select", {
        className: "inp",
        value: form.cp,
        onChange: e => setForm(f => ({
          ...f,
          cp: e.target.value
        }))
      }, /*#__PURE__*/React.createElement("option", {
        value: "P"
      }, "P \u2013 Put"), /*#__PURE__*/React.createElement("option", {
        value: "C"
      }, "C \u2013 Call"))
    }, {
      label: "S/B",
      el: /*#__PURE__*/React.createElement("select", {
        className: "inp",
        value: form.sb,
        onChange: e => setForm(f => ({
          ...f,
          sb: e.target.value
        }))
      }, /*#__PURE__*/React.createElement("option", {
        value: "S"
      }, "S \u2013 Sell"), /*#__PURE__*/React.createElement("option", {
        value: "B"
      }, "B \u2013 Buy"))
    }, {
      label: "Action",
      el: /*#__PURE__*/React.createElement("select", {
        className: "inp",
        value: form.action,
        onChange: e => setForm(f => ({
          ...f,
          action: e.target.value
        }))
      }, ACTIONS.map(a => /*#__PURE__*/React.createElement("option", {
        key: a
      }, a)))
    }].map(({
      label,
      el
    }) => /*#__PURE__*/React.createElement("div", {
      key: label
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, label), el))), form.sellPremium && form.contracts && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 12,
        padding: 10,
        background: "#1b1e29",
        borderRadius: 8,
        display: "flex",
        gap: 20,
        flexWrap: "wrap",
        fontSize: 13
      }
    }, /*#__PURE__*/React.createElement("span", null, "Sells: ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#4ade80"
      }
    }, fmt$(calcSells(form.sb, form.sellPremium, form.contracts)))), form.sb === "S" && form.cp === "P" && /*#__PURE__*/React.createElement("span", null, "$ On Hold: ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#fb923c"
      }
    }, fmt$(parseFloat(form.strike || 0) * parseInt(form.contracts || 1) * 100)))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        marginTop: 12
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#059669",
        color: "white"
      },
      onClick: handleSubmit
    }, editId ? "Save Changes" : "Add Trade"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "white"
      },
      onClick: () => {
        setShowForm(false);
        setEditId(null);
        setForm(EMPTY);
      }
    }, "Cancel"))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 10
      }
    }, showFilters && /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 10,
        padding: 14,
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill,minmax(170px,1fr))",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Status"), /*#__PURE__*/React.createElement("select", {
      className: "inp",
      value: filters.status,
      onChange: e => setF("status", e.target.value)
    }, /*#__PURE__*/React.createElement("option", {
      value: "all"
    }, "All"), /*#__PURE__*/React.createElement("option", {
      value: "open"
    }, "Open only"), /*#__PURE__*/React.createElement("option", {
      value: "closed"
    }, "Closed only"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Call / Put"), /*#__PURE__*/React.createElement("select", {
      className: "inp",
      value: filters.cp,
      onChange: e => setF("cp", e.target.value)
    }, /*#__PURE__*/React.createElement("option", {
      value: "all"
    }, "All"), /*#__PURE__*/React.createElement("option", {
      value: "P"
    }, "Puts only"), /*#__PURE__*/React.createElement("option", {
      value: "C"
    }, "Calls only"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Sell / Buy"), /*#__PURE__*/React.createElement("select", {
      className: "inp",
      value: filters.sb,
      onChange: e => setF("sb", e.target.value)
    }, /*#__PURE__*/React.createElement("option", {
      value: "all"
    }, "All"), /*#__PURE__*/React.createElement("option", {
      value: "S"
    }, "Sells only"), /*#__PURE__*/React.createElement("option", {
      value: "B"
    }, "Buys only"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Ticker"), /*#__PURE__*/React.createElement("input", {
      className: "inp",
      list: "ticker-history",
      placeholder: "e.g. MU",
      value: filters.ticker,
      onChange: e => setF("ticker", e.target.value)
    }), /*#__PURE__*/React.createElement("datalist", {
      id: "ticker-history"
    }, uniqueTickers.map(tk => /*#__PURE__*/React.createElement("option", {
      key: tk,
      value: tk
    })))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Open Date From"), /*#__PURE__*/React.createElement("input", {
      type: "date",
      className: "inp",
      value: filters.dateFrom,
      onChange: e => setF("dateFrom", e.target.value)
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Open Date To"), /*#__PURE__*/React.createElement("input", {
      type: "date",
      className: "inp",
      value: filters.dateTo,
      onChange: e => setF("dateTo", e.target.value)
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Close Date From"), /*#__PURE__*/React.createElement("input", {
      type: "date",
      className: "inp",
      value: filters.closeDateFrom,
      onChange: e => setF("closeDateFrom", e.target.value)
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Close Date To"), /*#__PURE__*/React.createElement("input", {
      type: "date",
      className: "inp",
      value: filters.closeDateTo,
      onChange: e => setF("closeDateTo", e.target.value)
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Min Net P&L ($)"), /*#__PURE__*/React.createElement("input", {
      type: "number",
      className: "inp",
      placeholder: "-500",
      value: filters.minPL,
      onChange: e => setF("minPL", e.target.value)
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Max Net P&L ($)"), /*#__PURE__*/React.createElement("input", {
      type: "number",
      className: "inp",
      placeholder: "2000",
      value: filters.maxPL,
      onChange: e => setF("maxPL", e.target.value)
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Max DTE (open only)"), /*#__PURE__*/React.createElement("input", {
      type: "number",
      className: "inp",
      placeholder: "e.g. 7",
      min: "0",
      value: filters.maxDTE,
      onChange: e => setF("maxDTE", e.target.value)
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 4,
        marginTop: 4
      }
    }, [7, 14, 30].map(d => /*#__PURE__*/React.createElement("button", {
      key: d,
      type: "button",
      onClick: () => setF("maxDTE", filters.maxDTE === String(d) ? "" : String(d)),
      style: {
        flex: 1,
        padding: "3px 0",
        fontSize: 11,
        fontWeight: 600,
        borderRadius: 4,
        border: "none",
        cursor: "pointer",
        background: filters.maxDTE === String(d) ? "#7c3aed" : "#374151",
        color: filters.maxDTE === String(d) ? "white" : "#94a3b8"
      }
    }, d, "d")))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8,
        paddingTop: 20
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "checkbox",
      id: "moh",
      checked: filters.moneyOnHold,
      onChange: e => setF("moneyOnHold", e.target.checked),
      style: {
        cursor: "pointer",
        width: 16,
        height: 16
      }
    }), /*#__PURE__*/React.createElement("label", {
      htmlFor: "moh",
      style: {
        fontSize: 13,
        color: "#e2e8f0",
        cursor: "pointer"
      }
    }, "Has $ On Hold")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8,
        paddingTop: 20
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "checkbox",
      id: "itmOnly",
      checked: filters.itmOnly,
      onChange: e => setF("itmOnly", e.target.checked),
      style: {
        cursor: "pointer",
        width: 16,
        height: 16
      }
    }), /*#__PURE__*/React.createElement("label", {
      htmlFor: "itmOnly",
      style: {
        fontSize: 13,
        color: "#e2e8f0",
        cursor: "pointer"
      }
    }, "ITM Only (open positions)")), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#6b7280",
        marginTop: 2
      }
    }, "Puts: Strike > Stock \xA0\xB7\xA0 Calls: Strike < Stock. Combine with Max DTE above, or leave DTE blank for all expiries.")))), filtered.length === 0 ? /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: "center",
        padding: 48,
        color: "#4b5563"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 40,
        marginBottom: 8
      }
    }, "\uD83D\uDCED"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15
      }
    }, "No trades found.")) : /*#__PURE__*/React.createElement("div", {
      style: {
        overflowX: "auto",
        overflowY: "auto",
        maxHeight: "65vh",
        borderRadius: 10,
        border: "1px solid #2d3748"
      }
    }, /*#__PURE__*/React.createElement("table", {
      style: {
        width: "100%",
        borderCollapse: "separate",
        borderSpacing: 0,
        fontSize: 13,
        minWidth: 1300
      }
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
      style: {
        background: "#2c3346",
        color: "#94a3b8"
      }
    }, [null, "Acct", "Date", "Ticker", "Strike", "Stk $", "Day Chg", "Diff", "Exp", "Prem", "Now", "Unreal", "Qty", "C/P", "S/B", "Sells", "Total", "Status", "Close Date", "Close Prem", "Net P&L", "Ann %", "$ On Hold", null].map((h, i) => {
      const sortable = LOG_SORT_COLS[h];
      const active = sortConfig.key === h;
      return /*#__PURE__*/React.createElement("th", {
        key: i,
        onClick: sortable ? () => handleSort(h) : undefined,
        style: {
          padding: "8px 9px",
          fontWeight: 600,
          whiteSpace: "nowrap",
          borderBottom: "1px solid #2d3748",
          textAlign: "left",
          position: "sticky",
          top: 0,
          background: active ? "#3a3f56" : "#2c3346",
          zIndex: 10,
          cursor: sortable ? "pointer" : "default",
          userSelect: "none",
          color: active ? "#fbbf24" : "#94a3b8"
        }
      }, i === 0 ? /*#__PURE__*/React.createElement("input", {
        type: "checkbox",
        checked: filtered.length > 0 && filtered.every(t => selected.has(t.id)),
        onChange: toggleAll,
        style: {
          cursor: "pointer"
        }
      }) : /*#__PURE__*/React.createElement(React.Fragment, null, h, active && (sortConfig.direction === "asc" ? " ▲" : " ▼")));
    }))), /*#__PURE__*/React.createElement("tbody", null, sortedFiltered.map(t => {
      const diff = t.currentStock && t.strike ? parseFloat(t.currentStock) - parseFloat(t.strike) : null;
      const ac = ACCT_COLOR[t.account] || "#60a5fa";
      if (inlineEditId === t.id) {
        return /*#__PURE__*/React.createElement("tr", {
          key: t.id,
          style: {
            borderBottom: "2px solid #3b82f6",
            background: "rgba(59,130,246,0.1)"
          }
        }, /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("select", {
          style: iinp,
          value: inlineForm.account,
          onChange: e => setInlineForm(p => ({
            ...p,
            account: e.target.value
          }))
        }, ACCOUNTS.map(a => /*#__PURE__*/React.createElement("option", {
          key: a
        }, a)))), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("input", {
          type: "date",
          style: iinp,
          value: inlineForm.date,
          onChange: e => setInlineForm(p => ({
            ...p,
            date: e.target.value
          }))
        })), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("input", {
          style: iinp,
          value: inlineForm.ticker,
          onChange: e => {
            const v = e.target.value.toUpperCase();
            setInlineForm(p => ({
              ...p,
              ticker: v,
              company: tickerName(v) || p.company
            }));
          }
        }), /*#__PURE__*/React.createElement("input", {
          style: {
            ...iinp,
            marginTop: 2
          },
          value: inlineForm.company,
          onChange: e => setInlineForm(p => ({
            ...p,
            company: e.target.value
          }))
        })), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("input", {
          type: "number",
          style: iinp,
          value: inlineForm.strike,
          onChange: e => setInlineForm(p => ({
            ...p,
            strike: e.target.value
          }))
        })), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("input", {
          type: "number",
          style: iinp,
          value: inlineForm.currentStock,
          onChange: e => setInlineForm(p => ({
            ...p,
            currentStock: e.target.value
          }))
        })), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("input", {
          type: "date",
          style: iinp,
          value: inlineForm.expDate,
          onChange: e => setInlineForm(p => ({
            ...p,
            expDate: e.target.value
          }))
        })), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("input", {
          type: "number",
          style: iinp,
          step: "0.01",
          value: inlineForm.sellPremium,
          onChange: e => setInlineForm(p => ({
            ...p,
            sellPremium: e.target.value
          }))
        })), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("input", {
          type: "number",
          style: iinp,
          min: "1",
          value: inlineForm.contracts,
          onChange: e => setInlineForm(p => ({
            ...p,
            contracts: e.target.value
          }))
        })), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("select", {
          style: iinp,
          value: inlineForm.cp,
          onChange: e => setInlineForm(p => ({
            ...p,
            cp: e.target.value
          }))
        }, /*#__PURE__*/React.createElement("option", {
          value: "P"
        }, "P"), /*#__PURE__*/React.createElement("option", {
          value: "C"
        }, "C"))), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("select", {
          style: iinp,
          value: inlineForm.sb,
          onChange: e => setInlineForm(p => ({
            ...p,
            sb: e.target.value
          }))
        }, /*#__PURE__*/React.createElement("option", {
          value: "S"
        }, "S"), /*#__PURE__*/React.createElement("option", {
          value: "B"
        }, "B"))), /*#__PURE__*/React.createElement("td", {
          colSpan: 2
        }), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("select", {
          style: iinp,
          value: inlineForm.action,
          onChange: e => setInlineForm(p => ({
            ...p,
            action: e.target.value
          }))
        }, ACTIONS.map(a => /*#__PURE__*/React.createElement("option", {
          key: a
        }, a)))), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("input", {
          type: "date",
          style: iinp,
          value: inlineForm.closeDate,
          onChange: e => setInlineForm(p => ({
            ...p,
            closeDate: e.target.value
          }))
        })), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px"
          }
        }, /*#__PURE__*/React.createElement("input", {
          type: "number",
          style: iinp,
          step: "0.01",
          placeholder: "exact $ amount",
          value: inlineForm.closePremium,
          onChange: e => setInlineForm(p => ({
            ...p,
            closePremium: e.target.value
          }))
        })), /*#__PURE__*/React.createElement("td", {
          colSpan: 3
        }), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "4px 6px",
            whiteSpace: "nowrap"
          }
        }, /*#__PURE__*/React.createElement("div", {
          style: {
            display: "flex",
            gap: 3
          }
        }, /*#__PURE__*/React.createElement("button", {
          className: "btn",
          style: {
            background: "#059669",
            color: "white",
            padding: "3px 8px",
            fontSize: 12
          },
          onClick: saveEdit
        }, "\u2713"), /*#__PURE__*/React.createElement("button", {
          className: "btn",
          style: {
            background: "#374151",
            color: "white",
            padding: "3px 8px",
            fontSize: 12
          },
          onClick: cancelEdit
        }, "\u2715"))));
      }
      return /*#__PURE__*/React.createElement("tr", {
        key: t.id,
        style: {
          borderBottom: "1px solid #262a3d",
          background: selected.has(t.id) ? "rgba(59,130,246,0.12)" : rowBg(t)
        }
      }, /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, /*#__PURE__*/React.createElement("input", {
        type: "checkbox",
        checked: selected.has(t.id),
        onChange: () => toggleSel(t.id),
        style: {
          cursor: "pointer"
        }
      })), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          color: ac,
          fontWeight: 600,
          fontSize: 11
        }
      }, t.account)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          whiteSpace: "nowrap",
          color: "#94a3b8"
        }
      }, t.date), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontWeight: 700
        }
      }, /*#__PURE__*/React.createElement("button", {
        onClick: () => setQuoteModalTicker(t.ticker),
        className: "ticker-link",
        style: {
          color: "#60a5fa",
          background: "none",
          border: "none",
          padding: 0,
          font: "inherit",
          fontWeight: 700,
          cursor: "pointer"
        }
      }, t.ticker)), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11,
          color: "#4b5563",
          maxWidth: 110,
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap"
        }
      }, t.company)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          fontWeight: 600
        }
      }, fmt$(t.strike)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, t.currentStock ? fmt$(t.currentStock) : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          whiteSpace: "nowrap"
        }
      }, tickerChange[t.ticker] ? (() => {
        const ch = tickerChange[t.ticker];
        const up = ch.abs >= 0;
        return /*#__PURE__*/React.createElement("span", {
          title: ch.pd ? `vs the close of ${ch.pd}${ch.ps && ch.ps !== "daily bar" ? ` — ${ch.ps}` : ""}` : "",
          style: {
            color: up ? "#4ade80" : "#f87171",
            fontWeight: 600,
            cursor: ch.pd ? "help" : "default"
          }
        }, up ? "▲" : "▼", fmt$(Math.abs(ch.abs)), " (", Math.abs(ch.pct).toFixed(2), "%)");
      })() : "—"), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          color: diff == null ? "" : diff >= 0 ? "#4ade80" : "#f87171",
          fontWeight: 600
        }
      }, diff != null ? (diff >= 0 ? "+" : "") + diff.toFixed(2) : ""), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          whiteSpace: "nowrap",
          color: "#94a3b8"
        }
      }, t.expDate), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, fmt$(t.sellPremium)), (() => {
        // Live contract price and unrealised P&L. Only meaningful
        // while a position is open, so closed rows stay blank.
        if (!isOpen(t)) return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 9px",
            color: "#4b5563"
          }
        }, "\u2014"), /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 9px",
            color: "#4b5563"
          }
        }, "\u2014"));
        const qq = quoteFor(t);
        if (qq && qq.expired) return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("td", {
          colSpan: 2,
          title: "This contract's expiry has passed but the trade is still marked Open. Close it out to keep your P&L accurate.",
          style: {
            padding: "6px 9px",
            color: "#fbbf24",
            whiteSpace: "nowrap"
          }
        }, "\u231B expired \u2014 still open"));
        const u = unrealisedPL(t);
        if (!u) return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("td", {
          colSpan: 2,
          title: qq && qq.err ? qq.err : "No quote yet — press 🔄 Prices with the screener service running",
          style: {
            padding: "6px 9px",
            color: qq && qq.err ? "#fbbf24" : "#4b5563",
            whiteSpace: "nowrap",
            cursor: qq && qq.err ? "help" : "default",
            maxWidth: 230,
            overflow: "hidden",
            textOverflow: "ellipsis"
          }
        }, qq && qq.err ? /*#__PURE__*/React.createElement(React.Fragment, null, "\u26A0 ", qq.err) : "—"));
        const age = quoteAgeHours(t);
        const stale = age != null && age > 24;
        const q = u.q || {};
        const tip = [`${u.basis === "mid" ? "Mid (no last trade)" : "Last traded"} $${u.price.toFixed(2)}`, q.bid != null ? `bid $${q.bid} / ask $${q.ask}` : null, q.oi != null ? `OI ${q.oi}` : null, age != null ? `fetched ${age < 1 ? "just now" : Math.round(age) + "h ago"}` : null, t.sb === "S" ? "Short: you profit as this falls" : "Long: you profit as this rises"].filter(Boolean).join(" · ");
        return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("td", {
          title: tip,
          style: {
            padding: "6px 9px",
            whiteSpace: "nowrap",
            color: stale ? "#6b7280" : "#e2e8f0"
          }
        }, fmt$(u.price), u.basis === "mid" && /*#__PURE__*/React.createElement("span", {
          title: "No last trade; showing mid",
          style: {
            color: "#fbbf24",
            marginLeft: 3
          }
        }, "*"), stale && /*#__PURE__*/React.createElement("span", {
          title: "Quote over a day old",
          style: {
            color: "#b45309",
            marginLeft: 3
          }
        }, "\u231B")), /*#__PURE__*/React.createElement("td", {
          title: u.pct != null ? `${u.pct.toFixed(0)}% of the premium captured` : "",
          style: {
            padding: "6px 9px",
            whiteSpace: "nowrap",
            fontWeight: 700,
            color: u.pl >= 0 ? "#4ade80" : "#f87171"
          }
        }, fmtPL(u.pl), u.pct != null && /*#__PURE__*/React.createElement("span", {
          style: {
            fontSize: 11,
            fontWeight: 400,
            color: "#94a3b8",
            marginLeft: 4
          }
        }, u.pct >= 0 ? "+" : "", u.pct.toFixed(0), "%")));
      })(), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          textAlign: "center"
        }
      }, t.contracts), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          textAlign: "center"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          background: t.cp === "P" ? "#7c3aed22" : "#0369a122",
          color: t.cp === "P" ? "#a78bfa" : "#38bdf8",
          padding: "2px 6px",
          borderRadius: 4,
          fontWeight: 700
        }
      }, t.cp)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          textAlign: "center"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          background: t.sb === "S" ? "#05966922" : "#dc262622",
          color: t.sb === "S" ? "#4ade80" : "#f87171",
          padding: "2px 6px",
          borderRadius: 4,
          fontWeight: 700
        }
      }, t.sb)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          color: "#4ade80"
        }
      }, t.sells ? fmt$(t.sells) : ""), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          fontWeight: 600,
          color: t.total >= 0 ? "#4ade80" : "#f87171"
        }
      }, fmt$(t.total)), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          padding: "2px 7px",
          borderRadius: 4,
          fontSize: 11,
          fontWeight: 600,
          whiteSpace: "nowrap",
          background: isOpen(t) ? "#78350f33" : t.action === "Expired" ? "#14532d33" : t.action === "Assigned" ? "#1e3a5f33" : "#1e293b",
          color: isOpen(t) ? "#fbbf24" : t.action === "Expired" ? "#4ade80" : t.action === "Assigned" ? "#60a5fa" : "#94a3b8"
        }
      }, t.action || "Open")), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          whiteSpace: "nowrap",
          color: "#94a3b8"
        }
      }, t.closeDate || ""), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px"
        }
      }, t.closePremium ? fmt$(t.closePremium) : ""), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          fontWeight: 700,
          color: t.netPL == null ? "" : t.netPL >= 0 ? "#4ade80" : "#f87171"
        }
      }, t.netPL != null ? fmtPL(t.netPL) : ""), (() => {
        const a = calcAnnualized(t);
        if (!a) return /*#__PURE__*/React.createElement("td", {
          style: {
            padding: "6px 9px",
            color: "#4b5563"
          }
        }, "\u2014");
        const stat = a.amount / a.collateral * 100;
        const tip = (a.open ? `Premium collected ${fmt$(a.amount)} on ${fmt$(a.collateral)} of collateral` : `Net P&L ${fmtPL(a.amount)} on ${fmt$(a.collateral)} of collateral`) + ` = ${stat.toFixed(2)}% over ${a.days} day${a.days === 1 ? "" : "s"} ` + `(${t.date} to ${a.endStr}, the ${a.endLabel} date), annualised ×${(365 / a.days).toFixed(2)}.\n\n` + (a.open ? `Open trade: the yield this was written at. It will be recalculated from the actual result when you close it.` : `Closed trade: what the capital actually earned over the time it was tied up.`);
        return /*#__PURE__*/React.createElement("td", {
          title: tip,
          style: {
            padding: "6px 9px",
            fontWeight: 600,
            cursor: "help",
            whiteSpace: "nowrap",
            color: a.pct < 0 ? "#f87171" : a.pct >= 30 ? "#4ade80" : a.pct >= 15 ? "#a3e635" : "#94a3b8"
          }
        }, a.pct >= 0 ? "" : "−", Math.abs(a.pct).toFixed(1), "%");
      })(), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          color: "#fb923c"
        }
      }, t.moneyOnHold ? fmt$(t.moneyOnHold) : ""), /*#__PURE__*/React.createElement("td", {
        style: {
          padding: "6px 9px",
          whiteSpace: "nowrap"
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          gap: 3
        }
      }, isOpen(t) && /*#__PURE__*/React.createElement("button", {
        className: "btn",
        style: {
          background: "#059669",
          color: "white",
          padding: "3px 8px",
          fontSize: 12
        },
        onClick: () => {
          setCloseTarget(t);
          setCloseForm({
            action: "Bought to Close",
            closeDate: "",
            closePremium: ""
          });
        }
      }, "Close"), /*#__PURE__*/React.createElement("button", {
        className: "btn",
        style: {
          background: "#374151",
          color: "#94a3b8",
          padding: "3px 8px",
          fontSize: 12
        },
        onClick: () => startEdit(t)
      }, "\u270F\uFE0F"), /*#__PURE__*/React.createElement("button", {
        className: "btn",
        style: {
          background: "#7f1d1d33",
          color: "#f87171",
          padding: "3px 8px",
          fontSize: 12
        },
        onClick: () => deleteTrade(t.id)
      }, "\uD83D\uDDD1"))));
    }))))))), closeTarget && /*#__PURE__*/React.createElement("div", {
      style: {
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.75)",
        zIndex: 200,
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #3b82f6",
        borderRadius: 12,
        width: closeForm.action === "Rolled" ? 820 : 400,
        maxWidth: "95vw",
        maxHeight: "92vh",
        display: "flex",
        flexDirection: "column"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "20px 24px 12px",
        borderBottom: "1px solid #2d3748"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 16,
        fontWeight: 700,
        color: "#60a5fa",
        marginBottom: 4
      }
    }, "Close / Roll Position"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8"
      }
    }, closeTarget.ticker, " ", closeTarget.cp, " $", closeTarget.strike, " exp ", closeTarget.expDate)), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "16px 24px",
        overflowY: "auto",
        flex: "1 1 auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 20,
        alignItems: "start",
        gridTemplateColumns: closeForm.action === "Rolled" ? "1fr 1fr" : "1fr"
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        fontWeight: 700,
        color: "#f87171",
        marginBottom: 8,
        letterSpacing: 0.3
      }
    }, "CLOSING", closeForm.action === "Rolled" ? " — the leg you are buying back" : ""), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 12
      }
    }, [{
      label: "Action",
      el: /*#__PURE__*/React.createElement("select", {
        className: "inp",
        value: closeForm.action,
        onChange: e => {
          const v = e.target.value;
          // Pre-fill the roll quantity from the position being closed the
          // first time Rolled is picked, without clobbering an edit if
          // the action is toggled back and forth.
          setCloseForm(f => ({
            ...f,
            action: v,
            rollQty: v === "Rolled" && !f.rollQty ? String(parseInt(closeTarget.contracts) || 1) : f.rollQty
          }));
        }
      }, ACTIONS.filter(a => a !== "Open").map(a => /*#__PURE__*/React.createElement("option", {
        key: a
      }, a)))
    }, {
      label: "Close Date",
      el: /*#__PURE__*/React.createElement("input", {
        type: "date",
        className: "inp",
        value: closeForm.closeDate,
        onChange: e => setCloseForm(f => ({
          ...f,
          closeDate: e.target.value
        }))
      })
    }, {
      label: "Close Premium (exact $ — negative if paid, positive if received)",
      el: /*#__PURE__*/React.createElement("input", {
        type: "number",
        className: "inp",
        step: "0.01",
        placeholder: "e.g. -200.67",
        value: closeForm.closePremium,
        onChange: e => setCloseForm(f => ({
          ...f,
          closePremium: e.target.value
        }))
      })
    }].map(({
      label,
      el
    }) => /*#__PURE__*/React.createElement("div", {
      key: label
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, label), el))), (closeForm.closePremium || closeForm.action === "Expired" || closeForm.action === "Assigned") && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 12,
        padding: 10,
        background: "#1b1e29",
        borderRadius: 8,
        fontSize: 13
      }
    }, "Est. Net P&L: ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: (calcNetPL(closeTarget.total, closeForm.closePremium, closeForm.action) || 0) >= 0 ? "#4ade80" : "#f87171"
      }
    }, fmtPL(calcNetPL(closeTarget.total, closeForm.closePremium, closeForm.action)))), closeForm.action === "Assigned" && closeTarget.cp === "P" && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 8,
        padding: 10,
        background: "#1e3a5f33",
        border: "1px solid #1e3a5f",
        borderRadius: 8,
        fontSize: 12,
        color: "#60a5fa"
      }
    }, "\uD83D\uDCCC This will automatically create a ", /*#__PURE__*/React.createElement("b", null, "Stock Holdings"), " entry in ", closeTarget.account, ": ", (parseInt(closeTarget.contracts) || 1) * 100, " shares of ", closeTarget.ticker, " @ $", closeTarget.strike, " cost basis, status \"Assigned\"."), closeForm.action === "Assigned" && closeTarget.cp === "C" && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 8,
        padding: 10,
        background: "#78350f33",
        border: "1px solid #78350f",
        borderRadius: 8,
        fontSize: 12,
        color: "#fbbf24"
      }
    }, "\u26A0\uFE0F This is a Call assignment (shares called away/sold) \u2014 no new holding is auto-created. If you held the underlying shares, go to Stocks and use \"Sell\" on that position with sold price $", closeTarget.strike, " and date ", closeForm.closeDate || "this close date", ".")), closeForm.action === "Rolled" && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        fontWeight: 700,
        color: "#a78bfa",
        marginBottom: 8,
        letterSpacing: 0.3
      }
    }, "OPENING \u2014 the replacement"), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 12,
        background: "#1b1e29",
        border: "1px solid #7c3aed",
        borderRadius: 8
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: "#6b7280",
        marginBottom: 10
      }
    }, closeTarget.account, " \xB7 ", closeTarget.ticker, " \xB7 ", closeTarget.cp === "P" ? "Put" : "Call", " \xB7 ", closeTarget.sb === "S" ? "Sold" : "Bought", " ", "\u2014 carried over. Opens on the close date."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 10
      }
    }, [{
      label: "New Expiry",
      el: /*#__PURE__*/React.createElement("input", {
        type: "date",
        className: "inp",
        value: closeForm.rollExp || "",
        onChange: e => setCloseForm(f => ({
          ...f,
          rollExp: e.target.value
        }))
      })
    }, {
      label: "New Strike",
      el: /*#__PURE__*/React.createElement("input", {
        type: "number",
        className: "inp",
        step: "0.01",
        placeholder: "e.g. 285.00",
        value: closeForm.rollStrike || "",
        onChange: e => setCloseForm(f => ({
          ...f,
          rollStrike: e.target.value
        }))
      })
    }, {
      label: "New Premium ($ per share)",
      el: /*#__PURE__*/React.createElement("input", {
        type: "number",
        className: "inp",
        step: "0.01",
        placeholder: "e.g. 6.40",
        value: closeForm.rollPrem || "",
        onChange: e => setCloseForm(f => ({
          ...f,
          rollPrem: e.target.value
        }))
      })
    }, {
      label: "Contracts",
      el: /*#__PURE__*/React.createElement("input", {
        type: "number",
        className: "inp",
        min: "1",
        value: closeForm.rollQty || "",
        onChange: e => setCloseForm(f => ({
          ...f,
          rollQty: e.target.value
        }))
      })
    }].map(({
      label,
      el
    }) => /*#__PURE__*/React.createElement("div", {
      key: label
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12.5,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, label), el))), closeForm.rollPrem && closeForm.rollQty && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 10,
        fontSize: 12.5,
        color: "#94a3b8",
        lineHeight: 1.6
      }
    }, "New trade collects ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "#4ade80"
      }
    }, fmt$(calcSells(closeTarget.sb, closeForm.rollPrem, closeForm.rollQty) + calcBuys(closeTarget.sb, closeForm.rollPrem, closeForm.rollQty))), closeForm.closePremium && (() => {
      // What the roll actually did to your cash, both legs together.
      const outLeg = parseFloat(closeForm.closePremium) || 0;
      const inLeg = calcSells(closeTarget.sb, closeForm.rollPrem, closeForm.rollQty) + calcBuys(closeTarget.sb, closeForm.rollPrem, closeForm.rollQty);
      const net = outLeg + inLeg;
      return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("br", null), "Net of the buy-back: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: net >= 0 ? "#4ade80" : "#f87171"
        }
      }, fmtPL(net)), " ", net >= 0 ? "credit" : "debit");
    })()))))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        padding: "14px 24px",
        borderTop: "1px solid #2d3748",
        background: "#21242f",
        borderRadius: "0 0 12px 12px",
        flex: "0 0 auto"
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#059669",
        color: "white"
      },
      onClick: handleClose
    }, closeForm.action === "Rolled" ? "Confirm Roll" : "Confirm"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "white"
      },
      onClick: () => setCloseTarget(null)
    }, "Cancel")))), csvPick && (() => {
      const nOpen = trades.filter(isOpen).length;
      const pick = (kind, label, n, note, bg) => /*#__PURE__*/React.createElement("button", {
        className: "btn",
        style: {
          background: bg,
          color: "white",
          textAlign: "left",
          padding: "10px 14px",
          display: "block",
          width: "100%"
        },
        onClick: () => doExportCSV(kind)
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontWeight: 700
        }
      }, label, " ", /*#__PURE__*/React.createElement("span", {
        style: {
          fontWeight: 400,
          opacity: 0.85
        }
      }, "(", n, " trade", n === 1 ? "" : "s", ")")), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 12,
          fontWeight: 400,
          opacity: 0.85,
          marginTop: 2
        }
      }, note));
      return /*#__PURE__*/React.createElement("div", {
        style: {
          position: "fixed",
          inset: 0,
          background: "rgba(0,0,0,0.75)",
          zIndex: 200,
          display: "flex",
          alignItems: "center",
          justifyContent: "center"
        },
        onClick: () => setCsvPick(false)
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          background: "#262a3d",
          border: "1px solid #a3e635",
          borderRadius: 12,
          padding: 24,
          width: 440,
          maxWidth: "90vw"
        },
        onClick: e => e.stopPropagation()
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 16,
          fontWeight: 700,
          color: "#a3e635",
          marginBottom: 4
        }
      }, "\u2B07 Save trades as CSV"), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 13,
          color: "#94a3b8",
          marginBottom: 16
        }
      }, "Which trades do you want in the file? It is saved in My Data \u2192 Exports."), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "grid",
          gap: 10
        }
      }, pick("all", "1. All trades", trades.length, "Every account, open and closed: your full history", "#1a5c2e"), pick("open", "2. Open trades only", nOpen, "Every account, only trades that are still open", "#0e7490"), pick("filtered", "3. What is on screen now", filtered.length, "Only the account tabs and filters you have picked", "#374151")), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          gap: 8,
          marginTop: 16
        }
      }, /*#__PURE__*/React.createElement("button", {
        className: "btn",
        style: {
          background: "#374151",
          color: "white"
        },
        onClick: () => setCsvPick(false)
      }, "Cancel"))));
    })(), imp && (() => {
      const rows = imp.sheets[imp.si].rows;
      const heads = rows[imp.hr] || [];
      const res = impBuild(rows, imp.hr, imp.map, imp);
      const letter = i => {
        let s = "";
        i++;
        while (i > 0) {
          s = String.fromCharCode(65 + (i - 1) % 26) + s;
          i = Math.floor((i - 1) / 26);
        }
        return s;
      };
      const ncol = Math.max(heads.length, ...rows.slice(imp.hr, imp.hr + 40).map(r => r.length));
      const sample = i => {
        const v = rows.slice(imp.hr + 1).map(r => r[i]).find(x => x && String(x).trim());
        return v ? String(v).slice(0, 22) : "";
      };
      const colName = i => `${letter(i)} · ${heads[i] || "(no heading)"}${sample(i) ? `  (e.g. ${sample(i)})` : ""}`;
      const setMap = (k, v) => setImp(p => ({
        ...p,
        map: {
          ...p.map,
          [k]: v
        },
        remembered: false
      }));
      const setOpt = ch => setImp(p => ({
        ...p,
        ...ch,
        remembered: false
      }));
      const hasOpt = imp.map.option >= 0;
      const missing = IMP_FIELDS.filter(f => f.need && imp.map[f.k] < 0 && !hasOpt).map(f => f.label);
      const lab = {
        fontSize: 12,
        color: "#94a3b8",
        marginBottom: 3
      };
      const sub = {
        fontSize: 11,
        color: "#94a3b8",
        marginTop: 4,
        display: "flex",
        gap: 6,
        alignItems: "center"
      };
      const fieldBox = f => /*#__PURE__*/React.createElement("div", {
        key: f.k,
        style: {
          background: imp.map[f.k] >= 0 ? "#1e293b" : "#1a1d2e",
          border: "1px solid #334155",
          borderRadius: 8,
          padding: "8px 10px"
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: lab
      }, f.label, f.need && !hasOpt && /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#f87171"
        }
      }, " *")), /*#__PURE__*/React.createElement("select", {
        className: "inp",
        style: {
          width: "100%"
        },
        value: imp.map[f.k],
        onChange: e => setMap(f.k, parseInt(e.target.value))
      }, /*#__PURE__*/React.createElement("option", {
        value: -1
      }, "\u2014 not in my file \u2014"), [...Array(ncol).keys()].map(i => /*#__PURE__*/React.createElement("option", {
        key: i,
        value: i
      }, colName(i)))), f.k === "account" && /*#__PURE__*/React.createElement("div", {
        style: sub
      }, imp.map.account >= 0 ? "Blank ones go to" : "All trades go to", /*#__PURE__*/React.createElement("select", {
        className: "inp",
        style: {
          flex: 1
        },
        value: imp.acct,
        onChange: e => setOpt({
          acct: e.target.value
        })
      }, ACCOUNTS.map(a => /*#__PURE__*/React.createElement("option", {
        key: a
      }, a)))), f.k === "sellPremium" && imp.map.sellPremium >= 0 && /*#__PURE__*/React.createElement("div", {
        style: sub
      }, "This column is", /*#__PURE__*/React.createElement("select", {
        className: "inp",
        style: {
          flex: 1
        },
        value: imp.premTotal ? "t" : "s",
        onChange: e => setOpt({
          premTotal: e.target.value === "t"
        })
      }, /*#__PURE__*/React.createElement("option", {
        value: "s"
      }, "per share (like 1.25)"), /*#__PURE__*/React.createElement("option", {
        value: "t"
      }, "dollars for the whole trade (like 125)"))), f.k === "closePremium" && imp.map.closePremium >= 0 && /*#__PURE__*/React.createElement("div", {
        style: sub
      }, "This column is", /*#__PURE__*/React.createElement("select", {
        className: "inp",
        style: {
          flex: 1
        },
        value: imp.closePerShare ? "s" : "t",
        onChange: e => setOpt({
          closePerShare: e.target.value === "s"
        })
      }, /*#__PURE__*/React.createElement("option", {
        value: "t"
      }, "dollars for the whole trade (like 150)"), /*#__PURE__*/React.createElement("option", {
        value: "s"
      }, "per share (like 0.75)"))));
      const th = {
        padding: "4px 6px",
        textAlign: "left",
        color: "#94a3b8",
        fontWeight: 600,
        borderBottom: "1px solid #334155",
        whiteSpace: "nowrap"
      };
      const td = {
        padding: "4px 6px",
        borderBottom: "1px solid #1e293b",
        whiteSpace: "nowrap"
      };
      const badActs = Object.entries(res.notes.badAct);
      return /*#__PURE__*/React.createElement("div", {
        style: {
          position: "fixed",
          inset: 0,
          background: "rgba(0,0,0,0.75)",
          zIndex: 200,
          display: "flex",
          alignItems: "center",
          justifyContent: "center"
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          background: "#262a3d",
          border: "1px solid #60a5fa",
          borderRadius: 12,
          padding: 22,
          width: 940,
          maxWidth: "96vw",
          maxHeight: "92vh",
          overflowY: "auto"
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 16,
          fontWeight: 700,
          color: "#60a5fa",
          marginBottom: 4
        }
      }, "\u2B06 Import trades from ", imp.name), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 13,
          color: "#cbd5e1",
          marginBottom: 12,
          lineHeight: 1.5
        }
      }, imp.remembered ? "These are the column choices you used last time for a file laid out like this one. " : "OptionIQ has guessed which of your columns is which. ", "Check each box below and change any that are wrong. Nothing is saved until you press Add or Replace."), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          gap: 16,
          flexWrap: "wrap",
          marginBottom: 12,
          fontSize: 13,
          color: "#cbd5e1",
          alignItems: "center"
        }
      }, imp.sheets.length > 1 && /*#__PURE__*/React.createElement("label", null, "Sheet\xA0", /*#__PURE__*/React.createElement("select", {
        className: "inp",
        value: imp.si,
        onChange: e => setImp(p => ({
          ...p,
          ...impSetup(p.sheets, parseInt(e.target.value))
        }))
      }, imp.sheets.map((s, i) => /*#__PURE__*/React.createElement("option", {
        key: i,
        value: i
      }, s.name, " (", s.rows.length, " rows)")))), /*#__PURE__*/React.createElement("label", null, "Headings are on row\xA0", /*#__PURE__*/React.createElement("select", {
        className: "inp",
        value: imp.hr,
        onChange: e => setImp(p => ({
          ...p,
          ...impSetup(p.sheets, p.si, parseInt(e.target.value))
        }))
      }, rows.slice(0, 25).map((r, i) => /*#__PURE__*/React.createElement("option", {
        key: i,
        value: i
      }, i + 1, ": ", r.filter(Boolean).slice(0, 4).join(", ").slice(0, 50)))))), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill,minmax(270px,1fr))",
          gap: 8
        }
      }, IMP_FIELDS.map(fieldBox)), /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11,
          color: "#94a3b8",
          marginTop: 6
        }
      }, "* needed. If one column holds the whole option (like \"AAPL 01/16/2026 150 P\" or \"-AAPL260116P150\"), pick it under \"Option (all in one)\" and the ticker, strike, expiry and call/put are read from it. Words like Put/Call, Sell/Buy, Sell to Open, Expired or Closed are understood."), /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 16,
          fontSize: 14,
          fontWeight: 700,
          color: res.list.length ? "#4ade80" : "#f87171"
        }
      }, missing.length ? `Pick the column for: ${missing.join(", ")}` : res.list.length ? `Preview: ${res.list.length} trade${res.list.length === 1 ? "" : "s"} ready to import` : "No trades found with these choices"), res.list.length > 0 && /*#__PURE__*/React.createElement("div", {
        style: {
          overflowX: "auto",
          marginTop: 6
        }
      }, /*#__PURE__*/React.createElement("table", {
        style: {
          borderCollapse: "collapse",
          fontSize: 12,
          color: "#e2e8f0",
          width: "100%"
        }
      }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, ["Account", "Opened", "Ticker", "C/P", "S/B", "Strike", "Expiry", "Prem", "Qty", "Status", "Closed", "Close $"].map(h => /*#__PURE__*/React.createElement("th", {
        key: h,
        style: th
      }, h)))), /*#__PURE__*/React.createElement("tbody", null, res.list.slice(0, 8).map(t => /*#__PURE__*/React.createElement("tr", {
        key: t.id
      }, /*#__PURE__*/React.createElement("td", {
        style: {
          ...td,
          color: ACCOUNTS.includes(t.account) ? "#e2e8f0" : "#fbbf24"
        }
      }, t.account), /*#__PURE__*/React.createElement("td", {
        style: td
      }, t.date), /*#__PURE__*/React.createElement("td", {
        style: {
          ...td,
          fontWeight: 700
        }
      }, t.ticker), /*#__PURE__*/React.createElement("td", {
        style: td
      }, t.cp), /*#__PURE__*/React.createElement("td", {
        style: td
      }, t.sb), /*#__PURE__*/React.createElement("td", {
        style: td
      }, t.strike), /*#__PURE__*/React.createElement("td", {
        style: td
      }, t.expDate), /*#__PURE__*/React.createElement("td", {
        style: td
      }, t.sellPremium), /*#__PURE__*/React.createElement("td", {
        style: td
      }, t.contracts), /*#__PURE__*/React.createElement("td", {
        style: td
      }, t.action), /*#__PURE__*/React.createElement("td", {
        style: td
      }, t.closeDate), /*#__PURE__*/React.createElement("td", {
        style: td
      }, t.closePremium))))), res.list.length > 8 && /*#__PURE__*/React.createElement("div", {
        style: {
          fontSize: 11,
          color: "#94a3b8",
          marginTop: 4
        }
      }, "\u2026and ", res.list.length - 8, " more")), (res.skipped.length > 0 || res.notes.noCP > 0 || badActs.length > 0) && /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 10,
          fontSize: 12,
          color: "#fbbf24",
          lineHeight: 1.6
        }
      }, res.skipped.length > 0 && /*#__PURE__*/React.createElement("div", null, "\u26A0 ", res.skipped.length, " row", res.skipped.length === 1 ? "" : "s", " will be left out: ", res.skipped.slice(0, 6).map(s => `row ${s.row} (${s.why})`).join(", "), res.skipped.length > 6 ? ", …" : ""), res.notes.noCP > 0 && /*#__PURE__*/React.createElement("div", null, "\u26A0 ", res.notes.noCP, " trade", res.notes.noCP === 1 ? "" : "s", " had no Call or Put, so they are marked Put. Pick the Call or Put column if your file has one."), badActs.length > 0 && /*#__PURE__*/React.createElement("div", null, "\u26A0 Status not understood: ", badActs.map(([t, n]) => `"${t}" (${n})`).join(", "), ". Those trades are marked Open, or closed if they have a close date. You can change them after importing.")), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          gap: 8,
          marginTop: 18,
          flexWrap: "wrap"
        }
      }, /*#__PURE__*/React.createElement("button", {
        className: "btn",
        disabled: !res.list.length,
        style: {
          background: res.list.length ? "#1a5c2e" : "#374151",
          color: "white",
          opacity: res.list.length ? 1 : 0.6
        },
        onClick: () => finishImport(false)
      }, "\u2795 Add ", res.list.length, " to my trades"), /*#__PURE__*/React.createElement("button", {
        className: "btn",
        disabled: !res.list.length,
        style: {
          background: res.list.length ? "#7f1d1d" : "#374151",
          color: "white",
          opacity: res.list.length ? 1 : 0.6
        },
        onClick: () => finishImport(true)
      }, "Replace all my trades with these"), /*#__PURE__*/React.createElement("button", {
        className: "btn",
        style: {
          background: "#374151",
          color: "white",
          marginLeft: "auto"
        },
        onClick: () => setImp(null)
      }, "Cancel"))));
    })(), sellTarget && /*#__PURE__*/React.createElement("div", {
      style: {
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.75)",
        zIndex: 200,
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #dc2626",
        borderRadius: 12,
        padding: 24,
        width: 400,
        maxWidth: "90vw"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 16,
        fontWeight: 700,
        color: "#f87171",
        marginBottom: 4
      }
    }, "Sell Shares"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 16
      }
    }, sellTarget.ticker, " \u2014 currently hold ", sellTarget.shares, " shares @ ", fmt$(sellTarget.costBasis), " cost basis"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "# of Shares to Sell"), /*#__PURE__*/React.createElement("input", {
      type: "number",
      className: "inp",
      max: sellTarget.shares,
      value: sellForm.sharesToSell,
      onChange: e => setSellForm(f => ({
        ...f,
        sharesToSell: e.target.value
      }))
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Sold Date"), /*#__PURE__*/React.createElement("input", {
      type: "date",
      className: "inp",
      value: sellForm.soldDate,
      onChange: e => setSellForm(f => ({
        ...f,
        soldDate: e.target.value
      }))
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Sold Price ($/share)"), /*#__PURE__*/React.createElement("input", {
      type: "number",
      step: "0.01",
      className: "inp",
      placeholder: "0.00",
      value: sellForm.soldPrice,
      onChange: e => setSellForm(f => ({
        ...f,
        soldPrice: e.target.value
      }))
    }))), sellForm.sharesToSell && sellForm.soldPrice && (() => {
      const qty = parseFloat(sellForm.sharesToSell) || 0,
        sp = parseFloat(sellForm.soldPrice) || 0,
        cb = parseFloat(sellTarget.costBasis) || 0;
      const remaining = (parseFloat(sellTarget.shares) || 0) - qty;
      const realizedGL = (sp - cb) * qty;
      return /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 12,
          padding: 10,
          background: "#1b1e29",
          borderRadius: 8,
          fontSize: 13
        }
      }, /*#__PURE__*/React.createElement("div", null, "Realized Gain/Loss: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: realizedGL >= 0 ? "#4ade80" : "#f87171"
        }
      }, fmtPL(realizedGL))), /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 4,
          color: "#94a3b8"
        }
      }, "Remaining Held: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#e2e8f0"
        }
      }, remaining), " shares", remaining <= 0 && /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#fbbf24"
        }
      }, " (full position closed)")));
    })(), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        marginTop: 16
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#dc2626",
        color: "white"
      },
      onClick: handleSell
    }, "Confirm Sale"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "white"
      },
      onClick: () => setSellTarget(null)
    }, "Cancel")))), buyTarget && /*#__PURE__*/React.createElement("div", {
      style: {
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.75)",
        zIndex: 200,
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#262a3d",
        border: "1px solid #0d9488",
        borderRadius: 12,
        padding: 24,
        width: 400,
        maxWidth: "90vw"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 16,
        fontWeight: 700,
        color: "#2dd4bf",
        marginBottom: 4
      }
    }, "Buy More Shares"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 16
      }
    }, buyTarget.ticker, " \u2014 currently hold ", buyTarget.shares, " shares @ ", fmt$(buyTarget.costBasis), " avg cost"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "# of Shares Purchased"), /*#__PURE__*/React.createElement("input", {
      type: "number",
      className: "inp",
      value: buyForm.sharesToBuy,
      onChange: e => setBuyForm(f => ({
        ...f,
        sharesToBuy: e.target.value
      }))
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Purchase Date"), /*#__PURE__*/React.createElement("input", {
      type: "date",
      className: "inp",
      value: buyForm.purchaseDate,
      onChange: e => setBuyForm(f => ({
        ...f,
        purchaseDate: e.target.value
      }))
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "#94a3b8",
        marginBottom: 4
      }
    }, "Cost Basis for New Shares ($/share)"), /*#__PURE__*/React.createElement("input", {
      type: "number",
      step: "0.01",
      className: "inp",
      placeholder: "0.00",
      value: buyForm.newCostBasis,
      onChange: e => setBuyForm(f => ({
        ...f,
        newCostBasis: e.target.value
      }))
    }))), buyForm.sharesToBuy && buyForm.newCostBasis && (() => {
      const newQty = parseFloat(buyForm.sharesToBuy) || 0,
        newPrice = parseFloat(buyForm.newCostBasis) || 0;
      const existQty = parseFloat(buyTarget.shares) || 0,
        existCB = parseFloat(buyTarget.costBasis) || 0;
      const totalQty = existQty + newQty;
      const avgCB = totalQty > 0 ? (existQty * existCB + newQty * newPrice) / totalQty : 0;
      return /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 12,
          padding: 10,
          background: "#1b1e29",
          borderRadius: 8,
          fontSize: 13
        }
      }, /*#__PURE__*/React.createElement("div", null, "New Total Shares: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#e2e8f0"
        }
      }, totalQty)), /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 4
        }
      }, "New Average Cost Basis: ", /*#__PURE__*/React.createElement("b", {
        style: {
          color: "#2dd4bf"
        }
      }, fmt$(avgCB))));
    })(), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        marginTop: 16
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#0d9488",
        color: "white"
      },
      onClick: handleBuy
    }, "Confirm Purchase"), /*#__PURE__*/React.createElement("button", {
      className: "btn",
      style: {
        background: "#374151",
        color: "white"
      },
      onClick: () => setBuyTarget(null)
    }, "Cancel")))), quoteModalTicker && /*#__PURE__*/React.createElement("div", {
      style: {
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.75)",
        zIndex: 200,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 16
      },
      onClick: () => setQuoteModalTicker(null)
    }, /*#__PURE__*/React.createElement("div", {
      onClick: e => e.stopPropagation(),
      style: {
        background: "#262a3d",
        border: "1px solid #2d3748",
        borderRadius: 12,
        padding: 20,
        width: 700,
        maxWidth: "95vw",
        maxHeight: "90vh",
        overflowY: "auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 18,
        fontWeight: 700,
        color: "#60a5fa"
      }
    }, quoteModalTicker), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 10,
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement("a", {
      href: `https://finance.yahoo.com/quote/${quoteModalTicker}`,
      target: "_blank",
      rel: "noopener noreferrer",
      style: {
        fontSize: 13,
        color: "#94a3b8",
        textDecoration: "none"
      }
    }, "Open in Yahoo Finance \u2197"), /*#__PURE__*/React.createElement("button", {
      onClick: () => setQuoteModalTicker(null),
      style: {
        background: "#374151",
        color: "white",
        border: "none",
        borderRadius: 6,
        width: 28,
        height: 28,
        cursor: "pointer",
        fontSize: 16
      }
    }, "\u2715"))), /*#__PURE__*/React.createElement("div", {
      ref: chartContainerRef,
      className: "tradingview-widget-container",
      style: {
        minHeight: 480
      }
    }))))
  );
}
ReactDOM.createRoot(document.getElementById("root")).render( /*#__PURE__*/React.createElement(App, null));