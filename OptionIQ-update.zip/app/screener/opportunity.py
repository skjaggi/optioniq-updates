"""
opportunity.py
--------------
The Opportunity Screener's second layer: the parts that decide which of the
contracts options_screener finds are actually worth selling, and in what order.

  * IV history   - a small local database of each symbol's 30-day at-the-money
                   implied volatility, one row per trading day. Free data has
                   no IV history, so the app builds its own; IV Rank switches
                   on once 60 days are recorded.
  * IV / HV      - implied volatility against the stock's own 20-day realised
                   volatility. Works from day one (it only needs price bars).
  * Score        - 0-100: Edge 35%, Cushion 25%, Return 25%, Liquidity 15%,
                   plus a few adjustments. Every part is returned so the app
                   can show where a score came from.
  * Rolls        - for open short options under pressure, the same-ticker
                   rolls out 1-4 weeks, ranked by credit per extra day.

Nothing here is advice; it is arithmetic on delayed public quotes.
"""

from __future__ import annotations

import contextlib
import math
import os
import sqlite3
import threading
import time
from datetime import date, datetime, timedelta, timezone

import numpy as np
import pandas as pd

FEE_PER_CONTRACT = 0.67

# ----------------------------------------------------------------------------
# Small helpers
# ----------------------------------------------------------------------------


def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    if v is None or not np.isfinite(v):
        return lo
    return max(lo, min(hi, float(v)))


def _f(x) -> float:
    try:
        v = float(x)
        return v if np.isfinite(v) else np.nan
    except (TypeError, ValueError):
        return np.nan


def _osc():
    import options_screener
    return options_screener


# ----------------------------------------------------------------------------
# US market clock, without a time-zone database (Windows' embedded Python
# ships without one). Eastern time is UTC-5, or UTC-4 from the second Sunday
# of March to the first Sunday of November.
# ----------------------------------------------------------------------------


def _nth_sunday(year: int, month: int, n: int) -> date:
    d = date(year, month, 1)
    d += timedelta(days=(6 - d.weekday()) % 7)
    return d + timedelta(weeks=n - 1)


def eastern_now(now_utc: datetime | None = None) -> datetime:
    now_utc = now_utc or datetime.now(timezone.utc)
    if now_utc.tzinfo is None:
        now_utc = now_utc.replace(tzinfo=timezone.utc)
    y = now_utc.year
    # Changes happen at 2am local, i.e. 7:00 UTC in March and 6:00 UTC in November.
    dst_start = datetime.combine(_nth_sunday(y, 3, 2), datetime.min.time(), timezone.utc) + timedelta(hours=7)
    dst_end = datetime.combine(_nth_sunday(y, 11, 1), datetime.min.time(), timezone.utc) + timedelta(hours=6)
    offset = 4 if dst_start <= now_utc < dst_end else 5
    return (now_utc - timedelta(hours=offset)).replace(tzinfo=None)


def _prev_weekday(d: date) -> date:
    d -= timedelta(days=1)
    while d.weekday() >= 5:
        d -= timedelta(days=1)
    return d


def market_session(now_et: datetime | None = None) -> tuple[date, bool]:
    """(session date the quotes belong to, whether that session has closed).

    After 4:15pm, overnight and at weekends the quotes are the last close, so
    the reading is final for that session. During the day it is a provisional
    reading for today, replaced by later ones and finalised after the close.
    """
    now_et = now_et or eastern_now()
    d, t = now_et.date(), now_et.time()
    if d.weekday() >= 5:
        return _prev_weekday(d + timedelta(days=1)), True
    if t < datetime.strptime("09:30", "%H:%M").time():
        return _prev_weekday(d), True
    if t >= datetime.strptime("16:15", "%H:%M").time():
        return d, True
    return d, False


# ----------------------------------------------------------------------------
# IV history (iv_history.sqlite)
# ----------------------------------------------------------------------------


def default_db_path() -> str:
    return os.environ.get("OPTIONIQ_IV_DB") or os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "iv_history.sqlite")


class IVHistory:
    """One row per symbol per trading day: 30-day ATM IV and the close."""

    def __init__(self, path: str | None = None):
        self.path = path or default_db_path()
        self._lock = threading.Lock()
        d = os.path.dirname(self.path)
        if d:
            os.makedirs(d, exist_ok=True)
        with self._conn() as c:
            c.execute("CREATE TABLE IF NOT EXISTS iv (symbol TEXT, date TEXT, iv30 REAL,"
                      " close REAL, final INTEGER, PRIMARY KEY (symbol, date))")
            c.execute("CREATE TABLE IF NOT EXISTS symbols (symbol TEXT PRIMARY KEY, last_seen TEXT)")

    @contextlib.contextmanager
    def _conn(self):
        """Commit and close after each use; nothing holds the file open."""
        c = sqlite3.connect(self.path, timeout=10)
        try:
            with c:
                yield c
        finally:
            c.close()

    def record(self, symbol: str, day: date, iv30: float, close: float, final: bool) -> bool:
        """Save a reading. A final reading is never overwritten."""
        if not np.isfinite(iv30) or iv30 <= 0:
            return False
        with self._lock, self._conn() as c:
            row = c.execute("SELECT final FROM iv WHERE symbol=? AND date=?",
                            (symbol, day.isoformat())).fetchone()
            if row and row[0]:
                return False
            c.execute("INSERT OR REPLACE INTO iv VALUES (?,?,?,?,?)",
                      (symbol, day.isoformat(), float(iv30),
                       float(close) if np.isfinite(close) else None, int(bool(final))))
        return True

    def has(self, symbol: str, day: date, final_only: bool) -> bool:
        with self._conn() as c:
            row = c.execute("SELECT final FROM iv WHERE symbol=? AND date=?",
                            (symbol, day.isoformat())).fetchone()
        return bool(row) and (bool(row[0]) or not final_only)

    def touch(self, symbols, day: date | None = None) -> None:
        """Remember symbols the person screens or holds, so they get recorded."""
        day = (day or date.today()).isoformat()
        rows = [(str(s).upper(), day) for s in symbols if str(s).strip()]
        if not rows:
            return
        with self._lock, self._conn() as c:
            c.executemany("INSERT OR REPLACE INTO symbols VALUES (?,?)", rows)

    def recent_symbols(self, days: int = 30) -> list[str]:
        cutoff = (date.today() - timedelta(days=days)).isoformat()
        with self._conn() as c:
            return [r[0] for r in c.execute(
                "SELECT symbol FROM symbols WHERE last_seen>=? ORDER BY symbol", (cutoff,))]

    def series(self, symbol: str, limit: int = 252) -> list[float]:
        with self._conn() as c:
            rows = c.execute("SELECT iv30 FROM iv WHERE symbol=? ORDER BY date DESC LIMIT ?",
                             (symbol, limit)).fetchall()
        return [r[0] for r in rows if r[0] is not None]

    def rank(self, symbol: str, current: float) -> tuple[float | None, int]:
        """(IV Rank 0-100 over up to a year, days recorded). Rank is None
        until there are at least 10 days; under 60 it is shown as partial and
        left out of the score and the filter."""
        hist = self.series(symbol)
        n = len(hist)
        if n < 10 or not np.isfinite(current):
            return None, n
        lo, hi = min(hist + [current]), max(hist + [current])
        if hi - lo <= 1e-9:
            return 50.0, n
        return round((current - lo) / (hi - lo) * 100.0, 1), n

    def days(self, symbol: str) -> int:
        with self._conn() as c:
            return c.execute("SELECT COUNT(*) FROM iv WHERE symbol=?", (symbol,)).fetchone()[0]


IVR_FULL_DAYS = 60
_DB: IVHistory | None = None
_DB_LOCK = threading.Lock()


def db() -> IVHistory | None:
    global _DB
    with _DB_LOCK:
        if _DB is None:
            try:
                _DB = IVHistory()
            except Exception:
                return None
        return _DB


# ----------------------------------------------------------------------------
# Daily bars: realised volatility and support/resistance, once per symbol a day
# ----------------------------------------------------------------------------

_BARS: dict = {}
_BARS_LOCK = threading.Lock()


def daily_bars(ticker: str) -> pd.DataFrame | None:
    today = date.today()
    with _BARS_LOCK:
        hit = _BARS.get(ticker)
        if hit and hit[0] == today:
            return hit[1]
    osc = _osc()
    if osc.yf is None:
        return None
    try:
        df = osc._paced(lambda: osc.yf.Ticker(ticker).history(period="1y", auto_adjust=False))
    except Exception:
        return None
    if df is None or len(df) == 0:
        df = None
    with _BARS_LOCK:
        _BARS[ticker] = (today, df)
    return df


def hv20(bars) -> float:
    """20-day realised volatility, annualised, as a fraction."""
    if bars is None or "Close" not in getattr(bars, "columns", []):
        return np.nan
    c = pd.to_numeric(bars["Close"], errors="coerce").dropna()
    if len(c) < 21:
        return np.nan
    r = np.log(c / c.shift(1)).dropna().iloc[-20:]
    v = float(r.std(ddof=1)) * math.sqrt(252.0)
    return v if np.isfinite(v) and v > 0 else np.nan


def strong_levels(bars, min_touches: int = 2) -> list[dict]:
    """Price levels the stock has turned at two or more times in the past year."""
    if bars is None or len(bars) < 30:
        return []
    osc = _osc()
    highs = pd.to_numeric(bars["High"], errors="coerce").dropna()
    lows = pd.to_numeric(bars["Low"], errors="coerce").dropna()
    if len(highs) < 30 or len(lows) < 30:
        return []
    ph, pl = osc._swing_pivots(highs.values, lows.values)
    return [c for c in osc._cluster_levels(ph + pl) if c["touches"] >= min_touches]


def level_beyond(levels: list[dict], spot: float, strike: float, side: str) -> dict | None:
    """The strongest level between the price and the strike: for a put, a
    support the strike sits at or below; for a call, a resistance at or below
    the strike. Price has to break through it first."""
    if side == "put":
        cands = [c for c in levels if strike <= c["level"] * 1.005 and c["level"] < spot]
    else:
        cands = [c for c in levels if strike >= c["level"] * 0.995 and c["level"] > spot]
    if not cands:
        return None
    return max(cands, key=lambda c: (c["touches"], -abs(c["level"] - strike)))


# ----------------------------------------------------------------------------
# 30-day at-the-money IV
# ----------------------------------------------------------------------------

_IV30: dict = {}
_IV30_LOCK = threading.Lock()


def _atm_iv(calls, puts, spot: float, t_years: float, rate: float, q: float) -> float:
    """Average of the call and put IV at the strike nearest the price."""
    osc = _osc()
    vals = []
    for df, side in ((calls, "call"), (puts, "put")):
        if df is None or len(df) == 0:
            continue
        d = df.copy()
        d["strike"] = pd.to_numeric(d["strike"], errors="coerce")
        d = d.dropna(subset=["strike"])
        if d.empty:
            continue
        r = d.iloc[(d["strike"] - spot).abs().argsort()].iloc[0]
        iv = _f(r.get("impliedVolatility"))
        bid, ask = _f(r.get("bid")), _f(r.get("ask"))
        if np.isfinite(bid) and np.isfinite(ask) and bid > 0 and ask > 0:
            solved = osc.implied_vol_bisect((bid + ask) / 2.0, spot, float(r["strike"]),
                                            t_years, rate, q, side)
            if np.isfinite(solved) and 0.01 < solved < 5.0:
                iv = solved
        if np.isfinite(iv) and 0.01 < iv < 5.0:
            vals.append(iv)
    return float(np.mean(vals)) if vals else np.nan


def interpolate_iv30(points: list[tuple[float, float]]) -> float:
    """points = [(days, iv), ...] from the expiries either side of 30 days.
    Interpolates in total variance (iv^2 * t), the usual way to blend terms."""
    pts = sorted((d, v) for d, v in points if d > 0 and np.isfinite(v) and v > 0)
    if not pts:
        return np.nan
    if len(pts) == 1:
        return pts[0][1]
    below = [p for p in pts if p[0] <= 30]
    above = [p for p in pts if p[0] > 30]
    if below and above:
        (d1, v1), (d2, v2) = below[-1], above[0]
    else:
        (d1, v1), (d2, v2) = (pts[-2], pts[-1]) if below else (pts[0], pts[1])
    w1, w2 = v1 * v1 * d1, v2 * v2 * d2
    w30 = w1 + (w2 - w1) * (30.0 - d1) / (d2 - d1)
    if w30 <= 0:
        return pts[0][1] if abs(pts[0][0] - 30) < abs(pts[-1][0] - 30) else pts[-1][1]
    return math.sqrt(w30 / 30.0)


def atm_iv30(ticker: str, spot: float, rate: float, q: float = 0.0,
             expiries: list | None = None, chains: dict | None = None,
             today: date | None = None) -> float:
    """30-day ATM IV for one symbol (cached for the day). `chains` lets the
    caller pass chains it already fetched, keyed by expiry."""
    today = today or date.today()
    with _IV30_LOCK:
        hit = _IV30.get(ticker)
        if hit and hit[0] == today:
            return hit[1]
    osc = _osc()
    try:
        if expiries is None:
            expiries = list(osc._paced(lambda: osc.yf.Ticker(ticker).options) or [])
    except Exception:
        return np.nan
    dated = []
    for e in expiries:
        try:
            dte = (datetime.strptime(e, "%Y-%m-%d").date() - today).days
        except ValueError:
            continue
        if dte >= 3:
            dated.append((dte, e))
    if not dated or not np.isfinite(spot):
        return np.nan
    below = [x for x in dated if x[0] <= 30]
    above = [x for x in dated if x[0] > 30]
    pick = ([below[-1]] if below else []) + ([above[0]] if above else [])
    points = []
    for dte, e in pick:
        try:
            calls, puts = (chains or {}).get(e) or osc.fetch_chain(ticker, e)
        except Exception:
            continue
        points.append((dte, _atm_iv(calls, puts, spot, dte / 365.0, rate, q)))
    iv = interpolate_iv30(points)
    with _IV30_LOCK:
        _IV30[ticker] = (today, iv)
    return iv


def record_symbol(ticker: str, rate: float, store: IVHistory | None = None,
                  now_et: datetime | None = None) -> float:
    """Measure and save today's reading for one symbol (the recorder's step)."""
    store = store or db()
    osc = _osc()
    snap = osc.fetch_ticker_snapshot(ticker, want_earnings=False)
    if snap.error or not np.isfinite(snap.spot):
        return np.nan
    iv = atm_iv30(ticker, snap.spot, rate, snap.div_yield)
    if store is not None and np.isfinite(iv):
        day, final = market_session(now_et)
        store.record(ticker, day, iv, snap.spot, final)
    return iv


def note_reading(ticker: str, iv30: float, spot: float) -> None:
    """Save a reading taken during a screen, so screening also builds history."""
    store = db()
    if store is None or not np.isfinite(iv30):
        return
    try:
        day, final = market_session()
        store.record(ticker, day, iv30, spot, final)
        store.touch([ticker])
    except Exception:
        pass


class Recorder:
    """Background job: after each check, every symbol the person uses (plus
    the S&P 500 list) gets one reading per trading day. It steps aside while a
    screen, scan or analysis is running, so it never slows the app down."""

    def __init__(self, busy, log=print, interval: float = 1800.0, gap: float = 1.0):
        self.busy, self.log, self.interval, self.gap = busy, log, interval, gap
        self.stop = threading.Event()

    def universe(self) -> list[str]:
        store = db()
        syms = list(store.recent_symbols()) if store else []
        try:
            syms += [s for s, _ in _osc()._sp500_from_cache()]
        except Exception:
            pass
        return list(dict.fromkeys(s for s in syms if s))

    def run_once(self) -> int:
        store = db()
        if store is None:
            return 0
        day, final = market_session()
        todo = [s for s in self.universe() if not store.has(s, day, final_only=final)]
        if not todo:
            return 0
        osc = _osc()
        rate = osc.get_risk_free_rate()
        saved = 0
        for s in todo:
            if self.stop.is_set() or self.busy():
                break
            try:
                if np.isfinite(record_symbol(s, rate, store)):
                    saved += 1
            except Exception:
                pass
            time.sleep(self.gap)
        if saved:
            self.log(f"IV history: saved {saved} reading(s) for {day.isoformat()}"
                     + ("" if final else " (provisional until the close)"))
        return saved

    def loop(self) -> None:
        time.sleep(120)   # let the app finish starting first
        while not self.stop.is_set():
            try:
                if not self.busy():
                    self.run_once()
            except Exception as exc:
                self.log(f"IV history: {exc}")
            self.stop.wait(self.interval)

    def start(self) -> None:
        threading.Thread(target=self.loop, daemon=True).start()


# ----------------------------------------------------------------------------
# Score
# ----------------------------------------------------------------------------

def ivhv_score(ratio: float) -> float:
    """IV/HV of 0.8 or less scores 0, 1.5 or more scores 100."""
    if not np.isfinite(ratio):
        return np.nan
    return _clamp((ratio - 0.8) / 0.7 * 100.0)


def cushion_moves(spot: float, strike: float, iv: float, dte: int) -> float:
    """How many expected moves (1 standard deviation to expiry) away the strike is."""
    if not all(np.isfinite(x) for x in (spot, strike, iv)) or spot <= 0 or iv <= 0:
        return np.nan
    sd = spot * iv * math.sqrt(max(dte, 1) / 365.0)
    return abs(spot - strike) / sd if sd > 0 else np.nan


def score_contract(*, ivr: float | None, ivr_days: int, ivhv: float, cushion: float,
                   beyond_level: bool, net_annualized_pct: float, spread_pct: float | None,
                   oi: float, earnings_inside: bool = False, concentrated: bool = False,
                   verdict: str = "") -> dict:
    """The 0-100 Score and every part of it."""
    hv_part = ivhv_score(ivhv)
    ivr_used = ivr if (ivr is not None and ivr_days >= IVR_FULL_DAYS) else None
    if ivr_used is not None and np.isfinite(hv_part):
        edge = 0.6 * ivr_used + 0.4 * hv_part
    elif ivr_used is not None:
        edge = ivr_used
    elif np.isfinite(hv_part):
        edge = hv_part          # until IV Rank has 60 days, IV/HV carries Edge alone
    else:
        edge = 50.0             # nothing to go on: neutral
    edge = _clamp(edge)

    cush = _clamp(cushion / 1.5 * 100.0) if np.isfinite(cushion) else 0.0
    if beyond_level:
        cush = _clamp(cush + 20.0)

    ret = _clamp(net_annualized_pct / 60.0 * 100.0)

    if spread_pct is None or not np.isfinite(spread_pct):
        spread_part = 50.0
    else:
        spread_part = _clamp((15.0 - spread_pct) / 15.0 * 100.0)
    oi_part = _clamp(math.log10(oi) / 3.0 * 100.0) if oi and oi > 0 else 0.0
    liq = 0.5 * spread_part + 0.5 * oi_part

    adj = []
    if earnings_inside:
        adj.append(["Earnings before expiry", -15])
    if concentrated:
        adj.append(["Sector over half your puts", -10])
    if verdict == "TRIM":
        adj.append(["Analysis says TRIM", -10])
    elif verdict == "BUY":
        adj.append(["Analysis says BUY", 5])

    total = 0.35 * edge + 0.25 * cush + 0.25 * ret + 0.15 * liq + sum(a[1] for a in adj)
    return {
        "score": int(round(_clamp(total))),
        "edge": round(edge), "cushion": round(cush), "ret": round(ret), "liq": round(liq),
        "adj": adj,
        "ivrUsed": ivr_used is not None,
    }


# ----------------------------------------------------------------------------
# Applying it to the screener's rows
# ----------------------------------------------------------------------------

def _sector_share(ctx: dict, sector: str, add_notional: float) -> float | None:
    """Share of short-put money in this sector if the trade were added.
    None when there are no open puts yet (one trade is always 100%)."""
    puts = ctx.get("openPuts") or []
    if not puts or not sector:
        return None
    sectors = ctx.get("sectors") or {}
    total = same = 0.0
    for p in puts:
        n = _f(p.get("strike")) * 100.0 * _f(p.get("contracts") or 1)
        if not np.isfinite(n):
            continue
        total += n
        if sectors.get(str(p.get("ticker", "")).upper()) == sector:
            same += n
    if total <= 0:
        return None
    return (same + add_notional) / (total + add_notional)


def enrich_rows(snap, rows: list[dict], crit, rate: float, today: date,
                expiries: list | None = None, chains: dict | None = None) -> list[dict]:
    """Add IV/HV, IV Rank, net premium, flags and the Score to one symbol's
    rows, and drop the ones that fail the new filters."""
    if not rows:
        return rows
    ctx = getattr(crit, "context", None) or {}
    fee = getattr(crit, "fee_per_contract", FEE_PER_CONTRACT)

    bars = daily_bars(snap.ticker)
    hv = hv20(bars)
    levels = strong_levels(bars)
    iv30 = atm_iv30(snap.ticker, snap.spot, rate, snap.div_yield,
                    expiries=expiries, chains=chains, today=today)
    if np.isfinite(iv30):
        note_reading(snap.ticker, iv30, snap.spot)
    store = db()
    ivr, ivr_days = (store.rank(snap.ticker, iv30) if store is not None else (None, 0))
    ivhv = iv30 / hv if np.isfinite(iv30) and np.isfinite(hv) and hv > 0 else np.nan

    min_ivhv = getattr(crit, "min_iv_hv", 0.0) or 0.0
    min_ivr = getattr(crit, "min_iv_rank", 0.0) or 0.0
    min_net = getattr(crit, "min_net_premium", 0.0) or 0.0
    if min_ivhv and np.isfinite(ivhv) and ivhv < min_ivhv:
        return []
    # IV Rank filters only once it is reliable; before that the column says
    # "building" and nothing is excluded on it.
    if min_ivr and ivr is not None and ivr_days >= IVR_FULL_DAYS and ivr < min_ivr:
        return []

    ex_div = getattr(snap, "ex_dividend", None)
    verdict = str((ctx.get("verdicts") or {}).get(snap.ticker, "") or "").upper()

    out = []
    for r in rows:
        dte = int(r["DTE"])
        exp_date = datetime.strptime(r["Expiry"], "%Y-%m-%d").date()
        net = r["Mid"] * 100.0 - fee
        if net < min_net:
            continue
        side = "put" if r["Side"] == "PUT" else "call"
        cush = cushion_moves(snap.spot, r["Strike"], r["IV"], dte)
        lvl = level_beyond(levels, snap.spot, r["Strike"], side)
        share = _sector_share(ctx, snap.sector, r["Strike"] * 100.0) if side == "put" else None
        concentrated = bool(share is not None and share > 0.5)
        earn = bool(r.get("Earnings Before Exp"))
        ex_div_flag = bool(side == "call" and ex_div and today <= ex_div <= exp_date)
        parts = score_contract(
            ivr=ivr, ivr_days=ivr_days, ivhv=ivhv, cushion=cush,
            beyond_level=lvl is not None, net_annualized_pct=r["Annualized %"],
            spread_pct=r.get("Spread %"), oi=r.get("OI") or 0,
            earnings_inside=earn, concentrated=concentrated, verdict=verdict)
        parts.update({
            "ivr": ivr, "ivrDays": ivr_days,
            "ivhv": round(ivhv, 2) if np.isfinite(ivhv) else None,
            "iv30": round(iv30 * 100, 1) if np.isfinite(iv30) else None,
            "hv20": round(hv * 100, 1) if np.isfinite(hv) else None,
            "cushionMoves": round(cush, 2) if np.isfinite(cush) else None,
            "level": round(lvl["level"], 2) if lvl else None,
            "levelTouches": lvl["touches"] if lvl else 0,
            "sectorShare": round(share * 100) if share is not None else None,
            "verdict": verdict,
        })
        r.update({
            "Score": parts["score"],
            "Score Parts": parts,
            "IV/HV": parts["ivhv"],
            "HV20 %": parts["hv20"],
            "IV30 %": parts["iv30"],
            "IV Rank": ivr,
            "IVR Days": ivr_days,
            "Net Premium $": round(net, 2),
            "Ex-Div Before Exp": ex_div_flag,
            "Ex-Div Date": ex_div.isoformat() if ex_div else "",
            "Concentration Flag": concentrated,
            "Sector Share %": parts["sectorShare"],
            "S/R": (f"{'below' if side == 'put' else 'above'} {lvl['level']:.2f} ({lvl['touches']}×)"
                    if lvl else ""),
            "Verdict": verdict,
        })
        out.append(r)
    return out


def sort_by_score(rows: list[dict]) -> list[dict]:
    return sorted(rows, key=lambda r: (-(r.get("Score") if r.get("Score") is not None else -1),
                                       -(r.get("Annualized %") or 0)))


# ----------------------------------------------------------------------------
# Rolls
# ----------------------------------------------------------------------------

def _mid(bid, ask, last) -> float:
    bid, ask, last = _f(bid), _f(ask), _f(last)
    if np.isfinite(bid) and np.isfinite(ask) and bid > 0 and ask > 0:
        return (bid + ask) / 2.0
    return last if np.isfinite(last) and last > 0 else np.nan


def _row_at(df, strike: float):
    if df is None or len(df) == 0:
        return None
    d = df.copy()
    d["strike"] = pd.to_numeric(d["strike"], errors="coerce")
    d["gap"] = (d["strike"] - strike).abs()
    d = d.sort_values("gap")
    if not len(d) or d["gap"].iloc[0] > 0.01:
        return None
    return d.iloc[0]


def roll_offers(pos: dict, spot: float, buy_back: float, chains: dict, today: date,
                rate: float, q: float = 0.0, fee: float = FEE_PER_CONTRACT,
                min_oi: int = 10, max_spread: float = 0.35) -> list[dict]:
    """Every roll for one position. `chains` maps later expiry -> (calls, puts).

    Net credit is per contract, after a fee on each leg (buy back + sell).
    New breakeven folds in everything collected on this chain of rolls so far.
    """
    osc = _osc()
    side = "call" if pos["cp"] == "C" else "put"
    k0 = float(pos["strike"])
    exp0 = datetime.strptime(pos["expDate"], "%Y-%m-%d").date()
    chain_prem = _f(pos.get("chainPremium"))
    if not np.isfinite(chain_prem):
        chain_prem = _f(pos.get("sellPremium"))
    cost_basis = _f(pos.get("costBasis"))
    out = []
    for exp, (calls, puts) in chains.items():
        exp_d = datetime.strptime(exp, "%Y-%m-%d").date()
        extra = (exp_d - exp0).days
        dte = (exp_d - today).days
        if extra <= 0 or dte <= 0:
            continue
        df = calls if side == "call" else puts
        if df is None or len(df) == 0:
            continue
        d = df.copy()
        for c in ("strike", "bid", "ask", "lastPrice", "impliedVolatility", "openInterest"):
            d[c] = pd.to_numeric(d[c], errors="coerce") if c in d.columns else np.nan
        iv_ref = _f(d.iloc[(d["strike"] - spot).abs().argsort()].iloc[0]["impliedVolatility"]) if len(d) else np.nan
        if not np.isfinite(iv_ref) or iv_ref <= 0.01:
            iv_ref = 0.35
        em = spot * iv_ref * math.sqrt(dte / 365.0)
        if side == "put":
            d = d[(d["strike"] <= k0 + 1e-9) & (d["strike"] >= k0 - em)]
        else:
            d = d[(d["strike"] >= k0 - 1e-9) & (d["strike"] <= k0 + em)]
            if np.isfinite(cost_basis) and cost_basis > 0:
                d = d[d["strike"] >= cost_basis]
        for _, r in d.iterrows():
            bid, ask = _f(r["bid"]), _f(r["ask"])
            if not (np.isfinite(bid) and bid > 0):
                continue
            mid = _mid(bid, ask, r.get("lastPrice"))
            if not np.isfinite(mid):
                continue
            if np.isfinite(ask) and ask > 0 and (ask - bid) / mid > max_spread:
                continue
            oi = _f(r.get("openInterest"))
            if np.isfinite(oi) and oi < min_oi:
                continue
            k = float(r["strike"])
            net = (mid - buy_back) * 100.0 - 2.0 * fee
            total_prem = chain_prem + mid - buy_back
            if side == "put":
                breakeven = k - total_prem
            else:
                breakeven = cost_basis - total_prem if np.isfinite(cost_basis) else np.nan
            iv = _f(r.get("impliedVolatility"))
            if not np.isfinite(iv) or iv <= 0.01:
                iv = osc.implied_vol_bisect(mid, spot, k, dte / 365.0, rate, q, side)
            g = osc.black_scholes_greeks(spot, k, dte / 365.0, iv, rate, q, side) if np.isfinite(iv) else {"delta": np.nan}
            out.append({
                "expiry": exp, "strike": k, "dte": dte, "extraDays": extra,
                "bid": round(bid, 2), "ask": round(ask, 2) if np.isfinite(ask) else None,
                "mid": round(mid, 2),
                "netCredit": round(net, 2),
                "credit": net > 0,
                "strikeChange": round(k - k0, 2),
                "creditPerDay": round(net / extra, 2),
                "newBreakeven": round(breakeven, 2) if np.isfinite(breakeven) else None,
                "delta": round(g["delta"], 3) if np.isfinite(g.get("delta", np.nan)) else None,
                "oi": int(oi) if np.isfinite(oi) else None,
            })
    out.sort(key=lambda o: -o["creditPerDay"])
    return out


def needs_roll(cp: str, spot: float, strike: float, dte: int, delta: float,
               max_dte: float | None = 5, min_delta: float | None = 0.40,
               itm: bool = True) -> list[str]:
    """Why a position is shown. The person sets the rules: expiring within
    max_dte days, |delta| at min_delta or more, or in the money. A rule set
    to None (or itm=False) is off."""
    why = []
    if max_dte is not None and dte <= max_dte:
        why.append(f"{max(dte, 0)} day(s) left")
    if min_delta is not None and np.isfinite(delta) and abs(delta) >= min_delta:
        why.append(f"delta {abs(delta):.2f}")
    in_money = (spot < strike) if cp == "P" else (spot > strike)
    if itm and np.isfinite(spot) and in_money:
        why.append("in the money")
    return why


def find_rolls(positions: list[dict], rate: float | None = None, today: date | None = None,
               fee: float = FEE_PER_CONTRACT, show_all: bool = False,
               max_dte: float | None = 5, min_delta: float | None = 0.40,
               itm: bool = True) -> dict:
    """positions: [{id, ticker, cp, strike, expDate, contracts, sellPremium,
    chainPremium, costBasis}]. Returns {rows, skipped}."""
    osc = _osc()
    today = today or date.today()
    if rate is None:
        rate = osc.get_risk_free_rate()
    rows, skipped = [], 0
    for p in positions or []:
        tkr = str(p.get("ticker", "")).strip().upper()
        cp = str(p.get("cp", "P")).upper()[:1]
        strike = _f(p.get("strike"))
        try:
            exp0 = datetime.strptime(str(p.get("expDate", ""))[:10], "%Y-%m-%d").date()
        except ValueError:
            continue
        if not tkr or not np.isfinite(strike) or exp0 < today:
            continue
        rec = {"id": p.get("id"), "ticker": tkr, "cp": cp, "strike": strike,
               "expDate": exp0.isoformat(), "contracts": int(_f(p.get("contracts")) or 1),
               "sellPremium": _f(p.get("sellPremium")), "error": ""}
        snap = osc.fetch_ticker_snapshot(tkr, want_earnings=False)
        spot = snap.spot
        dte0 = (exp0 - today).days
        try:
            expiries = list(osc._paced(lambda: osc.yf.Ticker(tkr).options) or [])
            calls0, puts0 = osc.fetch_chain(tkr, exp0.isoformat())
        except Exception as exc:
            rec["error"] = f"couldn't read the option chain ({exc})"
            rows.append(rec)
            continue
        cur = _row_at(calls0 if cp == "C" else puts0, strike)
        if cur is None:
            rec["error"] = "this strike isn't listed any more"
            rows.append(rec)
            continue
        buy_back = _mid(cur.get("bid"), cur.get("ask"), cur.get("lastPrice"))
        side = "call" if cp == "C" else "put"
        iv = _f(cur.get("impliedVolatility"))
        if (not np.isfinite(iv) or iv <= 0.01) and np.isfinite(buy_back):
            iv = osc.implied_vol_bisect(buy_back, spot, strike, max(dte0, 1) / 365.0, rate, snap.div_yield, side)
        delta = (osc.black_scholes_greeks(spot, strike, max(dte0, 1) / 365.0, iv, rate, snap.div_yield, side)["delta"]
                 if np.isfinite(iv) and np.isfinite(spot) else np.nan)
        why = needs_roll(cp, spot, strike, dte0, delta, max_dte, min_delta, itm)
        if not why and not show_all:
            skipped += 1
            continue
        chains = {}
        for e in expiries:
            try:
                ed = datetime.strptime(e, "%Y-%m-%d").date()
            except ValueError:
                continue
            if 5 <= (ed - exp0).days <= 30:
                try:
                    chains[e] = osc.fetch_chain(tkr, e)
                except Exception:
                    continue
        p2 = dict(p, cp=cp, strike=strike, expDate=exp0.isoformat())
        offers = roll_offers(p2, spot, buy_back, chains, today, rate, snap.div_yield, fee) if np.isfinite(buy_back) else []
        sell = rec["sellPremium"]
        rec.update({
            "spot": round(spot, 2) if np.isfinite(spot) else None,
            "dte": dte0, "why": why,
            "delta": round(delta, 3) if np.isfinite(delta) else None,
            "buyBack": round(buy_back, 2) if np.isfinite(buy_back) else None,
            "closeCost": round(buy_back * 100.0 * rec["contracts"] + fee * rec["contracts"], 2)
                         if np.isfinite(buy_back) else None,
            "captured": round((sell - buy_back) / sell * 100.0, 1)
                        if np.isfinite(sell) and sell > 0 and np.isfinite(buy_back) else None,
            "offers": [o for o in offers if o["credit"]][:8] + [o for o in offers if not o["credit"]][:4],
        })
        rows.append(rec)
    return {"rows": rows, "skipped": skipped}
