#!/usr/bin/env python3
"""
Options Trade Logger — Screener Service
---------------------------------------
A small local web service that fetches option chains and screens them, so the
Options Trade Logger HTML app can run a screen from inside the browser.

Why this exists: browsers cannot fetch option chains directly. Yahoo blocks
cross-origin requests, and Finnhub's option-chain endpoint is paid-tier only.
So the chain fetching happens here, in Python, exactly like Options_Updater
already does its work outside the browser.

Start it with Start_Screener_Service.bat (shows a console, so nothing can fail
invisibly) or by double-clicking this file. Leave it running while you use the
Screener tab. It listens only on 127.0.0.1.

Endpoints
  GET  /health   -> {ok, version, engine}
  POST /screen   -> {sides, tickers, holdings, openCalls, criteria} -> {rows, meta}
  POST /verify   -> {tickers} -> {results:[{ticker, ok, name, price, hasOptions}]}
  POST /quotes   -> {contracts:[{ticker,expiry,strike,cp}]} -> live prices for open positions
  POST /discover -> start a background S&P scan;  GET /discover/status to poll
  POST /analyze  -> fundamentals + technicals scorecard; GET /analyze/status to poll
  POST /rolls    -> {positions:[...]} -> roll candidates for short options under pressure
  GET  /ivhistory -> how many days of IV history are recorded
"""

from __future__ import annotations

import json
import os
import socket
import sys
import threading
import traceback
import webbrowser
from datetime import datetime

HOST = "127.0.0.1"
PORT = 8765
VERSION = "2.4"
MIN_PY = (3, 8)

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

STATUS = {"busy": False, "last_run": None, "last_rows": 0, "last_error": "",
          "ready": False, "boot_error": ""}

GUI = None
osc = None            # the screener engine, imported after deps are ensured
opp = None            # opportunity.py: Score, IV history, rolls
RECORDER = None


def say(line: str):
    """Log to the window if there is one, otherwise to the console."""
    stamped = f"{datetime.now().strftime('%H:%M:%S')}  {line}"
    if GUI:
        GUI.log(stamped)
    else:
        print(stamped, flush=True)


# ── startup checks ──────────────────────────────────────────────────────────

def check_python() -> str:
    if sys.version_info < MIN_PY:
        return (f"Python {MIN_PY[0]}.{MIN_PY[1]}+ is required. "
                f"This is {sys.version.split()[0]} at {sys.executable}")
    return ""


def check_engine_file() -> str:
    if not os.path.exists(os.path.join(HERE, "options_screener.py")):
        return ("options_screener.py is missing. It must sit in the same folder "
                f"as this file:\n{HERE}")
    return ""


def check_port() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1.0)
    try:
        in_use = s.connect_ex((HOST, PORT)) == 0
    finally:
        s.close()
    if in_use:
        return (f"Port {PORT} is already in use — the service is probably already "
                f"running in another window. Close that one first, or just use it.")
    return ""


def ensure_deps(progress=say) -> str:
    """Install numpy/pandas/yfinance if absent. Returns '' or an error string."""
    need = []
    # lxml is only needed to parse the S&P 500 constituents page. Without it
    # the Discover tab silently falls back to a much smaller universe, so it
    # is worth installing even though nothing else uses it.
    for mod, pkg in (("numpy", "numpy"), ("pandas", "pandas"),
                     ("yfinance", "yfinance"), ("lxml", "lxml")):
        try:
            __import__(mod)
        except ImportError:
            need.append(pkg)

    if not need:
        progress("Dependencies OK (numpy, pandas, yfinance, lxml).")
        return ""

    progress(f"Installing {', '.join(need)} — this takes a minute on first run…")
    import subprocess
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", *need]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    except Exception as exc:
        return f"Could not run pip: {exc}"

    if p.returncode != 0:
        tail = (p.stderr or p.stdout or "").strip().splitlines()[-6:]
        return ("pip failed to install " + ", ".join(need) + ":\n" + "\n".join(tail) +
                f"\n\nTry manually:\n  \"{sys.executable}\" -m pip install {' '.join(need)}")

    still = []
    for mod in ("numpy", "pandas", "yfinance", "lxml"):
        try:
            __import__(mod)
        except ImportError:
            still.append(mod)
    if still:
        return f"Installed, but still cannot import: {', '.join(still)}"

    progress("Dependencies installed.")
    return ""


def load_engine() -> str:
    global osc
    try:
        import options_screener as _osc
        import opportunity as _opp
        osc = _osc
        globals()["opp"] = _opp
        return ""
    except Exception as exc:
        return f"Could not load options_screener.py:\n{exc}"


# ── screening ───────────────────────────────────────────────────────────────

def _num(v, default=None):
    try:
        f = float(v)
        return f if f == f else default          # NaN check
    except (TypeError, ValueError):
        return default


def build_criteria(side: str, c: dict):
    g = c.get
    return osc.Criteria(
        side=side,
        pe_min=_num(g("peMin"), 0.0),
        pe_max=_num(g("peMax"), 100.0),
        allow_missing_pe=bool(g("allowMissingPE", True)),
        price_min=_num(g("priceMin"), 5.0),
        price_max=_num(g("priceMax"), 5000.0),
        market_cap_min=_num(g("marketCapMin"), 0.0),
        dte_min=int(_num(g("dteMin"), 7)),
        dte_max=int(_num(g("dteMax"), 45)),
        iv_min=_num(g("ivMin"), 0.15),
        iv_max=_num(g("ivMax"), 3.0),
        delta_min=_num(g("deltaMin"), 0.10),
        delta_max=_num(g("deltaMax"), 0.35),
        min_open_interest=int(_num(g("minOI"), 50)),
        min_volume=int(_num(g("minVolume"), 0)),
        max_spread_pct=_num(g("maxSpreadPct"), 0.20),
        min_bid=_num(g("minBid"), 0.05),
        min_annualized_yield=_num(g("minAnnualized"), 0.10),
        min_premium=_num(g("minPremium"), 0.10),
        exclude_earnings_before_expiry=bool(g("skipEarnings", False)),
        flag_earnings=bool(g("flagEarnings", True)),
        max_results_per_ticker=int(_num(g("maxPerTicker"), 3)),
        enforce_cost_basis_floor=bool(g("costBasisFloor", True)),
        cost_basis_margin=_num(g("costBasisMargin"), 0.0),
        fee_per_contract=_num(g("feePerContract"), 0.67),
        min_net_premium=_num(g("minNetPremium"), 0.0),
        min_iv_hv=_num(g("minIVHV"), 0.0),
        min_iv_rank=_num(g("minIVRank"), 0.0),
        min_avg_volume=_num(g("minAvgVolumeM"), 0.0) * 1e6,
    )


_SECTORS = {}


def sectors_for(tickers) -> dict:
    """Yahoo sector for each symbol, looked up once a day."""
    today = datetime.now().date()
    out = {}
    for t in dict.fromkeys(str(x).strip().upper() for x in tickers if str(x).strip()):
        hit = _SECTORS.get(t)
        if not hit or hit[0] != today:
            try:
                snap = osc.fetch_ticker_snapshot(t, want_earnings=False)
                if snap.error:
                    continue
                hit = _SECTORS[t] = (today, snap.sector or "")
            except Exception:
                continue
        out[t] = hit[1]
    return out


def screen_context(body: dict) -> dict:
    """What the Score needs from the app: open short puts (for sector
    concentration) and the Analysis verdicts."""
    puts = [p for p in (body.get("openPuts") or []) if p.get("ticker")]
    verdicts = {str(k).upper(): str(v) for k, v in (body.get("verdicts") or {}).items() if v}
    return {"openPuts": puts, "sectors": sectors_for(p["ticker"] for p in puts),
            "verdicts": verdicts}


def remember_symbols(tickers) -> None:
    """Symbols the person screens or holds get a daily IV reading."""
    try:
        store = opp.db()
        if store is not None:
            store.touch(tickers)
    except Exception:
        pass


def run_screen_request(body: dict) -> dict:
    sides = body.get("sides") or ["put"]
    crit_in = body.get("criteria") or {}
    holdings = body.get("holdings") or []
    open_calls = body.get("openCalls") or []

    positions = osc.build_positions(holdings, open_calls)

    put_universe = [str(t).strip().upper() for t in (body.get("tickers") or []) if str(t).strip()]
    call_universe = [t for t, p in positions.items() if p.available_contracts >= 1]

    osc.set_request_rate(_num(crit_in.get("requestsPerSecond"), 8.0))
    osc.reset_rate_stats()
    rate = osc.get_risk_free_rate()
    remember_symbols(put_universe + list(positions))
    context = screen_context(body)
    frames = []
    scanned = 0

    for side in sides:
        universe = put_universe if side == "put" else call_universe
        if not universe:
            continue
        scanned += len(universe)
        say(f"screening {len(universe)} symbols for {side}s…")
        crit = build_criteria(side, crit_in)
        crit.context = context
        df = osc.run_screen(
            universe, crit, rate=rate,
            max_workers=int(_num(crit_in.get("workers"), 8)),
            positions=positions if side == "call" else None,
        )
        if not df.empty:
            frames.append(df)

    if frames:
        import pandas as pd
        out = pd.concat(frames, ignore_index=True)
        key = "Score" if "Score" in out.columns else "Annualized %"
        out = out.sort_values([key, "Annualized %"], ascending=False)
        rows = json.loads(out.to_json(orient="records"))
    else:
        rows = []

    rs = osc.get_rate_stats()
    if rs.get("hits"):
        say(f"screen: WARNING - Yahoo throttled {rs['hits']} request(s); "
            f"{rs.get('gave_up', 0)} gave up. Results may be incomplete.")

    return {
        "ok": True,
        "rows": rows,
        "meta": {
            "scanned": scanned,
            "putUniverse": len(put_universe),
            "callUniverse": len(call_universe),
            "positions": {
                t: {"shares": p.shares, "costBasis": p.cost_basis,
                    "committed": p.committed_contracts,
                    "available": p.available_contracts}
                for t, p in positions.items()
            },
            "riskFreeRate": rate,
            "ranAt": datetime.now().isoformat(timespec="seconds"),
            # Same treatment as the Discover tab: a throttled screen returns
            # nothing, and without this it reads as "your criteria are strict".
            "rate": osc.get_rate_stats(),
        },
    }


# ── HTTP ────────────────────────────────────────────────────────────────────

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer  # noqa: E402


# ── analysis (background job, same shape as discovery) ──────────────────────

ANALYSIS = {
    "running": False, "stop": False, "done": 0, "total": 0, "ticker": "",
    "rows": [], "stats": None, "errors": {}, "error": "",
    "started": None, "finished": None,
}


def analysis_worker(body: dict):
    try:
        tickers = [str(t).strip().upper() for t in (body.get("tickers") or []) if str(t).strip()]
        if not tickers:
            ANALYSIS["error"] = "No tickers to analyse."
            return
        rps = _num((body.get("options") or {}).get("requestsPerSecond"), 10.0)
        workers = int(_num((body.get("options") or {}).get("workers"), 6))
        lookback = str((body.get("options") or {}).get("lookback") or "1y")
        want_value = bool((body.get("options") or {}).get("fairValue", True))
        osc.set_request_rate(rps)
        ANALYSIS.update(total=len(tickers), done=0)
        say(f"analyse: {len(tickers)} symbols, {lookback} history, "
            f"{rps}/sec across {workers} workers"
            + ("" if want_value else ", fair value off"))

        def prog(done, total, tkr):
            ANALYSIS.update(done=done, total=total, ticker=tkr)

        res = osc.analyze_stocks(tickers, lookback=lookback, max_workers=workers,
                                 progress_cb=prog, want_value=want_value,
                                 should_stop=lambda: ANALYSIS["stop"])
        ANALYSIS["rows"] = res["rows"]
        ANALYSIS["stats"] = res["stats"]
        ANALYSIS["errors"] = res["errors"]
        st = res["stats"]
        say(f"analyse: {st['analysed']}/{st['requested']} done"
            + (f", {st['failed']} failed" if st["failed"] else "")
            + (f" (throttled {st['rate']['hits']}x)" if st["rate"].get("hits") else ""))
    except Exception as exc:
        ANALYSIS["error"] = str(exc)
        say(f"analyse ERROR: {exc}")
    finally:
        ANALYSIS["running"] = False
        ANALYSIS["finished"] = datetime.now().isoformat(timespec="seconds")


# ── discovery (long-running, so it runs as a background job) ────────────────

DISCOVER = {
    "running": False, "stop": False, "stage": "", "done": 0, "total": 0,
    "ticker": "", "rows": [], "stats": None, "error": "", "started": None,
    "finished": None,
}


def build_discover_criteria(c: dict):
    g = c.get
    return osc.DiscoverCriteria(
        # stage 1 — the business
        price_min=_num(g("priceMin"), 20.0),
        price_max=_num(g("priceMax"), 600.0),
        market_cap_min=_num(g("marketCapMin"), 5e9),
        pe_min=_num(g("peMin"), 0.0),
        pe_max=_num(g("peMax"), 60.0),
        require_positive_eps=bool(g("positiveEPS", True)),
        profit_margin_min=_num(g("marginMin"), 0.05),
        roe_min=_num(g("roeMin"), 0.10),
        revenue_growth_min=_num(g("revGrowthMin"), 0.0),
        avg_volume_min=_num(g("avgVolumeMin"), 1_000_000),
        allow_missing_metrics=bool(g("allowMissingMetrics", True)),
        # stage 2 — the contracts, same knobs as the Screener tab
        side=str(g("side", "put")),
        dte_min=int(_num(g("dteMin"), 21)),
        dte_max=int(_num(g("dteMax"), 45)),
        delta_min=_num(g("deltaMin"), 0.15),
        delta_max=_num(g("deltaMax"), 0.30),
        iv_min=_num(g("ivMin"), 0.30),
        iv_max=_num(g("ivMax"), 1.50),
        min_open_interest=int(_num(g("minOI"), 500)),
        min_volume=int(_num(g("minVolume"), 0)),
        max_spread_pct=_num(g("maxSpreadPct"), 0.15),
        min_bid=_num(g("minBid"), 0.10),
        min_premium=_num(g("minPremium"), 0.20),
        min_annualized_yield=_num(g("minAnnualized"), 0.15),
        max_results_per_ticker=int(_num(g("maxPerTicker"), 1)),
        max_expiries=int(_num(g("maxExpiries"), 2)),
        exclude_earnings_before_expiry=bool(g("skipEarnings", False)),
        flag_earnings=bool(g("flagEarnings", False)),
        fee_per_contract=_num(g("feePerContract"), 0.67),
        min_net_premium=_num(g("minNetPremium"), 0.0),
        min_iv_hv=_num(g("minIVHV"), 0.0),
        min_iv_rank=_num(g("minIVRank"), 0.0),
    )


def discover_worker(body: dict):
    try:
        cin = body.get("criteria") or {}
        want_sectors = [str(x).strip() for x in (body.get("sectors") or []) if str(x).strip()]
        sector_map = {}
        skipped_by_sector = 0
        universe = [str(t).strip().upper() for t in (body.get("tickers") or []) if str(t).strip()]
        source = "your list"
        if not universe:
            # Reports which of the four lookup paths actually worked, so a
            # partial scan can never be mistaken for the full index.
            universe, sector_map, source = osc.get_sp500_universe()
            say(f"discover: universe = {source} ({len(universe)} symbols)")
            if len(universe) <= 400:
                say("discover: WARNING - this is NOT the full S&P 500")

            if want_sectors:
                if not any(sector_map.values()):
                    say("discover: sector filter ignored — the constituent list "
                        "came without sector data")
                    want_sectors = []
                else:
                    keep = set(want_sectors)
                    before = len(universe)
                    universe = [t for t in universe if sector_map.get(t, "") in keep]
                    skipped_by_sector = before - len(universe)
                    say(f"discover: sector filter kept {len(universe)} of {before} "
                        f"({skipped_by_sector} symbols never requested)")
                    source += f" · limited to {', '.join(want_sectors)}"
        crit = build_discover_criteria(cin)
        crit.context = screen_context(body)
        workers = int(_num(cin.get("workers"), 6))
        # Pace outbound requests. Yahoo throttles a 500-symbol sweep hard, and
        # a throttled scan returns nothing while looking like a strict one.
        rps = _num(cin.get("requestsPerSecond"), 12.0)
        osc.set_request_rate(rps)
        say(f"discover: targeting {rps} req/sec across {workers} workers (backs off automatically)")

        if not universe:
            DISCOVER["error"] = (
                "No symbols left to scan. The sector filter excluded every name "
                "in the constituent list — clear it or pick different sectors.")
            say("discover: sector filter left an empty universe")
            return

        DISCOVER.update(total=len(universe), stage="fundamentals", done=0)
        say(f"discover: scanning {len(universe)} symbols…")

        def prog(stage, done, total, tkr):
            DISCOVER.update(stage=stage, done=done, total=total, ticker=tkr)

        res = osc.discover_stocks(
            universe, crit,
            max_workers=workers,
            progress_cb=prog,
            should_stop=lambda: DISCOVER["stop"],
        )
        res["stats"]["universeSource"] = source
        res["stats"]["sectorFilter"] = want_sectors
        res["stats"]["skippedBySector"] = skipped_by_sector
        DISCOVER["rows"] = res["rows"]
        DISCOVER["stats"] = res["stats"]
        s = res["stats"]
        say(f"discover: {s['universe']} scanned -> {s['stage1_pass']} passed fundamentals "
            f"-> {s['stage2_pass']} candidates")
        if s.get("rate_limited"):
            r = s.get("rate") or {}
            say(f"discover: WARNING - Yahoo rate-limited {s['rate_limited']} symbol(s); "
                f"{r.get('retries', 0)} retried, {r.get('gave_up', 0)} gave up. "
                f"Lower 'Requests per second' and try again.")
    except Exception as exc:
        DISCOVER["error"] = str(exc)
        say(f"discover ERROR: {exc}")
        traceback.print_exc() if not GUI else None
    finally:
        DISCOVER["running"] = False
        DISCOVER["stage"] = "done"
        DISCOVER["finished"] = datetime.now().isoformat(timespec="seconds")


def verify_symbols(symbols: list) -> list:
    """
    Resolve each symbol: does it exist, does it have listed options, what is it
    called. Used by the watchlist so a typo is caught when you add it rather
    than silently returning nothing on every future screen.
    """
    # Normalise, drop blanks, de-duplicate, then cap — in that order, so a list
    # of 30 repeats of one symbol costs one lookup rather than filling the cap.
    seen, clean = set(), []
    for raw in symbols or []:
        sym = str(raw or "").strip().upper()
        if not sym or sym in seen:
            continue
        seen.add(sym)
        clean.append(sym)

    out = []
    for sym in clean[:25]:
        rec = {"ticker": sym, "ok": False, "name": "", "price": None,
               "hasOptions": False, "expirations": 0, "error": ""}
        try:
            snap = osc.fetch_ticker_snapshot(sym, want_earnings=False)
            if snap.error:
                rec["error"] = snap.error
            price = None if snap.spot != snap.spot else snap.spot   # NaN check
            if price:
                rec.update(ok=True, name=snap.name or sym, price=round(price, 2))
                rec["sector"] = snap.sector
                rec["pe"] = None if snap.pe != snap.pe else round(snap.pe, 1)
            else:
                rec["error"] = rec["error"] or "No price returned — symbol may not exist."

            if rec["ok"]:
                try:
                    exps = osc.yf.Ticker(sym).options or []
                    rec["expirations"] = len(exps)
                    rec["hasOptions"] = len(exps) > 0
                    if not rec["hasOptions"]:
                        rec["error"] = "Symbol resolves but has no listed options."
                except Exception as exc:
                    rec["error"] = f"Could not read option chain: {exc}"
        except Exception as exc:
            rec["error"] = f"{type(exc).__name__}: {exc}"
        out.append(rec)
    return out


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _cors(self):
        origin = self.headers.get("Origin") or "*"
        self.send_header("Access-Control-Allow-Origin", origin)
        self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        # Chrome's Private Network Access: a page on file:// or http:// counts as
        # a *public* context, so reaching 127.0.0.1 is a private-network request
        # and is refused unless the preflight is answered with this header.
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "600")

    def _send(self, code: int, payload: dict):
        raw = json.dumps(payload, default=str).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self._cors()
        self.end_headers()
        self.wfile.write(raw)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def log_message(self, fmt, *args):
        say(fmt % args)

    def do_GET(self):
        if self.path.startswith("/analyze/status"):
            d = ANALYSIS
            self._send(200, {
                "ok": True, "running": d["running"], "done": d["done"],
                "total": d["total"], "ticker": d["ticker"], "error": d["error"],
                "started": d["started"], "finished": d["finished"],
                "rows": d["rows"] if not d["running"] else [],
                "stats": d["stats"] if not d["running"] else None,
                "errors": d["errors"] if not d["running"] else {},
            })
            return

        if self.path.startswith("/discover/status"):
            d = DISCOVER
            self._send(200, {
                "ok": True, "running": d["running"], "stage": d["stage"],
                "done": d["done"], "total": d["total"], "ticker": d["ticker"],
                "error": d["error"], "started": d["started"], "finished": d["finished"],
                "rows": d["rows"] if not d["running"] else [],
                "stats": d["stats"] if not d["running"] else None,
            })
            return
        if self.path.startswith("/debug/quote"):
            # Raw, unprocessed truth from this machine, openable in a browser
            # tab. Every layer above adds interpretation; this one does not, so
            # it settles "is the feed stale or is the app misreading it".
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            tkr = (q.get("ticker", ["NVDA"])[0] or "NVDA").strip().upper()
            expiry = (q.get("expiry", [""])[0] or "").strip()
            out = {"ok": True, "ticker": tkr}
            try:
                import time as _t
                out["clock"] = {
                    "service_local": datetime.now().isoformat(timespec="seconds"),
                    "utc": datetime.utcnow().isoformat(timespec="seconds"),
                    "tz_offset_hours": round(-_t.timezone / 3600.0, 2),
                }
                out["yfinance"] = getattr(osc.yf, "__version__", "unknown")
            except Exception as exc:
                out["clock_error"] = str(exc)
            try:
                h = osc.yf.Ticker(tkr).history(period="5d", interval="1d",
                                               auto_adjust=False)
                out["daily_bars"] = [
                    {"date": str(ix), "open": round(float(r["Open"]), 4),
                     "high": round(float(r["High"]), 4), "low": round(float(r["Low"]), 4),
                     "close": round(float(r["Close"]), 4),
                     "volume": int(r["Volume"]) if r["Volume"] == r["Volume"] else None}
                    for ix, r in h.iterrows()
                ]
            except Exception as exc:
                out["daily_error"] = f"{type(exc).__name__}: {exc}"
            try:
                # One minute bar tells us instantly whether intraday data is
                # reaching this machine at all.
                m = osc.yf.Ticker(tkr).history(period="1d", interval="1m")
                if m is not None and len(m):
                    out["last_minute_bar"] = {"time": str(m.index[-1]),
                                              "close": round(float(m["Close"].iloc[-1]), 4),
                                              "bars_today": int(len(m))}
                else:
                    out["last_minute_bar"] = "none returned"
                # Closing price of each recent session taken from minute bars.
                # This is where a session missing from the daily array can still
                # be found, so it shows whether the gap is real or only in the
                # daily series.
                m5 = osc.yf.Ticker(tkr).history(period="5d", interval="1m")
                if m5 is not None and len(m5):
                    s = m5["Close"].dropna()
                    seen = {}
                    for ix, v in s.items():
                        seen[ix.date().isoformat()] = round(float(v), 4)
                    out["session_closes_from_minutes"] = seen
            except Exception as exc:
                out["minute_error"] = f"{type(exc).__name__}: {exc}"
            if expiry:
                try:
                    calls, puts = osc.fetch_chain(tkr, expiry)
                    want = None
                    try:
                        want = float(q.get("strike", [""])[0])
                    except Exception:
                        want = None

                    def sample(df, kind):
                        cols = [c for c in ("strike", "lastPrice", "bid", "ask",
                                            "lastTradeDate", "volume", "openInterest")
                                if c in df.columns]
                        # Rows around the strike actually held. Sampling the tail
                        # returns the furthest out-of-the-money strikes, which are
                        # never quoted and tell you nothing about your position.
                        if want is not None and "strike" in df.columns:
                            d = df.assign(_g=(df["strike"] - want).abs()) \
                                  .sort_values("_g").head(5).sort_values("strike")[cols]
                        else:
                            d = df[cols].tail(6)
                        return [{c: (str(r[c]) if c == "lastTradeDate" else
                                     (float(r[c]) if r[c] == r[c] else None))
                                 for c in cols} for _, r in d.iterrows()]
                    out["chain"] = {"expiry": expiry, "calls": sample(calls, "C"),
                                    "puts": sample(puts, "P")}
                except Exception as exc:
                    out["chain_error"] = f"{type(exc).__name__}: {exc}"
            self._send(200, out)
            return
        if self.path.startswith("/ivhistory"):
            store = opp.db() if opp else None
            if store is None:
                self._send(200, {"ok": False, "error": "IV history isn't available"})
                return
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            syms = [s.strip().upper() for s in (q.get("symbols", [""])[0]).split(",") if s.strip()]
            self._send(200, {"ok": True, "path": store.path, "fullDays": opp.IVR_FULL_DAYS,
                             "days": {s: store.days(s) for s in syms[:200]}})
            return
        if self.path.startswith("/health"):
            self._send(200, {"ok": True, "version": VERSION,
                             "engine": "options_screener",
                             "python": sys.version.split()[0],
                             "ready": STATUS["ready"],
                             "busy": STATUS["busy"],
                             "lastRun": STATUS["last_run"],
                             "lastRows": STATUS["last_rows"]})
        else:
            self._send(404, {"ok": False, "error": "not found"})

    def do_POST(self):
        if not (self.path.startswith("/screen") or self.path.startswith("/verify")
                or self.path.startswith("/discover") or self.path.startswith("/quotes")
                or self.path.startswith("/prices") or self.path.startswith("/benchmark")
                or self.path.startswith("/analyze") or self.path.startswith("/rolls")):
            # Read the body anyway, so it isn't mistaken for the next request.
            self.rfile.read(int(self.headers.get("Content-Length") or 0))
            self._send(404, {"ok": False, "error": "not found"})
            return
        if not STATUS["ready"]:
            self._send(503, {"ok": False,
                             "error": STATUS["boot_error"] or "Service is still starting up."})
            return
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}")
        except Exception as exc:
            self._send(400, {"ok": False, "error": f"bad JSON: {exc}"})
            return

        if self.path.startswith("/benchmark"):
            start = str(body.get("start") or "").strip()
            end = str(body.get("end") or "").strip()
            syms = [str(s).strip().upper() for s in (body.get("symbols") or ["SPY", "QQQ"]) if str(s).strip()]
            if not start or not end:
                self._send(400, {"ok": False, "error": "start and end dates are required"})
                return
            osc.set_request_rate(_num((body.get("options") or {}).get("requestsPerSecond"), 8.0))
            try:
                res = osc.benchmark_returns(start, end, syms)
            except Exception as exc:
                say(f"benchmark ERROR: {exc}")
                self._send(500, {"ok": False, "error": str(exc)})
                return
            if isinstance(res, dict) and res.get("error"):
                self._send(200, {"ok": False, "error": res["error"]})
                return
            say(f"benchmark: {', '.join(syms)} {start} to {end}")
            self._send(200, {"ok": True, "start": start, "end": end, "results": res})
            return

        if self.path.startswith("/prices"):
            # Stock quotes through yfinance. The browser's Finnhub path can be
            # served a stale last-close without erroring; this one reports the
            # bar date so staleness is visible rather than inferred.
            tickers = [str(t).strip().upper()
                       for t in (body.get("tickers") or []) if str(t).strip()]
            if not tickers:
                self._send(400, {"ok": False, "error": "No tickers supplied."})
                return
            rps = _num((body.get("options") or {}).get("requestsPerSecond"), 8.0)
            workers = int(_num((body.get("options") or {}).get("workers"), 6))
            osc.set_request_rate(rps)
            osc.reset_rate_stats()
            try:
                res = osc.quote_stocks(tickers, max_workers=workers)
            except Exception as exc:
                say(f"prices ERROR: {exc}")
                self._send(500, {"ok": False, "error": str(exc)})
                return
            say(f"prices: {res['returned']}/{res['requested']} quotes"
                + (f", {len(res['errors'])} failed" if res["errors"] else ""))
            self._send(200, {"ok": True, **res, "rate": osc.get_rate_stats()})
            return

        if self.path.startswith("/analyze/cancel"):
            ANALYSIS["stop"] = True
            say("analyse: cancel requested")
            self._send(200, {"ok": True, "cancelling": True})
            return

        if self.path.startswith("/analyze"):
            if ANALYSIS["running"]:
                self._send(409, {"ok": False, "error": "An analysis is already running."})
                return
            ANALYSIS.update(running=True, stop=False, done=0, total=0, ticker="",
                            rows=[], stats=None, errors={}, error="",
                            started=datetime.now().isoformat(timespec="seconds"),
                            finished=None)
            threading.Thread(target=analysis_worker, args=(body,), daemon=True).start()
            self._send(200, {"ok": True, "started": True})
            return

        if self.path.startswith("/discover/cancel"):
            DISCOVER["stop"] = True
            say("discover: cancel requested")
            self._send(200, {"ok": True, "cancelling": True})
            return

        if self.path.startswith("/discover"):
            if DISCOVER["running"]:
                self._send(409, {"ok": False, "error": "A scan is already running."})
                return
            DISCOVER.update(running=True, stop=False, stage="starting", done=0,
                            total=0, ticker="", rows=[], stats=None, error="",
                            started=datetime.now().isoformat(timespec="seconds"),
                            finished=None)
            threading.Thread(target=discover_worker, args=(body,), daemon=True).start()
            self._send(200, {"ok": True, "started": True})
            return

        if self.path.startswith("/quotes"):
            try:
                osc.set_request_rate(_num((body.get("criteria") or {}).get("requestsPerSecond"), 8.0))
                osc.reset_rate_stats()
                cons = body.get("contracts") or []
                say(f"quotes: pricing {len(cons)} open contract(s)…")
                results = osc.quote_contracts(cons)
                rs = osc.get_rate_stats()
                got = sum(1 for r in results if r.get("last") is not None
                          or r.get("mid") is not None)
                say(f"quotes: {got}/{len(results)} priced"
                    + (f" (throttled {rs['hits']}x)" if rs.get("hits") else ""))
                self._send(200, {"ok": True, "results": results, "rate": rs})
            except Exception as exc:
                say(f"ERROR quotes: {exc}")
                self._send(500, {"ok": False, "error": str(exc)})
            return

        if self.path.startswith("/rolls"):
            STATUS["busy"] = True
            try:
                osc.set_request_rate(_num((body.get("options") or {}).get("requestsPerSecond"), 8.0))
                osc.reset_rate_stats()
                pos = body.get("positions") or []
                remember_symbols(p.get("ticker", "") for p in pos)
                rules = body.get("rules") or {}
                res = opp.find_rolls(pos, fee=_num(body.get("feePerContract"), 0.67),
                                     show_all=bool(body.get("showAll", False)),
                                     max_dte=_num(rules.get("maxDays"), None) if "maxDays" in rules else 5,
                                     min_delta=_num(rules.get("minDelta"), None) if "minDelta" in rules else 0.40,
                                     itm=bool(rules.get("itm", True)))
                say(f"rolls: {len(res['rows'])} position(s) need a look, "
                    f"{res['skipped']} fine for now")
                self._send(200, {"ok": True, **res, "rate": osc.get_rate_stats()})
            except Exception as exc:
                say(f"ERROR rolls: {exc}")
                self._send(500, {"ok": False, "error": str(exc)})
            finally:
                STATUS["busy"] = False
            return

        if self.path.startswith("/verify"):
            try:
                results = verify_symbols(body.get("tickers") or [])
                good = sum(1 for r in results if r["ok"] and r["hasOptions"])
                say(f"verify {len(results)} symbol(s) -> {good} usable")
                self._send(200, {"ok": True, "results": results})
            except Exception as exc:
                say(f"ERROR verify: {exc}")
                self._send(500, {"ok": False, "error": str(exc)})
            return

        STATUS["busy"] = True
        try:
            result = run_screen_request(body)
            STATUS["last_run"] = datetime.now().isoformat(timespec="seconds")
            STATUS["last_rows"] = len(result["rows"])
            STATUS["last_error"] = ""
            say(f"-> {len(result['rows'])} contracts")
            self._send(200, result)
        except Exception as exc:
            STATUS["last_error"] = str(exc)
            say(f"ERROR {exc}")
            self._send(500, {"ok": False, "error": str(exc),
                             "trace": traceback.format_exc()[-1500:]})
        finally:
            STATUS["busy"] = False


def serve():
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()


# ── status window ───────────────────────────────────────────────────────────

class StatusWindow:
    def __init__(self):
        import tkinter as tk
        from tkinter import scrolledtext
        self.tk = tk
        self.root = tk.Tk()
        self.root.title("Options Screener Service")
        self.root.geometry("680x420")
        self.root.configure(bg="#1b1e29")

        tk.Label(self.root, text="🎯 Options Screener Service", bg="#1b1e29",
                 fg="#60a5fa", font=("Segoe UI", 14, "bold")).pack(pady=(12, 2))
        self.status = tk.Label(self.root, text="Starting…", bg="#1b1e29",
                               fg="#fbbf24", font=("Segoe UI", 10))
        self.status.pack(pady=(0, 8))

        self.box = scrolledtext.ScrolledText(
            self.root, bg="#262a3d", fg="#e2e8f0", insertbackground="#e2e8f0",
            font=("Consolas", 9), relief="flat", height=15)
        self.box.pack(fill="both", expand=True, padx=12, pady=(0, 10))

        btns = tk.Frame(self.root, bg="#1b1e29")
        btns.pack(pady=(0, 12))
        for label, cmd, bg, fg in (
            ("Open Logger", self.open_logger, "#2563eb", "white"),
            ("Test connection", self.test_conn, "#0d9488", "white"),
            ("Copy log", self.copy_log, "#374151", "#e2e8f0"),
            ("Quit", self.quit, "#7f1d1d", "#fecaca"),
        ):
            tk.Button(btns, text=label, command=cmd, bg=bg, fg=fg, relief="flat",
                      padx=12, pady=5).pack(side="left", padx=4)

    def set_status(self, text, color="#4ade80"):
        try:
            self.status.config(text=text, fg=color)
        except Exception:
            pass

    def open_logger(self):
        for name in ("options_logger1.html", "options_logger.html.html"):
            p = os.path.join(HERE, name)
            if os.path.exists(p):
                webbrowser.open("file:///" + p.replace("\\", "/"))
                return
        self.log("Could not find options_logger1.html next to this script.")

    def test_conn(self):
        webbrowser.open(f"http://{HOST}:{PORT}/health")
        self.log("Opened /health in your browser — you should see JSON with ok:true.")

    def copy_log(self):
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(self.box.get("1.0", "end"))
            self.log("Log copied to clipboard.")
        except Exception:
            pass

    def log(self, line: str):
        try:
            self.box.insert("end", line + "\n")
            self.box.see("end")
        except Exception:
            pass

    def fatal(self, title: str, detail: str):
        self.set_status("✖ " + title, "#f87171")
        self.log("")
        self.log("=" * 62)
        self.log(title)
        for ln in detail.splitlines():
            self.log("  " + ln)
        self.log("=" * 62)
        try:
            from tkinter import messagebox
            messagebox.showerror("Screener Service — " + title, detail)
        except Exception:
            pass

    def quit(self):
        os._exit(0)

    def run(self, minimized=False):
        self.root.protocol("WM_DELETE_WINDOW", self.quit)
        if minimized:
            # Launched from the one-click launcher: get out of the way, but stay
            # in the taskbar so the log and Quit button are one click away.
            try:
                self.root.iconify()
            except Exception:
                pass
        self.root.mainloop()


# ── boot ────────────────────────────────────────────────────────────────────

def boot(fatal):
    """Run every startup check in order. fatal(title, detail) reports failure."""
    say(f"Python {sys.version.split()[0]}")
    say(f"Folder  {HERE}")

    for check, title in ((check_python, "Python too old"),
                         (check_engine_file, "Engine file missing"),
                         (check_port, "Port in use")):
        err = check()
        if err:
            STATUS["boot_error"] = err
            fatal(title, err)
            return False

    err = ensure_deps()
    if err:
        STATUS["boot_error"] = err
        fatal("Dependency install failed", err)
        return False

    err = load_engine()
    if err:
        STATUS["boot_error"] = err
        fatal("Engine failed to load", err)
        return False

    try:
        threading.Thread(target=serve, daemon=True).start()
    except Exception as exc:
        STATUS["boot_error"] = str(exc)
        fatal("Could not start server", str(exc))
        return False

    STATUS["ready"] = True
    try:
        global RECORDER
        RECORDER = opp.Recorder(
            busy=lambda: STATUS["busy"] or DISCOVER["running"] or ANALYSIS["running"],
            log=say)
        RECORDER.start()
        say(f"IV history: {opp.db().path}")
    except Exception as exc:
        say(f"IV history is off: {exc}")
    say(f"Listening on http://{HOST}:{PORT} — leave this window open.")
    say("Now open the Screener tab in Options Trade Logger and press Run Screen.")
    return True


def main():
    global GUI
    headless = "--headless" in sys.argv or "--console" in sys.argv

    if headless:
        def fatal(title, detail):
            print("\n" + "=" * 62)
            print("ERROR: " + title)
            print(detail)
            print("=" * 62 + "\n")
        if boot(fatal):
            try:
                threading.Event().wait()
            except KeyboardInterrupt:
                print("\nStopped.")
        else:
            input("\nPress Enter to close…")
        return

    try:
        GUI = StatusWindow()
    except Exception as exc:
        print(f"No GUI available ({exc}); running headless.")
        if boot(lambda t, d: print(f"ERROR: {t}\n{d}")):
            threading.Event().wait()
        return

    def start():
        if boot(GUI.fatal):
            GUI.set_status(f"● Running on http://{HOST}:{PORT} — leave this window open")
        else:
            # Something failed: surface the window even if we were told to hide.
            try:
                GUI.root.deiconify()
                GUI.root.lift()
            except Exception:
                pass

    threading.Thread(target=start, daemon=True).start()
    GUI.run(minimized="--minimized" in sys.argv)


if __name__ == "__main__":
    main()
