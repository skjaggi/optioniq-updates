"""Fundamentals for the Watchlist tab (P/E, EPS, margin, debt/equity, beta,
revenue, market cap, sector), looked up live with yfinance, which ships with
the app for the Screener."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor


def _money(v):
    if v is None:
        return None
    for div, unit in ((1e12, "T"), (1e9, "B"), (1e6, "M")):
        if abs(v) >= div:
            return f"${v / div:.2f}{unit}"
    return f"${v:,.0f}"


def _num(v, digits=2):
    try:
        f = float(v)
        return round(f, digits) if f == f else None
    except (TypeError, ValueError):
        return None


def one(ticker: str) -> dict:
    import yfinance as yf  # type: ignore
    info = yf.Ticker(ticker).info or {}
    margin = _num(info.get("profitMargins"), 4)
    return {
        "sym": ticker,
        "name": info.get("shortName") or info.get("longName") or ticker,
        "sector": " / ".join(x for x in (info.get("sector"), info.get("industry")) if x) or "",
        "price": _num(info.get("currentPrice") or info.get("regularMarketPrice")),
        "cap": _money(info.get("marketCap")),
        "pe": _num(info.get("trailingPE"), 1),
        "eps": _num(info.get("trailingEps")),
        "margin": round(margin * 100, 2) if margin is not None else None,
        "de": _num(info.get("debtToEquity")),
        "beta": _num(info.get("beta")),
        "rev": _money(info.get("totalRevenue")),
    }


def lookup(tickers: list) -> dict:
    try:
        import yfinance  # type: ignore  # noqa: F401
    except ImportError:
        return {"ok": False, "error": "The fundamentals data piece isn't installed."}
    clean = [t.strip().upper() for t in tickers if isinstance(t, str) and t.strip()][:150]
    rows, failed = [], []

    def work(t):
        try:
            return one(t)
        except Exception:
            failed.append(t)
            return None
    with ThreadPoolExecutor(max_workers=6) as pool:
        rows = [r for r in pool.map(work, clean) if r]
    return {"ok": True, "rows": rows, "failed": failed}
