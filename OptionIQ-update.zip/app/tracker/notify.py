"""Best-effort desktop notifications for upcoming expiries.

On Windows this shows a toast through Windows PowerShell's built-in
notification API, and on a Mac a notification through AppleScript, so
nothing extra needs installing. Elsewhere, or if it fails, it does nothing:
the in-app reminder banner is the source of truth and always shows.
"""
from __future__ import annotations

import subprocess
import sys

_PS = r"""
$ErrorActionPreference = 'Stop'
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null
$tpl = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
$nodes = $tpl.GetElementsByTagName('text')
$nodes.Item(0).AppendChild($tpl.CreateTextNode($env:PT_TITLE)) > $null
$nodes.Item(1).AppendChild($tpl.CreateTextNode($env:PT_BODY)) > $null
$toast = [Windows.UI.Notifications.ToastNotification]::new($tpl)
$app = '{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe'
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($app).Show($toast)
"""


def _mac_notify(title: str, body: str) -> bool:
    script = ('on run argv\n'
              'display notification (item 2 of argv) with title (item 1 of argv)\n'
              'end run')
    try:
        subprocess.run(["osascript", "-e", script, title[:120], body[:400]],
                       timeout=15, capture_output=True)
        return True
    except Exception:
        return False


def toast(title: str, body: str) -> bool:
    if sys.platform == "darwin":
        return _mac_notify(title, body)
    if sys.platform != "win32":
        return False
    import os
    env = {**os.environ, "PT_TITLE": title[:120], "PT_BODY": body[:400]}
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", _PS],
            env=env, timeout=15, capture_output=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        return True
    except Exception:
        return False


def describe(r: dict) -> str:
    when = "today" if r["dte"] == 0 else ("tomorrow" if r["dte"] == 1 else f"in {r['dte']} days")
    side = "short" if r["side"] == "short" else "long"
    itm = " (ITM)" if r.get("itm") else ""
    strike = f"{r['strike']:g}"
    return f"{r['ticker']} {strike} {r['type']} ({side}) expires {when}{itm}"
