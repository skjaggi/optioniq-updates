"""The Screener's libraries (numpy, pandas, yfinance and friends), fetched once.

They make up two thirds of the app's size, which would put the shareable zip
over email limits. So the zip carries only `addons.json` (exact wheel names
and SHA-256 hashes, written by build_package.py) and the app downloads those
wheels from PyPI the first time it starts, checks each hash, and unpacks them
into its own Python. The trade log works meanwhile; the Screener, Analysis,
Discover and Watchlist tabs start once this is done.
"""
from __future__ import annotations

import hashlib
import importlib
import json
import platform
import sys
import sysconfig
import threading
import urllib.request
import zipfile
from io import BytesIO
from pathlib import Path

MANIFEST = Path(__file__).resolve().parent / "addons.json"
PYPI = "https://pypi.org/pypi/{name}/{version}/json"
# Parts of the wheels the app never uses (kept in step with build_package.py).
SKIP = ("numpy/_core/tests", "pandas/tests", "numpy/f2py", "numpy/typing/tests", "lxml/includes")

state = {"state": "none", "done": 0, "total": 0, "error": ""}
_lock = threading.Lock()


def site_packages() -> Path:
    if sys.platform == "win32":
        return Path(sys.prefix) / "Lib" / "site-packages"
    return Path(sysconfig.get_paths()["purelib"])  # Mac: python/lib/python3.12/site-packages


def wanted() -> list:
    if not MANIFEST.exists():
        return []
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    if "wheels" in data:
        return data["wheels"]
    # The Mac zip lists one set for Apple-chip Macs and one for Intel Macs.
    machine = platform.machine().lower()
    return data["byMachine"].get("arm64" if machine in ("arm64", "aarch64") else "x86_64", [])


def _marker(site: Path) -> Path:
    digest = hashlib.sha256(MANIFEST.read_bytes()).hexdigest()[:16]
    return site / f".optioniq-addons-{digest}"


def needed() -> bool:
    """True when this is a shareable build whose libraries aren't unpacked yet."""
    return bool(wanted()) and not _marker(site_packages()).exists()


def unpack(data: bytes, site: Path) -> None:
    """A wheel is a zip laid out exactly as site-packages expects."""
    with zipfile.ZipFile(BytesIO(data)) as z:
        for m in z.namelist():
            if m.endswith("/") or any(m.startswith(s) for s in SKIP):
                continue
            if ".data/" in m.split("/", 1)[0] + "/":
                continue
            parts = m.split("/")
            if any(p in ("tests", "__pycache__") for p in parts[1:-1]):
                continue
            target = site / m
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(z.read(m))


def _get(url: str, timeout: float = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "OptionIQ"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _wheel_url(w: dict) -> str:
    info = json.loads(_get(PYPI.format(name=w["name"], version=w["version"]), timeout=30))
    for f in info.get("urls", []):
        if f.get("filename") == w["file"]:
            return f["url"]
    raise RuntimeError(f"{w['file']} is no longer on PyPI")


def install(fetch=None) -> bool:
    """Download, check and unpack every wheel in the manifest. Safe to call
    again after a failure: it starts over and only marks success at the end."""
    fetch = fetch or (lambda w: _get(_wheel_url(w), timeout=300))
    wheels = wanted()
    site = site_packages()
    with _lock:
        state.update(state="installing", done=0, total=len(wheels), error="")
    try:
        site.mkdir(parents=True, exist_ok=True)
        for w in wheels:
            data = fetch(w)
            if hashlib.sha256(data).hexdigest() != w["sha256"]:
                raise RuntimeError(f"{w['file']} did not download correctly")
            unpack(data, site)
            with _lock:
                state["done"] += 1
            print(f"Installed {w['file']}")
        _marker(site).write_text("ok", encoding="utf-8")
        importlib.invalidate_caches()
        if str(site) not in sys.path:
            sys.path.append(str(site))
        with _lock:
            state.update(state="ready")
        return True
    except Exception as exc:
        print(f"Screener libraries didn't install: {exc}", file=sys.stderr)
        with _lock:
            state.update(state="failed", error=str(exc))
        return False


def status() -> dict:
    with _lock:
        s = dict(state)
    if s["state"] == "none":
        s["state"] = "installing" if needed() else "ready"
    return s
