"""New versions of OptionIQ, found and installed from inside the app.

The owner keeps three files in a shared OneDrive folder: `latest.json` (the
newest version number, what's new, and a link plus SHA-256 for each zip),
`OptionIQ.zip` and `OptionIQ for Mac.zip`. The link to latest.json is built
into the app (brand.UPDATE_URL).

At most once a day the app reads latest.json. When it names a newer version,
the page offers it. If the person clicks Update now, the app backs up their
data, downloads the zip, checks its SHA-256, unpacks the program files into
Settings/update/staged-<time>, and starts a small helper that waits for the app to
close, copies them over the old ones and starts the app again. "My Data" and
"Settings" are never in the zip and never touched, so nothing is asked again.

Only the shareable (portable) build updates itself.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

from tracker import brand, config

CHECK_EVERY = 6 * 3600
# The first check after the app starts always asks GitHub, so a new version
# shows up on the next start instead of up to a day later.
_checked_this_run = False
APP_DIR = Path(__file__).resolve().parent.parent           # <their folder>/app
# What an update may replace, relative to the folder the person unzipped into.
ALLOWED_TOP = ("app/", "Start OptionIQ.bat", "Start OptionIQ.command", "README.md",
               "READ ME FIRST.txt")

state = {"state": "idle", "error": "", "done": 0, "total": 0}
_lock = threading.Lock()


# ---- versions ----------------------------------------------------------------
def parse_version(v) -> tuple:
    out = []
    for part in str(v or "").strip().lstrip("vV").split("."):
        digits = "".join(c for c in part if c.isdigit())
        out.append(int(digits) if digits else 0)
    while len(out) < 3:
        out.append(0)
    return tuple(out)


def newer(latest, current=None) -> bool:
    return parse_version(latest) > parse_version(current or brand.VERSION)


def notes_since(latest: dict, current=None) -> str:
    """What's new, only for the versions newer than the one running.
    latest.json may carry "history": [{"version", "notes"}, ...] (newest first);
    older apps only read "notes", so that stays short (the newest release)."""
    current = current or brand.VERSION
    history = latest.get("history")
    if isinstance(history, list) and history:
        parts = [str(h.get("notes", "")).strip() for h in history
                 if isinstance(h, dict) and newer(h.get("version"), current)]
        return "\n\n".join(p for p in parts if p)
    # Plain "notes": drop the paragraphs headed "New in 1.4:" etc. for versions
    # the user already has; paragraphs without a version stay.
    keep = []
    for block in str(latest.get("notes", "")).split("\n\n"):
        head = block.strip().split("\n", 1)[0]
        if " in " in head and head.rstrip().endswith(":"):
            ver = head.rstrip()[:-1].rsplit(" in ", 1)[1]
            if ver[:1].isdigit() and not newer(ver, current):
                continue
        keep.append(block)
    return "\n\n".join(keep).strip()


def platform_key() -> str:
    return "mac" if sys.platform == "darwin" else "windows"


def enabled() -> bool:
    return bool(brand.UPDATE_URL) and config.PORTABLE_ROOT is not None


# ---- downloads from a OneDrive (or any) share link ------------------------------
def candidate_urls(link: str) -> list[str]:
    """A share link opens a web page; these are the ways to get the file itself.
    Tried in order until one gives the real file."""
    link = link.strip()
    urls = []
    host = urllib.parse.urlparse(link).netloc.lower()
    if any(h in host for h in ("1drv.ms", "onedrive.live.com", "sharepoint.com", "onedrive.com")):
        bare = link.split("?")[0]
        for form in dict.fromkeys([link, bare]):
            token = base64.urlsafe_b64encode(form.encode()).decode().rstrip("=")
            urls.append(f"https://api.onedrive.com/v1.0/shares/u!{token}/root/content")
        sep = "&" if "?" in link else "?"
        urls.append(link + sep + "download=1")
        urls.append(bare + "?download=1")
    elif "drive.google.com" in host:
        fid = ""
        parts = urllib.parse.urlparse(link)
        if "/d/" in parts.path:
            fid = parts.path.split("/d/")[1].split("/")[0]
        fid = fid or urllib.parse.parse_qs(parts.query).get("id", [""])[0]
        if fid:
            urls.append(f"https://drive.google.com/uc?export=download&id={fid}")
    elif "dropbox.com" in host:
        urls.append(link.replace("dl=0", "dl=1") if "dl=0" in link else link + ("&" if "?" in link else "?") + "dl=1")
    urls.append(link)
    return urls


def _get(url: str, timeout: float, progress=None) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": f"OptionIQ/{brand.VERSION}"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        total = int(r.headers.get("Content-Length") or 0)
        chunks, got = [], 0
        while True:
            block = r.read(256 * 1024)
            if not block:
                break
            chunks.append(block)
            got += len(block)
            if progress:
                progress(got, total)
        return b"".join(chunks)


def fetch(link: str, accept, timeout: float = 60, progress=None, getter=None) -> bytes:
    """Download a share link, trying each way in turn; `accept(data)` says
    whether what came back is the real file (not a sign-in or preview page)."""
    getter = getter or _get
    errors = []
    for url in candidate_urls(link):
        try:
            data = getter(url, timeout, progress)
        except Exception as exc:  # try the next way
            errors.append(f"{exc}")
            print(f"update download: {url[:80]} failed: {exc}", file=sys.stderr)
            continue
        if accept(data):
            print(f"update download: {url[:80]} ok ({len(data)} bytes)", file=sys.stderr)
            return data
        errors.append("what came back wasn't the right file")
        print(f"update download: {url[:80]} gave {data[:60]!r}", file=sys.stderr)
    raise RuntimeError("couldn't download it (" + "; ".join(errors[-2:]) + ")")


def _is_json(data: bytes) -> bool:
    try:
        return isinstance(json.loads(data.decode("utf-8-sig")), dict)
    except (ValueError, UnicodeDecodeError):
        return False


# ---- checking ------------------------------------------------------------------
def _cache_file() -> Path:
    return config.config_dir() / "update_check.json"


def _read_cache() -> dict:
    try:
        return json.loads(_cache_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def check(force: bool = False, getter=None) -> dict:
    """What the page shows. Reads latest.json once per start, then every few hours."""
    global _checked_this_run
    if not enabled():
        return {"enabled": False, "current": brand.VERSION}
    cache = _read_cache()
    latest = cache.get("latest")
    error = ""
    if force or not latest or not _checked_this_run or time.time() - cache.get("checkedAt", 0) > CHECK_EVERY:
        try:
            latest = json.loads(fetch(brand.UPDATE_URL, _is_json, timeout=20, getter=getter).decode("utf-8-sig"))
            cache = {"checkedAt": time.time(), "latest": latest}
            _checked_this_run = True
            config.config_dir().mkdir(parents=True, exist_ok=True)
            _cache_file().write_text(json.dumps(cache, indent=2), encoding="utf-8")
        except Exception as exc:
            error = str(exc)
            print(f"update check failed: {exc}", file=sys.stderr)
    latest = latest or {}
    pkg = latest.get(platform_key()) or {}
    with _lock:
        st = dict(state)
    return {
        "enabled": True,
        "current": brand.VERSION,
        "latest": latest.get("version"),
        "date": latest.get("date"),
        "notes": notes_since(latest),
        "available": bool(latest.get("version") and newer(latest["version"]) and pkg.get("url") and pkg.get("sha256")),
        "manualLink": pkg.get("url", ""),
        "checkError": error,
        "install": st,
    }


# ---- installing ----------------------------------------------------------------
def _staging() -> Path:
    """Log and helper script; kept with the person's Settings."""
    return config.config_dir() / "update"


def _unpack_dir() -> Path:
    """Where the new version is unpacked. Outside the OptionIQ folder on
    purpose: that folder is often in OneDrive, which grabs and locks freshly
    written files while it uploads them, and the copy then fails."""
    return Path(tempfile.gettempdir()) / "OptionIQ-update"


def _set(**kw) -> None:
    with _lock:
        state.update(kw)


def _clear(path: Path) -> None:
    """Remove a folder left by an earlier try. Windows refuses read-only files
    and files OneDrive is busy with, so clear the flag and retry a few times."""
    def writable(func, p, _exc):
        try:
            os.chmod(p, stat.S_IWRITE)
            func(p)
        except OSError:
            pass
    for _ in range(5):
        if not path.exists():
            return
        shutil.rmtree(path, onerror=writable)
        if path.exists():
            time.sleep(1)
    if path.exists():
        raise RuntimeError(f"couldn't clear the old update folder {path}")


def unpack(data: bytes, dest: Path, skip_python: bool = False) -> int:
    """Put the zip's program files in `dest`, laid out like the person's folder.
    The Mac zip has everything inside an `OptionIQ/` folder; the Windows one
    doesn't. Anything outside the program files is left out."""
    _clear(dest)
    dest.mkdir(parents=True)
    count = 0
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names = [n for n in z.namelist() if not n.endswith("/")]
        prefix = "OptionIQ/" if names and all(n.startswith("OptionIQ/") for n in names) else ""
        for info in z.infolist():
            name = info.filename
            if name.endswith("/") or not name.startswith(prefix):
                continue
            rel = name[len(prefix):]
            parts = rel.split("/")
            if ".." in parts or rel.startswith("/") or ":" in rel:
                continue
            if not (rel.startswith("app/") or rel in ALLOWED_TOP):
                continue
            # The bundled Python is the same in every version, and the Screener
            # keeps its files in use; copying it again is what made updates hang.
            if skip_python and rel.startswith("app/python/"):
                continue
            target = dest.joinpath(*parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            body = z.read(info)
            for attempt in range(5):
                try:
                    target.write_bytes(body)
                    break
                except PermissionError:
                    # OneDrive or antivirus can hold a brand-new file for a moment.
                    if attempt == 4:
                        raise
                    time.sleep(1)
            mode = (info.external_attr >> 16) & 0o777
            if mode and os.name != "nt":
                os.chmod(target, mode)
            count += 1
    if not (dest / "app" / "position_tracker.py").exists():
        raise RuntimeError("the download isn't an OptionIQ zip")
    return count


WINDOWS_HELPER = r"""
param([int]$AppPid, [string]$Src, [string]$Dst, [string]$Log)
$ErrorActionPreference = 'Continue'
# A small window so people can see the update is happening.
$form = $null; $label = $null
try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'OptionIQ'
    $form.Size = New-Object System.Drawing.Size(420, 150)
    $form.StartPosition = 'CenterScreen'
    $form.FormBorderStyle = 'FixedDialog'
    $form.ControlBox = $false
    $form.TopMost = $true
    $form.BackColor = [System.Drawing.Color]::FromArgb(17, 24, 39)
    $ico = Join-Path $Src 'app\web\app\brand\optioniq.ico'
    if (Test-Path $ico) { $form.Icon = New-Object System.Drawing.Icon($ico) }
    $label = New-Object System.Windows.Forms.Label
    $label.Dock = 'Fill'
    $label.TextAlign = 'MiddleCenter'
    $label.ForeColor = [System.Drawing.Color]::White
    $label.Font = New-Object System.Drawing.Font('Segoe UI', 11)
    $label.Text = "Updating OptionIQ...`nPlease wait, it will open again by itself."
    $form.Controls.Add($label)
    $form.Show()
    [System.Windows.Forms.Application]::DoEvents()
} catch { "$(Get-Date) no progress window: $_" | Out-File -Append $Log }
function Say([string]$t) {
    "$(Get-Date) $t" | Out-File -Append $Log
    if ($label) { $label.Text = $t; [System.Windows.Forms.Application]::DoEvents() }
}
function Pause-A-Little([int]$ms) {
    $end = (Get-Date).AddMilliseconds($ms)
    while ((Get-Date) -lt $end) { if ($form) { [System.Windows.Forms.Application]::DoEvents() }; Start-Sleep -Milliseconds 100 }
}
"$(Get-Date) waiting for OptionIQ ($AppPid) to close" | Out-File -Append $Log
for ($i = 0; $i -lt 600 -and (Get-Process -Id $AppPid -ErrorAction SilentlyContinue); $i++) { Pause-A-Little 100 }
# The Screener runs on the same bundled Python; stop it so its files can be replaced.
$py = Join-Path $Dst 'app\python'
Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path.StartsWith($py, [System.StringComparison]::OrdinalIgnoreCase) } |
    ForEach-Object { "$(Get-Date) stopping $($_.Name) ($($_.Id))" | Out-File -Append $Log; Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue }
Pause-A-Little 2000
Say "Updating OptionIQ...`nCopying the new version in."
$ok = $false
for ($i = 0; $i -lt 3 -and -not $ok; $i++) {
    robocopy "$Src" "$Dst" /E /IS /IT /R:5 /W:2 /NP /NFL /NDL /NJH /NJS | Out-File -Append $Log
    if ($LASTEXITCODE -lt 8) { $ok = $true } else { Pause-A-Little 3000 }
}
"$(Get-Date) copy finished, ok=$ok" | Out-File -Append $Log
Say "Starting OptionIQ..."
$exe = Join-Path $Dst 'app\python\pythonw.exe'
$p = Start-Process -FilePath $exe -ArgumentList '"app\position_tracker.py"','--portable' -WorkingDirectory $Dst -PassThru
"$(Get-Date) started $exe (pid $($p.Id))" | Out-File -Append $Log
Pause-A-Little 6000
if (-not (Get-Process -Id $p.Id -ErrorAction SilentlyContinue)) {
    "$(Get-Date) app exited early; trying Start OptionIQ.bat" | Out-File -Append $Log
    $bat = Join-Path $Dst 'Start OptionIQ.bat'
    if (Test-Path $bat) { Start-Process -FilePath $bat -WorkingDirectory $Dst -WindowStyle Hidden }
    Pause-A-Little 4000
}
if ($form) { $form.Close() }
"""

POSIX_HELPER = """#!/bin/sh
# OptionIQ update helper: wait for the app to close, copy the new files in, start again.
APP_PID="$1"; SRC="$2"; DST="$3"; LOG="$4"
echo "$(date) waiting for OptionIQ ($APP_PID) to close" >>"$LOG"
osascript -e 'display notification "Updating OptionIQ. It will open again by itself." with title "OptionIQ"' >/dev/null 2>&1
n=0
while kill -0 "$APP_PID" 2>/dev/null && [ $n -lt 60 ]; do sleep 1; n=$((n+1)); done
sleep 1
cp -Rp "$SRC/." "$DST/" >>"$LOG" 2>&1 && echo "$(date) copy finished" >>"$LOG" || echo "$(date) copy FAILED" >>"$LOG"
chmod +x "$DST/Start OptionIQ.command" 2>/dev/null
xattr -dr com.apple.quarantine "$DST/app" 2>/dev/null
cd "$DST" || exit 1
if [ -z "$SSL_CERT_FILE" ] && [ -f /etc/ssl/cert.pem ]; then export SSL_CERT_FILE=/etc/ssl/cert.pem; fi
nohup "$5" app/position_tracker.py --portable </dev/null >>"Settings/start.log" 2>&1 &
"""


def _launch_helper(staged: Path) -> None:
    root = config.PORTABLE_ROOT
    work = _staging()
    log = work / "update.log"
    if sys.platform == "win32":
        script = work / "apply_update.ps1"
        script.write_text(WINDOWS_HELPER, encoding="utf-8")
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        subprocess.Popen(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                          "-File", str(script), str(os.getpid()), str(staged), str(root), str(log)],
                         creationflags=flags, close_fds=True)
    else:
        script = work / "apply_update.sh"
        script.write_text(POSIX_HELPER, encoding="utf-8")
        os.chmod(script, 0o755)
        python = root / "app" / "python" / "bin" / "python3"
        subprocess.Popen(["/bin/sh", str(script), str(os.getpid()), str(staged), str(root), str(log),
                          str(python if python.exists() else sys.executable)],
                         start_new_session=True, close_fds=True,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def install(store, on_ready, getter=None) -> None:
    """Back up, download, check, unpack, then hand over to the helper and let
    `on_ready` close the app. Runs in the background; progress in `state`."""
    def run():
        try:
            # Ask again first: a version published since the banner appeared
            # replaces the zip, and the old checksum would no longer match.
            check(force=True, getter=getter)
            latest = (_read_cache().get("latest") or {})
            pkg = latest.get(platform_key()) or {}
            if not (pkg.get("url") and pkg.get("sha256") and newer(latest.get("version"))):
                raise RuntimeError("no newer version found; try Check for updates first")
            _set(state="backing-up", error="", done=0, total=0)
            if store.exists():
                store.backup()
            _set(state="downloading")
            want = pkg["sha256"].lower()
            data = fetch(pkg["url"], lambda d: hashlib.sha256(d).hexdigest() == want, timeout=300,
                         progress=lambda got, total: _set(done=got, total=total), getter=getter)
            _set(state="unpacking")
            work = _unpack_dir()
            work.mkdir(parents=True, exist_ok=True)
            # A fresh folder each time: an earlier try's folder may still be locked.
            for old in list(work.glob("staged*")) + list(_staging().glob("staged*")):
                try:
                    _clear(old)
                except RuntimeError:
                    pass
            staged = work / f"staged-{int(time.time())}"
            root = config.PORTABLE_ROOT
            unpack(data, staged, skip_python=bool(root and (Path(root) / "app" / "python").exists()))
            _set(state="restarting")
            _launch_helper(staged)
            on_ready()
        except Exception as exc:
            print(f"update failed: {exc}", file=sys.stderr)
            _set(state="failed", error=str(exc))

    with _lock:
        if state["state"] in ("backing-up", "downloading", "unpacking", "restarting"):
            return
        state.update(state="starting", error="")
    threading.Thread(target=run, daemon=True).start()


def status() -> dict:
    with _lock:
        return dict(state)


def cleanup() -> None:
    """Called at start: the helper has finished with the unpacked copy."""
    for staged in list(_staging().glob("staged*")) + list(_unpack_dir().glob("staged*")):
        try:
            _clear(staged)
        except RuntimeError:
            pass  # still locked; the next try uses a new folder anyway
