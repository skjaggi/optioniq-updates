"""Black-Scholes pricing, Greeks and implied volatility.

Pure standard library so the tracker runs on any Python 3.9+ install.
Conventions:
  * sigma and r are decimals (0.30 = 30%).
  * t is in years (calendar days / 365).
  * theta is per calendar day, vega and rho are per 1 percentage point.
"""
from __future__ import annotations

import math

SQRT_2PI = math.sqrt(2.0 * math.pi)


def norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def norm_pdf(x: float) -> float:
    return math.exp(-0.5 * x * x) / SQRT_2PI


def _d1_d2(s: float, k: float, t: float, r: float, sigma: float, q: float = 0.0):
    vol_t = sigma * math.sqrt(t)
    d1 = (math.log(s / k) + (r - q + 0.5 * sigma * sigma) * t) / vol_t
    return d1, d1 - vol_t


def price(s: float, k: float, t: float, r: float, sigma: float, is_call: bool, q: float = 0.0) -> float:
    """Theoretical option price per share."""
    if t <= 0 or sigma <= 0:
        return max(0.0, (s - k) if is_call else (k - s))
    d1, d2 = _d1_d2(s, k, t, r, sigma, q)
    if is_call:
        return s * math.exp(-q * t) * norm_cdf(d1) - k * math.exp(-r * t) * norm_cdf(d2)
    return k * math.exp(-r * t) * norm_cdf(-d2) - s * math.exp(-q * t) * norm_cdf(-d1)


def greeks(s: float, k: float, t: float, r: float, sigma: float, is_call: bool, q: float = 0.0) -> dict:
    """Per-share Greeks for one long option.

    At or past expiry the option is treated as intrinsic only: delta is 1/-1/0
    and the other Greeks are zero.
    """
    if t <= 0 or sigma <= 0:
        itm = (s > k) if is_call else (s < k)
        return {
            "price": price(s, k, 0, r, sigma, is_call, q),
            "delta": (1.0 if is_call else -1.0) if itm else 0.0,
            "gamma": 0.0, "theta": 0.0, "vega": 0.0, "rho": 0.0,
            "prob_itm": 1.0 if itm else 0.0,
        }
    d1, d2 = _d1_d2(s, k, t, r, sigma, q)
    disc_q = math.exp(-q * t)
    disc_r = math.exp(-r * t)
    pdf = norm_pdf(d1)
    sqrt_t = math.sqrt(t)
    gamma = disc_q * pdf / (s * sigma * sqrt_t)
    vega = s * disc_q * pdf * sqrt_t / 100.0
    common = -s * disc_q * pdf * sigma / (2.0 * sqrt_t)
    if is_call:
        delta = disc_q * norm_cdf(d1)
        theta = common - r * k * disc_r * norm_cdf(d2) + q * s * disc_q * norm_cdf(d1)
        rho = k * t * disc_r * norm_cdf(d2) / 100.0
        prob_itm = norm_cdf(d2)
    else:
        delta = -disc_q * norm_cdf(-d1)
        theta = common + r * k * disc_r * norm_cdf(-d2) - q * s * disc_q * norm_cdf(-d1)
        rho = -k * t * disc_r * norm_cdf(-d2) / 100.0
        prob_itm = norm_cdf(-d2)
    return {
        "price": price(s, k, t, r, sigma, is_call, q),
        "delta": delta,
        "gamma": gamma,
        "theta": theta / 365.0,
        "vega": vega,
        "rho": rho,
        "prob_itm": prob_itm,
    }


def implied_vol(market: float, s: float, k: float, t: float, r: float, is_call: bool,
                q: float = 0.0, lo: float = 0.001, hi: float = 5.0) -> float | None:
    """Solve for sigma by bisection. Returns None when the price is outside
    the no-arbitrage band (below intrinsic or above the underlying)."""
    if t <= 0 or market <= 0 or s <= 0 or k <= 0:
        return None
    if market < price(s, k, t, r, lo, is_call, q) - 1e-9 or market > price(s, k, t, r, hi, is_call, q):
        return None
    for _ in range(100):
        mid = 0.5 * (lo + hi)
        if price(s, k, t, r, mid, is_call, q) > market:
            hi = mid
        else:
            lo = mid
        if hi - lo < 1e-6:
            break
    return 0.5 * (lo + hi)
