"""An OptionIQ icon on the desktop, for starting the app each day.

Made once, the first time the shareable build starts in a folder (and again
if that folder is moved). If the person deletes the icon it stays deleted;
Settings -> About has a button to put it back. A second copy (say, a test
copy in another folder) leaves an icon that opens a different OptionIQ alone,
so starting a test copy never takes over the everyday icon.

Windows: a normal shortcut (OptionIQ.lnk) that starts the app with its own
Python, without the black Start window.
Mac: a small OptionIQ.app made inside the OptionIQ folder (made here, not
downloaded, so the Mac doesn't question it), with a link to it on the desktop.
"""
from __future__ import annotations

import os
import plistlib
import stat
import subprocess
import sys
from pathlib import Path

from . import brand, config

ICON_DIR = Path(__file__).resolve().parent.parent / "web" / "app" / "brand"

WINDOWS_PS = r"""
$desk = [Environment]::GetFolderPath('Desktop')
$root = $env:OIQ_ROOT
$s = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desk ($env:OIQ_NAME + '.lnk')))
$s.TargetPath = Join-Path $root 'app\python\pythonw.exe'
$s.Arguments = '"' + (Join-Path $root 'app\position_tracker.py') + '" --portable'
$s.WorkingDirectory = $root
$s.IconLocation = (Join-Path $root 'app\web\app\brand\optioniq.ico') + ',0'
$s.Description = 'Start ' + $env:OIQ_NAME
$s.Save()
[Console]::Out.Write($desk)
"""

READ_WINDOWS_PS = r"""
$lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) ($env:OIQ_NAME + '.lnk')
if (Test-Path -LiteralPath $lnk) {
    [Console]::Out.Write((New-Object -ComObject WScript.Shell).CreateShortcut($lnk).TargetPath)
}
"""

# Runs when the Mac icon is double-clicked: start OptionIQ the same way
# Start OptionIQ.command does, without a Terminal window. On the very first
# start (no Python yet) it hands over to Start OptionIQ.command, which shows
# its progress in Terminal.
MAC_LAUNCHER = """#!/bin/bash
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
cd "$ROOT" || exit 1
PY="app/python/bin/python3"
if [ ! -x "$PY" ] || [ ! -f app/position_tracker.py ]; then
    open -a Terminal "$ROOT/Start OptionIQ.command"
    exit 0
fi
if [ -z "$SSL_CERT_FILE" ] && [ -f /etc/ssl/cert.pem ]; then
    export SSL_CERT_FILE=/etc/ssl/cert.pem
fi
mkdir -p Settings
nohup "$PY" -c 'import os, sys; os.setsid(); os.execv(sys.argv[1], sys.argv[1:])' \\
    "$PY" app/position_tracker.py --portable </dev/null >>"Settings/start.log" 2>&1 &
exit 0
"""


def ensure(root: Path | None = None) -> None:
    """Make the desktop icon if it hasn't been made for this folder yet."""
    root = root or config.PORTABLE_ROOT
    if not root or sys.platform not in ("win32", "darwin"):
        return
    if config.read().get("desktopIconFor") == str(root):
        return
    try:
        other = icon_owner()
        if other and Path(other).resolve() != Path(root).resolve():
            print(f"Desktop icon: left alone, it opens the OptionIQ in {other}")
            return
        print(f"Desktop icon: {make(root)}")
    except Exception as exc:  # never stop the app over this
        print(f"Desktop icon: couldn't make it ({exc})")


def make(root: Path | None = None) -> str:
    """Put the icon on the desktop now (replacing an old one). Returns where."""
    root = root or config.PORTABLE_ROOT
    if not root:
        raise ValueError("The desktop icon is only for the shareable OptionIQ folder")
    root = Path(root)
    if sys.platform == "win32":
        where = _make_windows(root)
    elif sys.platform == "darwin":
        where = _make_mac(root)
    else:
        raise ValueError("A desktop icon can only be made on Windows or a Mac")
    cfg = config.read()
    cfg["desktopIconFor"] = str(root)
    config.write(cfg)
    return where


def icon_owner() -> str | None:
    """The OptionIQ folder the desktop icon opens now, if that folder is still there."""
    if sys.platform == "win32":
        try:
            out = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", READ_WINDOWS_PS],
                capture_output=True, text=True, timeout=60, env=dict(os.environ, OIQ_NAME=brand.APP_NAME),
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except (OSError, subprocess.SubprocessError):
            return None
        target = out.stdout.strip()
        if out.returncode != 0 or not target:
            return None
        folder = Path(target).parent.parent.parent  # <folder>\app\python\pythonw.exe
    elif sys.platform == "darwin":
        link = Path.home() / "Desktop" / brand.APP_NAME
        if not link.is_symlink():
            return None
        folder = Path(os.readlink(link)).parent  # <folder>/OptionIQ.app
    else:
        return None
    if not (folder / "app" / "position_tracker.py").is_file():
        return None  # that copy was deleted: the icon is free to take over
    return str(folder)


def _make_windows(root: Path) -> str:
    env = dict(os.environ, OIQ_ROOT=str(root), OIQ_NAME=brand.APP_NAME)
    out = subprocess.run(
        ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", WINDOWS_PS],
        capture_output=True, text=True, timeout=60, env=env,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if out.returncode != 0:
        raise OSError((out.stderr or "PowerShell failed").strip().splitlines()[-1])
    return str(Path(out.stdout.strip()) / f"{brand.APP_NAME}.lnk")


def mac_app(root: Path) -> Path:
    """Build <root>/OptionIQ.app: a launcher with the OptionIQ icon."""
    app = root / f"{brand.APP_NAME}.app"
    (app / "Contents" / "MacOS").mkdir(parents=True, exist_ok=True)
    (app / "Contents" / "Resources").mkdir(parents=True, exist_ok=True)
    info = {
        "CFBundleName": brand.APP_NAME,
        "CFBundleDisplayName": brand.APP_NAME,
        "CFBundleIdentifier": "com.quantumnexus.optioniq.launcher",
        "CFBundleExecutable": brand.APP_NAME,
        "CFBundleIconFile": "OptionIQ",
        "CFBundlePackageType": "APPL",
        "CFBundleShortVersionString": brand.VERSION,
        "LSUIElement": True,
        "NSHumanReadableCopyright": f"© {brand.YEAR} {brand.OWNER}",
    }
    with open(app / "Contents" / "Info.plist", "wb") as fh:
        plistlib.dump(info, fh)
    exe = app / "Contents" / "MacOS" / brand.APP_NAME
    exe.write_text(MAC_LAUNCHER, encoding="utf-8")
    exe.chmod(exe.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    (app / "Contents" / "Resources" / "OptionIQ.icns").write_bytes((ICON_DIR / "optioniq.icns").read_bytes())
    os.utime(app)  # so Finder picks up the icon
    return app


def _make_mac(root: Path) -> str:
    app = mac_app(root)
    link = Path.home() / "Desktop" / brand.APP_NAME
    if link.is_symlink() or link.exists():
        if not link.is_symlink():
            raise OSError(f"There is already something called {link.name} on the desktop")
        link.unlink()
    link.symlink_to(app)
    return str(link)
