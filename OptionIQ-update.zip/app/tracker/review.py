"""🧭 Portfolio Review: the parts that need the computer rather than the page.

  * the latest 30-day implied volatility and closing price of every ticker,
    from the Screener's daily history (Settings/iv_history.sqlite);
  * saving the review's Excel file, and a JSON copy of what it was worked
    out from, into My Data/Portfolio Reviews (or a folder the person picks).

The review itself is worked out in the page (web/app/portfolio_review_engine.js).
"""
from __future__ import annotations

import base64
import json
import os
import re
import sqlite3
import subprocess
import sys
from pathlib import Path

FOLDER_NAME = "Portfolio Reviews"
_SAFE = re.compile(r"^[A-Za-z0-9 _().\-]+\.(xlsx|json)$")


def latest_iv(db: Path) -> dict:
    """{SYMBOL: {iv30, close, date}} from each ticker's newest day."""
    if not db.is_file():
        return {}
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
    try:
        rows = con.execute(
            "SELECT symbol, date, iv30, close FROM iv i "
            "WHERE date = (SELECT MAX(date) FROM iv j WHERE j.symbol = i.symbol)").fetchall()
    except sqlite3.Error:
        return {}
    finally:
        con.close()
    return {s: {"iv30": v, "close": c, "date": d} for s, d, v, c in rows}


def folder(data_dir: Path, chosen: str | None) -> Path:
    """The chosen folder if it is a full path, otherwise My Data/Portfolio Reviews."""
    if chosen and str(chosen).strip():
        p = Path(str(chosen).strip().strip('"')).expanduser()
        if p.is_absolute():
            return p
    return Path(data_dir) / FOLDER_NAME


def save(data_dir: Path, body: dict) -> dict:
    """Write the Excel file (base64) and the inputs JSON; returns where."""
    target = folder(data_dir, body.get("folder"))
    target.mkdir(parents=True, exist_ok=True)
    out = {"folder": str(target), "files": []}
    for name_key, kind in (("xlsxName", "xlsx"), ("jsonName", "json")):
        name = str(body.get(name_key) or "")
        if not name:
            continue
        if not _SAFE.match(name) or not name.endswith("." + kind):
            raise ValueError(f"Not a usable file name: {name}")
        path = target / name
        if kind == "xlsx":
            path.write_bytes(base64.b64decode(body.get("xlsx") or ""))
        else:
            path.write_text(json.dumps(body.get("inputs") or {}, indent=1), encoding="utf-8")
        out["files"].append(str(path))
    return out


def open_folder(data_dir: Path, chosen: str | None) -> str:
    target = folder(data_dir, chosen)
    target.mkdir(parents=True, exist_ok=True)
    if sys.platform == "win32":
        os.startfile(str(target))  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(target)])
    else:
        subprocess.Popen(["xdg-open", str(target)])
    return str(target)
