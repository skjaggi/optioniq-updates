"""Where the tracker keeps its data.

A tiny pointer file in the user's app-settings folder remembers which folder
holds the data, so the data itself can live anywhere: Documents, OneDrive,
Google Drive, Dropbox or a USB drive.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

APP_DIR_NAME = "OptionIQ"
DATA_DIR_NAME = "OptionIQ Data"
DATA_FILE = "tracker_data.json"

# Portable mode (the shareable zip): settings and data live inside the folder
# the user unzipped into, so the whole folder can be moved or copied as one.
PORTABLE_ROOT: Path | None = None


def set_portable(root: Path) -> None:
    global PORTABLE_ROOT
    PORTABLE_ROOT = Path(root).resolve()


def config_dir() -> Path:
    override = os.environ.get("OPT_TRACKER_CONFIG_DIR")
    if override:
        return Path(override)
    if PORTABLE_ROOT:
        return PORTABLE_ROOT / "Settings"
    if sys.platform == "win32":
        return Path(os.environ.get("APPDATA", Path.home())) / APP_DIR_NAME
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / APP_DIR_NAME
    return Path.home() / ".config" / "options-position-tracker"


def _config_file() -> Path:
    return config_dir() / "config.json"


def read() -> dict:
    try:
        return json.loads(_config_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def write(cfg: dict) -> None:
    path = _config_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")


def default_data_dir() -> Path:
    if PORTABLE_ROOT:
        return PORTABLE_ROOT / "My Data"
    return Path.home() / "Documents" / DATA_DIR_NAME


def saved_data_file() -> Path | None:
    d = read().get("dataDir")
    if not d:
        return None
    p = Path(d)
    if not p.is_absolute() and PORTABLE_ROOT:
        p = PORTABLE_ROOT / p
    return p / DATA_FILE


def remember_data_dir(folder: Path) -> None:
    """Folders inside the portable folder are saved as relative paths, so the
    tracker still finds its data after the whole folder is moved."""
    folder = Path(folder)
    if PORTABLE_ROOT:
        try:
            folder = folder.resolve().relative_to(PORTABLE_ROOT)
        except ValueError:
            pass
    cfg = read()
    cfg["dataDir"] = str(folder)
    write(cfg)


# ---- price-data keys --------------------------------------------------
# Each person's own keys, kept with this installation's settings (never in
# the data file, never shipped with the app).
KEY_NAMES = ("finnhub",)


def get_keys() -> dict:
    keys = read().get("apiKeys") or {}
    return {k: keys.get(k, "") for k in KEY_NAMES}


def set_keys(changes: dict) -> dict:
    cfg = read()
    keys = cfg.get("apiKeys") or {}
    for k in KEY_NAMES:
        if k in changes:
            keys[k] = str(changes[k] or "").strip()
    cfg["apiKeys"] = keys
    write(cfg)
    return get_keys()


def masked(key: str) -> str:
    return "" if not key else ("•" * 6 + key[-4:] if len(key) > 4 else "•" * len(key))


def suggested_locations() -> list[dict]:
    """Folders worth offering during setup: this computer's Documents folder,
    plus any cloud-drive folders that are installed on this machine."""
    home = Path.home()
    if PORTABLE_ROOT:
        out = [{"kind": "local", "label": "Inside the tracker's own folder (recommended)",
                "path": str(default_data_dir())}]
    else:
        out = [{"kind": "local", "label": "This computer (Documents folder)",
                "path": str(default_data_dir())}]
    candidates = [
        ("OneDrive", [os.environ.get("OneDrive"), os.environ.get("OneDriveConsumer"), home / "OneDrive"]),
        ("Google Drive", [Path("G:/My Drive"), home / "My Drive", home / "Google Drive", home / "Google Drive" / "My Drive"]),
        ("Dropbox", [home / "Dropbox"]),
        ("iCloud Drive", [home / "iCloudDrive", home / "Library" / "Mobile Documents" / "com~apple~CloudDocs"]),
        ("Box", [home / "Box"]),
    ]
    # Newer Macs keep cloud drives in ~/Library/CloudStorage/<Name>-<account>.
    cloud = home / "Library" / "CloudStorage"
    if cloud.is_dir():
        by_name = dict(candidates)
        for name, prefix, sub in (("OneDrive", "OneDrive", ""), ("Google Drive", "GoogleDrive", "My Drive"),
                                  ("Dropbox", "Dropbox", ""), ("Box", "Box", "")):
            for d in sorted(cloud.glob(prefix + "*")):
                by_name[name].insert(0, d / sub if sub else d)
    for name, paths in candidates:
        for p in paths:
            if p and Path(p).is_dir():
                out.append({"kind": "cloud", "label": name, "path": str(Path(p) / DATA_DIR_NAME)})
                break
    return out
