"""Storage for the Options Trade Logger screens.

The logger was written for a browser and keeps everything in localStorage
(trades, stocks, watchlist, screener settings...). In the desktop app a small
shim in the page sends those same keys here instead, and they are saved in
one JSON file in the user's data folder:

    {"version": 2, "settings": {...}, "kv": {"options_trades_v3": "<json>", ...},
     "createdAt": "...", "lastBackupAt": "..."}

Values are kept exactly as the page wrote them (strings), so the logger's own
code reads back precisely what it stored.
"""
from __future__ import annotations

import json
import os
import threading
import time
from datetime import date, datetime, timezone
from pathlib import Path

TRADES_KEY = "options_trades_v3"
STOCKS_KEY = "stock_holdings_v1"
WATCHLIST_KEY = "watchlist_v1"
EXCLUDED_KEY = "excluded_v1"
# Never stored in the data file: each person's price key lives with this
# installation's settings (see config.get_keys).
SECRET_KEYS = {"finnhub_key"}

DEFAULT_SETTINGS = {
    "accounts": [],
    "setupDone": False,
    "reminderDays": 7,
    "desktopNotifications": True,
}

_lock = threading.RLock()


def _now() -> str:
    return datetime.now().isoformat(timespec="minutes")


def clean_account_name(name) -> str:
    name = " ".join(str(name or "").split())
    if not name:
        raise ValueError("Each account needs a name")
    if len(name) > 40:
        raise ValueError("Keep account names to 40 characters or fewer")
    return name


# OneDrive, iDrive, antivirus and other sync/backup programs open the data
# file for a moment right after each save. While they hold it Windows refuses
# to swap the new copy in ("Access is denied"), so keep trying for a few
# seconds before giving up.
REPLACE_WAITS = (0.05, 0.1, 0.2, 0.3, 0.5, 0.75, 1, 1.5, 2)


def replace_file(src: Path, dst: Path) -> None:
    for wait in REPLACE_WAITS:
        try:
            os.replace(src, dst)
            return
        except PermissionError:
            time.sleep(wait)
    try:
        os.replace(src, dst)
    except PermissionError as exc:
        raise PermissionError(exc.errno, "Your data file is being used by another program "
                              "(OneDrive, iDrive or similar). Please try again in a moment",
                              str(dst)) from exc


class KVStore:
    def __init__(self, path: Path):
        self.path = Path(path)

    def relocate(self, path: Path) -> None:
        with _lock:
            self.path = Path(path)

    def exists(self) -> bool:
        return self.path.exists()

    # ---- file io -------------------------------------------------------
    def load(self) -> dict:
        with _lock:
            if self.path.exists():
                with open(self.path, encoding="utf-8") as fh:
                    state = json.load(fh)
            else:
                state = {}
        state.setdefault("version", 2)
        state["settings"] = {**DEFAULT_SETTINGS, **state.get("settings", {})}
        state.setdefault("kv", {})
        state.setdefault("notified", {})
        state.setdefault("createdAt", _now())
        return state

    def save(self, state: dict) -> None:
        with _lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(state, fh, indent=1)
            replace_file(tmp, self.path)

    # ---- the page's key/value storage ---------------------------------
    def all_items(self) -> dict:
        return dict(self.load()["kv"])

    def set_item(self, key: str, value) -> list:
        """Store one key (None removes it). Returns any account names found in
        the saved trades or stocks that weren't known yet; they are added to
        the account list so imported data never disappears from view."""
        if key in SECRET_KEYS:
            raise ValueError("price keys are stored with the settings, not the data")
        with _lock:
            state = self.load()
            if value is None:
                state["kv"].pop(key, None)
            else:
                state["kv"][key] = str(value)
            added = []
            if key in (TRADES_KEY, STOCKS_KEY) and value is not None:
                added = self._adopt_accounts(state, value)
            self.save(state)
        return added

    @staticmethod
    def _adopt_accounts(state: dict, raw: str) -> list:
        try:
            rows = json.loads(raw)
        except ValueError:
            return []
        known = state["settings"]["accounts"]
        added = []
        for r in rows if isinstance(rows, list) else []:
            a = (r or {}).get("account") if isinstance(r, dict) else None
            if a and a not in known:
                known.append(a)
                added.append(a)
        return added

    def rows(self, key: str) -> list:
        try:
            v = json.loads(self.load()["kv"].get(key) or "[]")
            return v if isinstance(v, list) else []
        except ValueError:
            return []

    # ---- settings ------------------------------------------------------
    def update_settings(self, changes: dict) -> dict:
        with _lock:
            state = self.load()
            for k in ("reminderDays", "desktopNotifications"):
                if k in changes:
                    state["settings"][k] = changes[k]
            self.save(state)
            return state["settings"]

    def accept_terms(self, version: str) -> None:
        with _lock:
            state = self.load()
            state["settings"]["termsAccepted"] = {"version": version, "at": _now()}
            self.save(state)

    def finish_setup(self, accounts: list) -> dict:
        names = []
        for a in accounts:
            a = clean_account_name(a)
            if a.lower() in (n.lower() for n in names):
                raise ValueError(f"Two accounts are both called {a}. Give each a different name.")
            names.append(a)
        if not names:
            raise ValueError("Add at least one account")
        with _lock:
            state = self.load()
            state["settings"]["accounts"] = names
            state["settings"]["setupDone"] = True
            self.save(state)
            return state["settings"]

    # ---- accounts ------------------------------------------------------
    def _usage(self, state: dict) -> dict:
        counts = {}
        for key in (TRADES_KEY, STOCKS_KEY):
            try:
                rows = json.loads(state["kv"].get(key) or "[]")
            except ValueError:
                rows = []
            for r in rows:
                a = r.get("account") if isinstance(r, dict) else None
                counts[a] = counts.get(a, 0) + 1
        return counts

    def account_usage(self) -> dict:
        return self._usage(self.load())

    def add_account(self, name: str) -> list:
        name = clean_account_name(name)
        with _lock:
            state = self.load()
            accounts = state["settings"]["accounts"]
            if name.lower() in (a.lower() for a in accounts):
                raise ValueError(f"You already have an account called {name}")
            accounts.append(name)
            self.save(state)
            return accounts

    def rename_account(self, old: str, new: str) -> list:
        new = clean_account_name(new)
        with _lock:
            state = self.load()
            accounts = state["settings"]["accounts"]
            if old not in accounts:
                raise ValueError(f"No account called {old}")
            if new != old and new.lower() in (a.lower() for a in accounts):
                raise ValueError(f"You already have an account called {new}")
            accounts[accounts.index(old)] = new
            for key in (TRADES_KEY, STOCKS_KEY):
                raw = state["kv"].get(key)
                if not raw:
                    continue
                rows = json.loads(raw)
                for r in rows:
                    if isinstance(r, dict) and r.get("account") == old:
                        r["account"] = new
                state["kv"][key] = json.dumps(rows)
            self.save(state)
            return accounts

    def remove_account(self, name: str) -> list:
        with _lock:
            state = self.load()
            n = self._usage(state).get(name, 0)
            if n:
                raise ValueError(f"{name} still has {n} trade{'s' if n > 1 else ''} or holding{'s' if n > 1 else ''}. "
                                 "Move or delete them first.")
            state["settings"]["accounts"] = [a for a in state["settings"]["accounts"] if a != name]
            self.save(state)
            return state["settings"]["accounts"]

    # ---- backups -------------------------------------------------------
    def logger_backup(self) -> dict:
        """The same JSON the logger's Save Data button produces (version 4),
        so a backup can be loaded back into either app."""
        kv = self.load()["kv"]

        def j(key, default):
            try:
                return json.loads(kv.get(key) or "null") or default
            except ValueError:
                return default
        return {"version": 4, "exportedAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
                "trades": j(TRADES_KEY, []), "stocks": j(STOCKS_KEY, []),
                "watchlist": j(WATCHLIST_KEY, {}), "excluded": j(EXCLUDED_KEY, [])}

    def backup(self, content: str | None = None, keep: int = 30) -> dict:
        """Write options_trades_backup_<date>.json into the Backups folder next
        to the data. `content` is what the page's Save Data button built; if
        not given, the same thing is built here."""
        if content is None:
            content = json.dumps(self.logger_backup(), indent=2)
        else:
            json.loads(content)  # refuse anything that isn't JSON
        folder = self.path.parent / "Backups"
        folder.mkdir(parents=True, exist_ok=True)
        target = folder / f"options_trades_backup_{date.today().isoformat()}.json"
        target.write_text(content, encoding="utf-8")
        for f in sorted(folder.glob("options_trades_backup_*.json"))[:-keep]:
            f.unlink()
        with _lock:
            state = self.load()
            state["lastBackupAt"] = _now()
            self.save(state)
        return {"file": str(target), "at": state["lastBackupAt"]}


# ---- reminders ------------------------------------------------------------
def _days_since(stamp, today: date):
    try:
        return (today - date.fromisoformat(str(stamp)[:10])).days
    except (TypeError, ValueError):
        return None


def status(state: dict, today: date) -> dict:
    """What the reminder panel shows: open options expiring soon (or already
    past expiry but still marked Open) and whether a backup is due."""
    window = int(state["settings"].get("reminderDays") or 7)
    try:
        trades = json.loads(state["kv"].get(TRADES_KEY) or "[]")
    except ValueError:
        trades = []
    expiring = []
    for t in trades:
        if not isinstance(t, dict) or t.get("action") != "Open" or t.get("closeDate"):
            continue
        try:
            dte = (date.fromisoformat(str(t.get("expDate"))[:10]) - today).days  # days until expiry
        except ValueError:
            continue
        if dte <= window:
            expiring.append({"ticker": t.get("ticker"), "strike": t.get("strike"), "cp": t.get("cp"),
                             "sb": t.get("sb"), "expDate": t.get("expDate"), "dte": dte,
                             "contracts": t.get("contracts"), "account": t.get("account"),
                             "currentStock": t.get("currentStock")})
    expiring.sort(key=lambda r: (r["dte"], r["ticker"] or ""))
    last = state.get("lastBackupAt")
    age = _days_since(last or state.get("createdAt"), today)
    has_data = bool(trades) or bool(state["kv"].get(STOCKS_KEY, "[]") not in ("[]", ""))
    return {
        "today": today.isoformat(),
        "reminderDays": window,
        "expiring": [r for r in expiring if r["dte"] >= 0],
        "pastExpiry": [r for r in expiring if r["dte"] < 0],
        "lastBackupAt": last,
        "daysSinceBackup": _days_since(last, today) if last else None,
        "backupDue": has_data and age is not None and age >= 7,
    }
