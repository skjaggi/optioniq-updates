"""Checking a price key. The Options Trade Logger screens fetch prices
themselves; the service only needs this to test a newly entered key."""
from __future__ import annotations

import json
import urllib.parse
import urllib.request


def finnhub_price(ticker: str, key: str, timeout: float = 10.0) -> float:
    """Current price from Finnhub's free quote endpoint (needs the user's own key)."""
    url = ("https://finnhub.io/api/v1/quote?symbol=" + urllib.parse.quote(ticker)
           + "&token=" + urllib.parse.quote(key))
    req = urllib.request.Request(url, headers={"User-Agent": "OptionIQ"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        payload = json.load(resp)
    px = payload.get("c")
    if not px:
        raise ValueError(f"No Finnhub price for {ticker}")
    return float(px)
